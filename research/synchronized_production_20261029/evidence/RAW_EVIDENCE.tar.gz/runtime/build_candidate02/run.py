from pathlib import Path
import subprocess,json,hashlib,os,time,signal,datetime,resource,shutil
r=Path('/workspace/scratch/f9615df1ce94');rt=r/'runtime';repo=r/'vigilode';out=rt/'build_candidate02';out.mkdir(exist_ok=True);dest=rt/'candidate02';dest.mkdir(exist_ok=True)
names=['rust_allocation_probe','ownership_projection_probe','production_from_json']
cmd=['cargo','build','--profile','measurement','--locked','--offline','-p','vigilode']
for n in names:cmd+=['--example',n]
env=os.environ.copy();env.update(PATH=str(rt/'rust/bin')+':'+env['PATH'],CARGO_HOME=str(rt/'cargo-home'),CARGO_TARGET_DIR=str(rt/'target-candidate-fresh'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def hashes():return {str(p.relative_to(repo)):h(p) for p in [repo/'Cargo.lock',repo/'Cargo.toml',*sorted((repo/'crates').rglob('*.rs')),*sorted((repo/'crates').rglob('Cargo.toml'))]}
def blobsha(s,p):return hashlib.sha256(subprocess.check_output(['git','show',s+':'+p],cwd=repo)).hexdigest()
source=git('rev-parse','HEAD');assert source=='ef84aa3d6c028b0922bb5c1e66202b95fd88a2fc',source
before=hashes();(out/'source_hashes_before.json').write_text(json.dumps(before,indent=2)+'\n');before_cpu=resource.getrusage(resource.RUSAGE_CHILDREN);t0=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat();timeout=False
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timeout=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
wall=time.monotonic()-t0;after_cpu=resource.getrusage(resource.RUSAGE_CHILDREN);after=hashes();(out/'source_hashes_after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'purpose':'compile_only_no_scientific_execution','argv':cmd,'cwd':str(repo),'source':source,'tree':git('rev-parse',source+'^{tree}'),'head_after':git('rev-parse','HEAD'),'started_at_utc':start,'exit_code':code,'wall_seconds':wall,'child_user_seconds':after_cpu.ru_utime-before_cpu.ru_utime,'child_system_seconds':after_cpu.ru_stime-before_cpu.ru_stime,'timeout_seconds':900,'timed_out':timeout,'source_file_hashes_unchanged':before==after,'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']},'logs':{n:{'bytes':(out/n).stat().st_size,'sha256':h(out/n)} for n in ['stdout.log','stderr.log','source_hashes_before.json','source_hashes_after.json']}}
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
if code==0 and before==after:
 compiler={'version_verbose':subprocess.check_output([str(rt/'rust/bin/rustc'),'-Vv'],text=True),'rustc_binary_sha256':h(rt/'rust/bin/rustc'),'cargo_version':subprocess.check_output([str(rt/'rust/bin/cargo'),'-V'],text=True),'cargo_binary_sha256':h(rt/'rust/bin/cargo')}
 bindings={}
 for name in names:
  binary=rt/'target-candidate-fresh/measurement/examples'/name;copied=dest/name;shutil.copy2(binary,copied);probe='crates/vigilode/examples/'+name+'.rs'
  bindings[name]={'source':source,'source_tree':receipt['tree'],'binary':str(copied),'binary_sha256':h(copied),'binary_bytes':copied.stat().st_size,'build_receipt':str(out/'RECEIPT.json'),'build_receipt_sha256':h(out/'RECEIPT.json'),'native_source_identity':{'crates_git_tree':git('rev-parse',source+':crates'),'cargo_lock_blob':git('rev-parse',source+':Cargo.lock'),'cargo_lock_sha256':blobsha(source,'Cargo.lock'),'workspace_manifest_blob':git('rev-parse',source+':Cargo.toml'),'probe_source_path':probe,'probe_source_blob':git('rev-parse',source+':'+probe),'probe_source_sha256':blobsha(source,probe),'snapshot_manifest':str(out/'source_hashes_before.json'),'snapshot_manifest_sha256':h(out/'source_hashes_before.json'),'unchanged_during_build':before==after},'compiler':compiler,'execution':'not_run'}
 (dest/'BINDINGS.json').write_text(json.dumps(bindings,indent=2)+'\n');print(json.dumps({'candidate_bindings':str(dest/'BINDINGS.json'),'sha256':h(dest/'BINDINGS.json'),'binary_hashes':{n:b['binary_sha256'] for n,b in bindings.items()}}))
