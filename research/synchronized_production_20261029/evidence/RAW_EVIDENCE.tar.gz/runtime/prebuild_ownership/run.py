import subprocess,pathlib,hashlib,json,time,os,signal,datetime
r=pathlib.Path('/workspace/scratch/f9615df1ce94'); repo=r/'vigilode-baseline'; out=r/'runtime/prebuild_ownership'; out.mkdir(exist_ok=True); env=os.environ.copy()
env.update(PATH=str(r/'runtime/rust/bin')+':'+env['PATH'],CARGO_HOME=str(r/'runtime/cargo-home'),CARGO_TARGET_DIR=str(r/'runtime/target'),CARGO_BUILD_JOBS='2',RAYON_NUM_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
cmd=['cargo','build','--profile','measurement','--locked','--offline','-p','vigilode','--example','ownership_projection_probe']
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def hashes():return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [repo/'Cargo.lock',repo/'Cargo.toml',*sorted((repo/'crates').rglob('*.rs')),*sorted((repo/'crates').rglob('Cargo.toml'))]}
before=hashes();(out/'source_hashes_before.json').write_text(json.dumps(before,indent=2)+'\n'); source=git('rev-parse','HEAD');assert source=='d37e3b2d2c418ca425a0ceed5e930caffd5bb771',source
t0=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat(); timed_out=False
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
 p=subprocess.Popen(cmd,cwd=repo,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:
  timed_out=True;os.killpg(p.pid,signal.SIGTERM)
  try:code=p.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);code=p.wait()
elapsed=time.monotonic()-t0;after=hashes();(out/'source_hashes_after.json').write_text(json.dumps(after,indent=2)+'\n')
receipt={'purpose':'compile_only_no_scientific_execution','argv':cmd,'cwd':str(repo),'source':source,'tree':git('rev-parse',source+'^{tree}'),'head_after':git('rev-parse','HEAD'),'started_at_utc':start,'exit_code':code,'wall_seconds':elapsed,'timeout_seconds':900,'timed_out':timed_out,'source_file_hashes_unchanged':before==after,'environment':{k:env[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','RAYON_NUM_THREADS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS']},'logs':{x:{'bytes':(out/x).stat().st_size,'sha256':hashlib.sha256((out/x).read_bytes()).hexdigest()} for x in ['stdout.log','stderr.log','source_hashes_before.json','source_hashes_after.json']},'binaries':[line.strip() for line in (out/'stderr.log').read_text().splitlines() if 'Executable ' in line]}
(out/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))

if code == 0 and before == after:
 import shutil
 binary=r/'runtime/target/measurement/examples/ownership_projection_probe';dest=r/'runtime/baseline';dest.mkdir(exist_ok=True);shutil.copy2(binary,dest/'ownership_projection_probe')
 identity={'source':source,'native_hashes_unchanged':before==after,'binary':str(dest/'ownership_projection_probe'),'bytes':binary.stat().st_size,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'build_receipt':str(out/'RECEIPT.json'),'execution':'not_run'}
 (dest/'OWNERSHIP_IDENTITY.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity))
