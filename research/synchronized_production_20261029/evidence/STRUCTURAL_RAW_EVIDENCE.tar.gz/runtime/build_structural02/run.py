#!/usr/bin/env python3
"""Compile-only preparation for the published structural quadratic experiment.

This script never executes a solver example or test executable. Its wall and CPU
costs are retained separately from the source-bound scientific campaign.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import shutil
import signal
import subprocess
import time


ROOT = Path('/workspace/scratch/f9615df1ce94')
RUNTIME = ROOT / 'runtime'
REPO = ROOT / 'vigilode'
OUT = RUNTIME / 'build_structural02'
DEST = RUNTIME / 'structural02'
REMOTE_REF = 'origin/research/synchronized-production-20261029'
NAME = 'structural_quadratic_probe'


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True, timeout=30).strip()


def source_hashes() -> dict[str, str]:
    paths = [REPO / 'Cargo.lock', REPO / 'Cargo.toml']
    paths += sorted((REPO / 'crates').rglob('*.rs'))
    paths += sorted((REPO / 'crates').rglob('Cargo.toml'))
    return {str(path.relative_to(REPO)): digest(path) for path in paths}


def assert_source(source: str) -> None:
    if git('rev-parse', 'HEAD') != source or git('rev-parse', REMOTE_REF) != source:
        raise ValueError('HEAD and fetched remote ref must equal --source-sha')
    subprocess.run(['git', 'diff', '--exit-code', source, '--', 'crates', 'Cargo.lock', 'Cargo.toml'],
                   cwd=REPO, check=True, timeout=30)
    untracked = git('ls-files', '--others', '--exclude-standard', '--', 'crates', 'Cargo.lock', 'Cargo.toml')
    for name in untracked.splitlines():
        if name.endswith('.rs') or Path(name).name in ('Cargo.toml', 'Cargo.lock'):
            raise ValueError(f'unpublished native source: {name}')


def stop_group(process: subprocess.Popen) -> int:
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return process.wait()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-sha', required=True)
    args = parser.parse_args()
    if not re.fullmatch('[0-9a-f]{40}', args.source_sha):
        raise ValueError('source must be an exact lowercase SHA-1 commit')
    source = args.source_sha
    assert_source(source)
    OUT.mkdir(parents=True, exist_ok=True)
    DEST.mkdir(parents=True, exist_ok=True)
    if (OUT / 'SUMMARY.json').exists() or (DEST / 'BINDINGS.json').exists():
        raise ValueError('existing preparation evidence must not be overwritten')

    # Reuse the supplied offline toolchain environment, then explicitly select
    # the isolated candidate-only target. Do not expose the inherited environment.
    environment_bytes = subprocess.check_output(
        ['bash', '-c', 'source "$1"; env -0', '_', str(RUNTIME / 'env.sh')],
        cwd=REPO, timeout=30)
    env = dict(item.decode().split('=', 1) for item in environment_bytes.split(b'\0') if item)
    env.update(CARGO_TARGET_DIR=str(RUNTIME / 'target-candidate-fresh'),
               CARGO_BUILD_JOBS='2', RAYON_NUM_THREADS='1', OMP_NUM_THREADS='1',
               OPENBLAS_NUM_THREADS='1', VIGILODE_SOURCE_COMMIT=source)
    compiler = {
        'version_verbose': subprocess.check_output([str(RUNTIME / 'rust/bin/rustc'), '-Vv'], text=True, timeout=30),
        'rustc_binary_sha256': digest(RUNTIME / 'rust/bin/rustc'),
        'cargo_version': subprocess.check_output([str(RUNTIME / 'rust/bin/cargo'), '-V'], text=True, timeout=30),
        'cargo_binary_sha256': digest(RUNTIME / 'rust/bin/cargo'),
    }
    common = ['--profile', 'measurement', '--locked', '--offline']
    commands = [
        ('example-build', ['cargo', 'build', *common, '-p', 'vigilode', '--example', NAME]),
        ('integrator-unit-precompile', ['cargo', 'test', *common, '-p', 'rodas5p-integrators', '--lib', '--no-run']),
        ('integrator-contract-precompile', ['cargo', 'test', *common, '-p', 'rodas5p-integrators',
            '--test', 'directional_quadratic_contracts', '--test', 'matrix_free_problem_contracts',
            '--test', 'spd07_mf_step_warm_start', '--test', 'time_fd_workspace_contracts', '--no-run']),
    ]
    summary = {'schema': 'vigilode.structural-compile-preparation.v1', 'source': source,
               'purpose': 'compile_only_no_scientific_execution', 'commands': [],
               'script_sha256': digest(Path(__file__)), 'compiler': compiler,
               'env_source_path': str(RUNTIME / 'env.sh'),
               'env_source_sha256': digest(RUNTIME / 'env.sh'), 'execution': 'running'}
    write_json(OUT / 'SUMMARY.json', summary)

    def interrupted(signum, frame):
        raise InterruptedError(f'compile preparer received signal {signum}')
    signal.signal(signal.SIGTERM, interrupted)

    for label, command in commands:
        assert_source(source)
        target = OUT / label
        target.mkdir(exist_ok=False)
        before = source_hashes()
        write_json(target / 'source_hashes_before.json', before)
        start = time.monotonic()
        started_utc = dt.datetime.now(dt.timezone.utc).isoformat()
        cpu_before = resource.getrusage(resource.RUSAGE_CHILDREN)
        timed_out = False
        interruption = None
        code = None
        with (target / 'stdout.log').open('wb') as stdout, (target / 'stderr.log').open('wb') as stderr:
            try:
                process = subprocess.Popen(command, cwd=REPO, env=env, stdout=stdout,
                                           stderr=stderr, start_new_session=True)
                try:
                    code = process.wait(timeout=900)
                except subprocess.TimeoutExpired:
                    timed_out = True
                    code = stop_group(process)
                except BaseException as exc:
                    interruption = exc
                    code = stop_group(process)
            except BaseException as exc:
                interruption = exc
        wall = time.monotonic() - start
        cpu_after = resource.getrusage(resource.RUSAGE_CHILDREN)
        after = source_hashes()
        write_json(target / 'source_hashes_after.json', after)
        head_after = git('rev-parse', 'HEAD')
        receipt = {'purpose': 'compile_only_no_scientific_execution', 'label': label,
                   'argv': command, 'cwd': str(REPO), 'source': source,
                   'tree': git('rev-parse', source + '^{tree}'), 'head_after': head_after,
                   'remote_ref': REMOTE_REF, 'remote_after': git('rev-parse', REMOTE_REF),
                   'started_at_utc': started_utc, 'exit_code': code, 'wall_seconds': wall,
                   'child_user_seconds': cpu_after.ru_utime - cpu_before.ru_utime,
                   'child_system_seconds': cpu_after.ru_stime - cpu_before.ru_stime,
                   'timeout_seconds': 900, 'timed_out': timed_out,
                   'source_file_hashes_unchanged': before == after,
                   'interruption': None if interruption is None else {'type': type(interruption).__name__, 'message': str(interruption)},
                   'environment': {key: env[key] for key in ['CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
                       'RAYON_NUM_THREADS', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'VIGILODE_SOURCE_COMMIT']},
                   'compiler': compiler,
                   'logs': {name: {'bytes': (target / name).stat().st_size, 'sha256': digest(target / name)}
                            for name in ['stdout.log', 'stderr.log', 'source_hashes_before.json', 'source_hashes_after.json']}}
        write_json(target / 'RECEIPT.json', receipt)
        summary['commands'].append({'label': label, 'receipt': str(target / 'RECEIPT.json'),
                                    'receipt_sha256': digest(target / 'RECEIPT.json'),
                                    'exit_code': code, 'wall_seconds': wall})
        summary['wall_seconds'] = sum(row['wall_seconds'] for row in summary['commands'])
        passed = code == 0 and before == after and head_after == source and receipt['remote_after'] == source
        if not passed or interruption is not None:
            summary['execution'] = 'failed_or_interrupted'
        write_json(OUT / 'SUMMARY.json', summary)
        print(json.dumps({'label': label, 'exit_code': code, 'wall_seconds': wall, 'source_unchanged': before == after}), flush=True)
        if interruption is not None:
            raise interruption
        if not passed:
            return 1

    assert_source(source)
    source_binary = RUNTIME / 'target-candidate-fresh/measurement/examples' / NAME
    copied_binary = DEST / NAME
    if copied_binary.exists():
        raise ValueError('existing structural binary must not be overwritten')
    shutil.copy2(source_binary, copied_binary)
    build_receipt = OUT / 'example-build/RECEIPT.json'
    manifest = OUT / 'example-build/source_hashes_before.json'
    probe = f'crates/vigilode/examples/{NAME}.rs'

    def blob_sha256(path: str) -> str:
        return hashlib.sha256(subprocess.check_output(['git', 'show', source + ':' + path], cwd=REPO, timeout=30)).hexdigest()

    bindings = {NAME: {
        'source': source, 'source_tree': git('rev-parse', source + '^{tree}'),
        'binary': str(copied_binary), 'binary_sha256': digest(copied_binary),
        'binary_bytes': copied_binary.stat().st_size, 'build_receipt': str(build_receipt),
        'build_receipt_sha256': digest(build_receipt),
        'native_source_identity': {
            'crates_git_tree': git('rev-parse', source + ':crates'),
            'cargo_lock_blob': git('rev-parse', source + ':Cargo.lock'),
            'cargo_lock_sha256': blob_sha256('Cargo.lock'),
            'workspace_manifest_blob': git('rev-parse', source + ':Cargo.toml'),
            'probe_source_path': probe, 'probe_source_blob': git('rev-parse', source + ':' + probe),
            'probe_source_sha256': blob_sha256(probe), 'snapshot_manifest': str(manifest),
            'snapshot_manifest_sha256': digest(manifest), 'unchanged_during_build': True},
        'compiler': compiler, 'execution': 'not_run',
        'test_precompilation_receipts': summary['commands'][1:],
    }}
    write_json(DEST / 'BINDINGS.json', bindings)
    summary['execution'] = 'completed_compile_only'
    summary['binding_path'] = str(DEST / 'BINDINGS.json')
    summary['binding_sha256'] = digest(DEST / 'BINDINGS.json')
    write_json(OUT / 'SUMMARY.json', summary)
    print(json.dumps({'binding': str(DEST / 'BINDINGS.json'), 'sha256': summary['binding_sha256'],
                      'binary_sha256': digest(copied_binary), 'compile_wall_seconds': summary['wall_seconds']}), flush=True)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
