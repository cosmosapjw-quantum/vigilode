# Read-only process audit at structural source cdbee50

- Research-node check against PR101: **PASS**, 185 ledger rows; this node is the only new node.
- Research-node check against main: **FAIL**, 40 inherited diagnostics in older nodes; no diagnostic names the synchronized-production node.
- Scoped authority check: **FAIL**, 191 citations / 53 distinct authority identities; reachable39, non-commit10, missing+allowlisted1, unreachable3. Four diagnostics comprise three raw synthetic PR merge-SHA references and one historical runtime-preparation source reference. They are not current solver execution authority, but the checker failure remains real and is preserved.
- Full authority attempt: **NOT_ESTABLISHED**. The tool session ended with an interruption error, leaving empty stdout/stderr and no original completion receipt. No checker process remained on subsequent inspection. The post-interruption receipt explicitly leaves exit code and elapsed wall time unknown; configured timeout was300seconds. Historical full-authority counts must not be relabeled as this run’s result.

Raw completed command receipts include arguments, source, exit code, elapsed wall time, checker and stdout/stderr SHA-256. No native solver run occurred in this process audit. No repository source file or raw captured metadata was edited. Production remains HOLD.
