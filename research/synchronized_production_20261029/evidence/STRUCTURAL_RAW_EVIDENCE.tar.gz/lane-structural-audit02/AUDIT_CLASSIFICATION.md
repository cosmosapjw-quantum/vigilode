# Safe read-only authority readback

Audited published source `0a2a8eb9b9b0b775561f42f42cf36b1ef6e96f4b`, tree `5795e928f78fe3e99bfa91a4e7d10eaa7540c4db`. Immediately after completion, a Git comparison confirmed no tracked source or node-document changes; the PR103 metadata snapshot was already committed in this source. Subsequent final report/handoff edits are outside this authority audit. The unrelated untracked smoke temporary file was not scanned.

With `GIT_NO_LAZY_FETCH=1` and `GIT_TERMINAL_PROMPT=0`, both checks completed with exit1 and no timeout. The earlier interrupted attempt remains retained separately.

- Scoped authority: FAIL, 202 citations /57 distinct identities. missing1, missing+allowlisted1, non-commit10, reachable42, unreachable3. Six failure diagnostics represent four identities: three synthetic PR merge-SHA metadata identifiers and one historical runtime-preparation source identifier.
- Full authority: FAIL, 11095 citations /1363 distinct identities. invalid-repository11, missing59, missing+allowlisted25, non-commit226, reachable1011, repository-unavailable16, tree-equivalent11, unreachable3, unreachable+allowlisted1. There are178 failure diagnostics, including6 in this node.

Missing here means unavailable in the local Git object database with lazy fetch explicitly disabled. It does not prove the object does not exist remotely. These current counts must not be conflated with the prior full audit’s historical31-missing result. Repository-unavailable and invalid-repository identities remain separate categories. Captured synthetic PR metadata is not current solver execution authority; nonetheless its extraction causes a real checker failure, and raw evidence was not rewritten to suppress it.

Production remains HOLD. This is a process audit, not a native scientific experiment.
