Original BigFloat attempt produced 12 MethodErrors converting Vector{BigFloat}
to BigFloat. Retain the entire failed stream. All four canonical models have
uniform component scales, verified from the locked corpus. Scalar absolute
tolerance is therefore numerically identical to the original vector; only
representation changes. No changes to model, rtol, working precision, grid,
step cap, global threshold or required levels. Treat the corrected run as a
separate API retry. Runtime and compiler errors are not scientific failures.
