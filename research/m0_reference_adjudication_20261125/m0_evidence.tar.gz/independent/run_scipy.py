import ctypes as C, json, pathlib, sys, time, signal
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.sparse.linalg import expm_multiply
from scipy.sparse import csr_matrix
D=pathlib.Path(__file__).resolve().parents[1]
lib=C.CDLL(str(D/'bridge/model_bridge.so'))
p=C.POINTER(C.c_double)
for name,n in [('vb_y0',1),('vb_rhs',2),('vb_jac',2)]:
 f=getattr(lib,name);f.argtypes=[C.c_uint32,C.c_size_t]+[p]*n;f.restype=C.c_int
ids={k:i for i,k in enumerate(['sphere-photon2d','semilinear-advection-diffusion2d','semilinear-advection-diffusion3d','sphere-photon3d','spherical-diffusion2d','allen-cahn2d','gray-scott2d','burgers2d','sine-gordon2d','robertson','hires','van-der-pol-mu1000','oregonator','brusselator1d'])}
def ptr(a):return a.ctypes.data_as(p)
def setup(spec):
 n=spec['n'];i=ids[spec['kind']]
 def rhs(t,y):
  y=np.ascontiguousarray(y,dtype=np.float64);out=np.empty(n)
  if lib.vb_rhs(i,n,ptr(y),ptr(out)):raise ValueError('rhs')
  return out
 y=np.empty(n);assert lib.vb_y0(i,n,ptr(y))==0
 return y,rhs
def timeout(a,b):raise TimeoutError('per-trajectory wall cap')
signal.signal(signal.SIGALRM,timeout)
for cohort in ['canonical','spatial']:
 doc=json.loads((D/'replay'/f'{cohort}.json').read_bytes());refs={r['problem']:r for r in doc['references']}
 grid={r['problem']:r['grid'] for r in doc['plan']['cases']}
 for s in doc['plan']['corpus']['problems']:
  if cohort=='canonical' and s['kind']!='brusselator1d':continue
  name=s['id'];y,rhs=setup(s);t=np.array(grid[name]);assert np.array_equal(y,refs[name]['states'][0])
  for rtol,factor in zip([1e-12,1e-13,3e-14],[.01,.001,.0003]):
   r={'problem':name,'family':'scipy-dop853','rtol':rtol,'atol':s['reference_atol']*factor,'ok':False};start=time.monotonic()
   try:
    signal.alarm(120)
    sol=solve_ivp(rhs,(t[0],t[-1]),y,method='DOP853',rtol=rtol,atol=r['atol'],t_eval=t)
    r.update(message=sol.message,nfev=sol.nfev,grid_points=len(sol.t))
    if sol.success and np.array_equal(sol.t,t) and np.all(np.isfinite(sol.y)) and np.array_equal(sol.y[:,0],y):r.update(ok=True,states=sol.y.T.tolist())
   except Exception as exc:r['reason']=repr(exc)
   finally:signal.alarm(0)
   r['wall_s']=time.monotonic()-start
   print(json.dumps(r,allow_nan=False),flush=True)
  if s['kind'] in ['sphere-photon2d','sphere-photon3d','spherical-diffusion2d']:
   # An orthogonal calculation on the represented linear generator; source
   # read confirms linearity, action on each basis vector fixes state ordering.
   eye=np.eye(len(y));a=np.column_stack([rhs(0,e) for e in eye])
   v=np.sin(np.arange(len(y),dtype=float))
   rel=np.max(np.abs(rhs(0,v)-a@v))/max(1,np.max(np.abs(a@v)))
   assert np.max(np.abs(rhs(0,np.zeros_like(y))))==0
   vals=expm_multiply(csr_matrix(a),y,start=0,stop=t[-1],num=len(t),endpoint=True)
   np.savez_compressed(D/'independent'/f'{name}.linear.npz',matrix=a,y0=y,grid=t,states=vals)
   print(json.dumps({'problem':name,'family':'scipy-expm-multiply','ok':bool(np.all(np.isfinite(vals))),'linear_action_rel_inf':float(rel),'states':vals.tolist(),'grid_points':len(t)},allow_nan=False),flush=True)
