import ctypes as C, json, pathlib, sys, time, signal
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.sparse.linalg import expm_multiply
from scipy.sparse import csr_matrix
D=pathlib.Path(__file__).resolve().parents[1]
lib=C.CDLL(str(D/'bridge/model_bridge.so'))
p=C.POINTER(C.c_double)
for name,n in [('vb_y0',1),('vb_rhs',2),('vb_jac',2)]:
 f=getattr(lib,name);f.argtypes=[C.c_uint32,C.c_size_t]+[p]*n;f.restype=C.c_int
ids={k:i for i,k in enumerate(['sphere-photon2d','semilinear-advection-diffusion2d','semilinear-advection-diffusion3d','sphere-photon3d','spherical-diffusion2d','allen-cahn2d','gray-scott2d','burgers2d','sine-gordon2d','robertson','hires','van-der-pol-mu1000','oregonator','brusselator1d'])}
def ptr(a):return a.ctypes.data_as(p)
def setup(spec):
 n=spec['n'];i=ids[spec['kind']]
 def rhs(t,y):
  y=np.ascontiguousarray(y,dtype=np.float64);out=np.empty(n)
  if lib.vb_rhs(i,n,ptr(y),ptr(out)):raise ValueError('rhs')
  return out
 y=np.empty(n);assert lib.vb_y0(i,n,ptr(y))==0
 return y,rhs
def timeout(a,b):raise TimeoutError('per-trajectory wall cap')
signal.signal(signal.SIGALRM,timeout)

doc=json.loads((D/'replay/canonical.json').read_bytes())
spec=next(s for s in doc['plan']['corpus']['problems'] if s['kind']=='brusselator1d')
name=spec['id'];n=spec['n'];y,rhs=setup(spec);t=np.array(next(s['grid'] for s in doc['plan']['cases'] if s['problem']==name))
ref=next(r for r in doc['references'] if r['problem']==name)
assert np.array_equal(y,ref['states'][0])
def jac(t,y):
 a=np.ascontiguousarray(y);out=np.empty((n,n),order='F')
 assert lib.vb_jac(ids[spec['kind']],n,ptr(a),ptr(out))==0
 return out
for method in ['DOP853','Radau']:
 for rtol,factor,h in zip([1e-12,1e-13,3e-14],[.01,.001,.0003],[.005,.0025,.00125]):
  r={'problem':name,'family':'scipy-'+method.lower()+'-capped','rtol':rtol,'atol':spec['reference_atol']*factor,'max_step':h,'ok':False}
  start=time.monotonic()
  try:
   signal.alarm(120)
   kw={'jac':jac} if method=='Radau' else {}
   sol=solve_ivp(rhs,(t[0],t[-1]),y,method=method,rtol=rtol,atol=r['atol'],t_eval=t,max_step=h,**kw)
   r.update(message=sol.message,nfev=sol.nfev,grid_points=len(sol.t))
   if sol.success and np.array_equal(sol.t,t) and np.all(np.isfinite(sol.y)) and np.array_equal(sol.y[:,0],y):r.update(ok=True,states=sol.y.T.tolist())
  except Exception as exc:r['reason']=repr(exc)
  finally:signal.alarm(0)
  r['wall_s']=time.monotonic()-start
  print(json.dumps(r,allow_nan=False),flush=True)
