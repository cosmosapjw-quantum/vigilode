Registered recovery after the fixed-table BigFloat refinement failure and
before the new custom run. Fixed RadauIIA9 table source uses convert(T,
Float64 literals), so arbitrary state precision is not arbitrary coefficient
precision. This is a plausible contributor, not yet a causal proof.
Generate right Radau 7-stage coefficients at 90 decimal digits with mpmath;
nodes from Jacobi P_6^(1,0), plus 1; integrate exact-basis polynomials
numerically at high precision. Verify quadrature moments through degree 12,
row sums and stiff accuracy. Direct fully coupled stage Newton in Julia
BigFloat (224 bits), independent of OrdinaryDiffEq integrator and table.
Step doubling, no order-dependent Richardson correction in acceptance;
accepted result is two half steps. Clip at all exact grid nodes. Same
represented binary64 source constants/IC/clock. Three local rtol levels
1e-15,1e-17,1e-19, atol=rtol*1e-6; max macro step 1, cap 180 s per level,
max 200000 attempted macro steps, Newton residual threshold 1e-45 (scaled).
Compare to already separately registered SciPy Radau grid-endpoint ladder
all paired and successive levels in both directions at unchanged 1e-10.
This new experiment does not erase any failed RadauIIA9 or Wolfram cell.
Empirical accuracy only.
