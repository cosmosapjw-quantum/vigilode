import ctypes as C, json, pathlib, sys, time, signal
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.sparse.linalg import expm_multiply
from scipy.sparse import csr_matrix
D=pathlib.Path(__file__).resolve().parents[1]
lib=C.CDLL(str(D/'bridge/model_bridge.so'))
p=C.POINTER(C.c_double)
for name,n in [('vb_y0',1),('vb_rhs',2),('vb_jac',2)]:
 f=getattr(lib,name);f.argtypes=[C.c_uint32,C.c_size_t]+[p]*n;f.restype=C.c_int
ids={k:i for i,k in enumerate(['sphere-photon2d','semilinear-advection-diffusion2d','semilinear-advection-diffusion3d','sphere-photon3d','spherical-diffusion2d','allen-cahn2d','gray-scott2d','burgers2d','sine-gordon2d','robertson','hires','van-der-pol-mu1000','oregonator','brusselator1d'])}
def ptr(a):return a.ctypes.data_as(p)
def setup(spec):
 n=spec['n'];i=ids[spec['kind']]
 def rhs(t,y):
  y=np.ascontiguousarray(y,dtype=np.float64);out=np.empty(n)
  if lib.vb_rhs(i,n,ptr(y),ptr(out)):raise ValueError('rhs')
  return out
 y=np.empty(n);assert lib.vb_y0(i,n,ptr(y))==0
 return y,rhs
def timeout(a,b):raise TimeoutError('per-trajectory wall cap')
signal.signal(signal.SIGALRM,timeout)

doc=json.loads((D/'replay/canonical.json').read_bytes())
refs={r['problem']:r for r in doc['references']}
grid={r['problem']:r['grid'] for r in doc['plan']['cases']}
for s in doc['plan']['corpus']['problems']:
 if s['kind']=='brusselator1d':continue
 name=s['id'];n=s['n'];y,rhs=setup(s);t=np.array(grid[name]);assert np.array_equal(y,refs[name]['states'][0])
 def jac(t,y):
  a=np.ascontiguousarray(y);out=np.empty((n,n),order='F')
  assert lib.vb_jac(ids[s['kind']],n,ptr(a),ptr(out))==0
  return out
 for rt in [1e-13,5e-14,2.5e-14]:
  at=float(s['atol_scale'][0])*rt*.01
  assert len(set(s['atol_scale']))==1
  r={'problem':name,'family':'scipy-radau-grid-endpoints','rtol':rt,'atol':at,'ok':False};start=time.monotonic()
  try:
   signal.alarm(120)
   ys=[y.copy()];nfev=0
   for a,b in zip(t[:-1],t[1:]):
    sol=solve_ivp(rhs,(a,b),ys[-1],method='Radau',jac=jac,rtol=rt,atol=at,t_eval=[b])
    nfev+=sol.nfev
    if not sol.success or sol.t.size!=1 or sol.t[0]!=b or not np.all(np.isfinite(sol.y)):raise RuntimeError(sol.message)
    ys.append(sol.y[:,0].copy())
   r.update(ok=True,states=np.array(ys).tolist(),grid_points=len(ys),nfev=nfev)
  except Exception as exc:r['reason']=repr(exc)
  finally:signal.alarm(0)
  r['wall_s']=time.monotonic()-start
  print(json.dumps(r,allow_nan=False),flush=True)
for f in sorted((D/'independent').glob('*.linear.npz')):
 z=np.load(f);a=csr_matrix(z['matrix']);y=z['y0'];t=z['grid']
 v=np.array([expm_multiply(a*ti,y) if ti!=0. else y for ti in t])
 name=f.name.removesuffix('.linear.npz')
 print(json.dumps({'problem':name,'family':'scipy-expm-exact-grid','ok':bool(np.all(np.isfinite(v))),'states':v.tolist(),'grid_points':len(t)},allow_nan=False),flush=True)
