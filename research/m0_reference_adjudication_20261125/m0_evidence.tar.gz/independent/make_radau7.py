import json,pathlib,mpmath as mp
from scipy.special import roots_jacobi
mp.mp.dps=90
s=7
seeds=roots_jacobi(s-1,1,0)[0]
c=[(1+mp.findroot(lambda x:mp.jacobi(s-1,1,0,x),mp.mpf(float(x))))/2 for x in seeds]+[mp.mpf(1)]
V=mp.matrix([[x**j for j in range(s)] for x in c])
Q=mp.matrix([[x**(j+1)/(j+1) for j in range(s)] for x in c])
A=Q*V**-1;b=[A[s-1,j] for j in range(s)]
root_error=max(abs(mp.jacobi(s-1,1,0,2*x-1)) for x in c[:-1])
moment_error=max(abs(sum(b[j]*c[j]**k for j in range(s))-mp.mpf(1)/(k+1)) for k in range(2*s-1))
row_error=max(abs(sum(A[i,j] for j in range(s))-c[i]) for i in range(s))
assert max(root_error,moment_error,row_error)<mp.mpf('1e-75')
fmt=lambda x:mp.nstr(x,78)
p={'stages':s,'order':13,'generator_dps':90,'c':[fmt(x) for x in c],'A':[[fmt(A[i,j]) for j in range(s)] for i in range(s)],'b':[fmt(x) for x in b],'root_residual':fmt(root_error),'quadrature_residual':fmt(moment_error),'row_sum_residual':fmt(row_error)}
pathlib.Path('independent/radau7.json').write_text(json.dumps(p,indent=2)+'\n')
print(root_error,moment_error,row_error)
