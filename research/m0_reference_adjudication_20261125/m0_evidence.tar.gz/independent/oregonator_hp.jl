using LinearAlgebra, JSON3
BLAS.set_num_threads(1)
setprecision(BigFloat,224)
const D=dirname(@__DIR__)
tab=JSON3.read(read(joinpath(@__DIR__,"radau7.json"),String))
const S=Int(tab.stages);const N=3
const A=[parse(BigFloat,String(tab.A[i][j])) for i in 1:S,j in 1:S]
const C=[parse(BigFloat,String(x)) for x in tab.c]
const K=BigFloat(77.27);const KI=BigFloat(1.0/77.27);const Q=BigFloat(8.375e-6);const B=BigFloat(0.161)
const NEWTON_TOL=big"1e-45"
const G=big"0.85";const ONE=BigFloat(1)
function rhs(y)
    x,v,z=y
    [K*(v-x*v+x-Q*x*x),KI*(-v-x*v+z),B*(x-z)]
end
function jac(y)
    x,v,z=y
    [K*(1-v-2Q*x) K*(1-x) zero(x);
     -KI*v -KI*(1+x) KI;
     B zero(x) -B]
end
function res(z,y,h)
    fs=hcat((rhs(view(z,:,i)) for i in 1:S)...)
    r=z .- y .- h .* (fs*transpose(A))
    rr=maximum(abs.(r)./(1 .+ abs.(z)))
    r,rr
end
function step(y,h)
    z=repeat(y,1,S)
    for it in 1:16
        r,err=res(z,y,h)
        if err<=NEWTON_TOL
            return copy(z[:,end]),it,err
        end
        js=[jac(view(z,:,i)) for i in 1:S]
        W=zeros(BigFloat,N*S,N*S)
        for i in 1:S,j in 1:S
            v=-h*A[i,j]
            for a in 1:N,b in 1:N
                W[(i-1)*N+a,(j-1)*N+b]=v*js[j][a,b]+(i==j&&a==b ? ONE : zero(ONE))
            end
        end
        delta=try
            reshape(W\vec(r),N,S)
        catch
            return nothing,it,err
        end
        # Residual-decreasing line search, no accepted nonconvergent Newton.
        scale=ONE;accepted=false
        for _ in 1:8
            znew=z.-scale.*delta
            _,e=res(znew,y,h)
            if isfinite(e)&&e<err
                z=znew;accepted=true;break
            end
            scale/=2
        end
        accepted||return nothing,it,err
    end
    nothing,16,BigFloat(Inf)
end
doc=JSON3.read(read(joinpath(D,"replay","canonical.json"),String))
ref=only(filter(x->x.problem=="oregonator",doc.references))
case=only(filter(x->x.problem=="oregonator",doc.plan.cases))
grid=BigFloat.(Float64.(case.grid))
y0=BigFloat.(Float64.(ref.states[1]))
for rt in [big"1e-15",big"1e-17",big"1e-19"]
    at=rt*big"1e-6"
    row=Dict{String,Any}("problem"=>"oregonator","family"=>"direct-radau7-mp","rtol"=>Float64(rt),"atol"=>Float64(at),"ok"=>false,"precision_bits"=>precision(BigFloat))
    start=time();t=grid[1];y=copy(y0);out=[copy(y)];h=big"0.001";attempts=0;rejects=0;nit=0;maxres=BigFloat(0);failed=""
    for dest in grid[2:end]
        while t<dest
            if time()-start>180 || attempts>=200000
                failed="resource cap";break
            end
            h=min(h,dest-t,ONE)
            if h<big"1e-35"
                failed="minimum step";break
            end
            attempts+=1
            coarse,n1,r1=step(y,h)
            if coarse===nothing
                rejects+=1;h/=2;continue
            end
            mid,n2,r2=step(y,h/2)
            if mid===nothing
                rejects+=1;h/=2;continue
            end
            fine,n3,r3=step(mid,h/2)
            if fine===nothing
                rejects+=1;h/=2;continue
            end
            nit+=n1+n2+n3
            err=maximum(abs.(fine.-coarse)./(at.+rt.*max.(abs.(fine),abs.(coarse))))
            if isfinite(err)&&err<=ONE
                y=fine;t+=h
                maxres=max(maxres,r1,r2,r3)
                h*=clamp(G*max(err,big"1e-30")^(-ONE/14),big"0.2",big"2.0")
            else
                rejects+=1
                h*=isfinite(err) ? clamp(G*err^(-ONE/14),big"0.1",big"0.5") : big"0.1"
            end
        end
        isempty(failed)||break
        push!(out,copy(y))
    end
    row["wall_s"]=time()-start;row["attempts"]=attempts;row["rejected"]=rejects;row["newton_iterations"]=nit
    row["max_accepted_stage_residual"]=Float64(maxres);row["grid_points"]=length(out)
    if isempty(failed)&&length(out)==101&&out[1]==y0&&all(isfinite,Iterators.flatten(out))
        row["ok"]=true;row["states"]=[Float64.(x) for x in out];row["states_decimal"]=[string.(x) for x in out]
    else
        row["reason"]=failed
    end
    println(JSON3.write(row));flush(stdout)
end
