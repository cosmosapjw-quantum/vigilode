Additional separately registered implementation cross-check for the four
low-dimensional canonical models. The vector-atol Julia API attempt is
preserved; scalar-atol equivalent retry completed. Wolfram ladder remains
unchanged and mandatory for the original high-precision protocol, even if
this additional cross-check passes. In this independent alternative
protocol compare the same Julia BigFloat RadauIIA9 ladder to SciPy Radau
(binary64, separate implementation, analytic source Jacobian) using three
levels rtol 1e-13,5e-14,2.5e-14 and uniform per-problem component atol
rtol*atol_scale*0.01. Restart at every locked grid node to eliminate
dense-output interpolation from SciPy. 120 s wall cap per trajectory.
Both directions of all paired and adjacent discrepancies <=1e-10.
This tests integration agreement, not independence of the Radau family
or of the spatial model. An empirical alternate may qualify separately
if every level passes, without changing the outcome of the earlier protocol.
Also re-evaluate the three linear spatial matrix exponential diagnostics
at EACH exact archived binary64 time (previous uniform linspace differed
by at most rounding; retain that diagnostic rather than claiming bitwise
grid identity).
