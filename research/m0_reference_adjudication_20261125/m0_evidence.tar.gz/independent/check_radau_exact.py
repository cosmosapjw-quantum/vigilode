from pathlib import Path
import json
from fractions import Fraction as F
from mathharness_general.poly_exact import parse_polynomial
from mathharness_general.sturm import count_distinct_real_roots
from mathharness_general.ledger import Ledger, fresh_verify
p=Path(__file__).resolve().parent
poly='1-48*x+540*x^2-2400*x^3+4950*x^4-4752*x^5+1716*x^6'
root=count_distinct_real_roots(parse_polynomial(poly),'x','0','1')
assert root['status']=='CERTIFIED' and root['count']==6,root
coeff=[1,-49,588,-2940,7350,-9702,6468,-1716]
ledger=Ledger(p/'radau_exact_ledger.json')
for k in range(6):
    expr='+'.join(f'({c})/{k+j+1}' for j,c in enumerate(coeff))
    assert sum(F(c,k+j+1) for j,c in enumerate(coeff))==0
    cid='RADAU-ORTHO-'+str(k)
    ledger.add_claim(cid,expr+'=0',source={"scope":"exact integral of x^k (1-x) shifted Jacobi polynomial"},formal_statement=f'POLY_IDENTITY: {parse_polynomial(expr)} = {parse_polynomial("0")}')
    r=ledger.record_certificate(cid,'identity',dict(lhs=expr,rhs='0'))
    assert r['status']=='PROVED_EXACT_CERTIFICATE'
v=fresh_verify(p/'radau_exact_ledger.json',strict=True,timeout=60)
assert v.get('ok')
(p/'radau_exact.json').write_text(json.dumps({'root_count':root,'exact_integrals':6,'ledger_replay':v,'non_claim':'does not certify a rounded tableau, stage Newton or global IVP error'},indent=2)+'\n')
print('6 distinct interior roots, 6 exact orthogonality identities, fresh ledger replay PASS')
