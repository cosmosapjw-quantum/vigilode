
$HistoryLength=0;
vars={x1,x2};eq={x1'[t]==x2[t],x2'[t]==1000*(1-x1[t]^2)*x2[t]-x1[t],x1[0]==(2/1),x2[0]==(0/1)};grid={(0/1),(20/1),(40/1),(60/1),(80/1),(100/1),(120/1),(140/1),(160/1),(180/1),(200/1),(220/1),(240/1),(260/1),(280/1),(300/1),(320/1),(340/1),(360/1),(380/1),(400/1),(420/1),(440/1),(460/1),(480/1),(500/1),(520/1),(540/1),(560/1),(580/1),(600/1),(620/1),(640/1),(660/1),(680/1),(700/1),(720/1),(740/1),(760/1),(780/1),(800/1),(820/1),(840/1),(860/1),(880/1),(900/1),(920/1),(940/1),(960/1),(980/1),(1000/1),(1020/1),(1040/1),(1060/1),(1080/1),(1100/1),(1120/1),(1140/1),(1160/1),(1180/1),(1200/1),(1220/1),(1240/1),(1260/1),(1280/1),(1300/1),(1320/1),(1340/1),(1360/1),(1380/1),(1400/1),(1420/1),(1440/1),(1460/1),(1480/1),(1500/1),(1520/1),(1540/1),(1560/1),(1580/1),(1600/1),(1620/1),(1640/1),(1660/1),(1680/1),(1700/1),(1720/1),(1740/1),(1760/1),(1780/1),(1800/1),(1820/1),(1840/1),(1860/1),(1880/1),(1900/1),(1920/1),(1940/1),(1960/1),(1980/1),(2000/1)};
Print["KERNEL ",$Version];
Do[
 wp={40,50,60}[[lev]];goal={15,17,19}[[lev]];
 started=AbsoluteTime[];
 sol=TimeConstrained[NDSolveValue[eq,vars,{t,0,Last[grid]},WorkingPrecision->wp,AccuracyGoal->goal,PrecisionGoal->goal,Method->"StiffnessSwitching",InterpolationOrder->All,MaxSteps->1000000],180,$Aborted];
 row=<|"problem"->"van-der-pol-mu1000","family"->"wolfram-stiffness-extrapolation","working_precision"->wp,"goal"->goal,"ok"->False|>;
 If[ListQ[sol]&&Length[sol]==2&&AllTrue[sol,Head[#]===InterpolatingFunction&],
  domains=(#["Domain"]&/@sol);
  If[AllTrue[domains,#[[1,1]]<=0 && #[[1,2]]>=N[Last[grid],wp]&],
    vals=Table[(#[N[s,wp]]&/@sol),{s,grid}];
    If[MatrixQ[vals,NumberQ]&&Dimensions[vals]=={101,2}&&And@@(TrueQ[Abs[#]<Infinity]&/@Flatten[vals]),
      row=Join[row,<|"ok"->True,"grid_points"->101,"states"->N[vals,MachinePrecision],"states_decimal"->Map[ToString[InputForm[#]]&,vals,{2}]|>],
      row=Join[row,<|"reason"->"nonfinite or shape mismatch"|>]],
    row=Join[row,<|"reason"->"incomplete domain","domains"->ToString[domains,InputForm]|>]],
  row=Join[row,<|"reason"->ToString[Head[sol],InputForm]|>]];
 row=Join[row,<|"wall_s"->N[AbsoluteTime[]-started]|>];
 Export[FileNameJoin[{DirectoryName[$InputFileName],"van-der-pol-mu1000.wl."<>ToString[lev]<>".json"}],row,"RawJSON"];
 Print["WL ", "van-der-pol-mu1000", " ", lev, " ",row["ok"]];
 ,{lev,1,3}];
Quit[];
