import json,pathlib
from fractions import Fraction
D=pathlib.Path(__file__).resolve().parents[1]
doc=json.loads((D/'replay/canonical.json').read_bytes())
refs={r['problem']:r for r in doc['references']}
grids={r['problem']:r['grid'] for r in doc['plan']['cases']}
def exact(x):
 r=Fraction(float(x));return f'({r.numerator}/{r.denominator})'
def arr(a):return '{'+','.join(exact(x) for x in a)+'}'
a,b,c,d,e,f,g,h=[f'x{i}[t]' for i in range(1,9)]
q=exact(8.375e-6);k=exact(77.27);ki=exact(1./77.27)
rhs={
'robertson':[f'-{exact(.04)}*{a}+10000*{b}*{c}',f'{exact(.04)}*{a}-10000*{b}*{c}-30000000*{b}^2',f'30000000*{b}^2'],
'oregonator':[f'{k}*({b}-{a}*{b}+{a}-{q}*{a}^2)',f'{ki}*(-{b}-{a}*{b}+{c})',f'{exact(.161)}*({a}-{c})'],
'van-der-pol-mu1000':[b,f'1000*(1-{a}^2)*{b}-{a}'],
'hires':[f'-{exact(1.71)}*{a}+{exact(.43)}*{b}+{exact(8.32)}*{c}+{exact(.0007)}',f'{exact(1.71)}*{a}-{exact(8.75)}*{b}',f'-{exact(10.03)}*{c}+{exact(.43)}*{d}+{exact(.035)}*{e}',f'{exact(8.32)}*{b}+{exact(1.71)}*{c}-{exact(1.12)}*{d}',f'-{exact(1.745)}*{e}+{exact(.43)}*{f}+{exact(.43)}*{g}',f'-280*{f}*{h}+{exact(.69)}*{d}+{exact(1.71)}*{e}-{exact(.43)}*{f}+{exact(.69)}*{g}',f'280*{f}*{h}-{exact(1.81)}*{g}',f'-280*{f}*{h}+{exact(1.81)}*{g}']
}
for name,fs in rhs.items():
 n=len(fs);g=grids[name];y=refs[name]['states'][0]
 variables='{'+','.join(f'x{i}' for i in range(1,n+1))+'}'
 equations='{'+','.join([f"x{i}'[t]=={f}" for i,f in enumerate(fs,1)]+[f'x{i}[0]=={exact(v)}' for i,v in enumerate(y,1)])+'}'
 script=f'''
$HistoryLength=0;
vars={variables};eq={equations};grid={arr(g)};
Print["KERNEL ",$Version];
Do[
 wp={{40,50,60}}[[lev]];goal={{15,17,19}}[[lev]];
 started=AbsoluteTime[];
 sol=TimeConstrained[NDSolveValue[eq,vars,{{t,0,Last[grid]}},WorkingPrecision->wp,AccuracyGoal->goal,PrecisionGoal->goal,Method->"StiffnessSwitching",InterpolationOrder->All,MaxSteps->1000000],180,$Aborted];
 row=<|"problem"->"{name}","family"->"wolfram-stiffness-extrapolation","working_precision"->wp,"goal"->goal,"ok"->False|>;
 If[ListQ[sol]&&Length[sol]=={n}&&AllTrue[sol,Head[#]===InterpolatingFunction&],
  domains=(#["Domain"]&/@sol);
  If[AllTrue[domains,#[[1,1]]<=0 && #[[1,2]]>=N[Last[grid],wp]&],
    vals=Table[(#[N[s,wp]]&/@sol),{{s,grid}}];
    If[MatrixQ[vals,NumberQ]&&Dimensions[vals]=={{101,{n}}}&&And@@(TrueQ[Abs[#]<Infinity]&/@Flatten[vals]),
      row=Join[row,<|"ok"->True,"grid_points"->101,"states"->N[vals,MachinePrecision],"states_decimal"->Map[ToString[InputForm[#]]&,vals,{{2}}]|>],
      row=Join[row,<|"reason"->"nonfinite or shape mismatch"|>]],
    row=Join[row,<|"reason"->"incomplete domain","domains"->ToString[domains,InputForm]|>]],
  row=Join[row,<|"reason"->ToString[Head[sol],InputForm]|>]];
 row=Join[row,<|"wall_s"->N[AbsoluteTime[]-started]|>];
 Export[FileNameJoin[{{DirectoryName[$InputFileName],"{name}.wl."<>ToString[lev]<>".json"}}],row,"RawJSON"];
 Print["WL ", "{name}", " ", lev, " ",row["ok"]];
 ,{{lev,1,3}}];
Quit[];
'''
 (D/'independent'/f'{name}.wls').write_text(script)
