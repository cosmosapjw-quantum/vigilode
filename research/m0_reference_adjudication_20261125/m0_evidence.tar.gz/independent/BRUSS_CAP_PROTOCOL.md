Separate, preregistered recovery protocol: the original uncapped DOP853/Vern9
Brusselator ladder failed. SciPy DOP853 differed from the old finest RADAU5 by
5.99e-9 at its coarse level, whereas Julia Vern9 differed by 1.97e-11.
Test whether the discrepancy is associated with step-size / interpolation
behavior, without assuming the mechanism. Keep all prior failures. Repeat
both families at original new tolerances [1e-12,1e-13,3e-14], same scalar
atol factors [.01,.001,.0003], add max step [0.005,0.0025,0.00125].
Use identical represented grid and source bridge. All levels, both
directions, successive refinements, threshold 1e-10; 120 s per level.
Additional SciPy Radau (same capped levels and tolerances, exact dense
Jacobian from shared source) is an orthogonal numerical diagnostic.
This is not a replacement of previous results or a weakened threshold.
