using OrdinaryDiffEq, OrdinaryDiffEqFIRK, OrdinaryDiffEqVerner, LinearAlgebra, JSON3, SciMLBase
BLAS.set_num_threads(1)
const D=dirname(@__DIR__)
const BRIDGE=joinpath(D,"bridge","model_bridge.so")
const IDS=Dict(k=>UInt32(i-1) for (i,k) in enumerate(["sphere-photon2d","semilinear-advection-diffusion2d","semilinear-advection-diffusion3d","sphere-photon3d","spherical-diffusion2d","allen-cahn2d","gray-scott2d","burgers2d","sine-gordon2d","robertson","hires","van-der-pol-mu1000","oregonator","brusselator1d"]))
function bridge_setup(kind,n)
    id=IDS[kind];y0=zeros(n)
    @assert ccall((:vb_y0,BRIDGE),Cint,(UInt32,Csize_t,Ptr{Cdouble}),id,n,y0)==0
    function rhs!(dy,y,p,t)
        @assert eltype(y)===Float64 && eltype(dy)===Float64
        ccall((:vb_rhs,BRIDGE),Cint,(UInt32,Csize_t,Ptr{Cdouble},Ptr{Cdouble}),id,n,y,dy)==0||error("source RHS")
    end
    y0,rhs!
end
# Reuse native canonical formulas from the checked original source. The
# literal Float64 constants promote exactly to BigFloat, including the
# pre-rounded inverse 1/77.27. Explicit source comparison precedes solve.
include_string(Main,first(split(read(joinpath(ARGS[1],"bench","julia_comparator_bench.jl"),String),"# WRMS Error metric";limit=2)),"pinned_canonical_defs.jl")
function run_case(spec,grid,reference,big)
    kind=String(spec.kind);name=String(spec.id);n=Int(spec.n)
    y0,f=bridge_setup(kind,n);@assert y0==Float64.(reference[1])
    if big
        p=only(filter(x->x.id==name,get_problems()))
        @assert y0==p.u0 && p.tspan[2]==grid[end]
        # Native source vs original Rust source at fixed and historical states.
        max_delta=0.
        for y in [y0,[Float64.(v) for v in reference[1:10:end]]...]
            a=zeros(n);b=zeros(n);f(a,y,nothing,0.);p.ode_fun(b,y,nothing,0.)
            max_delta=max(max_delta,norm(a-b,Inf)/max(1.,norm(a,Inf)))
        end
        @assert max_delta<1e-13
        println(stderr,"NATIVE_SOURCE_AUDIT ",name," ",max_delta)
        # Solve in BigFloat using the same numeric constants, and stop at all
        # represented grid nodes to avoid lower-order stiff interpolants.
        setprecision(BigFloat,128)
        g=BigFloat.(grid);u=BigFloat.(y0)
        prob=ODEProblem(p.ode_fun,u,(g[1],g[end]))
        levels=[big"1e-15",big"1e-17",big"1e-19"]
        @assert all(==(spec.atol_scale[1]),spec.atol_scale)
        af=BigFloat(Float64(spec.atol_scale[1]))*big"0.01"
        alg=RadauIIA9()
    else
        g=grid;u=y0;prob=ODEProblem(f,u,(g[1],g[end]))
        levels=[1e-12,1e-13,3e-14];af=nothing;alg=Vern9()
    end
    for (i,rt) in enumerate(levels)
        at=big ? af.*rt : Float64(spec.reference_atol)*[.01,.001,.0003][i]
        r=Dict{String,Any}("problem"=>name,"family"=>big ? "julia-radau9-bigfloat" : "julia-vern9","rtol"=>Float64(rt),"atol"=>Float64.(at),"ok"=>false)
        start=time()
        cap=big ? 180. : 120.
        cb=DiscreteCallback((u,t,integrator)->time()-start>cap,terminate!;save_positions=(false,false))
        try
            sol=solve(prob,alg;reltol=rt,abstol=at,saveat=g,tstops=big ? g[2:end] : typeof(g[1])[],maxiters=1000000,callback=cb)
            r["retcode"]=string(sol.retcode);r["grid_points"]=length(sol.t)
            r["accepted"]=sol.stats.naccept;r["rejected"]=sol.stats.nreject
            if SciMLBase.successful_retcode(sol.retcode)&&sol.t==g&&length(sol.u)==length(g)&&sol.u[1]==u&&all(isfinite,Iterators.flatten(sol.u))&&time()-start<=cap
                r["ok"]=true;r["states"]=[Float64.(v) for v in sol.u]
                if big;r["states_decimal"]=[string.(v) for v in sol.u];end
            end
        catch e
            r["reason"]=sprint(showerror,e)
        end
        r["wall_s"]=time()-start
        println(JSON3.write(r));flush(stdout)
    end
end
group=ARGS[2]
for cohort in ["canonical","spatial"]
    doc=JSON3.read(read(joinpath(D,"replay",cohort*".json"),String))
    refs=Dict(String(r.problem)=>r.states for r in doc.references)
    grids=Dict(String(r.problem)=>Float64.(r.grid) for r in doc.plan.cases)
    for s in doc.plan.corpus.problems
        big=cohort=="canonical" && String(s.kind)!="brusselator1d"
        if (group=="big")!=big;continue;end
        run_case(s,grids[String(s.id)],refs[String(s.id)],big)
    end
end
