//! Benchmark-only bridge. The original autonomous Rust Model supplies
//! exact same RHS/Jacobian/initial conditions. Call overhead is measured.
use vigilode_bench::model::{Kind,Model};
use std::slice::{from_raw_parts,from_raw_parts_mut};
fn model(id:u32,n:usize)->Option<Model>{
    let k=match id{0=>Kind::SpherePhoton2d,1=>Kind::SemilinearAdvectionDiffusion2d,2=>Kind::SemilinearAdvectionDiffusion3d,3=>Kind::SpherePhoton3d,4=>Kind::SphericalDiffusion2d,5=>Kind::AllenCahn2d,6=>Kind::GrayScott2d,7=>Kind::Burgers2d,8=>Kind::SineGordon2d,9=>Kind::Robertson,10=>Kind::Hires,11=>Kind::VanDerPolMu1000,12=>Kind::Oregonator,13=>Kind::Brusselator1d,_=>return None};
    Model::new(k,n).ok()
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn vb_y0(id:u32,n:usize,out:*mut f64)->i32{
    let Some(m)=model(id,n) else{return 1};
    if out.is_null(){return 2;}
    unsafe{from_raw_parts_mut(out,n).copy_from_slice(&m.y0());}
    0
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn vb_rhs(id:u32,n:usize,y:*const f64,out:*mut f64)->i32{
    let Some(m)=model(id,n) else{return 1};
    if y.is_null()||out.is_null(){return 2;}
    unsafe{m.rhs(0.,from_raw_parts(y,n),from_raw_parts_mut(out,n));}
    0
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn vb_jac(id:u32,n:usize,y:*const f64,out:*mut f64)->i32{
    let Some(m)=model(id,n) else{return 1};
    if y.is_null()||out.is_null(){return 2;}
    unsafe{m.jac_dense_col_major(0.,from_raw_parts(y,n),n,from_raw_parts_mut(out,n*n));}
    0
}
