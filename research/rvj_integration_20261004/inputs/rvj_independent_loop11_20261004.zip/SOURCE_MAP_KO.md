# 원문·유도·실행의 대응표

원본 ZIP의 exact identity는 SOURCE_BINDING.json을 기준으로 한다. v12와 Stage6를 읽었으며 검색에서 발견한 v13으로 대체하지 않았다. 아래 source_excerpts의 줄은 원 ZIP member를 그대로 복사한 파일 기준이다. 발췌 원문은 사용자 제공 자료이며 사용자 이름/저작권을 추정하지 않는다.

| 원문 | 실제 읽은 범위 | 이번에 사용한 내용 | 적용하지 않은 주장 |
|---|---|---|---|
| v12/05_compact_source.tex | 11–84 | 포물선 m=(t,t²/2), normal-foot cubic, discriminant, reflected target | 모든 이차곡선이 cubic; normal witness가 임의 physical eigenmode |
| v12/07_algebraic_track_c.tex | 190–220 | endpoint-swap (m,d)↦(m,−d)와 ordered/unordered 구별 | fixed point가 있는 임의 involution의 길이 반감 |
| v12/08_boundary_audit.tex | 85–125 | 선형 projector로부터 2P−I involution | nonlinear projection의 일반 involution 성질 |
| Stage6/02_carrier.tex | 정칙 carrier 정의와 Cramer-domain 부분 | 평행 normal/분모0을 정칙 witness로 다루지 않음 | singular chart에서 ordinary inverse 사용 |
| Stage6/04_residual.tex | 23–151 | saturation domain, Artinian 제한, free witness quotient와 nonreduced length | nonfree sign action에서 degree2 torsor 결론 |
| Stage6/05_midpoints.tex | 1–100 | cubic directional Taylor의 even/odd 식, 정칙 조건 | jet 일부 삭제 후 모든 branch 복원 |
| Stage6/06_affine_projective.tex | 전체 1–end | affine regular incidence와 projective boundary 구분 | 무한대 근을 버린 affine degree 감소를 finite coalescence로 해석 |
| Loop10/RESEARCH_NOTE_KO.md와 HANDOFF_KO.md | 전체 | Fourier convolution, alias, final λ=1, original target certificate | FFT roundtrip만으로 physical certification |
| Loop10/code/fourier_volterra.py | 전체 및 dependency code 부분 | 저장경로와 원방정식 residual 인증 재사용 | 부모 full numerical campaign 재실행 |

새로 직접 유도한 것: line-limit의 projective fibre, cusp-family quotient, flat rank3, multiplicity-preserving multiplication, stable confluent analytic evaluation, center-shift resolvent bound, Cauchy–FFT alias bound, 그리고 source-specific FFT bridge.

외부 문헌은 LITERATURE.json에 exact URL과 실제 읽은 범위(abstract 수준)를 기록했다. 가까운 spectral cluster와 local multiplicity를 다루는 선행 맥락이며 우리 코드의 정확성이나 novelty의 증명이 아니다.

원문 full replay는 수행하지 않았다. 원래 보고서에서 알려진 authentic missing-input blocker를 ‘없음’으로 덮어쓰지 않는다.
