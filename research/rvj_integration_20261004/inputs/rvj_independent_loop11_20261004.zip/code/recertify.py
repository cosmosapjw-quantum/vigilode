"""Recompute parent target certificate for all stored current-turn paths."""
from pathlib import Path
from fractions import Fraction as F
import json
from fft_bridge import parent as p
ROOT=Path(__file__).resolve().parents[1]

def state(d):
    return p.State(F(d['t']),tuple(p.C(F(v[0]),F(v[1])) for v in d['a']),F(d['error']),d['generation'])

def run():
    results=[]
    for file in sorted((ROOT/'evidence').glob('fft_case_*.json')):
        data=json.loads(file.read_text());m=p.Model(F(data['omega']));passed=0
        for row in data['records']:
            st=state(row['start']);end=state(row['state']);h=F(row['h'])
            path=tuple(p.EP({(k,j):p.C(F(re),F(im)) for k,j,re,im in coeff}) for coeff in row['path'])
            rt=p.rotate_interval(m.omega*st.t,144)
            mid=p.C(sum(rt['cos'])/2,sum(rt['sin'])/2)
            e0=(rt['cos'][1]-rt['cos'][0]+rt['sin'][1]-rt['sin'][0])/2
            phase,tail,mode=p.phase_candidate(m.omega*h,mid,144)
            cert=p.certificate(st,h,m,path,phase,e0+mid.abs1()*tail,mode)
            assert cert['accepted']
            assert cert['residual_bound']==F(row['residual'])
            assert cert['error']==end.error and cert['endpoint']==end.a
            out=p.commit({'path':path,'certificate':cert,'state':st,'model':m,'h':h},st,m,F(data['tol'])/4)
            assert out==end
            assert p.physical(end,m)['H_error']==F(row['physical_error'])
            passed+=1
        results.append({'file':file.name,'paths_recertified':passed,'exact_equal':True})
    result={'runs':len(results),'paths':sum(x['paths_recertified'] for x in results),'results':results,
            'not_a_new_oracle_campaign':True,'new_candidate_generation_replay':False}
    (ROOT/'evidence/final_recertification.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__':run()
