"""Matched candidate contracts; only predictor arithmetic differs."""
from fractions import Fraction as F
from pathlib import Path
import sys,json,time
import numpy as np
from fft_bridge import parent as p,build_fft
import importlib.util
_spec=importlib.util.spec_from_file_location("loop10_study_exact_source", Path(__file__).resolve().parents[1]/"inputs/loop10/code/run_studies.py")
_study=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(_study)
oracle,jsonify=_study.oracle,_study.jsonify
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'

def run(kind,omega,T=F(1,2),tol=F(1,10**8)):
    model=p.Model(F(omega));state=p.State();G=1/(1-T*model.growth);records=[]
    counts={'candidate_builds':0,'candidate_rejections':0,'rhs_calls':0,'forward_fft2':0,'inverse_fft2':0,'padded_grid_points':0,'max_grid_points':0,'coefficient_outputs':0}
    start=time.perf_counter()
    while state.t<T:
        h=min(F(1,8),T-state.t)
        while True:
            accepted=None
            for K,degree,sweeps in [(2,4,2),(3,6,4)]:
                build=p.build if kind=='exact' else build_fft
                tr=build(state,h,model,K=K,p=degree,sweeps=sweeps)
                counts['candidate_builds']+=1;counts['rhs_calls']+=len(tr['history'])
                if kind=='fft':
                    for key in ['forward_fft2','inverse_fft2','padded_grid_points','coefficient_outputs']:counts[key]+=tr['fft_work'].get(key,0)
                    counts['max_grid_points']=max(counts['max_grid_points'],tr['fft_work'].get('max_grid_points',0))
                c=tr['certificate']
                if c['accepted'] and c['error']<=tol/4 and c['error']-c['growth']*state.error<=tol*h/(8*T*G):
                    accepted=tr;break
                counts['candidate_rejections']+=1
            if accepted is not None:break
            h/=2
            if h<F(1,2**16):raise RuntimeError('resource cap: step')
        before=state;state=p.commit(accepted,state,model,tol/4);physical=p.physical(state,model)
        assert physical['H_error']<=tol
        records.append({'start':before,'h':h,'state':state,'path':[ep.frozen() for ep in accepted['path']],
                        'residual':accepted['certificate']['residual_bound'],'error':state.error,'physical_error':physical['H_error'],
                        'value':[v.to_complex() for v in state.a], 'candidate':{'K':K,'p':degree,'sweeps':sweeps}})
        if len(records)>128:raise RuntimeError('resource cap: number of steps')
    elapsed=time.perf_counter()-start
    refs=[oracle(model,T,rtol=2e-13),oracle(model,T,rtol=8e-14)]
    errors=[];ratio=0;viol=0;interior=0;difference=0
    for rec in records:
        t=float(rec['state'].t);v=np.array(rec['value']);err=float(max(abs(v-refs[-1].sol(t))));errors.append(err)
        ratio=max(ratio,err/float(rec['error']));viol+=int(err>float(rec['error']))
        difference=max(difference,float(max(abs(refs[0].sol(t)-refs[1].sol(t)))))
        eps=[]
        for coeff in rec['path']:
            eps.append(p.EP({(k,j):p.C(F(r),F(i)) for k,j,r,i in coeff}))
        for tau in [F(1,4),F(1,2),F(3,4)]:
            val=np.array([ep.value_interval(model.omega*rec['h'],tau)[0].to_complex() for ep in eps])
            erri=float(max(abs(val-refs[-1].sol(float(rec['start'].t+tau*rec['h'])))))
            viol+=int(erri>float(rec['error']));interior+=1
        # serialize exact current state separately from dataclass internal repr.
        rec['start']={'t':rec['start'].t,'a':rec['start'].a,'error':rec['start'].error,'generation':rec['start'].generation}
        rec['state']={'t':rec['state'].t,'a':rec['state'].a,'error':rec['state'].error,'generation':rec['state'].generation}
        rec.pop('value')
    out={'predictor':kind,'omega':omega,'T':str(T),'tol':str(tol),'accepted_steps':len(records),
         'counts':counts,'max_observed_error':max(errors),'max_error_bound_ratio':ratio,
         'raw_oracle_violations':viol,'interior_checks':interior,'cross_tolerance_oracle_difference':difference,
         'wall_seconds_single_exploratory_run_not_performance_claim':elapsed,
         'original_target_certificate_unchanged':True,'records':records}
    assert viol==0
    (OUT/f'fft_case_{kind}_{omega}.json').write_text(json.dumps(jsonify(out),indent=2))
    print(json.dumps({k:v for k,v in out.items() if k!='records'},indent=2),flush=True)

if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]))
