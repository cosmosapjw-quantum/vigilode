"""Untrusted f64 FFT predictor; parent exact target certificate stays unchanged.

Axis 0 is harmonic index, axis 1 is formal polynomial degree. The second
axis is NOT physical time. Conjugating complex-grid values would reverse
polynomial degree incorrectly, so conjugation is done on coefficients first.
"""
from pathlib import Path
from fractions import Fraction as F
import sys
import numpy as np
from scipy.fft import next_fast_len
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'inputs/loop10/code'))
import fourier_volterra as parent


def required_shape(path,phase):
    K=max((abs(k) for z in path for k,j in z.c),default=0)
    P=max((j for z in path for k,j in z.c),default=0)
    S=max((abs(k) for k,j in phase.c),default=0)
    Q=max((j for k,j in phase.c),default=0)
    band=3*K+S;degree=3*P+Q
    return band,degree,next_fast_len(2*band+1),next_fast_len(degree+1)


def fft_rhs(path,m,phase,lam=F(1),stats=None,shape=None):
    if len(path)!=2:raise ValueError('two complex modes required')
    lam=F(lam)
    if not 0<=lam<=1:raise ValueError('homotopy parameter outside [0,1]')
    band,degree,nk,nj=required_shape(path,phase)
    if shape is not None:
        nk,nj=shape
        if nk<2*band+1 or nj<degree+1:raise ValueError('insufficient full-product padding')
    def values(ep):
        a=np.zeros((nk,nj),dtype=np.complex128)
        for (k,j),v in ep.c.items():a[k%nk,j]=v.to_complex()
        if not np.all(np.isfinite(a)):raise ValueError('nonfinite FFT input')
        return np.fft.fft2(a)
    av=values(path[0]);ac=values(path[0].conj());bv=values(path[1])
    pv=values(phase);pc=values(phase.conj())
    cv=float(m.g)+float(lam*m.eps)*(pv*av+pc*ac)/2
    grids=(1j*float(m.q)*cv*ac*bv,1j*float(m.q/2)*cv*av*av)
    out=[]
    for v in grids:
        coeff=np.fft.ifft2(v)
        if not np.all(np.isfinite(coeff)):raise ValueError('nonfinite FFT output')
        # Freeze every finite f64 coefficient as its exact binary rational.
        cc={}
        for k in range(-band,band+1):
            for j in range(degree+1):
                x=coeff[k%nk,j]
                if x!=0:cc[k,j]=parent.C(F(float(x.real)),F(float(x.imag)))
        out.append(parent.EP(cc))
    if stats is not None:
        stats['rhs_calls']=stats.get('rhs_calls',0)+1
        stats['forward_fft2']=stats.get('forward_fft2',0)+5
        stats['inverse_fft2']=stats.get('inverse_fft2',0)+2
        stats['padded_grid_points']=stats.get('padded_grid_points',0)+nk*nj
        stats['max_grid_points']=max(stats.get('max_grid_points',0),nk*nj)
        stats['coefficient_outputs']=stats.get('coefficient_outputs',0)+2*(2*band+1)*(degree+1)
    return tuple(out)


def build_fft(state,h,m,K=3,p=6,sweeps=4,homotopy=(F(1),),bits=112):
    h=F(h)
    if h<=0 or K<0 or p<1 or sweeps<1 or bits<48 or h*m.growth>=1:raise ValueError('bad step or resource contract')
    if state.generation==0 and state.error==0 and sum((z.r*z.r+z.i*z.i)*w for z,w in zip(state.a,(1,2)))!=F(9,16):raise ValueError('wrong initial invariant leaf')
    if not homotopy or F(homotopy[-1])!=1:raise ValueError('target homotopy must end at one')
    rt=parent.rotate_interval(m.omega*state.t,bits+32)
    mid=parent.C(sum(rt['cos'])/2,sum(rt['sin'])/2)
    e0=(rt['cos'][1]-rt['cos'][0]+rt['sin'][1]-rt['sin'][0])/2
    phase,tail,mode=parent.phase_candidate(m.omega*h,mid,bits+32)
    phase_error=e0+mid.abs1()*tail
    path=tuple(parent.EP.const(z) for z in state.a);hist=[];stats={}
    for ll in homotopy:
        for n in range(sweeps):
            ff=fft_rhs(path,m,phase,F(ll),stats)
            raw=tuple(parent.EP.const(state.a[j])+ff[j].scale(h).primitive(m.omega*h) for j in range(2))
            nxt=tuple(x.truncate(K,p,bits).enforce_start(state.a[j]) for j,x in enumerate(raw))
            hist.append({'lambda':str(ll),'iteration':n+1,
                         'increment':float(max((nxt[j]-path[j]).sup_bound() for j in range(2))),
                         'coefficient_count':sum(len(x.c) for x in nxt)})
            path=nxt
    # Crucial firewall: parent's certificate always recomputes noncyclic exact
    # original-target RHS. It does NOT call fft_rhs or trust its estimates.
    cert=parent.certificate(state,h,m,path,phase,phase_error,mode)
    return {'path':path,'certificate':cert,'history':hist,'h':h,'state':state,
            'model':m,'K':K,'p':p,'fft_work':stats,'predictor':'F64_FFT2_EXACT_TARGET_AUDIT'}
