from pathlib import Path
from fractions import Fraction as F
import json,math,cmath,time
import numpy as np
import mpmath as mp
from scipy.linalg import solve
from fusion import *
from shift_jet import *
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'

def js(o):
 if isinstance(o,F):return str(o)
 if isinstance(o,complex):return [o.real,o.imag]
 if isinstance(o,np.ndarray):return js(o.tolist())
 if isinstance(o,np.generic):return o.item()
 if isinstance(o,dict):return {k:js(v) for k,v in o.items()}
 if isinstance(o,(tuple,list)):return [js(v) for v in o]
 return o


def cluster():
 mp.mp.dps=80;rows=[]
 for s in [0,1e-3,1e-8,1e-12,1e-16,0.1,1.0]:
  a=-.1+1.2j;b=.7j;c=exp_q3(a,b,s)
  ss=mp.mpf(str(s));aa=mp.mpc(a.real,a.imag);bb=mp.mpc(b.real,b.imag)
  exact=[mp.exp(aa),mp.exp(aa)*bb,mp.exp(aa)*bb**2/2] if s==0 else [mp.exp(aa),mp.exp(aa)*mp.sinh(bb*ss)/ss,mp.exp(aa)*(mp.cosh(bb*ss)-1)/(ss*ss)]
  error=max(abs(complex(v)-u) for u,v in zip(c,exact))
  naive=None
  if s:
   vp=cmath.exp(a+b*s);vm=cmath.exp(a-b*s);v0=cmath.exp(a)
   naive=(v0,(vp-vm)/(2*s),(vp+vm-2*v0)/(2*s*s))
  row={'s':s,'stable_coefficient_error':error,'naive_coefficient_error':None if naive is None else max(abs(u-complex(v)) for u,v in zip(naive,exact)),
       'V_condition_number':None if not s else float(np.linalg.cond(np.array([[1,0,0],[1,s,s*s],[1,-s,s*s]])))}
  assert error<5e-15;rows.append(row)
 # Central jet can have a bounded remainder, but not a free inversion.
 tail=[]
 for theta in [F(1,100),F(1),F(10),F(100)]:
  p=8;t=float(theta);poly=sum((1j*t)**k/math.factorial(k) for k in range(p+1));err=abs(poly-cmath.exp(1j*t));bound=imaginary_cluster_tail(theta,p)
  assert err<=float(bound)+1e-14
  tail.append({'theta':str(theta),'degree':p,'actual_error':err,'bound':str(bound)})
 # Explicit nonlinear computation in the length-3 local algebra.
 nonlin=[]
 for s in [F(0),F(1,10**6),F(1,10),F(1)]:
  a=tuple(map(F,[F(1,4),F(1,8),F(-1,16)]));t=F(1,4)
  cols=[multiply_q3(a,e,s) for e in [(1,0,0),(0,1,0),(0,0,1)]]
  Mu=[[cols[j][i] for j in range(3)] for i in range(3)]
  B=[[F(i==j)-t*Mu[i][j] for j in range(3)] for i in range(3)]
  coeff=mv(exact_inverse(B),a)
  node=evaluation(a,s);target=tuple(v/(1-t*v) for v in node)
  assert evaluation(coeff,s)==target
  nonlin.append({'s':s,'coefficient_solution':coeff,'three_node_values':target,'exact_equality':True})
 obj={'stable_confluent_exp':rows,'center_jet_tail':tail,'nonlinear_quotient_flow':nonlin,
      'transcendental_certified_rounding':False,'multiplicity_preserved':3,'independent_state_dof_reduced':False}
 (OUT/'cluster_results.json').write_text(json.dumps(js(obj),indent=2));print('cluster',len(rows),len(tail),len(nonlin),flush=True)


def shifted():
 base=[[-1,-80,0],[80,-4,-30],[0,30,-9]];g=F(1,2);ds=[g*F(j,160) for j in range(-32,33)];p=select_degree(F(1,5),F(1,10**12))
 exact=[]
 for scale,h in [(1,F(1,1000)),(1,F(1,8)),(10000,F(1,8)),(10**8,F(1,8))]:
  J=[[F(scale*v) for v in row] for row in base];b=[F(1),F(2),F(-1)]
  ans=exact_shared(J,h,g,b,ds,p);ratio=0;maxerr=0
  for row in ans['rows']:
   target=mv(exact_inverse(shifted_matrix(J,h,g+row['delta'])),b)
   e2=sum((u-v)**2 for u,v in zip(target,row['value']));r2=sum(v*v for v in row['residual'])
   assert e2<=row['series_bound']**2 and e2<=r2
   maxerr=max(maxerr,math.sqrt(float(e2)))
   if row['series_bound']:ratio=max(ratio,math.sqrt(float(e2))/float(row['series_bound']))
  exact.append({'operator_scale':scale,'h':h,'targets':len(ds),'degree':p,'base_factorizations':1,
                'base_rhs_solves':p+1,'max_error':maxerr,'max_error_to_series_bound':ratio,'exact_enclosure_checks':2*len(ds)})
 # Multiple independent RHS are not replaced with one scalar.
 rng=np.random.default_rng(731);n=48;S=rng.normal(size=(n,n));J=S-S.T-np.diag(np.geomspace(0.01,10000,n));B=rng.normal(size=(n,2));dd=np.array([float(v) for v in ds]);hf=.125;gf=.5
 vals,jet,work=float_shared(J,hf,gf,B,dd,p)
 err=0;res=0
 for d,u in zip(dd,vals):
  P=np.eye(n)-(gf+d)*hf*J;ref=solve(P,B)
  err=max(err,float(np.linalg.norm(u-ref)));res=max(res,float(np.linalg.norm(B-P@u)))
 # This is a numerical check, not an f64 rigorous bound.
 assert err<1e-9
 fl={'n':n,'rhs_rank':2,'targets':len(ds),'degree':p,'max_observed_error_F':err,'max_target_residual_F':res,'work':work,
     'direct_baseline_factorizations':len(ds),'direct_baseline_rhs_solves':2*len(ds),'certified_f64':False}
 obj={'exact_cases':exact,'float_case':fl,'DAG_depth_not_removed':True,'no_wall_clock_speed_claim':True}
 (OUT/'shifted_results.json').write_text(json.dumps(js(obj),indent=2));print('shifted',p,exact[-1],fl,flush=True)

if __name__=='__main__':
 cluster();shifted()
