"""Shared-center shifted solves with true target residuals.

The norm bound requires H-dissipativity. The exact reference below assumes
Euclidean dissipativity and checks it in the experiment fixture, not by an
unsupported numerical eigenvalue guess. Float results are numerical probes.
"""
from __future__ import annotations
from fractions import Fraction as F
from dataclasses import dataclass
import numpy as np
from scipy.linalg import lu_factor, lu_solve


def select_degree(rho,tolerance,max_degree=128):
    rho=F(rho);tolerance=F(tolerance)
    if rho<0 or rho>=1 or tolerance<=0:raise ValueError('require 0<=rho<1 and positive tolerance')
    for p in range(max_degree+1):
        if rho**(p+1)/(1-rho)<=tolerance:return p
    raise ValueError('jet resource cap')


def exact_inverse(M):
    n=len(M)
    if n==0 or any(len(row)!=n for row in M):raise ValueError('square matrix required')
    a=[[F(v) for v in row]+[F(i==j) for j in range(n)] for i,row in enumerate(M)]
    for j in range(n):
        k=next((k for k in range(j,n) if a[k][j]),None)
        if k is None:raise ValueError('singular matrix')
        a[j],a[k]=a[k],a[j];v=a[j][j];a[j]=[x/v for x in a[j]]
        for i in range(n):
            if i!=j:
                t=a[i][j];a[i]=[x-t*y for x,y in zip(a[i],a[j])]
    return [r[n:] for r in a]


def mv(M,v):return [sum((a*b for a,b in zip(row,v)),F(0)) for row in M]

def matmul(A,B):
    return [[sum((A[i][k]*B[k][j] for k in range(len(B))),F(0)) for j in range(len(B[0]))] for i in range(len(A))]

def shifted_matrix(J,h,gamma):
    return [[F(i==j)-h*gamma*J[i][j] for j in range(len(J))] for i in range(len(J))]

def exact_shared(J,h,gamma0,b,deltas,degree):
    J=[[F(v) for v in row] for row in J];h=F(h);g=F(gamma0);b=[F(v) for v in b]
    if h<0 or g<=0 or degree<0:raise ValueError('invalid center/time/degree')
    ds=[F(x) for x in deltas]
    if any(abs(x)>=g for x in ds):raise ValueError('outside proven geometric-series domain')
    R=exact_inverse(shifted_matrix(J,h,g));K=[[h*x for x in row] for row in matmul(R,J)]
    vs=[mv(R,b)]
    for _ in range(degree):vs.append(mv(K,vs[-1]))
    rows=[]
    for d in ds:
        u=[sum((d**k*vs[k][i] for k in range(degree+1)),F(0)) for i in range(len(J))]
        target=shifted_matrix(J,h,g+d)
        residual=[bi-vi for bi,vi in zip(b,mv(target,u))]
        rho=abs(d)/g
        # ||R b||2 <= ||b||2 <= ||b||1. Exact upper, no numerical sqrt.
        bound=sum(abs(x) for x in b)*rho**(degree+1)/(1-rho)
        rows.append({'delta':d,'value':u,'residual':residual,'series_bound':bound})
    return {'rows':rows,'jet':vs,'center_factorizations':1,'center_rhs_solves':degree+1,
            'degree':degree,'target_residuals_computed':len(ds)}


def even_odd_evaluate(jet,delta):
    """Reuse one evaluation per parity, returning paired +/- delta actions."""
    d=F(delta);n=len(jet[0]);even=[F(0)]*n;odd=[F(0)]*n
    for k,v in enumerate(jet):
        dst=even if k%2==0 else odd
        for i in range(n):dst[i]+=d**k*v[i]
    return [x+y for x,y in zip(even,odd)],[x-y for x,y in zip(even,odd)]


def float_shared(J,h,gamma0,B,deltas,degree):
    J=np.asarray(J,dtype=float);B=np.asarray(B,dtype=float)
    if B.ndim==1:B=B[:,None]
    if not np.all(np.isfinite(J)) or not np.all(np.isfinite(B)):raise ValueError('nonfinite operator/data')
    if gamma0<=0 or h<0 or degree<0 or any(abs(d)>=gamma0 for d in deltas):raise ValueError('invalid center or shifts')
    P=np.eye(J.shape[0])-gamma0*h*J;fac=lu_factor(P);jet=[lu_solve(fac,B)]
    for _ in range(degree):jet.append(lu_solve(fac,h*J@jet[-1]))
    vals=[]
    for d in deltas:
        u=jet[-1].copy()
        for v in jet[-2::-1]:u=v+d*u
        vals.append(u)
    return np.asarray(vals),jet,{'factorizations':1,'block_triangular_solves':degree+1,
                                'scalar_rhs_solves':(degree+1)*B.shape[1],
                                'jet_storage_scalars':sum(v.size for v in jet),
                                'output_scalars':len(vals)*B.size,
                                'recurrence_depth':degree+1}
