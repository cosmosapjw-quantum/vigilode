"""Local-algebra reference. Exact rational algebra; transcendentals are probes.

The module never compresses three independent coefficients to one scalar.
The real homotopy s controls the monic quotient x**3-s**2*x.
"""
from __future__ import annotations
from fractions import Fraction as F
import cmath
from math import factorial
from typing import Sequence


def _triple(a: Sequence) -> tuple[F,F,F]:
    if len(a)!=3:
        raise ValueError('three local-algebra coefficients required')
    return tuple(F(x) for x in a)


def multiply_q3(a: Sequence,b: Sequence,s) -> tuple[F,F,F]:
    a0,a1,a2=_triple(a);b0,b1,b2=_triple(b);s2=F(s)**2
    return (a0*b0,
            a0*b1+a1*b0+s2*(a1*b2+a2*b1),
            a0*b2+a1*b1+a2*b0+s2*a2*b2)


def reflection(a: Sequence) -> tuple[F,F,F]:
    a0,a1,a2=_triple(a)
    return a0,-a1,a2


def evaluation(a: Sequence,s) -> tuple[F,F,F]:
    """Order: the central root, plus root, minus root."""
    a0,a1,a2=_triple(a);s=F(s)
    return a0,a0+s*a1+s*s*a2,a0-s*a1+s*s*a2


def inverse_evaluation(values: Sequence,s) -> tuple[F,F,F]:
    v0,vp,vm=_triple(values);s=F(s)
    if s==0:
        raise ValueError('singular evaluation map at coalescence; jets required')
    return v0,(vp-vm)/(2*s),(vp+vm-2*v0)/(2*s*s)


def sinhc(z: complex) -> complex:
    """Entire sinh(z)/z; small-argument recurrence avoids cancellation."""
    z=complex(z)
    if abs(z)>=0.5:
        return cmath.sinh(z)/z
    term=1+0j;out=term
    for k in range(1,30):
        term*=z*z/((2*k)*(2*k+1));out+=term
        if abs(term)<1e-18*max(1,abs(out)):
            return out
    return out


def exp_q3(a: complex,b: complex,s: float) -> tuple[complex,complex,complex]:
    """Exact formula evaluated in f64, NOT a directed-rounding certificate."""
    z=complex(b)*s;base=cmath.exp(a)
    return base,base*b*sinhc(z),base*b*b*sinhc(z/2)**2/2


def exp_center_jet(a: complex,b: complex) -> tuple[complex,complex,complex]:
    """The confluent 2-jet only. Not an exact answer at nonzero s."""
    base=cmath.exp(a)
    return base,base*b,base*b*b/2


def imaginary_cluster_tail(theta,degree: int):
    """Exact rational bound for exp(i theta)'s Taylor remainder along real theta."""
    if degree<0:raise ValueError('degree must be nonnegative')
    return abs(F(theta))**(degree+1)/factorial(degree+1)


def cauchy_fft_jet(function,center: complex,radius: float,count: int,degree: int):
    """Derivative-free numerical Taylor coefficients from one circular stencil.

    NOT one scalar function evaluation: count independent values plus one FFT.
    Roundoff is not certified here. See cauchy_alias_bound for analytic aliasing.
    """
    import numpy as np
    if radius<=0 or degree<0 or count<=degree:raise ValueError('invalid contour/degree')
    roots=np.exp(2j*np.pi*np.arange(count)/count)
    vals=np.asarray([function(center+radius*z) for z in roots],dtype=complex)
    if not np.all(np.isfinite(vals)):raise ValueError('nonfinite contour samples')
    co=np.fft.fft(vals)/count
    return co[:degree+1]/radius**np.arange(degree+1)


def cauchy_alias_bound(M,outer_radius,radius,count,j):
    """Exact rational analytic-alias bound; excludes sample and FFT roundoff."""
    M=F(M);R=F(outer_radius);r=F(radius)
    if M<0 or not 0<r<R or not 0<=j<count:raise ValueError('invalid analytic disk')
    z=(r/R)**count
    return M/R**j*z/(1-z)
