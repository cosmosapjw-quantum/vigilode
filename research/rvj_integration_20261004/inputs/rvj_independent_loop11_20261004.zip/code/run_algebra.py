from pathlib import Path
import sympy as S
import json
ROOT=Path(__file__).resolve().parents[1]
t,s,mu,e,X,Y,T,U,b,z=S.symbols('t s mu e X Y T U b z')
M=S.Matrix([[0,0,0],[1,0,s*s],[0,1,0]]);P=S.diag(1,-1,1)
V=S.Matrix([[1,0,0],[1,s,s*s],[1,-s,s*s]])
normal=t**3+2*(1-Y)*t-2*X
flat=2*e**2*T**3+(1-2*e*Y)*T*U**2-X*U**3
q=t**3-s**2*t
checks={}
def check(name,value):
 if isinstance(value,S.MatrixBase):ok=all(S.simplify(x)==0 for x in value)
 elif value is True or value is False:ok=bool(value)
 else:ok=S.simplify(value)==0
 checks[name]=ok
 if not ok:raise AssertionError((name,value))
check('source_normal_cubic',S.expand(normal.subs({X:mu/2,Y:1+s*s/2}))-(q-mu))
check('discriminant',S.discriminant(q-mu,t)-(4*s**6-27*mu**2))
check('line_limit_infinity_double_root',flat.subs(e,0)-U**2*(T-X*U))
check('degree3_quotient_relation',M**3-s*s*M)
check('involution_square',P**2-S.eye(3))
check('involution_intertwining',P*M*P+M)
check('evaluation_determinant',V.det()-2*s**3)
check('evaluation_diagonalizes',V*M-S.diag(0,s,-s)*V)
check('off_axis_reflection_changes_base',(q-mu).subs(t,-t)+(q-mu)+2*mu)
check('nilpotent_rank_two',(M.subs(s,0).rank()==2))
check('nilpotent_square_rank_one',((M.subs(s,0)**2).rank()==1))
E=S.eye(3)+S.sinh(b*s)/s*M+(S.cosh(b*s)-1)/s**2*M**2
check('exponential_ode',E.diff(b)-M*E)
check('exponential_initial',E.subs(b,0)-S.eye(3))
check('stable_cosh_identity',S.cosh(z)-1-2*S.sinh(z/2)**2)
# Arbitrary first 3 derivatives do not determine all analytic functions away from zero.
check('identical_2jet_different_target', [S.diff(t**3,t,k).subs(t,0) for k in range(3)]==[0,0,0] and (t**3).subs(t,1)==1)
check('spectral_equal_not_operator_equal',M.subs(s,0)!=S.zeros(3))
# Nonlinear quotient flow at the triple point y'=y^2.
a,c1,c2,tt=S.symbols('a c1 c2 tt')
v0=a/(1-a*tt);v1=c1/(1-a*tt)**2;v2=c2/(1-a*tt)**2+tt*c1*c1/(1-a*tt)**3
check('nonlinear_jet0',S.diff(v0,tt)-v0*v0)
check('nonlinear_jet1',S.diff(v1,tt)-2*v0*v1)
check('nonlinear_jet2',S.diff(v2,tt)-(2*v0*v2+v1*v1))
# Neumann identity for general noncommuting P,C: K=P^-1 C.
pp=S.Matrix([[2,1],[0,3]]);cc=S.Matrix([[1,2],[3,1]]);kk=pp.inv()*cc
jj=3;poly=sum((z**k*kk**k for k in range(jj+1)),S.zeros(2))*pp.inv()
check('general_resolvent_partial_sum',(pp-z*cc)*poly-S.eye(2)+z**(jj+1)*cc*kk**jj*pp.inv())
# A fixed odd function maps the base parameter sign, not a universal branch orbit.
check('fixed_origin_involution',P*S.Matrix([1,0,0])-S.Matrix([1,0,0]))
# Rank obstruction is a proof in the note; an exact explicit lossy-encoding witness is checked.
enc=S.Matrix([[1,0,0]]);dec=S.Matrix([1,0,0]);check('lossy_rank_one_not_identity',(dec*enc).rank()==1 and dec*enc!=S.eye(3))
aa,bb=S.symbols('aa bb')
ellipse=2*(aa**2-bb**2)*t*(1-t*t)-2*aa*X*t*(1+t*t)+bb*Y*(1-t**4)
check('generic_ellipse_not_cubic',S.degree(ellipse,t)==4)
check('circle_factors_denominator_chart',S.factor(ellipse.subs(bb,aa))+aa*(1+t*t)*(2*t*X-Y+t*t*Y))
out={'exact_checks':len(checks),'checks':checks,'all_passed':all(checks.values()),'formal_proof_assistant':False}
(ROOT/'evidence/algebra.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
