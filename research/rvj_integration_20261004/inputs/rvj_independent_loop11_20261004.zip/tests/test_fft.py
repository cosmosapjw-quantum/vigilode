from fractions import Fraction as F
from fft_bridge import fft_rhs,parent as p

def test_fft_rhs_original_polynomial_target():
    a=p.EP({(0,0):p.C(F(1,4)),(1,1):p.C(F(1,16),F(1,32))})
    b=p.EP({(0,0):p.C(F(1,2)),(-1,2):p.C(0,F(1,64))})
    phase=p.EP({(1,0):p.C(1)})
    exact=p.rhs((a,b),p.Model(40),phase)
    approx=fft_rhs((a,b),p.Model(40),phase)
    assert max((x-y).coefficients_l1() for x,y in zip(exact,approx)) < F(1,10**13)
import numpy as np
import pytest
from fft_bridge import required_shape,build_fft

def test_fft_complex_coefficient_conjugation_preserves_degree():
    a=p.EP({(1,2):p.C(0,F(1,8)),(0,0):p.C(F(1,4))})
    b=p.EP.const(F(1,2));phase=p.EP({(1,0):p.C(1)})
    ans=fft_rhs((a,b),p.Model(40),phase)
    ex=p.rhs((a,b),p.Model(40),phase)
    assert max((x-y).coefficients_l1() for x,y in zip(ans,ex))<F(1,10**13)

def test_fft_full_product_padding_guard():
    a=p.EP({(2,2):p.C(F(1,4))});phase=p.EP({(1,0):p.C(1)})
    with pytest.raises(ValueError,match='padding'):
        fft_rhs((a,a),p.Model(40),phase,shape=(9,7))

def test_fft_roundtrip_does_not_recover_alias():
    n=5;k=2;v=np.exp(2j*np.pi*k*np.arange(n)/n)
    coeff=np.fft.fft(v*v)/n
    assert abs(coeff[4]-1)<1e-14
    assert (4+n//2)%n-n//2==-1
    assert np.max(abs(np.fft.ifft(np.fft.fft(v*v))-v*v))<1e-14

def test_fft_single_slab_exact_target_certificate():
    tr=build_fft(p.State(),F(1,8),p.Model(40),K=3,p=6,sweeps=4)
    cert=tr['certificate']
    assert cert['accepted'] and cert['error']<F(1,10**8)
    assert tr['fft_work']['forward_fft2']==20
    # No predictor-based error estimate is substituted for target residual.
    assert cert['target_lambda']==1

def test_fft_wrong_initial_leaf_rejected():
    with pytest.raises(ValueError,match='leaf'):
        build_fft(p.State(a=(p.C(1),p.C(0))),F(1,8),p.Model(40))
