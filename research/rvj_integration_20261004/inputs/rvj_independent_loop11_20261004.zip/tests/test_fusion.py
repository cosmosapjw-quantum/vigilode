from fractions import Fraction as F
import pytest
from fusion import multiply_q3,inverse_evaluation,reflection

def test_nilpotent_square_retains_second_jet():
    assert multiply_q3((0,1,0),(0,1,0),F(0)) == (0,0,1)

def test_collapse_cannot_invert_values_only():
    with pytest.raises(ValueError,match='singular'):
        inverse_evaluation((1,1,1),F(0))

def test_involution_keeps_odd_sector_instead_of_erasing_it():
    assert reflection((1,2,3)) == (1,-2,3)
from fusion import evaluation,exp_q3,exp_center_jet
from shift_jet import exact_shared,exact_inverse,mv,shifted_matrix,even_odd_evaluate,select_degree
import cmath

@pytest.mark.parametrize('s',[F(0),F(1,1000),F(1),F(-2)])
def test_quotient_products_match_all_three_evaluations(s):
    a=(2,-3,4);b=(-1,5,2)
    assert evaluation(multiply_q3(a,b,s),s)==tuple(x*y for x,y in zip(evaluation(a,s),evaluation(b,s)))

@pytest.mark.parametrize('s',[F(1,100000),F(1),F(-2)])
def test_evaluation_inverse_nonzero(s):
    a=(F(1,3),F(-4,7),F(5,9))
    assert inverse_evaluation(evaluation(a,s),s)==a

def test_involution_multiplicative_and_square():
    a=(1,2,3);b=(4,5,6);s=F(2,3)
    assert reflection(reflection(a))==a
    assert reflection(multiply_q3(a,b,s))==multiply_q3(reflection(a),reflection(b),s)

def test_scalar_support_does_not_distinguish_two_jets():
    assert evaluation((1,0,0),0)==evaluation((1,2,3),0)
    assert multiply_q3((1,0,0),(1,0,0),0)!=multiply_q3((1,2,3),(1,2,3),0)

@pytest.mark.parametrize('s',[0,1e-12,1e-4,0.1,1])
def test_exponential_three_modes(s):
    a=-.2+2j;b=.3j;c=exp_q3(a,b,s)
    for r in [0,s,-s]:
        assert abs(sum(c[k]*r**k for k in range(3))-cmath.exp(a+b*r))<3e-15

def test_center_jet_is_not_exact_away_from_center():
    c=exp_center_jet(0,1j)
    assert abs(sum(c)-cmath.exp(1j))>0.1

J=[[F(-1),F(-80),F(0)],[F(80),F(-4),F(-30)],[F(0),F(30),F(-9)]]

@pytest.mark.parametrize('shift',[F(-1,10),F(0),F(1,10)])
def test_exact_shiftjet_enclosure_and_true_residual(shift):
    h=F(1,8);g=F(1,2);b=[F(1),F(2),F(-1)]
    ans=exact_shared(J,h,g,b,[shift],12);row=ans['rows'][0]
    actual=mv(exact_inverse(shifted_matrix(J,h,g+shift)),b)
    err2=sum((x-y)**2 for x,y in zip(actual,row['value']))
    assert err2<=row['series_bound']**2
    assert err2<=sum(x*x for x in row['residual']) # positive real shifted inverse is contractive

def test_even_odd_jet_evaluation_matches_signed_pair():
    ans=exact_shared(J,F(1,8),F(1,2),[1,2,-1],[F(1,10),F(-1,10)],12)
    assert even_odd_evaluate(ans['jet'],F(1,10))==tuple(r['value'] for r in ans['rows'])

def test_shift_domain_rejection():
    with pytest.raises(ValueError):exact_shared(J,F(1,8),F(1,2),[1,2,-1],[F(1,2)],12)

def test_degree_selection():
    p=select_degree(F(1,5),F(1,10**10))
    assert F(1,5)**(p+1)/(1-F(1,5))<=F(1,10**10)
    assert p==0 or F(1,5)**p/(1-F(1,5))>F(1,10**10)
from fusion import cauchy_fft_jet,cauchy_alias_bound

def test_cauchy_fft_derivative_free_jet_with_alias_allowance():
    co=cauchy_fft_jet(lambda z:1/(2-z),0,.5,16,6)
    for j,v in enumerate(co):
        bound=cauchy_alias_bound(2,F(3,2),F(1,2),16,j)
        assert abs(v-2**(-j-1))<=float(bound)+1e-14

def test_cauchy_radius_must_not_cross_analytic_disk():
    with pytest.raises(ValueError):cauchy_alias_bound(2,1,2,16,3)

def test_cauchy_alias_vs_rounding_are_separate():
    # An over-small contour amplifies sample errors even while analytic alias shrinks.
    j=6;r1=F(1,2);r2=F(1,100)
    assert cauchy_alias_bound(2,F(3,2),r2,16,j)<cauchy_alias_bound(2,F(3,2),r1,16,j)
    assert F(1,10**16)/r2**j>F(1,10**16)/r1**j
