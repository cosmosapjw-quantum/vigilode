# RVJ independent research loop 11

Read `RESEARCH_NOTE_KO.md` first. This package investigates multiplicity-preserving homotopy, involutive parity reuse, shared shifted-resolvent jets and a de-aliased FFT predictor audited by the unchanged parent target certificate.

This is not a production solver and does not modify Vigilode. No claim of lossless scalar compression, generic stiff/oscillatory order, certified f64 matrix solves, or wall-clock speedup is made.

Local replay in the recorded Python environment:

```sh
bash REPLAY.sh
```

Replay includes new tests, symbolic identities, bounded reference experiments and recertification of the four saved candidate runs. It does not rerun all historic trajectories or original geometry packages. To regenerate a paired trajectory setting explicitly:

```sh
PYTHONPATH=code python code/run_fft.py exact 40
PYTHONPATH=code python code/run_fft.py fft 40
```

Use `10000` for the second setting. No network access is required for replay. NumPy/SciPy/SymPy/mpmath/pytest must already be installed. Installed versions are in `ENVIRONMENT.json`. Code is research reference code with trusted inputs and documented domain guards, not a fully hardened external API.

`inputs/loop10` is a byte-preserving subset of original Python dependencies; it is not the complete parent archive. `source_excerpts` is original user-provided TeX source, not independently verified new mathematics. `SOURCE_BINDING.json` identifies the three source archives. Final promotion remains HOLD without independent review.
