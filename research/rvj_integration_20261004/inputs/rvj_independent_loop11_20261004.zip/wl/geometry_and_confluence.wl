ClearAll[t,s,mu,eps,xx,yy,uu,tt,b,h];
m={t,t^2/2}; normal=Expand[-2 ({xx,yy}-m).D[m,t]];
cusp=normal/.{xx->mu/2,yy->1+s^2/2};
homogeneous=2 eps^2 tt^3+(1-2 eps yy)tt uu^2-xx uu^3;
mat={{0,0,0},{1,0,s^2},{0,1,0}};rev=DiagonalMatrix[{1,-1,1}];
vm={{1,0,0},{1,s,s^2},{1,-s,s^2}};
eb=IdentityMatrix[3]+Sinh[b s]/s mat+(Cosh[b s]-1)/s^2 MatrixPower[mat,2];
<|"normal_cubic"->normal,"cusp_cubic"->cusp,
"cusp_discriminant"->Factor[Discriminant[cusp,t]],
"line_limit_projective"->Factor[homogeneous/.eps->0],
"quotient_relation"->Simplify[MatrixPower[mat,3]-s^2 mat],
"involution"->rev.rev-IdentityMatrix[3],"parity_operator"->rev.mat.rev+mat,
"evaluation_determinant"->Factor[Det[vm]],
"analytic_function_ODE"->FullSimplify[D[eb,b]-mat.eb,Assumptions->s!=0],
"analytic_function_initial"->FullSimplify[eb/.b->0,Assumptions->s!=0],
"off_axis_sign_defect"->Expand[(cusp/.t->-t)+cusp],
"nilpotent_chain_ranks"->{MatrixRank[mat/.s->0],MatrixRank[MatrixPower[mat/.s->0,2]]}|>
