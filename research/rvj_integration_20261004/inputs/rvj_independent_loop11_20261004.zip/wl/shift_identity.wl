ClearAll[h,g0,d,j11,j12,j21,j22,x,y,a,b,tt,xx,yy];
jj={{j11,j12},{j21,j22}};pp=IdentityMatrix[2]-g0 h jj;rr=Inverse[pp];kk=h rr.jj;
sum3=Sum[d^k MatrixPower[kk,k],{k,0,3}].rr;
rem=FullSimplify[(pp-d h jj).sum3-IdentityMatrix[2]+d^4 h jj.MatrixPower[kk,3].rr];
ellipse=Expand[2(a^2-b^2)tt(1-tt^2)-2 a xx tt(1+tt^2)+b yy(1-tt^4)];
nn={{-1,-80,0},{80,-4,-30},{0,30,-9}};
<|"shifted_resolvent_residual"->rem,
"target_dissipative_symmetric_part"->nn+Transpose[nn],
"ellipse_normal_polynomial"->ellipse,"ellipse_generic_degree"->Exponent[ellipse,tt],
"circle_factor"->Factor[ellipse/.b->a],
"radius_norm_square_identity"->Expand[(x^2-2g0 h y+g0^2 h^2 a^2)-g0^2 h^2 a^2],
"taylor_scalar_second_order_loss"->Series[Exp[x]-(1+x+x^2/2),{x,0,3}]|>
