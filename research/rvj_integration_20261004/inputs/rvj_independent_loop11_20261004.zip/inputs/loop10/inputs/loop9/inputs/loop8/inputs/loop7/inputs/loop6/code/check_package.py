"""Structural artifact validation, distinct from mathematical/code tests."""
from pathlib import Path
import ast,hashlib,json
R=Path(__file__).resolve().parents[1]
for p in (R/'code').glob('*.py'):ast.parse(p.read_text(),filename=str(p))
for p in list(R.glob('*.json'))+list((R/'evidence').glob('*.json')):json.loads(p.read_text())
d=json.loads((R/'NEXT_DEVELOPMENT_DAG.json').read_text());ns={n['id']:n for n in d['nodes']}
visited=set();active=set()
def walk(k):
 assert k in ns,k
 assert k not in active,('cycle',k)
 if k in visited:return
 active.add(k)
 for p in ns[k]['depends_on']:walk(p)
 active.remove(k);visited.add(k)
for k in ns:walk(k)
assert all(n['status'] in ('NOT_STARTED','PENDING_INDEPENDENT_REVIEW','BLOCKED_SOURCE') for n in ns.values())
claims=json.loads((R/'CLAIM_LEDGER.json').read_text())
for c in claims['claims']:
 for e in c['evidence']:assert (R/e).is_file(),e
v=json.loads((R/'FINAL_VERIFICATION.json').read_text())
for c in v['commands']:
 assert int((R/c['exit_file']).read_text())==c['exit_code']==0
 assert (R/c['raw_log']).is_file()
contract=R/'RESEARCH_CONTRACT.md'
first=json.loads((R/'evidence/EVIDENCE_LOG.jsonl').read_text().splitlines()[0])
assert hashlib.sha256(contract.read_bytes()).hexdigest()==first['contract_sha256']
for ext in ('*.ttf','*.otf','*.woff','*.woff2'):
 assert not list(R.rglob(ext)),('font files forbidden in output',ext)
print(json.dumps({'python_syntax':'valid','json':'parseable','DAG':'acyclic, remaining only','claim_evidence_paths':'exist','recorded_exit_files':'consistent','frozen_contract_hash':'unchanged','font_file_scan':'none'},indent=2))
