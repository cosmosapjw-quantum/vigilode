from fractions import Fraction as F
from twoway import fast_return_defect
from polynomial import abs_bound

def test_current_return_forcing_cannot_be_silently_dropped():
    # x(s)=s, u=v=0 cannot solve v'=k*(eta*x-rho*v).
    p=((F(0),F(1,10)),(F(0),),(F(0),))
    got=abs_bound(fast_return_defect(p,F(1,10),F(40),F(1,16),F(1)))
    assert got==F(1,4),f'missing O(kappa) return source: {got}'
