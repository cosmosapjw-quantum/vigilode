"""Scoped causal adaptive hybrid RVJ with unknown slow/closure path.

Not a general-purpose ODE/DAE integrator. Fast families and slow closure are
explicitly checked. No future/exact trajectory enters candidate or acceptance.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
import hashlib
from fast_pair import FastModel,choose_fast
from slow_closure import slow_attempt
from loop4_scalar import nearest,up,ContractError,PrecisionBlocked,pow2

@dataclass(frozen=True)
class Snapshot:
    t:F
    x:F
    w:tuple[F,F]
    x_radius:F
    w_radius:F
    branch:int
    model_binding:str
    generation:int=0
    def __post_init__(self):
        for key in ('t','x','x_radius','w_radius'):
            object.__setattr__(self,key,F(getattr(self,key)))
        object.__setattr__(self,'w',tuple(map(F,self.w)))
        if (self.t<0 or self.x_radius<0 or self.w_radius<0 or len(self.w)!=2
                or self.branch not in(-1,1) or self.generation<0
                or not isinstance(self.model_binding,str) or not self.model_binding):
            raise ContractError('invalid accepted snapshot')
    def digest(self):
        return hashlib.sha256(repr(self).encode()).hexdigest()


def physical_error(x,w,rx,rw,model,stored):
    """Additive chart, determinant one, including stored reconstruction errors."""
    if rx<0 or rw<0:raise ContractError('negative radius')
    d=model.scale;k=model.kappa;ax=abs(x)
    b1=d*rw+(2*ax*rx+rx*rx)/k+abs(w[0]+x*x/k-stored[0])
    b2=rw+(3*ax*ax*rx+3*ax*rx*rx+rx**3)/k+abs(w[1]+x**3/k-stored[1])
    return b1,b2


def attempt(s:Snapshot,h:F,model:FastModel,tol:F,T:F,bits:int=128):
    h,tol,T=map(F,(h,tol,T))
    if s.model_binding!=model.binding():raise ContractError('MODEL_EPOCH_OR_PARAMETER_MISMATCH')
    if s.branch not in (-1,1) or h<=0 or tol<=0 or T<=0 or not 0<=s.t<s.t+h<=T:
        raise ContractError('invalid trial domain')
    ex=tol/16;ew=tol/(16*model.scale);bx=ex*h/T;bw=ew*h/T
    slow=slow_attempt(s.x,h,s.x_radius,s.branch,bits)
    work={'slow_candidates':1,'bernstein_certificates':1,'implicit_sqrt_intervals':1,
          'generated_jet_levels':5,'rational_candidates':0,'scalar_exp_intervals':0,'exp_enclosure_terms_squares':0}
    if not slow['valid']:
        return dict(accepted=False,reason=slow['reason'],input_digest=s.digest(),work=work)
    if slow['local_error']>bx:
        return dict(accepted=False,reason='SLOW_DEFECT_BUDGET',local_error=slow['local_error'],
                    budget=bx,input_digest=s.digest(),work=work)
    fast=choose_fast(s.w,s.w_radius,h,model,bw,bits)
    work.update(fast['work'])
    xx=slow['value'];ww=fast['value'];rx=slow['radius'];rw=fast['radius']
    yy=(nearest(ww[0]+xx*xx/model.kappa,bits),nearest(ww[1]+xx**3/model.kappa,bits))
    bphys=physical_error(xx,ww,rx,rw,model,yy)
    if rx>ex or rw>ew or max(bphys)>tol:
        return dict(accepted=False,reason='GLOBAL_OR_PHYSICAL_BUDGET',input_digest=s.digest(),work=work)
    new=Snapshot(s.t+h,xx,ww,rx,rw,s.branch,s.model_binding,s.generation+1)
    return dict(accepted=True,reason='CERTIFIED',input_digest=s.digest(),snapshot=new,
                h=h,slow=slow,fast=fast,physical=yy,physical_bound=bphys,work=work,
                local_x_budget=bx,local_w_budget=bw)


def commit(s:Snapshot,trial:dict)->Snapshot:
    if not trial.get('accepted') or trial.get('input_digest')!=s.digest():
        raise ContractError('STALE_OR_UNACCEPTED_TRIAL')
    out=trial['snapshot']
    if out.branch!=s.branch or out.model_binding!=s.model_binding or out.generation!=s.generation+1:
        raise ContractError('WITNESS_OR_GENERATION_MISMATCH')
    return out


def integrate(model:FastModel,branch:int=1,w0=(F(0),F(1)),tol:F=F(1,10**8),T:F=F(1,4),bits:int=128,max_attempts:int=10000):
    tol,T=map(F,(tol,T));w0=tuple(map(F,w0))
    if model.kappa<1 or not 0<T<=F(1,4) or branch not in(-1,1) or tol<=0:
        raise ContractError('reference requires kappa>=1, T<=1/4, branch +/-1')
    s=Snapshot(F(0),F(0),w0,F(0),F(0),branch,model.binding())
    h=min(F(1,8),T);history=[];reject=[];counts={};modes={'RVJ':0,'EXP_ENCLOSURE':0}
    for _ in range(max_attempts):
        if s.t==T:break
        h=min(h,T-s.t);before=s.digest()
        trial=attempt(s,h,model,tol,T,bits)
        for key,v in trial['work'].items():counts[key]=counts.get(key,0)+v
        if not trial['accepted']:
            assert s.digest()==before
            reject.append({'t':str(s.t),'h':str(h),'reason':trial['reason'],'input_digest':before,'work':trial['work']})
            h/=2
            if h<pow2(-bits//2):raise PrecisionBlocked('step floor')
            continue
        history.append(trial);s=commit(s,trial);modes[trial['fast']['mode']]+=1
        # Only the slow defect controls prospective growth; fast mode is independently hybrid.
        if trial['slow']['local_error']<=trial['local_x_budget']/64:h=min(F(1,8),h*2)
    else:raise PrecisionBlocked('attempt cap')
    return dict(snapshot=s,history=history,rejected=reject,counts=counts,modes=modes,
                accepted=len(history),attempts=len(history)+len(reject),branch=branch,
                model={'kappa':str(model.kappa),'beta':str(model.beta),'rate':model.rate},tol=tol,T=T)
