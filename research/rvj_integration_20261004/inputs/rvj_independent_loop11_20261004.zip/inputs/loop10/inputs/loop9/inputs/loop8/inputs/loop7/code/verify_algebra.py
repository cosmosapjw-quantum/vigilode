"""Exact algebra checks, distinct from numerical solution comparisons."""
import sympy as S
from pathlib import Path
import json
k,al,be,et,ro,x,u,v,q,z,Z=S.symbols('k al be et ro x u v q z Z')
A=k*S.Matrix([[-1,be],[0,-ro]]);C=S.Matrix([[al,0]])
ell=S.simplify(C*A.inv());vf=S.Matrix([q-x+al*u,k*(-u+be*v),k*(et*x-ro*v)])
sh=x-(ell*S.Matrix([u,v]))[0];shdot=(S.Matrix([[S.diff(sh,t) for t in (x,u,v)]])*vf)[0]
M=S.Matrix([[-S.Rational(1,4),S.Rational(1,2)],[k/16,-k/2]])
Q=1-S.Rational(3,5)*z+S.Rational(3,20)*z*z-z**3/60
P=1+S.Rational(2,5)*z+z*z/20
phi=(z*z-5*z+12)/(1440*Q)
checks={}
def check(key,expr):
    if isinstance(expr,S.MatrixBase): ok=all(S.simplify(t)==0 for t in expr)
    elif isinstance(expr,bool):ok=expr
    else:ok=S.simplify(expr)==0
    checks[key]=bool(ok)
    assert ok,(key,expr)
check('primitive_row',ell*A-C)
check('bidirectional_primitive_extra_term',shdot-(q-x+al*be*et*x/ro))
check('quasisteady_feedback',(-C*A.inv()*S.Matrix([0,k*et]))[0]-al*be*et/ro)
check('primitive_chart_determinant',S.Matrix([sh,u,v]).jacobian([x,u,v]).det()-1)
check('fast_determinant_regular_at_coalescence',A.det()-k*k*ro)
check('comparison_determinant',M.det()-3*k/32)
check('positive_comparison_inverse',(-M).inv()-S.Matrix([[S.Rational(16,3),16/(3*k)],[S.Rational(2,3),8/(3*k)]]))
check('fixed_weight_comparison_rows',M*S.Matrix([1,S.Rational(1,4)])-S.Matrix([-S.Rational(1,8),-k/16]))
check('stationary_barrier_rows',M*S.Matrix([Z,Z/4])+S.Matrix([Z/8,k*Z/16]))
check('rvj_linear_identity',sum(z**j/S.factorial(j) for j in range(5))+z**5*phi-P/Q)
check('rvj_classical_jet_coefficient',phi.subs(z,0)-S.Rational(1,120))
check('root_discriminant',S.discriminant(q*q-1-x,q)-4*(1+x))
r=S.symbols('r');check('root_residual_factorization',(r-q)*(r+q)-(r*r-1-x)+(q*q-1-x))
B=S.Matrix([[-1,2],[-2,-1]]);Mb=S.Matrix([[-1,2],[2,-1]]);lam=S.symbols('lam')
check('stable_signed_control',B.charpoly(lam).as_expr()-((lam+1)**2+4))
check('unstable_absolute_comparison_control',Mb.charpoly(lam).as_expr()-(lam+3)*(lam-1))
dx,dv=S.symbols('dx dv')
check('physical_cubic_transport',(v+dv)+(x+dx)**3/k-(v+x**3/k)-(dv+(3*x*x*dx+3*x*dx*dx+dx**3)/k))
# Markov estimate applies only to real full-path polynomial approximation.
eps=S.Rational(1,10**6)
markov=2*6**2*(1+eps)/(1-S.exp(-1)-2*eps)
report={'checks':checks,'passed':sum(checks.values()),'failed':len(checks)-sum(checks.values()),
        'markov_degree6_epsilon1e6_kh_upper':str(S.N(markov,35)),
        'markov_scope':'necessary condition for uniform real polynomial approximation of exp(-a theta), not an endpoint-only integrator restriction'}
root=Path(__file__).resolve().parents[1]
(root/'evidence'/'algebra.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
