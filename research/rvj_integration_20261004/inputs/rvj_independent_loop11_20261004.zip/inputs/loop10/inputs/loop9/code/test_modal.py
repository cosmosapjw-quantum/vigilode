from fractions import Fraction as F
import pytest
from modal import Model, State, initial_state, attempt, commit, integrate, rhs, norm2, reconstruction, rotate_interval

@pytest.mark.parametrize('sigma',[-1,1])
def test_signed_closure_and_action_balance(sigma):
    m=Model(sigma=sigma)
    a=(F(1,2),F(1,4),F(1,8),F(-1,8))
    f=rhs(a,F(sigma),m)
    assert sum(w*x*y for w,x,y in zip((1,1,2,2),a,f))==0

def test_damped_action_balance():
    m=Model(gamma1=F(1,2),gamma2=F(2))
    a=(F(1,2),F(1,4),F(1,8),F(-1,8)); f=rhs(a,F(3,2),m)
    assert 2*sum(w*x*y for w,x,y in zip((1,1,2,2),a,f)) == -2*m.gamma1*(a[0]**2+a[1]**2)-4*m.gamma2*(a[2]**2+a[3]**2)

@pytest.mark.parametrize('mode',['TAYLOR','RVJ'])
def test_candidate_certification(mode):
    m=Model();s=initial_state(); c=attempt(s,F(1,32),m,F(1,2),F(1,10**6),mode)
    assert c['accepted']; assert c['delta']>=0; assert c['new'].error>=0
    assert c['q_min']>=F(1,2); assert c['curve_norm2_upper']<=1
    assert commit(s,c,m)==c['new']

def test_stale_snapshot_rejected():
    m=Model();s=initial_state(); c=attempt(s,F(1,32),m,F(1,2),F(1,10**6),'TAYLOR')
    altered=State(s.t,s.a,F(1,100),s.generation)
    with pytest.raises(ValueError):commit(altered,c,m)

def test_epoch_and_branch_rejected():
    m=Model();s=initial_state();c=attempt(s,F(1,32),m,F(1,2),F(1,10**6),'TAYLOR')
    with pytest.raises(ValueError):commit(s,c,Model(epoch=1))
    with pytest.raises(ValueError):commit(s,c,Model(sigma=-1))

def test_rejection_no_mutation():
    m=Model();s=initial_state();before=s.digest();c=attempt(s,F(1,2),m,F(1,2),F(1,10**20),'TAYLOR')
    assert not c['accepted']; assert before==s.digest()

@pytest.mark.parametrize('kwargs',[{'gamma1':F(-1)},{'sigma':0}])
def test_invalid_model(kwargs):
    with pytest.raises(ValueError):Model(**kwargs)

def test_large_angle_interval_contains_unit_circle():
    z=rotate_interval(F(1000000),112)
    cl,ch=z['cos'];sl,sh=z['sin']
    assert cl<=ch and sl<=sh
    assert ch-cl<F(1,10**15) and sh-sl<F(1,10**15)

def test_zero_rotation_exact():
    r=rotate_interval(F(0)); assert r['cos']==(F(1),F(1));assert r['sin']==(F(0),F(0))

def test_physical_reconstruction_includes_frequency_uncertainty():
    s=State(F(1,4),initial_state().a,F(1,10**9),1)
    r=reconstruction(s,F(1000),frequency_radius=F(1,1000))
    assert r['frequency_error']>0 and r['error']>=r['frequency_error']

def test_candidate_no_frequency_integration_input():
    import inspect
    assert 'omega' not in inspect.signature(integrate).parameters
    assert 'mpmath' not in inspect.getsource(__import__('modal'))

def test_positive_global_time_and_tolerance():
    with pytest.raises(ValueError):integrate(Model(),T=F(0))
    with pytest.raises(ValueError):integrate(Model(),tol=F(0))

def test_rounding_charge_is_additive_to_unrounded_propagated_bound():
    m=Model();s0=initial_state();s=State(s0.t,s0.a,F(1,10**10))
    c=attempt(s,F(1,32),m,F(1,2),F(1,10**6),'TAYLOR',bits=56)
    assert c['accepted']
    assert c['gain']*s.error+c['local']>=c['endpoint_error']

def test_commit_rejects_changed_endpoint_same_path():
    from dataclasses import replace
    m=Model();s=initial_state();c=attempt(s,F(1,8),m,F(1,2),F(1,10**6))
    assert c['accepted']
    c['new']=replace(c['new'],a=(F(0),)*4)
    with pytest.raises(ValueError):commit(s,c,m)

def test_commit_rejects_changed_bound_same_path():
    from dataclasses import replace
    m=Model();s=initial_state();c=attempt(s,F(1,8),m,F(1,2),F(1,10**6))
    assert c['accepted']
    c['new']=replace(c['new'],error=F(0))
    with pytest.raises(ValueError):commit(s,c,m)
