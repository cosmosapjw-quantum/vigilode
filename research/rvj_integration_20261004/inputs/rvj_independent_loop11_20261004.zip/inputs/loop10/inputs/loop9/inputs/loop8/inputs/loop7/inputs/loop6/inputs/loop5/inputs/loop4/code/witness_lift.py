"""Certified path-local continuation for the SOURCE cubic u^3-3u-lambda.

Complex numbers are pairs of Fractions. Norm = |Re|+|Im|, so each
certificate is an exact contraction proof on a closed diamond, not a
floating-point residual heuristic. Newton is only a candidate generator.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from hybrid_rvj import round_sig,pow2,ContractError

@dataclass(frozen=True)
class C:
    re:F=F(0); im:F=F(0)
    def __add__(self,o):
        o=cc(o); return C(self.re+o.re,self.im+o.im)
    __radd__=__add__
    def __neg__(self): return C(-self.re,-self.im)
    def __sub__(self,o):return self+-cc(o)
    def __rsub__(self,o):return cc(o)+-self
    def __mul__(self,o):
        o=cc(o);return C(self.re*o.re-self.im*o.im,self.re*o.im+self.im*o.re)
    __rmul__=__mul__
    def __truediv__(self,o):
        o=cc(o);d=o.re**2+o.im**2
        if not d:raise ContractError('singular complex derivative')
        return C((self.re*o.re+self.im*o.im)/d,(self.im*o.re-self.re*o.im)/d)
    def __pow__(self,n):
        if n<0:return cc(1)/(self**(-n))
        out=cc(1)
        for _ in range(n):out=out*self
        return out
    def norm(self):return abs(self.re)+abs(self.im)
    def rounded(self,bits=112):return C(round_sig(self.re,bits),round_sig(self.im,bits))

def cc(v):
    return v if isinstance(v,C) else C(F(v),F(0))

def cubic(q:C,la:C)->C:return q**3-3*q-la

def tube_certificate(q:C,la0:C,la1:C,rho:F)->dict:
    """Uniform in the straight parameter segment [la0,la1]."""
    rho=F(rho)
    if rho<=0:raise ContractError('positive root tube radius required')
    d=3*q*q-3
    if not d.norm():return dict(valid=False,reason='DERIVATIVE_SINGULAR')
    inv=(cc(1)/d).norm()
    beta=inv*(cubic(q,la0).norm()+(la1-la0).norm())
    theta=inv*(6*q.norm()*rho+3*rho*rho)
    margin=rho-beta-theta*rho
    return dict(valid=(theta<1 and margin>=0),beta=beta,theta=theta,margin=margin,rho=rho)

def correct_candidate(q:C,la:C,bits=112)->C:
    # A bounded Newton generator; returned values are not trusted until enclosed.
    for _ in range(8):
        d=3*q*q-3
        if not d.norm():raise ContractError('Newton derivative singular')
        new=(q-cubic(q,la)/d).rounded(bits)
        if new==q:return q
        q=new
    return q

def point_radius(q:C,la:C,bits=112)->F:
    d=3*q*q-3
    if not d.norm():raise ContractError('singular root')
    beta=(cc(1)/d).norm()*cubic(q,la).norm()
    r=max(4*beta,pow2(-bits+8))
    if not tube_certificate(q,la,la,r)['valid']:
        raise ContractError('candidate did not certify')
    return r

def lift_segment(q:C,r:F,la0:C,la1:C,depth=0)->tuple[C,F,list]:
    if depth>20:raise ContractError('path budget exhausted; no branch switch')
    rho=F(1,16)
    cert=tube_certificate(q,la0,la1,rho)
    if r>rho or not cert['valid']:
        mid=(la0+la1)/2
        q1,r1,left=lift_segment(q,r,la0,mid,depth+1)
        q2,r2,right=lift_segment(q1,r1,mid,la1,depth+1)
        return q2,r2,left+right
    pred=q+(la1-la0)/(3*q*q-3)
    new=correct_candidate(pred,la1); nr=point_radius(new,la1)
    # Proves the endpoint root is the SAME root as in the whole-segment tube.
    if (new-q).norm()+nr>rho:
        mid=(la0+la1)/2
        q1,r1,left=lift_segment(q,r,la0,mid,depth+1)
        q2,r2,right=lift_segment(q1,r1,mid,la1,depth+1)
        return q2,r2,left+right
    return new,nr,[dict(lambda0=la0,lambda1=la1,root0=q,root1=new,
                        endpoint_radius=nr,**cert)]

def square_loop(center:F,radius:F=F(1,4))->list[C]:
    c=F(center);r=F(radius)
    return [C(c+r),C(c,r),C(c-r),C(c,-r),C(c+r)]

def certified_loop(center:F,initial_centers:list[C])->dict:
    path=square_loop(center)
    initial=[correct_candidate(q,path[0]) for q in initial_centers]
    label_radius=F(1,100)
    for i,q in enumerate(initial):
        assert tube_certificate(q,path[0],path[0],label_radius)['valid']
        for p in initial[:i]:assert (q-p).norm()>2*label_radius
    permutations=[];traces=[]
    for q0 in initial:
        q=q0;r=point_radius(q,path[0]);trace=[]
        for a,b in zip(path,path[1:]):
            q,r,slabs=lift_segment(q,r,a,b);trace+=slabs
        idx=min(range(len(initial)),key=lambda i:(q-initial[i]).norm())
        if (q-initial[idx]).norm()+r>=label_radius:
            raise ContractError('endpoint did not match a certified initial label')
        permutations.append(idx);traces.append(trace)
    if len(set(permutations))!=3:raise ContractError('not a permutation')
    return dict(permutation=permutations,slabs=sum(map(len,traces)),
                root_traces=traces,initial=initial,closed_parameter_path=True,
                all_slabs_certified=all(s['valid'] for t in traces for s in t))

def approach_real_fold(tau0:F=F(1),nu:F=F(1),event_tolerance:F=F(1,2**20))->dict:
    """q^2=tau, tau'= -nu. Stop with event bracket; never choose a new branch."""
    if tau0<=0 or nu<=0 or event_tolerance<=0:raise ContractError('invalid fold approach')
    tau=F(tau0);t=F(0);n=0
    while tau>event_tolerance:
        h=tau/(2*nu);t+=h;tau/=2;n+=1
        if n>4096:raise ContractError('fold guard attempt cap')
    return dict(status='FOLD_EVENT_MODEL_DECISION_REQUIRED',steps=n,
                event_lower=t,event_upper=t+tau/nu,remaining_tau=tau,
                exact_fold_time=tau0/nu,physical_continuation_claimed=False)
