"""Exploratory nonuniform-mesh composition; same acceptance, no future oracle."""
from fractions import Fraction as F
from fast_pair import FastModel
from hybrid_pair import Snapshot,attempt,commit
from run_experiments import oracles,audit,save,serial

def main():
    oo=oracles(100);records=[]
    for kappa,rate,branch in [(k,r,b) for k in (40,10000) for r in (1,2) for b in (-1,1)]:
            model=FastModel(F(kappa),F(4),rate)
            case=dict(k=kappa,beta=4,rate=rate,branch=branch,w0=(F(0),F(1)))
            s=Snapshot(F(0),F(0),case['w0'],F(0),F(0),branch,model.binding())
            history=[];modes={'RVJ':0,'EXP_ENCLOSURE':0};steps=[];work={};i=0
            while s.t<F(1,4):
                h=min(F(1,64) if i%2==0 else F(1,32),F(1,4)-s.t)
                trial=attempt(s,h,model,F(1,10**8),F(1,4))
                assert trial['accepted'],trial['reason']
                s=commit(s,trial);history.append(trial);steps.append(str(h));i+=1
                modes[trial['fast']['mode']]+=1
                for key,v in trial['work'].items():work[key]=work.get(key,0)+v
            assert len(set(steps))>=2
            result=dict(history=history)
            records.append(dict(case=serial(case),accepted=i,steps=steps,modes=modes,
                                work=work,**audit(result,case,oo)))
    save('nonuniform_mesh.json',dict(kind='exploratory E07 added before this run',
                                    cases=records,all_checks_passed=True))
    for r in records:print(r['case']['k'],r['case']['rate'],r['case']['branch'],r['accepted'],r['modes'],r['max_error_to_bound'])

if __name__=='__main__':main()
