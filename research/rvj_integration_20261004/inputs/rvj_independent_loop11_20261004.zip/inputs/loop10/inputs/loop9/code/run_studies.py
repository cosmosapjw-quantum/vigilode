from modal import *
import mpmath as mp,numpy as np,json,time,sys
from scipy.integrate import solve_ivp
from pathlib import Path
OUT=Path('../evidence');mp.mp.dps=75

def mpf(q):
    if isinstance(q,F):return mp.mpf(q.numerator)/q.denominator
    return mp.mpf(q)

def jconvert(o):
    if isinstance(o,F):return str(o)
    if isinstance(o,Model):return {k:jconvert(v) for k,v in vars(o).items()}
    if isinstance(o,State):return {'t':str(o.t),'a':list(map(str,o.a)),'error':str(o.error),'generation':o.generation}
    if isinstance(o,dict):return {str(k):jconvert(v) for k,v in o.items()}
    if isinstance(o,(tuple,list)):return list(map(jconvert,o))
    if isinstance(o,(mp.mpf,mp.mpc)):return str(o)
    return o

def dump(name,obj): (OUT/name).write_text(json.dumps(jconvert(obj),indent=2,ensure_ascii=False))

def r23(z):return (1+mp.mpf(2)/5*z+z*z/20)/(1-mp.mpf(3)/5*z+mp.mpf(3)/20*z*z-z**3/60)
def r33(z):return (1+z/2+z*z/10+z**3/120)/(1-z/2+z*z/10-z**3/120)

def run_linear():
    rows=[]
    N=100; h=mp.mpf('0.1')
    for omega in (1,10,100,1000):
        a=omega*h
        for name,r in [('R23',r23),('R33',r33)]:
            val=r(mp.j*a);numerical=val**N;exact=mp.exp(mp.j*a*N)
            if name=='R23':
                np_=mp.arg(1-a*a/20+mp.j*2*a/5); dp=mp.arg(1-3*a*a/20+mp.j*(-3*a/5+a**3/60))
                if dp>0:dp-=2*mp.pi
                phase=np_-dp
            else:
                pphase=mp.arg(1-a*a/10+mp.j*(a/2-a**3/120))
                if pphase<0:pphase+=2*mp.pi
                phase=2*pphase
            rows.append(dict(method=name,omega=omega,h=str(h),N=N,amplitude=mp.nstr(abs(numerical),25),state_error=mp.nstr(abs(numerical-exact),25),continuous_phase_lag=mp.nstr(N*(phase-a),25)))
    conv=[]
    for omega,nu,kappa in [(1000,1000,0),(1000,1000+mp.mpf('1e-6'),0),(1000,0,0),(1000,1000,1000)]:
        hh=mp.mpf('0.1');z=(-kappa+mp.j*(omega-nu))*hh
        val=mp.exp(mp.j*nu*hh)*hh*(mp.expm1(z)/z if z else 1)
        conv.append({'omega':str(omega),'nu':str(nu),'kappa':str(kappa),'gain':mp.nstr(abs(val),30),'h':str(hh)})
    alias={'nodes':['0','1/4','1/2','3/4','1'],'carrier':'8*pi','sampled_forcing':'exp(8*pi*i*t) == 1 at each node','exact_endpoint':1,'interpolated_endpoint':0,'false_endpoint_error':1,'exact_symbolic_check':'algebra.json'}
    nn=[]
    for M in (0,10,1000):
        # Acting on (0,1), H=I. Spectrum is always {i omega,i omega}.
        nn.append({'M':M,'t':1,'norm_at_t':mp.nstr(mp.sqrt(1+M*M),20),'eigenvalue_modulus_gain':1})
    dump('oscillator_filters.json',rows);dump('resonance_convolution.json',conv);dump('aliasing_negative.json',alias);dump('nonnormal_oscillator_negative.json',nn)
    print('linear and resonance controls complete',flush=True)

def oracle(m,T):
    def fun(t,a):
        x,y,u,v=a;qq=m.sigma*np.sqrt(1+x*x+y*y+2*(u*u+v*v));g=float(m.g);d=float(m.delta);g1=float(m.gamma1);g2=float(m.gamma2)
        return [-g1*x+g*qq*(y*u-x*v),-g1*y+g*qq*(x*u+y*v),-g2*u-d*v-g*qq*x*y,d*u-g2*v+g*qq*(x*x-y*y)/2]
    a0=np.array(list(map(float,initial_state().a)))
    kw=dict(rtol=3e-13,atol=2e-15,dense_output=True)
    x=solve_ivp(fun,(0,float(T)),a0,method='DOP853',**kw)
    y=solve_ivp(fun,(0,float(T)),a0,method='Radau',**kw)
    if not x.success or not y.success:raise RuntimeError('oracle failed')
    return x,y

CASES=[
 ('resonant',Model(),F(1,10**6),'RVJ_FIRST'),
 ('detuned',Model(delta=F(3,4)),F(1,10**6),'RVJ_FIRST'),
 ('damped',Model(delta=F(3,4),gamma1=F(1,2),gamma2=F(2)),F(1,10**6),'RVJ_FIRST'),
 ('negative_branch',Model(delta=F(-1,2),sigma=-1),F(1,10**6),'RVJ_FIRST'),
 ('large_detuning',Model(delta=F(20)),F(1,10**6),'RVJ_FIRST'),
 ('strong_damping',Model(gamma1=F(10),gamma2=F(20)),F(1,10**6),'RVJ_FIRST'),
 ('taylor_first',Model(),F(1,10**6),'TAYLOR_FIRST'),
 ('tight_tolerance',Model(),F(1,10**8),'RVJ_FIRST'),
]

def run_case(i):
    name,m,tol,policy=CASES[i];T=F(1,2)
    start=time.monotonic();r=integrate(m,T=T,tol=tol,policy=policy)
    sol,sol2=oracle(m,T); maxerr=mp.mpf(0);maxratio=mp.mpf(0);maxcross=mp.mpf(0); violations=0;interior_violations=0;records=[]
    frequencies=[F(0),F(1),F(1000),F(10**6),F(10**12)]
    outrows={str(om):dict(omega=str(om),max_error=mp.mpf(0),max_bound=mp.mpf(0),raw_violations=0,max_rotation_rounding=mp.mpf(0),doublings=0,series_terms=0) for om in frequencies}
    for c in r['history']:
        s=c['new'];aex=list(map(mpf,sol.sol(float(s.t))));aex2=list(map(mpf,sol2.sol(float(s.t))))
        e=mp.sqrt(sum(int(w)*(mpf(a)-b)**2 for w,a,b in zip(WEIGHTS,s.a,aex)))
        cross=mp.sqrt(sum(int(w)*(a-b)**2 for w,a,b in zip(WEIGHTS,aex,aex2)));maxcross=max(maxcross,cross)
        maxerr=max(maxerr,e);maxratio=max(maxratio,e/mpf(s.error));violations+=int(e>mpf(s.error))
        t0=s.t-c['h']
        for theta in (F(1,4),F(1,2),F(3,4)):
            tt=t0+theta*c['h'];pval=[value(row,theta) for row in c['p']];ex=sol.sol(float(tt))
            ee=mp.sqrt(sum(int(w)*(mpf(a)-mpf(b))**2 for w,a,b in zip(WEIGHTS,pval,ex)))
            interior_violations+=int(ee>mpf(c['whole_error']))
        for om in frequencies:
            rec=reconstruction(s,om);zex=[]
            for j in range(2):
                z=mp.mpc(aex[2*j],aex[2*j+1])*mp.exp(mp.j*(j+1)*mpf(om)*mpf(s.t));zex.extend([z.real,z.imag])
            er=mp.sqrt(sum(int(w)*(mpf(a)-b)**2 for w,a,b in zip(WEIGHTS,rec['value'],zex)))
            rr=outrows[str(om)];rr['max_error']=max(rr['max_error'],er);rr['max_bound']=max(rr['max_bound'],mpf(rec['error']));rr['raw_violations']+=int(er>mpf(rec['error']));rr['max_rotation_rounding']=max(rr['max_rotation_rounding'],mpf(rec['carrier_arithmetic_error']));rr['doublings']+=rec['doublings'];rr['series_terms']+=rec['series_terms']
        records.append({'t':s.t,'h':c['h'],'mode':c['mode'],'a':s.a,'error':s.error,'defect':c['delta'],'root_defect':c['algebraic_bound'],'path_digest':c['path_digest'],'energy':norm2(s.a)})
    enerr=abs(mpf(norm2(r['state'].a))-mpf(norm2(initial_state().a)))
    report=dict(name=name,model=m,T=T,tol=tol,policy=policy,accepted=r['accepted'],work=r['work'],modes={mode:sum(c['mode']==mode for c in r['history']) for mode in ('RVJ','TAYLOR')},
                final=r['state'],max_amplitude_error=maxerr,max_error_bound_ratio=maxratio,raw_endpoint_violations=violations,raw_interior_violations=interior_violations,oracle_cross_difference=maxcross,oracle='two independent scipy methods, numerical only',physical_frequency_sweep=list(outrows.values()),energy_change=enerr,records=records,seconds_including_oracles=time.monotonic()-start,
                no_speedup_claim=True,frequency_independent_mesh='one carrier-free amplitude run reused at five frequencies, not five independent integration runs')
    dump(f'case_{name}.json',report)
    print(name,'steps',r['accepted'],'modes',report['modes'],'err',mp.nstr(maxerr,8),'ratio',mp.nstr(maxratio,6),'violations',violations,interior_violations,'secs',report['seconds_including_oracles'],flush=True)

if __name__=='__main__':
    if len(sys.argv)==1:run_linear()
    else:
        for i in map(int,sys.argv[1:]):run_case(i)
