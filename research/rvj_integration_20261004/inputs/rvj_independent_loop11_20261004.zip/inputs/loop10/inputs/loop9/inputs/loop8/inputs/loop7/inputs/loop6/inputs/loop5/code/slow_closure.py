"""Residual certificate, not an exact slow-flow oracle.

x'=q-x, q^2=1+x, q has fixed sign; admissible x domain [-1/2,1].
A candidate p(theta), r(theta) is certified on the entire step by Bernstein
bounds on p'/h+p-r and r²-1-p. The true reduced vector field has
one-sided derivative <= -1/4 on this domain for either selected branch.
"""
from fractions import Fraction as F
from math import factorial
from polynomial import (add,scale,mul,deriv,value,abs_bound,bernstein_range,sqrt_interval)
from loop4_scalar import nearest,up,ContractError

DOMAIN=(F(-1,2),F(1)); QMIN=F(2,3)

def make_candidate(x:F,h:F,branch:int,bits:int=128)->dict:
    x,h=F(x),F(h)
    if branch not in (-1,1) or h<=0 or not DOMAIN[0]<=x<=DOMAIN[1]:
        raise ContractError('unsupported initial slow chart')
    qlo,qhi=sqrt_interval(1+x,bits+16)
    q0=branch*(qlo+qhi)/2
    xx=[x];qq=[q0]
    # Formal order-by-order implicit jet; no root iteration at stage points.
    for j in range(5):
        xx.append((qq[j]-xx[j])/F(j+1))
        jj=j+1
        qq.append((xx[jj]-sum((qq[i]*qq[jj-i] for i in range(1,jj)),F(0)))/(2*q0))
    pp=[xx[i]*h**i for i in range(6)]
    rr=[qq[i]*h**i for i in range(6)]
    W=-1+1/(2*q0);z=h*W
    Q=1-3*z/5+3*z*z/20-z**3/60
    if Q==0:raise ContractError('slow rational pole')
    phi=(z*z-5*z+12)/(1440*Q)
    correction=h**5*factorial(5)*xx[5]*(phi-F(1,120))
    # Exact initial point and jets through order five, RVJ endpoint at theta=1.
    pp.append(correction)
    return dict(p=tuple(pp),r=tuple(rr),branch=branch,q_start=tuple(sorted((branch*qlo,branch*qhi))),
                W=W,correction=correction,jet_order=5,
                work={'implicit_sqrt_intervals':1,'jet_scalar_divisions':10,'jet_levels':5})

def certify_candidate(p,r,h:F,inherited:F,branch:int,bits:int=128)->dict:
    h,inherited=F(h),F(inherited)
    if h<=0 or inherited<0 or branch not in(-1,1):raise ContractError('invalid slow certificate')
    if len(p)<1 or len(r)<1:raise ContractError('empty path')
    pr=bernstein_range(p);rr=bernstein_range(r)
    rmin=rr[0] if branch==1 else -rr[1]
    if rmin<QMIN:
        return dict(valid=False,reason='WITNESS_SIGN_OR_MARGIN',r_range=rr)
    dg=add(add(scale(deriv(p),1/h),p),scale(r,-1))
    ag=add(add(mul(r,r),(-F(1),)),scale(p,-1))
    differential=abs_bound(dg);algebraic=abs_bound(ag)
    qerr=algebraic/(rmin+QMIN)
    defect=differential+qerr
    whole_radius=inherited+h*defect
    # Bootstrap/first-exit argument; no assumption that true x is in tube.
    if not (DOMAIN[0]<pr[0]-whole_radius and pr[1]+whole_radius<DOMAIN[1]):
        return dict(valid=False,reason='WHOLE_SLOW_TUBE',p_range=pr,radius=whole_radius)
    raw=value(p,F(1)); stored=nearest(raw,bits)
    local_raw=h*defect+abs(raw-stored)
    local=up(local_raw,bits)
    radius=inherited+local
    if not (DOMAIN[0]<stored-radius and stored+radius<DOMAIN[1]):
        return dict(valid=False,reason='ROUNDED_ENDPOINT_TUBE')
    return dict(valid=True,reason='CERTIFIED',value=stored,local_error=local,radius=radius,
                whole_radius=whole_radius,closure_whole_error=(algebraic+whole_radius)/(rmin+QMIN),
                p_range=pr,r_range=rr,rmin=rmin,differential_defect=differential,
                algebraic_defect=algebraic,reduced_defect=defect,
                endpoint_rounding=abs(raw-stored),certificate_inflation=local-local_raw,branch=branch,
                defect_power_coefficients=dg,algebraic_power_coefficients=ag,
                work={'bernstein_envelopes':4,'slow_residual_degree':len(dg)-1,'closure_residual_degree':len(ag)-1})

def slow_attempt(x:F,h:F,inherited:F,branch:int,bits:int=128)->dict:
    c=make_candidate(x,h,branch,bits)
    out=certify_candidate(c['p'],c['r'],h,inherited,branch,bits)
    out['candidate']=c
    return out
