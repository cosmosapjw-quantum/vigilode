from fractions import Fraction as F
import pytest
from enriched import Model,Path,certify
from generator import make_forcing
from run_study import Snapshot,model_id,commit

@pytest.fixture(scope='module')
def valid_path():
    m=Model();y=(F(0),F(0),F(4));h=F(1,64)
    r,_=make_forcing(m,h,y)
    return Path.build(m,h,y,r)

def test_negative_inherited_error_is_invalid(valid_path):
    with pytest.raises(ValueError): certify(valid_path,F(-1,100),F(1,10**6))

def test_positive_budget_and_resource_limits_required(valid_path):
    for eps,limit in [(F(0),256),(F(-1),256),(F(1),0)]:
        with pytest.raises(ValueError):certify(valid_path,0,eps,limit)

def test_cannot_construct_wrong_dimension_path():
    with pytest.raises(ValueError):Path.build(Model(),F(1,8),(F(0),F(0)),(F(1),))

def test_accepted_all_slab_guard_includes_global_error(valid_path):
    c=certify(valid_path,F(1,10**9),F(1,10**6))
    assert c['valid']
    lo,hi=c['xrange'];assert lo-c['Z']>F(-1,2) and hi+c['Z']<1

def test_stale_or_different_model_commit_fails(valid_path):
    p=valid_path;m=p.model;c=certify(p,0,F(1,10**6));assert c['valid']
    s=Snapshot(F(0),p.y0,F(0),model_id(m))
    with pytest.raises(ValueError):commit(s,m,p,c,'old-binding')
    with pytest.raises(ValueError):commit(s,Model(k=2),p,c,s.digest())
    nxt=commit(s,m,p,c,s.digest())
    assert nxt.generation==s.generation+1 and s.t==0

def test_bad_forcing_trial_has_no_commit(valid_path):
    p=valid_path;m=p.model;s=Snapshot(F(0),p.y0,F(0),model_id(m));before=s.digest()
    bad=Path.build(m,p.h,p.y0,(F(-1),))
    c=certify(bad,s.E,F(1,10**6));assert not c['valid']
    with pytest.raises(ValueError):commit(s,m,bad,c,before)
    assert s.digest()==before

def test_certificate_cannot_be_swapped_between_two_valid_paths(valid_path):
    p=valid_path;m=p.model;s=Snapshot(F(0),p.y0,F(0),model_id(m))
    c=certify(p,s.E,F(1,10**6));assert c['valid']
    r,_=make_forcing(m,p.h/2,p.y0)
    other=Path.build(m,p.h/2,p.y0,r)
    with pytest.raises(ValueError):commit(s,m,other,c,s.digest())

def test_certificate_initial_radius_must_match_snapshot(valid_path):
    p=valid_path;m=p.model;s=Snapshot(F(0),p.y0,F(1,10**9),model_id(m))
    c=certify(p,F(0),F(1,10**6));assert c['valid']
    with pytest.raises(ValueError):commit(s,m,p,c,s.digest())
