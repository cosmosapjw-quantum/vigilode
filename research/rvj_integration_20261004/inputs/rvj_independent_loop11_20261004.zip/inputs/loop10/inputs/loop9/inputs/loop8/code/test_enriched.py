from fractions import Fraction as F
import pytest
from enriched import *
from generator import make_forcing,bases,extrapolate
from polynomial import value

@pytest.mark.parametrize('k',[1,40,10000])
def test_exponential_interval_contains_independent_high_precision_matrix(k):
    import mpmath as mp
    with mp.workdps(100):
        m=Model(k=F(k));h=F(1,8);E=exp_matrix_interval(m.L,h)
        A=mp.matrix([[mp.mpf(x.numerator)/x.denominator for x in row] for row in m.L])
        ref=mp.expm(mp.mpf(1)/8*A)
        for i in range(3):
            for j in range(3):
                lo,hi=E[i][j]
                assert mp.mpf(lo.numerator)/lo.denominator<=ref[i,j]<=mp.mpf(hi.numerator)/hi.denominator

@pytest.mark.parametrize('k',[1,40,10000])
def test_polynomial_particular_equation_is_exact(k):
    m=Model(k=F(k));p=Path.build(m,F(1,8),(F(0),F(0),F(4)),(F(1),F(1,16),F(-1,64)))
    for j in range(3):
        for i in range(3):
            lhs=(j+1)*p.V[i][j+1] if j<2 else F(0)
            rhs=sum(p.h*m.L[i][a]*p.V[a][j] for a in range(3))+(p.h*p.r[j] if i==0 else 0)
            assert lhs==rhs
    for i,interval in enumerate(p.evaluate(0)):assert interval[0]<=p.y0[i]<=interval[1]

def test_bad_branch_is_not_repaired_by_involution():
    p=Path.build(Model(),F(1,8),(F(0),F(0),F(4)),(F(-1),))
    assert certify(p,0,F(1,10**6))['reason']=='WITNESS_MARGIN'

def test_interpolation_cardinality():
    ns=(F(0),F(1,4),F(1,2),F(3,4),F(1))
    for i,p in enumerate(bases()):
        for j,t in enumerate(ns):assert value(p,t)==int(i==j)

def test_history_extrapolation_is_same_polynomial_not_same_domain():
    p=(F(2),F(3),F(4));e=extrapolate(p,F(1,8),F(1,16))
    for t in (F(0),F(1,2),F(1)):assert value(e,t)==value(p,1+t/2)

def test_exact_equilibrium_constant_forcing_certifies():
    # choose a linear forcing path, certification is to the nonlinear equation;
    # this generic constant is NOT an equilibrium and must not be accepted too freely.
    p=Path.build(Model(),F(1,8),(F(0),)*3,(F(1),))
    assert not certify(p,0,F(1,10**8))['valid']

def test_supersolution_inherited_radius_is_not_reset():
    m=Model();r,info=make_forcing(m,F(1,64),(F(0),F(0),F(4)))
    p=Path.build(m,F(1,64),(F(0),F(0),F(4)),r)
    e=F(1,10**9);c=certify(p,e,F(1,10**6))
    assert c['valid'],c
    assert c['E']>=e

def test_forward_only_exponential_domain():
    with pytest.raises(ValueError):exp_matrix_interval(Model().L,F(-1))
