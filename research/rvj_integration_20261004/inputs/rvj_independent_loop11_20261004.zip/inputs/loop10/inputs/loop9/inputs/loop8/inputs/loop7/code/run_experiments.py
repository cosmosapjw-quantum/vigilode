"""Separate floating-point audit; never imported by the candidate/certificate."""
from fractions import Fraction as F
from pathlib import Path
import json,hashlib,sys,time
from collections import Counter
import numpy as np
from scipy.integrate import solve_ivp
from twoway import Model,integrate,initial_state,physical,make_jet,make_candidate,certify
from polynomial import value
from loop4_scalar import up
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence';OUT.mkdir(exist_ok=True)
CASES=[
 ('k1',dict(k=1),0,1),('k40',dict(k=40),0,1),('k400',dict(k=400),0,1),('k10000',dict(k=10000),0,1),
 ('negative_branch',dict(k=40,branch=-1),0,1),('distinct_rates',dict(k=40,rho=2),0,1),
 ('negative_feedback',dict(k=400,alpha=F(-1,16)),0,1),('negative_nonnormal',dict(k=400,beta=-4),1,-1),
 ('zero_fast_but_forced',dict(k=40),0,0),('no_return_control',dict(k=40,eta=0),0,1),
 ('larger_nonnormal',dict(k=400,beta=20,alpha=F(1,128)),0,1),
]

def dump(path,data):path.write_text(json.dumps(data,indent=2,ensure_ascii=False),encoding='utf8')
def fstr(x):return str(x)
def get_oracles(m,u,v,T):
    k,al,be,et,ro,sign=map(float,(m.k,m.alpha,m.beta,m.eta,m.rho,m.branch))
    def rhs(t,y):
        x,u,v=y;return [sign*np.sqrt(1+x)-x+al*u,k*(-u+be*v),k*(et*x-ro*v)]
    def jac(t,y):return [[sign/(2*np.sqrt(1+y[0]))-1,al,0],[0,-k,k*be],[k*et,0,-k*ro]]
    r=solve_ivp(rhs,(0,float(T)),[0,float(u),float(v)],method='Radau',jac=jac,rtol=5e-14,atol=1e-15,dense_output=True)
    d=solve_ivp(rhs,(0,float(T)),[0,float(u),float(v)],method='DOP853',rtol=5e-14,atol=1e-15,dense_output=True)
    assert r.success and d.success
    return r,d

def run_case(name,kwargs,u,v,policy='DENSITY',mode='RVJ_FIRST',eps=F(1,10**6),cap=None):
    m=Model(**kwargs);T=F(1,4)
    r=integrate(m,F(u),F(v),eps,T,certificate_policy=policy,mode_policy=mode,cap_pattern=cap,max_attempts=4000)
    if r['status']!='COMPLETED':
        ret={'name':name,'status':r['status'],'t':str(r['state'].t),'steps':len(r['history']),'work':r['work']};dump(OUT/(name+'_'+policy+'_'+mode+'.json'),ret);return ret
    a,b=get_oracles(m,u,v,T)
    times=np.array([float(c['output'].t) for c in r['history']]);ya=a.sol(times).T;yb=b.sol(times).T
    oracle_delta=float(np.max(np.abs(ya-yb)));slack=max(2e-14,4*oracle_delta)
    maxerr=np.zeros(3);maxnorm=0.;maxratio=0.;rawbad=0;interiorbad=0;rootbad=0;wholepts=0;trace=[]
    for i,c in enumerate(r['history']):
        st=c['output'];yy=ya[i];z=np.array(list(map(float,c['physical'])));bd=np.array(list(map(float,c['physical_bounds'])))
        exact=np.array([yy[0],yy[1]+yy[0]**2/float(m.k),yy[2]+yy[0]**3/float(m.k)])
        er=np.abs(exact-z);maxerr=np.maximum(maxerr,er);maxratio=max(maxratio,float(np.max(er/bd)))
        rawbad+=int(np.any(er>bd));assert np.all(er<=bd+4*slack)
        maxnorm=max(maxnorm,float(m.norm(tuple(F(float(st.y[j])-yy[j]) for j in range(3)))))
        for th in [F(0),F(1,4),F(1,2),F(3,4),F(1)]:
            t=float(st.t-c['h']+th*c['h']);exactpath=a.sol(t)
            pp=np.array([float(value(p,th)) for p in c['candidate']['p']]);norm=np.max(np.abs(pp-exactpath)/np.array(list(map(float,m.units))))
            if norm>float(c['whole']):interiorbad+=1
            assert norm<=float(c['whole'])+slack*max(1,float(1/m.weight))
            qp=float(value(c['candidate']['q'],th));qtrue=m.branch*np.sqrt(1+exactpath[0])
            if abs(qp-qtrue)>float(c['closure_whole']):rootbad+=1
            assert abs(qp-qtrue)<=float(c['closure_whole'])+4*slack
            wholepts+=1
        exact_fingerprint=hashlib.sha256(repr((c['candidate'],c['defects'],c['whole'],c['radius'],c['physical_bounds'])).encode()).hexdigest()
        trace.append({'t':str(st.t),'h':str(c['h']),'y':list(map(str,st.y)),'norm_error_bound':str(st.error),
                      'physical':list(map(str,c['physical'])),'physical_bounds':list(map(str,c['physical_bounds'])),
                      'criterion_value_upper128':str(up(c['criterion_value'],128)),'criterion_budget':str(c['criterion_budget']),
                      'mode':c['mode'],'whole_upper128':str(up(c['whole'],128)),
                      'certificate_fingerprint':exact_fingerprint})
    result={'name':name,'status':'COMPLETED','certificate_policy':policy,'mode_policy':mode,'tolerance':str(eps),
      'model':{k:str(getattr(m,k)) for k in ['k','alpha','beta','eta','rho','branch','weight']},'initial_fast':[str(u),str(v)],
      'steps':len(r['history']),'mode_counts':dict(Counter(c['mode'] for c in r['history'])),'rejected_candidates':len(r['rejects']),
      'min_h':str(min(c['h'] for c in r['history'])),'max_h':str(max(c['h'] for c in r['history'])),
      'mesh_distinct_lengths':len(set(c['h'] for c in r['history'])),'max_physical_errors':maxerr.tolist(),
      'max_physical_error_bound_ratio_numeric':maxratio,'max_norm_error_numeric':maxnorm,
      'oracle_difference':oracle_delta,'oracle_numerical_slack':slack,'raw_endpoint_violations':rawbad,
      'raw_interior_violations':interiorbad,'raw_root_violations':rootbad,'whole_path_samples':wholepts,
      'all_comparisons_with_numerical_slack':True,'oracle_is_not_formally_validated':True,
      'oracle_radau_evaluations':a.nfev,'oracle_dop853_evaluations':b.nfev,
      'work':r['work'],'steps_trace':trace}
    filename=name+'_'+policy+'_'+mode+'_'+str(eps.denominator)+'.json';dump(OUT/filename,result)
    print(name,policy,mode,'steps',result['steps'],'modes',result['mode_counts'],'err',maxerr.tolist(),'ratio',maxratio,'rawbad',rawbad,interiorbad,rootbad,flush=True)
    return {k:v for k,v in result.items() if k!='steps_trace'}

if __name__=='__main__':
    args=sys.argv[1:] or ['main']
    if args[0]=='main':
        rows=[]
        for name,m,u,v in CASES:
            for policy in (['DENSITY','INVARIANT'] if name in ['k1','k40','k400','k10000'] else ['INVARIANT']):
                rows.append(run_case(name,m,u,v,policy))
        dump(OUT/'MAIN_RESULTS.json',rows)
    elif args[0]=='hybrid':
        rows=[run_case('hybrid_k'+str(k),dict(k=k),0,1,'INVARIANT','TAYLOR_FIRST') for k in [1,40,400,10000]]
        dump(OUT/'HYBRID_RESULTS.json',rows)
    elif args[0]=='aux':
        rows=[run_case('tol_'+str(n),dict(k=400),0,1,'INVARIANT',eps=F(1,10**n)) for n in [4,6,8]]
        rows +=[run_case('cap',dict(k=40),0,1,'INVARIANT',cap=[F(1,512),F(1,256)])]
        dump(OUT/'AUX_RESULTS.json',rows)
