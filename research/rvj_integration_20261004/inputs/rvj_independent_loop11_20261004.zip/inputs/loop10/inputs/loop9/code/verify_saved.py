"""Recompute every primary amplitude path from final source, without numeric oracles."""
from modal import *
from pathlib import Path
import json
E=Path('../evidence');rows=[]
for path in sorted(E.glob('case_*.json')):
 o=json.loads(path.read_text());md=o['model'];m=Model(**{k:(int(v) if k in ('epoch','sigma') else F(v)) for k,v in md.items()})
 r=integrate(m,T=F(o['T']),tol=F(o['tol']),policy=o['policy']);assert r['work']==o['work'];assert r['accepted']==o['accepted']
 for c,v in zip(r['history'],o['records']):
  assert str(c['new'].t)==v['t'] and str(c['h'])==v['h'] and list(map(str,c['new'].a))==v['a']
  assert str(c['new'].error)==v['error'] and str(c['delta'])==v['defect'] and c['mode']==v['mode'] and c['path_digest']==v['path_digest']
 rows.append({'name':o['name'],'steps':r['accepted'],'exact_final_source_agreement':True})
(E/'final_source_replay.json').write_text(json.dumps({'cases':len(rows),'steps':sum(x['steps'] for x in rows),'checks':'stored state, mesh, mode, current path, defect, error bound, all counted work','records':rows},indent=2))
print('final source agrees exactly with',len(rows),'cases and',sum(x['steps'] for x in rows),'accepted steps')
