from fractions import Fraction as F
import pytest
from semantic_controls import endpoint_forcing_error, nodal_noise_norm

def test_same_endpoint_forcing_does_not_have_zero_convolution_error():
    # zero at both endpoints but a nonzero time integral
    assert endpoint_forcing_error((F(0),F(6),F(-6))) == 1

def test_extrapolation_does_not_inherit_interior_interpolation_conditioning():
    nodes=tuple(F(-j) for j in range(5))
    assert nodal_noise_norm(nodes,F(1)) == 31
