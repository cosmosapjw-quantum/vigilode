"""Integrated feedback charge. Endpoint discrepancy is a separate output contract."""
from fractions import Fraction as F

def feedback_charge(endpoint_error, integrated_path_error, coupling):
    endpoint_error,integrated_path_error,coupling=map(F,(endpoint_error,integrated_path_error,coupling))
    if endpoint_error<0 or integrated_path_error<0:
        raise ValueError('error bounds must be nonnegative')
    return abs(coupling)*integrated_path_error
