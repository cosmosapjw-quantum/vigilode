from fractions import Fraction as F
from twoway import Model,invariant_box_radius

def test_fast_defect_gain_is_damped_before_physical_budget():
    m=Model(k=10000)
    ds=(F(0),F(0),F(1,100))
    # Weighted fast defect is 0.01; k*(b*s-eta)=625.
    r=invariant_box_radius(m,ds,F(0),F(1,4))
    assert r==F(1,62500),f'undamped time-density bound reused: {r}'


def test_supersolution_contains_inherited_error_without_reset():
    from twoway import Model, invariant_box_radius
    m=Model(k=10000)
    assert invariant_box_radius(m,(F(0),F(0),F(0)),F(1,100),F(1,4))==F(1,100)


def test_both_actual_comparison_rows_point_inward():
    from twoway import Model, invariant_box_radius, A_SLOW
    for k in [1,40,10000]:
        m=Model(k=k);ds=(F(1,10000),F(1,10),F(1,100))
        z=invariant_box_radius(m,ds,F(1,100000),F(1,8))
        dw=max(ds[1]/m.d,ds[2])
        assert -A_SLOW*z+m.c*m.weight*z+ds[0]<=0
        assert m.k*abs(m.eta)*z-m.k*m.b*m.weight*z+dw<=0


def test_stored_rounding_is_added_after_the_barrier():
    from twoway import Model, State, initial_state, make_jet, make_candidate, certify
    m=Model();s=initial_state(m);s=State(s.t,s.y,F(1,10**9),0);h=F(1,32)
    c=certify(m,s,h,make_candidate(make_jet(m,s.y,h)),F(1,10**6),F(1,4),certificate_policy='INVARIANT')
    assert c['valid']
    assert c['radius']>=c['whole']+c['rounding']
    assert c['radius']>=s.error
    assert c['criterion_value']<=c['criterion_budget']


def test_invalid_residuals_fail_closed():
    import pytest
    from twoway import Model, invariant_box_radius, ContractError
    for ds,e,h in [((F(-1),F(0),F(0)),0,1),((F(0),F(0)),0,1),((F(0),F(0),F(0)),-1,1),((F(0),F(0),F(0)),0,0)]:
        with pytest.raises(ContractError):invariant_box_radius(Model(),ds,e,h)
