#!/usr/bin/env python3
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
from dataclasses import asdict,is_dataclass
import sys,json,hashlib,time,platform
import mpmath as mp
import sympy as sp
from hybrid_rvj import *
from witness_lift import *
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'EVIDENCE'
OUT.mkdir(exist_ok=True)
mp.mp.dps=140

def mm(v):return mp.mpf(v.numerator)/v.denominator

def encode(o):
    if isinstance(o,F):return str(o)
    if is_dataclass(o):return {k:encode(v) for k,v in asdict(o).items()}
    if isinstance(o,dict):return {k:encode(v) for k,v in o.items()}
    if isinstance(o,(list,tuple)):return [encode(v) for v in o]
    return o

def save(name,obj):
    (OUT/name).write_text(json.dumps(encode(obj),indent=2,ensure_ascii=False))

# Source-bound selected identities, not the missing full PR11 runner.
u,la,s,a,x,h,t=sp.symbols('u la s a x h t')
source=[]
source.append({'id':'v12_cubic_discriminant','passed':sp.discriminant(u**3-3*u-la,u)==27*(4-la**2)})
source.append({'id':'v12_fold_expansion','passed':sp.expand((u**3-3*u-la).subs({u:-1+s,la:2+a}))==s**3-3*s**2-a})
source.append({'id':'v12_fold_at_2','passed':sp.expand((u-2)*(u+1)**2)==u**3-3*u-2})
for r in [sp.Rational(1,20),sp.Rational(1,10),sp.Rational(1,5),sp.Rational(1,4),sp.Rational(3,10)]:
    y2=(r-1)*(r+1)*(3*r-1)**3/(3*r+1)**3
    slope2=-r*(3*r-1)*(9*r**3+9*r**2+3*r-5)**2/(16*(r+1)*(3*r+1)**2)
    source.append({'id':'v12_low_r_positivity_'+str(r),'passed':bool(y2>0 and slope2>0)})
# An independent finite-field engine supplied in the ZIP.
sys.path.insert(0,str(ROOT/'sources'/'curved_mirror_v12'/'reproducibility'))
from modgb import groebner, quotient_dimension, is_unit_ideal
# Monomial dict for u^3-3u at lambda=0 modulo three good primes.
for prime in (101,103,107):
    gb=groebner([{(3,):1,(1,):(-3)%prime}],prime)
    # Signature inspected below if this check requires adaptation; do not hide failure.
    dim=quotient_dimension(gb,prime)
    simple=is_unit_ideal([{(3,):1,(1,):(-3)%prime},{(2,):3,(0,):(-3)%prime}],prime)
    source.append({'id':'modgb_three_simple_witnesses_'+str(prime),'passed':dim==3 and simple,'dimension':dim,'derivative_unit_ideal':simple})
save('source_selected_checks.json',source)
assert all(x['passed'] for x in source)

q=1+3*a/5+3*a*a/20+a**3/60;p=1-2*a/5+a*a/20
I=sp.integrate(sp.exp(-a*t)*t**3*(1-t)**2,(t,0,1))
identity=sp.simplify((p-q*sp.exp(-a)-a**6*I/120).subs(a,sp.Symbol('positive_a',positive=True)))
slow=sp.Symbol('xx')
# Use rational substitution checks plus exact formula factorization.
aa=sp.symbols('aa');Q2=1-6*aa/5+3*aa**2/5-2*aa**3/15
phi=(4*aa**2-10*aa+12)/(1440*Q2)
U=1+aa+aa**2+aa**3+aa**4+120*aa**5*phi
expected=-aa**6*(19-17*aa+6*aa**2)/(30*(1-aa)*Q2)
alg=[{'id':'Pade_integral_identity','passed':identity==0},
     {'id':'slow_exact_defect','passed':sp.cancel(U-1/(1-aa)-expected)==0},
     {'id':'Pade_stiff_limit','passed':sp.limit(a*p/q,a,sp.oo)==3}]
save('algebra_checks.json',alg);assert all(z['passed'] for z in alg)

runs=[];traces={}
for k in (1,40,10000):
  for w0 in (0,1,-1):
    o=integrate(F(k),F(w0));maxratio=mp.mpf(0);maxerr=mp.mpf(0)
    for row in o['history']:
        s=row['state'];ex=1/(1-mm(s.t));ew=mp.mpf(w0)*mp.exp(-k*mm(s.t));ey=ex**2*(ew+mp.mpf(1)/k)
        err=abs(mm(row['y'])-ey);bd=mm(row['y_error'])
        assert err<=bd
        assert abs(mm(s.x)-ex)<=mm(s.rx)
        assert abs(mm(s.w)-ew)<=mm(s.rw)
        if bd:maxratio=max(maxratio,err/bd)
        maxerr=max(maxerr,err)
    r=dict(kappa=k,w0=w0,tolerance='1e-8',accepted=o['accepted'],rejected=len(o['rejected']),
           modes=o['modes'],exp_calls=o['exp_calls'],enclosure_ops=o['enclosure_ops'],
           max_physical_error=mp.nstr(maxerr,30),max_error_to_bound=mp.nstr(maxratio,30),
           last_bound=float(o['history'][-1]['y_error']),
           nonzero_fast_amplitude_preserved=(bool(o['state'].w) if w0 else o['state'].w==0),
           candidate_comparison='model-specific exact-rational certificate; 140-digit independent oracle only in audit')
    runs.append(r);traces[f'k{k}_w{w0}']={'history':o['history'],'rejected':o['rejected']}
save('adaptive_runs.json',runs);save('adaptive_traces.json',traces)
# Accuracy-adaptive response and no-oracle same-prefix replay.
refinement=[]
for tol in (F(1,10**6),F(1,10**8),F(1,10**10)):
    o=integrate(F(10000),F(1),tol=tol)
    refinement.append({'tol':str(tol),'steps':o['accepted'],'modes':o['modes'],
                       'physical_bound_final':str(o['history'][-1]['y_error'])})
save('tolerance_refinement.json',refinement)

loops=[];looptraces={}
for center in (0,2):
    ll=mp.mpf(center)+mp.mpf(1)/4
    roots=mp.polyroots([1,0,-3,-ll],maxsteps=500)
    starts=[C(F(str(mp.re(r))),F(str(mp.im(r)))).rounded() for r in roots]
    o=certified_loop(F(center),starts)
    perm=o['permutation']
    assert (perm==list(range(3))) if center==0 else (sum(i!=j for i,j in enumerate(perm))==2)
    loops.append({'center':center,'permutation':perm,'certified_slabs':o['slabs'],
                  'all_slabs_certified':o['all_slabs_certified'],'initial_witnesses':o['initial'],
                  'path':'counterclockwise square of radius 1/4, homotopic to source meridian'})
    looptraces[str(center)]=o['root_traces']
save('witness_loops.json',loops);save('witness_trace_certificates.json',looptraces)
save('fold_event.json',approach_real_fold())

# Preserve the original no-go in its original coordinates, not the repaired map.
sys.path.insert(0,str(ROOT/'sources'/'rvj_loop3'))
from reference_rvj import AnalyticRVJ
xx,yy,kk=sp.symbols('xx yy kk');raw=AnalyticRVJ((xx,yy),(kk,),sp.Matrix([xx*xx,(-kk+2*xx)*yy+xx*xx]))
no_go=[]
for n in (32,64,128,256):
    hh=mp.mpf(1)/n;k=hh**-6;state=mp.matrix([1,1/k])
    for _ in range(2):state=raw.step(state,hh,(k,))
    val=(state[1]-1/(k*(1-2*hh)**2))/hh**3
    no_go.append({'N':n,'error_over_h3':mp.nstr(val,40)})
assert abs(mp.mpf(no_go[-1]['error_over_h3'])-mp.mpf(4)/3)<mp.mpf('0.02')
save('inherited_negative_control.json',no_go)
print(json.dumps({'source_selected':len(source),'algebra':len(alg),'adaptive_cases':len(runs),
                  'witness_slabs':sum(t['certified_slabs'] for t in loops),'no_go_cases':len(no_go),
                  'modes':[{'k':r['kappa'],'w':r['w0'],**r['modes']} for r in runs]},indent=2))
