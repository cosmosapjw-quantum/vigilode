from fractions import Fraction as F
from dataclasses import replace
import pytest
from feedback import *
from comparison import feedback_box
from polynomial import value

@pytest.mark.parametrize('rate',[1,2])
@pytest.mark.parametrize('alpha',[F(1,4),F(-1,4),F(0)])
def test_primitive_row_exactly_recovers_feedback(rate,alpha):
    m=Model(40,-4,rate,alpha)
    for w in [(F(2),F(-3)),(F(0),F(1))]:
        assert m.ell_dot(m.A(w))==m.alpha*w[0]

def test_initial_lift_keeps_nonzero_fast_memory():
    m=Model(10**6,4,1,1)
    s=initial(m,1)
    assert s.z>0
    assert abs(s.z+m.ell_dot(s.w))<=s.ez
    assert s.z>=F(39,10**7)

@pytest.mark.parametrize('rate',[1,2])
def test_resolved_jet_matches_initial_state_and_first_derivative(rate):
    m=Model(40,4,rate,F(1,4));s=initial(m,1)
    c=make_candidate(s,F(1,100),m,'RESOLVED_JET')
    assert c['valid']
    assert c['xi'][0]==s.z+m.ell_dot(s.w)
    assert c['p'][1]/F(1,100)==c['q'][0]-c['xi'][0]

def test_outer_mode_does_not_evaluate_unphysical_shifted_root():
    m=Model(1,20,1,1);s=initial(m,1)
    c=make_candidate(s,F(1,8),m,'LIFTED_OUTER')
    assert not c['valid'] and c['reason']=='CANDIDATE_BASE_OUTSIDE_CHART'

def test_integrated_transient_gains_extra_inverse_rate():
    m1=Model(1000);m2=Model(10000)
    _,a=outer_shift_bounds((F(0),F(1)),F(1,8),m1)
    _,b=outer_shift_bounds((F(0),F(1)),F(1,8),m2)
    assert a==100*b

def test_zero_feedback_zero_transient_bound():
    m=Model(1,4,1,0)
    assert outer_shift_bounds((F(1),F(2)),F(1,8),m)==(0,0)
    assert m.ellnorm==0

@pytest.mark.parametrize('k',[1,40,10000,1000000])
def test_decay_gain_integral_contract(k):
    m=Model(k);h=F(1,8)
    assert 0<=endpoint_gain(h,m)<=1
    assert 0<decay_integral(h,m)<=h

@pytest.mark.parametrize('branch',[-1,1])
def test_high_rate_accepts_a_finite_outer_slow_step(branch):
    m=Model(1000000);s=initial(m,branch);tr=attempt(s,F(1,64),m,F(1,10**8),F(1,4),96)
    assert tr['accepted']
    assert tr['slow']['mode']=='LIFTED_OUTER'
    assert tr['fast']['mode']=='EXP_ENCLOSURE'
    assert s.generation==0 and commit(s,tr).generation==1
    assert tr['slow']['root_path_error']>0

def test_rejected_trial_is_atomic():
    m=Model(40);s=initial(m,1);digest=s.digest()
    tr=attempt(s,F(1,8),m,F(1,10**12),F(1,4),96)
    assert not tr['accepted'] and digest==s.digest()
    with pytest.raises(ContractError):commit(s,tr)

def test_epoch_mismatch_rejected_before_candidate():
    m=Model(1);s=initial(m,1)
    with pytest.raises(ContractError):attempt(s,F(1,64),replace(m,epoch='new'),F(1,10**6),F(1,4))

def test_stale_commit_and_wrong_branch_rejected():
    m=Model(1000000);s=initial(m,1);tr=attempt(s,F(1,64),m,F(1,10**6),F(1,4),96)
    assert tr['accepted']
    with pytest.raises(ContractError):commit(replace(s,generation=1),tr)
    bad=dict(tr);bad['snapshot']=replace(tr['snapshot'],branch=-1)
    with pytest.raises(ContractError):commit(s,bad)

def test_inherited_fast_radius_charged_to_slow_path():
    m=Model(1000000);s=replace(initial(m,1),ew=F(1,10**12));h=F(1,64)
    c=make_candidate(s,h,m,'LIFTED_OUTER',96);b=certify(s,h,m,c,96)
    assert b['valid'] and b['inherited_cross']==LIP*m.ellnorm*s.ew*decay_integral(h,m)

def test_small_gain_certificate_and_failure_are_distinct():
    c=feedback_box(0,0,F(1,100),F(1,100),F(1,4),1,100,2,3)
    assert c['closed'] and c['gain_upper']<1
    bad=feedback_box(0,0,1,1,1,1,1,2,2)
    assert not bad['closed'] and bad['reason']=='SMALL_GAIN_NOT_ESTABLISHED'

def test_small_gain_bounds_satisfy_declared_inequalities():
    a=feedback_box(F(1,100),F(1,50),F(1,20),F(1,30),F(1,5),1,10,2,3)
    assert a['closed']
    assert a['x'] == F(1,100)+a['psi_slow_upper']*(F(1,20)+2*a['w'])
    assert a['w'] == F(1,50)+a['psi_fast_upper']*(F(1,30)+3*a['x'])

def test_coefficient_tampering_defect_does_not_disappear():
    m=Model(1000000);s=initial(m,1);h=F(1,64)
    c=make_candidate(s,h,m,'LIFTED_OUTER',96)
    normal=certify(s,h,m,c,96)
    bad=dict(c);p=list(c['p']);p[1]+=F(1,100);bad['p']=tuple(p);bad['xi']=tuple(p)
    out=certify(s,h,m,bad,96)
    assert not out['valid'] or out['local_error']>normal['local_error']*100

def test_no_future_oracle_import_in_implementation():
    import inspect,feedback
    src=inspect.getsource(feedback)
    assert 'import mpmath' not in src and 'from scipy' not in src

def test_bad_model_and_negative_error_fail_closed():
    with pytest.raises(ContractError):Model(0)
    with pytest.raises(ContractError):Model(1,4,3)
    with pytest.raises(ValueError):feedback_box(-1,0,0,0,1,1,1,1,1)

def test_split_reserve_is_committed_once_and_is_immutable_on_rejection():
    m=Model(1000000);s=initial(m,1,budget_policy='split_reserve')
    tr=attempt(s,F(1,128),m,F(1,10**10),F(1,4),112)
    assert tr['accepted'] and tr['slow']['mode']=='LIFTED_OUTER'
    assert s.spent_transient==0
    new=commit(s,tr)
    assert new.spent_transient==tr['slow']['transient_error']>0
    assert new.spent_transient<=F(3,4)*budgets(m,F(1,10**10),F(1,4))[0]
    with pytest.raises(ContractError):commit(new,tr)

def test_split_reserve_cannot_be_reused_after_spending_or_policy_change():
    m=Model(1000000);s=initial(m,1,budget_policy='split_reserve');ez,_=budgets(m,F(1,10**10),F(1,4))
    s=replace(s,spent_transient=3*ez/4)
    tr=attempt(s,F(1,128),m,F(1,10**10),F(1,4),112,forced_mode='LIFTED_OUTER')
    assert not tr['accepted'] and s.spent_transient==3*ez/4

def test_exact_lift_has_no_unmodelled_residual_forcing():
    from comparison import inexact_lift_charge
    m=Model(10000);assert inexact_lift_charge(F(1,8),m,m.ell,(0,1),F(1,10**10))==0

def test_approximate_lift_residual_cannot_be_silently_ignored():
    from comparison import inexact_lift_charge
    m=Model(10000);ell_hat=tuple(F(101,100)*v for v in m.ell)
    charge=inexact_lift_charge(F(1,8),m,ell_hat,(0,1),0)
    assert charge==F(1,500000)  # weighted current-operator residual, not epsilon-J folklore
