"""Phase-equivariant resonant two-mode ODE with signed algebraic closure.

All model coefficients are rational. The exact carrier is NOT a Taylor mode.
This is an exploratory small-matrix reference, not a production AD/Krylov code.
No future exact trajectory is used by candidate or certificate functions.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import factorial
import hashlib
from polynomial import add,scale,mul,deriv,value,abs_bound,bernstein_range,sqrt_interval
from loop4_scalar import nearest,up,down,pow2,exp_minus_interval,PrecisionBlocked
from policy import carrier_uncertainty_charge

WEIGHTS=(F(1),F(1),F(2),F(2))
ZERO=(F(0),)

def norm2(a):return sum((w*x*x for w,x in zip(WEIGHTS,a)),F(0))
def norm_up(a,bits=128):return sqrt_interval(norm2(a),bits)[1]
def vec_add(a,b):return tuple(x+y for x,y in zip(a,b))

def digest(obj):return hashlib.sha256(repr(obj).encode()).hexdigest()

@dataclass(frozen=True)
class Model:
    g:F=F(1,2)
    delta:F=F(0)
    gamma1:F=F(0)
    gamma2:F=F(0)
    sigma:int=1
    epoch:int=0
    def __post_init__(self):
        for k in ('g','delta','gamma1','gamma2'):object.__setattr__(self,k,F(getattr(self,k)))
        if min(self.gamma1,self.gamma2)<0 or self.sigma not in (-1,1):raise ValueError('nonnegative damping, signed regular branch required')
    def binding(self):return digest(self)
    @property
    def growth(self):return max(F(0),4*abs(self.g)-min(self.gamma1,self.gamma2))

@dataclass(frozen=True)
class State:
    t:F
    a:tuple[F,...]
    error:F=F(0)
    generation:int=0
    def digest(self):return digest(self)

def initial_state():return State(F(0),(F(1,2),F(0),F(1,4),F(1,8)))

def linear(m):
    return [[-m.gamma1,F(0),F(0),F(0)],
            [F(0),-m.gamma1,F(0),F(0)],
            [F(0),F(0),-m.gamma2,-m.delta],
            [F(0),F(0),m.delta,-m.gamma2]]

def nonlinear(a):
    x,y,u,v=a
    return (y*u-x*v,x*u+y*v,-x*y,(x*x-y*y)/2)

def rhs(a,q,m):
    L=linear(m);H=nonlinear(a)
    return tuple(sum((L[i][j]*a[j] for j in range(4)),F(0))+m.g*q*H[i] for i in range(4))

def polyrhs(p,r,m):
    x,y,u,v=p
    H=(add(mul(y,u),scale(mul(x,v),-1)),add(mul(x,u),mul(y,v)),scale(mul(x,y),-1),scale(add(mul(x,x),scale(mul(y,y),-1)),F(1,2)))
    L=linear(m);out=[]
    for i in range(4):
        z=scale(mul(r,H[i]),m.g)
        for j in range(4):z=add(z,scale(p[j],L[i][j]))
        out.append(z)
    return tuple(out)

def jet(a,m,order=5,bits=128):
    lo,hi=sqrt_interval(1+norm2(a),bits)
    q0=m.sigma*(lo+hi)/2
    p=[[v] for v in a];r=[q0]
    for n in range(order):
        if n:
            ac=sum((WEIGHTS[j]*sum((p[j][k]*p[j][n-k] for k in range(n+1)),F(0)) for j in range(4)),F(0))
            r.append((ac-sum((r[k]*r[n-k] for k in range(1,n)),F(0)))/(2*q0))
        ff=polyrhs(tuple(map(tuple,p)),tuple(r),m)
        for j in range(4):p[j].append((ff[j][n] if n<len(ff[j]) else F(0))/(n+1))
    n=order
    ac=sum((WEIGHTS[j]*sum((p[j][k]*p[j][n-k] for k in range(n+1)),F(0)) for j in range(4)),F(0))
    r.append((ac-sum((r[k]*r[n-k] for k in range(1,n)),F(0)))/(2*q0))
    return tuple(map(tuple,p)),tuple(r)

def jacobian(a,q,m):
    x,y,u,v=a
    DH=[[-v,u,y,-x],[u,v,x,y],[-y,-x,F(0),F(0)],[x,-y,F(0),F(0)]]
    H=nonlinear(a);dq=[x/q,y/q,2*u/q,2*v/q];L=linear(m)
    return [[L[i][j]+m.g*(q*DH[i][j]+H[i]*dq[j]) for j in range(4)] for i in range(4)]

def mm(A,B):
    return [[sum((A[i][k]*B[k][j] for k in range(4)),F(0)) for j in range(4)] for i in range(4)]
def mv(A,x):return tuple(sum((A[i][j]*x[j] for j in range(4)),F(0)) for i in range(4))
def solve(A,b):
    rows=[list(A[i])+[b[i]] for i in range(4)]
    for k in range(4):
        piv=next((i for i in range(k,4) if rows[i][k]),None)
        if piv is None:raise PrecisionBlocked('singular exact RVJ denominator')
        rows[k],rows[piv]=rows[piv],rows[k]
        d=rows[k][k];rows[k]=[v/d for v in rows[k]]
        for i in range(4):
            if i!=k:
                c=rows[i][k];rows[i]=[rows[i][j]-c*rows[k][j] for j in range(5)]
    return tuple(r[-1] for r in rows)

def candidate(state,h,m,mode,bits):
    P,R=jet(state.a,m,bits=bits)
    p=tuple(tuple(c*h**j for j,c in enumerate(row)) for row in P)
    r=tuple(c*h**j for j,c in enumerate(R))
    if mode=='RVJ':
        J=jacobian(state.a,R[0],m);Z=[[h*x for x in row] for row in J];Z2=mm(Z,Z);Z3=mm(Z2,Z)
        Q=[[F(i==j)-F(3,5)*Z[i][j]+F(3,20)*Z2[i][j]-Z3[i][j]/60 for j in range(4)] for i in range(4)]
        N=[[Z2[i][j]-5*Z[i][j]+12*F(i==j) for j in range(4)] for i in range(4)]
        a5=tuple(row[5] for row in P)
        z=solve(Q,mv(N,a5))
        p=tuple(tuple(row)+(h**5*(z[i]/12-a5[i]),) for i,row in enumerate(p))
    elif mode!='TAYLOR':raise ValueError('unknown mode')
    return p,r

def exp_upper(x,bits=128):
    if x<0:raise ValueError('nonnegative growth argument required')
    lo,hi,_=exp_minus_interval(x,bits)
    if lo<=0:raise PrecisionBlocked('growth factor outside interval resource cap')
    return up(1/lo,bits)

def curve_binding(state,h,m,p,r):return digest((state.digest(),h,m.binding(),p,r))

def attempt(state,h,m,T,tol,mode='RVJ',bits=112):
    h,T,tol=map(F,(h,T,tol))
    if h<=0 or T<=0 or tol<=0 or state.error<0 or len(state.a)!=4 or state.t<0 or state.t+h>T or bits<48:raise ValueError('invalid step/initial data contract')
    if norm2(state.a)>1:return dict(accepted=False,reason='INITIAL_DOMAIN')
    p,r=candidate(state,h,m,mode,bits+16)
    pp=ZERO
    for w,row in zip(WEIGHTS,p):pp=add(pp,scale(mul(row,row),w))
    pupper=bernstein_range(pp)[1]
    rmin=bernstein_range(scale(r,m.sigma))[0]
    if pupper>1 or rmin<F(1,2):return dict(accepted=False,reason='CURVE_OR_BRANCH_DOMAIN',mode=mode)
    ff=polyrhs(p,r,m)
    dv=tuple(abs_bound(add(scale(deriv(p[i]),1/h),scale(ff[i],-1))) for i in range(4))
    gg=add(add(mul(r,r),(-F(1),)),scale(pp,-1));Dg=abs_bound(gg)
    Df=norm_up(dv,bits+16)
    defect=up(Df+abs(m.g)*Dg/(rmin+1),bits+16)
    gain=exp_upper(m.growth*h,bits+16)
    whole_error=up(gain*(state.error+h*defect),bits+16)
    raw=tuple(value(row,F(1)) for row in p); aa=tuple(nearest(v,bits) for v in raw)
    rounding=norm_up(tuple(x-y for x,y in zip(raw,aa)),bits+16)
    propagated=up(gain*state.error,bits+16)
    newerr=up(whole_error+rounding,bits)
    local=newerr-gain*state.error
    global_gain=exp_upper(m.growth*T,bits+16)
    budget=tol*h/(4*T*global_gain)
    if local>budget or newerr>tol/4:
        return dict(accepted=False,reason='ERROR_BUDGET',mode=mode,local=local,budget=budget)
    new=State(state.t+h,aa,newerr,state.generation+1)
    return dict(accepted=True,mode=mode,new=new,h=h,p=p,r=r,delta=defect,differential_bound=Df,algebraic_bound=Dg,
                q_min=rmin,curve_norm2_upper=pupper,whole_error=whole_error,endpoint_error=newerr,
                local=local,budget=budget,input_digest=state.digest(),model_binding=m.binding(),
                path_digest=curve_binding(state,h,m,p,r),gain=gain,stored_rounding=rounding,
                endpoint_binding=digest((new,curve_binding(state,h,m,p,r))))

def commit(state,c,m):
    if not c.get('accepted') or state.digest()!=c.get('input_digest') or m.binding()!=c.get('model_binding'):
        raise ValueError('unaccepted, stale snapshot, wrong model epoch or branch')
    if curve_binding(state,c['h'],m,c['p'],c['r'])!=c['path_digest'] or c['new'].generation!=state.generation+1:
        raise ValueError('wrong path or generation')
    if digest((c['new'],c['path_digest']))!=c.get('endpoint_binding'):
        raise ValueError('changed stored endpoint or error bound')
    return c['new']

def integrate(m,T=F(1,2),tol=F(1,10**6),policy='RVJ_FIRST',bits=112,max_attempts=10000,step_cap=F(1,8)):
    T,tol,step_cap=map(F,(T,tol,step_cap))
    if not 0<T<=1 or tol<=0 or step_cap<=0 or max_attempts<1 or policy not in ('RVJ_FIRST','TAYLOR_FIRST'):raise ValueError('invalid integration contract')
    s=initial_state();h=min(step_cap,T); history=[];reject=[];work={'candidate_builds':0,'small_solves':0,'certificates':0,'rejected_candidates':0}
    modes=('RVJ','TAYLOR') if policy=='RVJ_FIRST' else ('TAYLOR','RVJ')
    for _ in range(max_attempts):
        if s.t==T:break
        h=min(h,T-s.t);c=None;d=s.digest()
        for mode in modes:
            work['candidate_builds']+=1;work['small_solves']+=int(mode=='RVJ');work['certificates']+=1
            out=attempt(s,h,m,T,tol,mode,bits)
            if out['accepted']:c=out;break
            work['rejected_candidates']+=1;reject.append(dict(t=s.t,h=h,**out))
            if s.digest()!=d:raise AssertionError('rejected state mutation')
        if c is None:
            h/=2
            if h<pow2(-bits//3):raise PrecisionBlocked('step floor')
            continue
        history.append(c);s=commit(s,c,m)
        if c['local']<c['budget']/64:h=min(2*h,step_cap)
    else:raise PrecisionBlocked('attempt cap')
    return dict(model=m,state=s,history=history,rejected=reject,work=work,accepted=len(history),tol=tol,T=T,policy=policy)

# Certified scalar carrier using exact Taylor intervals and repeated angle doubling.
# No pi or floating argument reduction is required for exact-rational omega*t.
def imul(a,b):
    vals=[x*y for x in a for y in b];return min(vals),max(vals)
def iadd(a,b):return a[0]+b[0],a[1]+b[1]
def ineg(a):return -a[1],-a[0]
def iscale(a,c):return imul(a,(c,c))
def iround(a,bits):return down(a[0],bits),up(a[1],bits)

def rotate_interval(angle,bits=112,max_doublings=4096):
    angle=F(angle)
    if bits<48:raise ValueError('insufficient precision')
    if not angle:return dict(cos=(F(1),F(1)),sin=(F(0),F(0)),doublings=0,terms=0)
    s=0;r=abs(angle)
    while r>F(1,8):
        r/=2;s+=1
        if s>max_doublings:raise PrecisionBlocked('carrier reduction cap')
    # remainder for truncated complex exponential: sum absolute tail <= 2 r^(n+1)/(n+1)! when r<=1/8.
    c=F(1);sn=F(0);power=F(1)
    for n in range(1,4*bits):
        power*=r/n
        if n%4==0:c+=power
        elif n%4==1:sn+=power
        elif n%4==2:c-=power
        else:sn-=power
        tail=2*power*r/(n+1)
        if tail<pow2(-(bits+2*s+16)):break
    else:raise PrecisionBlocked('carrier series cap')
    workbits=bits+2*s+16
    C=iround((c-tail,c+tail),workbits);S=iround((sn-tail,sn+tail),workbits)
    for _ in range(s):
        C2=iadd(imul(C,C),ineg(imul(S,S)));S2=iscale(imul(S,C),F(2))
        C=iround((max(-F(1),C2[0]),min(F(1),C2[1])),workbits)
        S=iround((max(-F(1),S2[0]),min(F(1),S2[1])),workbits)
    if angle<0:S=ineg(S)
    return dict(cos=C,sin=S,doublings=s,terms=n)

def reconstruction(state,omega,bits=112,frequency_radius=F(0)):
    omega,frequency_radius=map(F,(omega,frequency_radius))
    if frequency_radius<0:raise ValueError('negative frequency radius')
    vals=[];rad=[];ops=0;terms=0
    for j in range(2):
        rt=rotate_interval((j+1)*omega*state.t,bits);ops+=rt['doublings'];terms+=rt['terms']
        a,b=state.a[2*j:2*j+2]
        Re=iadd(iscale(rt['cos'],a),iscale(rt['sin'],-b));Im=iadd(iscale(rt['sin'],a),iscale(rt['cos'],b))
        for interval in (Re,Im):
            v=nearest(sum(interval)/2,bits);vals.append(v);rad.append(max(v-interval[0],interval[1]-v))
    arithmetic=norm_up(rad,bits)
    # ||U(omega)t-U(omega+dw)t||_H <= min(2,2*t*|dw|); ||a_hat||_H bound is computed.
    phase=carrier_uncertainty_charge(2*state.t,frequency_radius,norm_up(state.a,bits))
    return dict(value=tuple(vals),carrier_arithmetic_error=arithmetic,frequency_error=phase,
                error=up(state.error+arithmetic+phase,bits),doublings=ops,series_terms=terms)
