"""Recompute selected saved trajectories with final code and exact fingerprints."""
import json, hashlib
from pathlib import Path
from fractions import Fraction as F
from twoway import Model, integrate
ROOT=Path(__file__).resolve().parents[1]
rows=[]
for fn in ['k1_DENSITY_RVJ_FIRST_1000000.json','k10000_INVARIANT_RVJ_FIRST_1000000.json','hybrid_k40_INVARIANT_TAYLOR_FIRST_1000000.json']:
    old=json.loads((ROOT/'evidence'/fn).read_text())
    params={k:(int(v) if k=='branch' else F(v)) for k,v in old['model'].items()}
    m=Model(**params)
    run=integrate(m,*map(F,old['initial_fast']),eps=F(old['tolerance']),certificate_policy=old['certificate_policy'],mode_policy=old['mode_policy'])
    assert run['status']=='COMPLETED' and len(run['history'])==old['steps']
    for new,saved in zip(run['history'],old['steps_trace']):
        fp=hashlib.sha256(repr((new['candidate'],new['defects'],new['whole'],new['radius'],new['physical_bounds'])).encode()).hexdigest()
        assert fp==saved['certificate_fingerprint'],(fn,str(new['output'].t))
        assert list(map(str,new['output'].y))==saved['y']
    assert run['work']==old['work']
    rows.append({'file':fn,'steps':len(run['history']),'exact_fingerprints_states_and_work_equal':True})
(ROOT/'evidence'/'final_source_replay.json').write_text(json.dumps(rows,indent=2))
print(json.dumps(rows,indent=2))
