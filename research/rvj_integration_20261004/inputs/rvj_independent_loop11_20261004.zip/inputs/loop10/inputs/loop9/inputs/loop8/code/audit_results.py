"""Independent floating ODE audit, never imported by candidate/certificate."""
import json,sys
from pathlib import Path
from fractions import Fraction as F
import numpy as np
from scipy.integrate import solve_ivp
from enriched import Model,Path as Curve

def parse(x):return float(F(x))
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'

def audit(name):
    data=json.loads((OUT/f'{name}.json').read_text());params=data['model'];branch=int(params['branch']);m=Model(**{k:(int(v) if k=='branch' else F(v)) for k,v in params.items()})
    k,a,b,e,r=map(float,(m.k,m.alpha,m.beta,m.eta,m.rho));T=parse(data['T']);u0,v0=map(parse,data['initial_uv'])
    def fun(t,y):x,u,v=y;return [branch*np.sqrt(1+x)-x+a*u,k*(-u+b*v),k*(e*x-r*v)]
    def jac(t,y):return [[branch/(2*np.sqrt(1+y[0]))-1,a,0],[0,-k,k*b],[k*e,0,-k*r]]
    oracles=[solve_ivp(fun,[0,T],[0,u0,v0],method='Radau',jac=jac,rtol=rt,atol=at,dense_output=True) for rt,at in [(2e-13,2e-15),(5e-14,5e-16)]]
    if not all(o.success for o in oracles):raise AssertionError('oracle failed')
    maxerr=np.zeros(3);maxratio=0.;rawbad=0;rootbad=0;maxdifference=0.;interior=0;epbad=0
    for hh in data['history']:
        t,h=parse(hh['t']),parse(hh['h']);yc=np.array([parse(x) for x in hh['y']])*np.array(list(map(float,m.units)))
        ref=oracles[1].sol(t);reference=np.array([ref[0],ref[1]+ref[0]**2/k,ref[2]+ref[0]**3/k]);v=np.array(list(map(parse,hh['physical'])));err=abs(v-reference);bd=np.array(list(map(parse,hh['physical_bounds'])))
        maxerr=np.maximum(maxerr,err);maxratio=max(maxratio,float(np.max(err/bd)));epbad+=int(np.any(err>bd))
        path=Curve.build(m,F(hh['h']),tuple(F(x) for x in hh['initial']),tuple(F(x) for x in hh['r']))
        for theta in [F(0),F(1,4),F(1,2),F(3,4),F(1)]:
            at=t-h+h*float(theta);ref=oracles[1].sol(at);vint=path.evaluate(theta);v=np.array([float((lo+hi)/2) for lo,hi in vint]);scaled=ref/np.array(list(map(float,m.units)));err=np.max(abs(v-scaled));bd=parse(hh['whole']);rawbad+=int(err>bd);interior+=1
            from polynomial import value
            qr=float(value(path.r,theta));rooterror=abs(qr-branch*np.sqrt(1+ref[0]));rootbad+=int(rooterror>parse(hh['root_bound']))
            maxdifference=max(maxdifference,float(np.max(abs(oracles[0].sol(at)-ref))))
    result={'case':name,'status':data['status'],'accepted':len(data['history']),'rejected_candidates':len(data['rejected']),'min_h':min(parse(h['h']) for h in data['history']),'max_h':max(parse(h['h']) for h in data['history']),
            'endpoint_raw_violations':epbad,'interior_raw_violations':rawbad,'root_raw_violations':rootbad,'interior_comparisons':interior,'max_physical_errors':list(maxerr),'max_error_bound_ratio':maxratio,'oracle_cross_tolerance_difference':maxdifference,'oracle_is_rigorous_certificate':False,'oracle_radau_success':[o.success for o in oracles]}
    (OUT/f'audit_{name}.json').write_text(json.dumps(result,indent=2));print(result,flush=True)
if __name__=='__main__':
    for name in sys.argv[1:]:audit(name)
