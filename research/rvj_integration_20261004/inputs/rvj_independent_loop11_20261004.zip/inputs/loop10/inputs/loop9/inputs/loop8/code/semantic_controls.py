"""Exact, deliberately small semantic controls; no solver promotion."""
from fractions import Fraction as F

def endpoint_forcing_error(coeff):
    """Signed unit-kernel convolution; not a norm bound for arbitrary forcing."""
    return abs(sum((F(c)/(j+1) for j,c in enumerate(coeff)),F(0)))

def lagrange_values(nodes,x):
    nodes=tuple(map(F,nodes));x=F(x)
    if not nodes or len(set(nodes))!=len(nodes):raise ValueError('distinct nodes required')
    vals=[]
    for i,t in enumerate(nodes):
        z=F(1)
        for j,u in enumerate(nodes):
            if j!=i:z*= (x-u)/(t-u)
        vals.append(z)
    return tuple(vals)

def nodal_noise_norm(nodes,x):
    return sum(map(abs,lagrange_values(nodes,x)),F(0))
