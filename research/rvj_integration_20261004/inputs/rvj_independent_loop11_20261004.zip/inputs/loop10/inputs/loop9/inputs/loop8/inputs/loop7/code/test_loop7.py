from fractions import Fraction as F
from dataclasses import replace
import pytest
from twoway import *
from polynomial import bernstein_coefficients

@pytest.mark.parametrize('k',[1,40,10000])
def test_fixed_comparison_margin(k):
    m=Model(k=k)
    assert m.d==8 and m.b==F(1,2) and m.margin==F(1,8)
    for h in [F(1,1000),F(1,4),F(4),F(100)]:
        b=small_gain_box(m,h,F(1,100),F(1,200),F(1,10),F(1,10))
        assert 0<=b['gain']<=F(1,4)

@pytest.mark.parametrize('branch',[-1,1])
def test_full_current_residual_certifies_small_step(branch):
    m=Model(k=40,branch=branch);s=initial_state(m)
    h=F(1,4096);jet=make_jet(m,s.y,h)
    c=certify(m,s,h,make_candidate(jet),F(1,10**6),F(1,4))
    assert c['valid']
    assert c['defects']['rmin']>=QMIN
    assert all(b<=F(1,10**6) for b in c['physical_bounds'])
    assert commit(m,s,c).t==h

@pytest.mark.parametrize('mode',['RVJ','TAYLOR'])
def test_path_keeps_initial_jets_and_rounding_budget(mode):
    m=Model();s=initial_state(m);h=F(1,32);j=make_jet(m,s.y,h)
    c=make_candidate(j,mode)
    assert all(c['p'][i][:6]==j['p'][i] for i in range(3))
    out=certify(m,s,h,c,F(1,10**6),F(1,4))
    assert out['valid']
    assert out['local']>=h*out['defects']['delta']+out['rounding']


def test_failed_trial_and_stale_epoch_never_commit():
    m=Model(k=40);s=initial_state(m);old=s.digest()
    jet=make_jet(m,s.y,F(1,4))
    bad=certify(m,s,F(1,4),make_candidate(jet),F(1,10**8),F(1,4))
    assert not bad['valid'] and s.digest()==old
    with pytest.raises(ContractError):commit(m,s,bad)
    h=F(1,4096);good=certify(m,s,h,make_candidate(make_jet(m,s.y,h)),F(1,10**6),F(1,4))
    assert good['valid']
    with pytest.raises(ContractError):commit(replace(m,epoch=1),s,good)
    with pytest.raises(ContractError):commit(m,replace(s,generation=1),good)


def test_witness_sign_margin_rejects_root_square_equivalence():
    m=Model();s=initial_state(m);h=F(1,32)
    c=make_candidate(make_jet(m,s.y,h));c['q']=tuple(-z for z in c['q'])
    out=certify(m,s,h,c,F(1,10**6),F(1,4))
    assert not out['valid'] and out['reason']=='WITNESS_MARGIN'


def test_slow_only_residual_is_not_a_full_certificate():
    m=Model(k=40);h=F(1,10)
    p=((F(0),h),(F(0),),(F(0),));q=(F(1),h)
    d=coupled_defects(m,p,q,h)
    assert d['valid']
    assert d['differential'][2]==F(1,4)
    assert d['delta']>=1


def test_endpoint_blindness_continuous_polynomial():
    p=(F(0),F(0),F(3),F(-2))
    assert value(deriv(p),F(0))==value(deriv(p),F(1))==0
    assert value(p,F(1))-value(p,F(0))==1
    assert abs_bound(deriv(p))>=F(3,2)


def test_equilibrium_forcing_does_not_vanish_as_k_increases():
    for k in [1,10000]:
        m=Model(k=k);x=F(1,5)
        v=m.eta*x/m.rho;u=m.beta*v
        assert m.k*(-u+m.beta*v)==m.k*(m.eta*x-m.rho*v)==0
        assert m.alpha*u==x*F(1,64)


def test_physical_reconstruction_exact_dyadic_corners():
    m=Model(k=2);y=(F(1,4),F(1,8),F(-1,16));E=F(1,64)
    stored,bounds=physical(m,y,E)
    for sx in [-1,0,1]:
        for su in [-1,0,1]:
            for sv in [-1,0,1]:
                x,u,v=(a+s*w*E for a,s,w in zip(y,(sx,su,sv),m.units))
                physical_exact=(x,u+x*x/m.k,v+x**3/m.k)
                assert all(abs(a-b)<=c for a,b,c in zip(physical_exact,stored,bounds))


def test_actual_bidirectional_single_step_return_mode_nonzero():
    m=Model(k=40);r=integrate(m,u=0,v=0,T=F(1,64),max_attempts=200)
    assert r['status']=='COMPLETED'
    assert r['state'].y[1]>0 and r['state'].y[2]>0

@pytest.mark.parametrize('kwargs',[{'k':0},{'rho':0},{'branch':0},{'alpha':10},{'eta':1},{'weight':0}])
def test_unsupported_contract_fails_closed(kwargs):
    with pytest.raises(ContractError):Model(**kwargs)


def test_compact_matrix_expression_linear_identity():
    import sympy as S
    z=S.Matrix([[-F(1,2),F(1,4),0],[0,-F(1,3),F(1,5)],[F(1,20),0,-F(2,3)]])
    y=S.Matrix([1,2,3]);Q=S.eye(3)-S.Rational(3,5)*z+S.Rational(3,20)*z*z-z**3/60
    P=S.eye(3)+S.Rational(2,5)*z+z*z/20
    a5=z**5*y/120
    got=S.Matrix(phi5_action(tuple(tuple(F(z[i,j]) for j in range(3)) for i in range(3)),tuple(F(x) for x in a5)))
    step=sum((z**j*y/S.factorial(j) for j in range(5)),S.zeros(3,1))+120*got
    assert step==Q.inv()*P*y


def test_bernstein_hull_exact_interior_points():
    p=(F(2),F(-7),F(5),F(11),F(-8))
    lo,hi=bernstein_range(p)
    for i in range(101):assert lo<=value(p,F(i,100))<=hi


def test_nonuniform_cap_and_every_budget_charged():
    m=Model(k=1);r=integrate(m,T=F(1,8),cap_pattern=[F(1,64),F(1,32)])
    assert r['status']=='COMPLETED'
    assert len(set(c['h'] for c in r['history']))>1
    assert r['state'].error==sum((c['local'] for c in r['history']),F(0))
    assert r['work']['candidate_certificates']==len(r['history'])+r['work']['rejected_candidates']


def test_wrong_candidate_start_is_not_rebased_silently():
    m=Model();s=initial_state(m);h=F(1,32);c=make_candidate(make_jet(m,s.y,h))
    rows=list(c['p']);p=list(rows[0]);p[0]+=F(1,100);rows[0]=tuple(p);c['p']=tuple(rows)
    with pytest.raises(ContractError):certify(m,s,h,c,F(1,10**6),F(1,4))
