"""Exact power/Bernstein polynomial arithmetic, ascending coefficients on [0,1]."""
from fractions import Fraction as F
from math import comb,isqrt
from loop4_scalar import ContractError

def trim(p):
    p=list(map(F,p))
    if not p:raise ContractError('empty polynomial')
    while len(p)>1 and p[-1]==0:p.pop()
    return tuple(p)
def add(p,q):
    r=[F(0)]*max(len(p),len(q))
    for i,v in enumerate(p):r[i]+=v
    for i,v in enumerate(q):r[i]+=v
    return trim(r)
def scale(p,a):return trim([F(a)*v for v in p])
def mul(p,q):
    r=[F(0)]*(len(p)+len(q)-1)
    for i,a in enumerate(p):
        for j,b in enumerate(q):r[i+j]+=a*b
    return trim(r)
def deriv(p):return trim([i*p[i] for i in range(1,len(p))] or [F(0)])
def value(p,x):
    r=F(0)
    for a in reversed(p):r=r*x+a
    return r

def bernstein_coefficients(p):
    p=trim(p);n=len(p)-1
    return tuple(sum((p[j]*F(comb(i,j),comb(n,j)) for j in range(i+1)),F(0)) for i in range(n+1))

def bernstein_range(p):
    b=bernstein_coefficients(p)
    return min(b),max(b)

def abs_bound(p):
    lo,hi=bernstein_range(p)
    return max(abs(lo),abs(hi))

def sqrt_interval(v:F,bits:int=128):
    v=F(v)
    if v<0 or bits<8:raise ContractError('invalid sqrt interval request')
    unit=1<<bits
    n=isqrt((v.numerator<<(2*bits))//v.denominator)
    lo=F(n,unit)
    hi=lo if lo*lo==v else F(n+1,unit)
    assert lo*lo<=v<=hi*hi
    return lo,hi
