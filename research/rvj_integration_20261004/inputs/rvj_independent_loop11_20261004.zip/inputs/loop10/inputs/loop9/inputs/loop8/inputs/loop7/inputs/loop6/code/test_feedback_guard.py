from fractions import Fraction as F
import pytest
from feedback_guard import feedback_charge

def test_equal_endpoints_do_not_cancel_integrated_feedback():
    # w_true=0, w_candidate=6*s*(1-s), s in [0,1]. Endpoint error=0, area=1.
    assert feedback_charge(F(0),F(1),F(2)) >= 2

def test_charge_is_sign_independent():
    assert feedback_charge(F(0),F(1,3),F(-2)) >= F(2,3)
