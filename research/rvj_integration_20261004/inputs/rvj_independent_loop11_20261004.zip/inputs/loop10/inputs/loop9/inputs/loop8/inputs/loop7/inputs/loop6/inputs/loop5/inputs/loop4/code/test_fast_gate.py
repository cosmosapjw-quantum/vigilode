from fractions import Fraction as F
from hybrid_rvj import choose_fast

def test_unresolved_initial_layer_is_not_accepted_from_L_stability():
    out=choose_fast(F(1),F(0),F(1000),F(1,10**12))
    assert out['mode']=='EXP_ENCLOSURE'
    assert out['local_error']<=F(1,10**12)
    assert out['value']!=0, 'do not silently project fast amplitude to zero'

def test_zero_fast_mode_needs_no_exponential_fallback():
    out=choose_fast(F(0),F(0),F(1000),F(1,10**12))
    assert out['mode']=='RVJ'
    assert out['value']==0

def test_decayed_nonzero_mode_returns_to_cheap_path():
    out=choose_fast(F(1,10**20),F(0),F(1000),F(1,10**12))
    assert out['mode']=='RVJ'
    assert out['value']!=0
