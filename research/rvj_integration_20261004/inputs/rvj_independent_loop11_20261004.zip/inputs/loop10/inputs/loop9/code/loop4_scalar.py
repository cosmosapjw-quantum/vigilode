"""RVJ chart reference. Exact rational guards; rounded dyadic stored states.

Domain: x'=x^2, w'=-kappa*w, y=x^2*(w+1/kappa), x(0)=1,
0<T<=1/4, kappa>0. No external future-solution oracle is used.
This is NOT a general stiff solver or a cost-optimized implementation.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
import hashlib

class ContractError(ValueError): pass
class PrecisionBlocked(ArithmeticError): pass

def pow2(n: int) -> F:
    return F(2**n) if n >= 0 else F(1,2**(-n))

def down(v: F, bits: int=128) -> F:
    k=2**bits
    return F((v.numerator*k)//v.denominator,k)

def up(v: F, bits: int=128) -> F:
    return -down(-v,bits)

def nearest(v: F, bits: int=128) -> F:
    return down(v+pow2(-bits-1),bits)

def round_sig(v: F, bits: int=128) -> F:
    if not v: return F(0)
    e=abs(v).numerator.bit_length()-abs(v).denominator.bit_length()
    if abs(v)<pow2(e): e-=1
    unit=pow2(e-bits+1)
    return nearest(v/unit,0)*unit

def exp_minus_interval(a: F, bits: int=128) -> tuple[F,F,int]:
    """e^-a enclosure by alternating series and outward dyadic squaring.
    Large a: e>2, hence e^-a <= 2^-floor(a). No libm certification.
    """
    a=F(a)
    if a<0 or bits<32: raise ContractError('nonnegative a and bits>=32 required')
    if not a: return F(1),F(1),0
    if a>=bits+8:
        return F(0),pow2(-(bits+8)),0
    s=0; r=a
    while r>F(1,2): r/=2; s+=1
    total=F(1); term=F(1); lo=F(0); hi=F(1)
    for n in range(1,4*bits+1):
        term *= -r/n; total += term
        if n%2: lo=total
        else: hi=total
        if hi-lo <= pow2(-(bits+s+8)): break
    else: raise PrecisionBlocked('alternating series iteration cap')
    lo=down(lo,bits+s+8); hi=up(hi,bits+s+8)
    for _ in range(s):
        lo=down(lo*lo,bits); hi=up(hi*hi,bits)
    return max(F(0),lo),min(F(1),hi),n+s

def rational_fast(a: F) -> F:
    a=F(a)
    if a<0: raise ContractError('a must be nonnegative')
    return (1-2*a/5+a*a/20)/(1+3*a/5+3*a*a/20+a**3/60)

def fast_defect_bound(a: F) -> F:
    a=F(a)
    if a<0: raise ContractError('a must be nonnegative')
    q=1+3*a/5+3*a*a/20+a**3/60
    # Integral identity proves 0 <= R(-a)-exp(-a) <= each bound.
    return min(rational_fast(a),a**6/(7200*q),a*a/(20*q))

def choose_fast(w: F, rw: F, a: F, budget: F, bits: int=128) -> dict:
    w,rw,a,budget=map(F,(w,rw,a,budget))
    if rw<0 or a<0 or budget<=0: raise ContractError('invalid fast budget or radius')
    r=rational_fast(a); raw=r*w; value=round_sig(raw,bits)
    local=fast_defect_bound(a)*abs(w)+abs(value-raw)
    if local<=budget:
        return dict(mode='RVJ',value=value,radius=up(r*rw+local,bits),
                    local_error=local,exp_calls=0,enclosure_ops=0,fast_gain=r)
    lo,hi,ops=exp_minus_interval(a,bits)
    raw=(lo+hi)*w/2; value=round_sig(raw,bits)
    local=(hi-lo)*abs(w)/2+abs(value-raw)
    if local>budget: raise PrecisionBlocked('EXP enclosure too wide at fixed precision')
    return dict(mode='EXP_ENCLOSURE',value=value,radius=up(hi*rw+local,bits),
                local_error=local,exp_calls=1,enclosure_ops=ops,fast_gain=hi)

def slow_rvj(x: F,h: F) -> F:
    x,h=F(x),F(h); a=h*x
    if not F(0)<=a<=F(1,4): raise ContractError('slow RVJ chart requires 0<=h*x<=1/4')
    z=2*a; q=1-3*z/5+3*z*z/20-z**3/60
    phi=(z*z-5*z+12)/(1440*q)
    return x*(1+a+a*a+a**3+a**4+120*a**5*phi)

def slow_exact_defect(x:F,h:F)->F:
    a=h*x; q=1-6*a/5+3*a*a/5-2*a**3/15
    return x*a**6*(19-17*a+6*a*a)/(30*(1-a)*q)

@dataclass(frozen=True)
class State:
    t:F; x:F; w:F; rx:F=F(0); rw:F=F(0)
    def digest(self)->str:
        return hashlib.sha256('|'.join(map(str,(self.t,self.x,self.w,self.rx,self.rw))).encode()).hexdigest()

def physical_bound(x:F,w:F,rx:F,rw:F,k:F,stored_y:F)->F:
    if k<=0 or rx<0 or rw<0 or x-rx<=0: raise ContractError('nonregular reconstruction box')
    a=w+1/k
    return (2*abs(x)*rx+rx*rx)*abs(a)+(abs(x)+rx)**2*rw+abs(x*x*a-stored_y)

def attempt(state:State,h:F,k:F,T:F,tol:F,w0_abs:F,bits:int=128)->dict:
    h,k,T,tol=map(F,(h,k,T,tol))
    if h<=0 or h>F(1,8) or k<=0 or not 0<T<=F(1,4) or tol<=0:
        raise ContractError('out of reference domain')
    xl=state.x-state.rx; xu=state.x+state.rx
    if xl<F(1,2) or h*xu>=1 or xu/(1-h*xu)>2:
        return {'accepted':False,'reason':'CHART_TUBE','state_digest':state.digest()}
    ex=tol/(16*(w0_abs+1/k+1)); ew=tol/16
    bx=ex*h/(9*T); bw=ew*h/T
    raw=slow_rvj(state.x,h); xx=nearest(raw,bits)
    # Polynomial upper bound applies to all partial lengths 0<=s<=h.
    tx=2*state.x**7*h**6+abs(xx-raw)
    if tx>bx:
        return {'accepted':False,'reason':'SLOW_DEFECT','state_digest':state.digest(),
                'slow_local_error':tx,'slow_budget':bx}
    ff=choose_fast(state.w,state.rw,k*h,bw,bits)
    lx=1/(1-h*xu)**2
    rx=up(lx*state.rx+tx,bits); rw=ff['radius']
    yy=nearest(xx*xx*(ff['value']+1/k),bits)
    by=physical_bound(xx,ff['value'],rx,rw,k,yy)
    if rx>ex or rw>ew or by>tol or rx>tol:
        return {'accepted':False,'reason':'GLOBAL_BUDGET','state_digest':state.digest()}
    out=State(state.t+h,xx,ff['value'],rx,rw)
    return dict(accepted=True,reason='CERTIFIED',state=out,y=yy,y_error=up(by,bits),
                x_error=rx,slow_local_error=tx,slow_budget=bx,fast_local_error=ff['local_error'],
                fast_budget=bw,mode=ff['mode'],exp_calls=ff['exp_calls'],enclosure_ops=ff['enclosure_ops'],
                input_digest=state.digest(),output_digest=out.digest(),h=h,
                tube_x_lower=xl,tube_x_upper=xu/(1-h*xu))

def integrate(k:F,w0:F,tol:F=F(1,10**8),T:F=F(1,4),bits:int=128,max_attempts:int=10000)->dict:
    k,w0,tol,T=map(F,(k,w0,tol,T))
    if k<=0 or tol<=0 or not 0<T<=F(1,4): raise ContractError('invalid model inputs')
    state=State(F(0),F(1),w0); h=min(F(1,8),T)
    history=[]; rejected=[]; modes={'RVJ':0,'EXP_ENCLOSURE':0}; exp_calls=0; encops=0
    for _ in range(max_attempts):
        if state.t==T: break
        h=min(h,T-state.t); before=state.digest()
        r=attempt(state,h,k,T,tol,abs(w0),bits)
        if not r['accepted']:
            if state.digest()!=before: raise AssertionError('rejected trial changed accepted state')
            rejected.append({'t':state.t,'h':h,**r}); h/=2
            if h<pow2(-bits//2): raise PrecisionBlocked('step floor reached without commitment')
            continue
        history.append(r); state=r['state']; modes[r['mode']]+=1
        exp_calls+=r['exp_calls']; encops+=r['enclosure_ops']
        ratio=max(r['slow_local_error']/r['slow_budget'],r['fast_local_error']/r['fast_budget'])
        if ratio<=F(1,64): h=min(2*h,F(1,8))
    else: raise PrecisionBlocked('attempt cap reached')
    return dict(state=state,history=history,rejected=rejected,modes=modes,
                exp_calls=exp_calls,enclosure_ops=encops,accepted=len(history),attempts=len(history)+len(rejected),
                model='xprime=x^2;wprime=-k*w;physical_y=x^2*(w+1/k)',
                certificate_domain='k>0;T<=1/4;x tube subset [1/2,2];exact model;fixed binary precision')

def dense_box(state:State,s0:F,s1:F,k:F,bits:int=128)->dict:
    """Whole-window enclosure for this integrable chart, NOT a generic dense interpolant.
    It uses local model identities and the accepted state's box only.
    """
    s0,s1,k=map(F,(s0,s1,k))
    if not 0<=s0<=s1 or k<=0:raise ContractError('invalid dense window')
    xl,xu=state.x-state.rx,state.x+state.rx
    if xl<=0 or s1*xu>=1:raise ContractError('dense tube reaches chart/flow boundary')
    X=(xl/(1-s0*xl),xu/(1-s1*xu))
    wl,wu=state.w-state.rw,state.w+state.rw
    el,_,_=exp_minus_interval(k*s1,bits);_,eu,_=exp_minus_interval(k*s0,bits)
    vv=[wl*el,wl*eu,wu*el,wu*eu];W=(min(vv),max(vv))
    xx=[X[0]**2,X[1]**2];aa=[W[0]+1/k,W[1]+1/k]
    vv=[a*b for a in xx for b in aa]
    return {'x':X,'w':W,'y':(min(vv),max(vv)),
            'domain':'entire local time window; chart model identities; not generic dense output'}

def cofactor_forcing_local_bound(eps_C:F,eps_D:F,w_upper:F,D_lower:F,k:F,h:F)->F:
    if min(eps_C,eps_D,w_upper,h)<0 or D_lower<=0 or k<=0:
        raise ContractError('invalid approximate chart residual bounds')
    G=(eps_C+w_upper*eps_D)/D_lower
    return min(h,1/k)*G
