from run_experiments import *
from feedback import *
from pathlib import Path
import json,mpmath as mp

root=Path(__file__).resolve().parents[1]
m=Model(1000000);T=F(1,4);w0=(F(0),F(1));oracle=Oracle(m,1,w0,T)
refinements=[]
for e in [6,8,10]:
 for policy in ['time_density','split_reserve']:
  run=integrate(m,1,w0,tol=F(1,10**e),budget_policy=policy)
  result=audit(run,oracle);result['policy']=policy
  result['minimum_accepted_h']=str(min(t['h'] for t in run['history']))
  result['spent_transient']=str(run['snapshot'].spent_transient)
  refinements.append(result)
  print('REFINE',e,policy,run['accepted'],result['max_x_error'],flush=True)
(root/'evidence/tolerance_and_reserve.json').write_text(json.dumps(refinements,indent=2))
nonuniform=[]
for kk in [1000000,40]:
 model=Model(kk);oo=oracle if kk==1000000 else Oracle(model,1,w0,T)
 for policy in ['time_density','split_reserve']:
  run=integrate(model,1,w0,nonuniform=True,budget_policy=policy)
  out=audit(run,oo);out['policy']=policy;out['step_values']=sorted({str(tr['h']) for tr in run['history']})
  nonuniform.append(out);print('NONUNIFORM',kk,policy,run['accepted'],out['step_values'],flush=True)
(root/'evidence/nonuniform.json').write_text(json.dumps(nonuniform,indent=2))
# Wrong post-layer approximation resets slow state rather than keeping its impulse.
no_feedback=mp.odefun(lambda t,x:mp.sqrt(1+x)-x,0,0,tol=mp.mpf('1e-55'),degree=32)
true=oracle.x(MP(T));wrong=no_feedback(MP(T));difference=abs(true-wrong)
(root/'evidence/missing_memory_negative.json').write_text(json.dumps({
 'model':serial(m),'T':str(T),'tolerance':'1e-8',
 'true_x_oracle':mp.nstr(true,40),'wrong_unshifted_slow_x':mp.nstr(wrong,40),
 'missed_slow_effect':mp.nstr(difference,25),
 'fast_endpoint_norm':mp.nstr(max(map(abs,fast_oracle(MP(T),m,w0))),16),
 'oracle_tail_bound':mp.nstr(oracle.tail,12),
 'interpretation':'endpoint fast decay does not remove accumulated slow displacement; not a failure of the certified lifted algorithm'},indent=2))
print('MEMORY',mp.nstr(difference,20),flush=True)
# Higher precision, longer initial-layer interval: independently refined numerical oracle.
old=mp.mp.dps;baseline=true
mp.mp.dps=80
ref=Oracle(m,1,w0,T,dps=80,cut=112)
ref_x=ref.x(MP(T));gap=abs(ref_x-baseline)
(root/'evidence/oracle_refinement.json').write_text(json.dumps({
 'first_dps':65,'first_cut':96,'second_dps':80,'second_cut':112,
 'x_T_difference':mp.nstr(gap,25),'first_tail_bound':mp.nstr(oracle.tail,20),
 'second_tail_bound':mp.nstr(ref.tail,20),'verified_exact_solution':False,
 'interpretation':'numerical cross-precision verification plus analytical truncation-tail bound, not a separate formal oracle proof'},indent=2))
mp.mp.dps=old
print('ORACLE_REFINEMENT',mp.nstr(gap,25),flush=True)
