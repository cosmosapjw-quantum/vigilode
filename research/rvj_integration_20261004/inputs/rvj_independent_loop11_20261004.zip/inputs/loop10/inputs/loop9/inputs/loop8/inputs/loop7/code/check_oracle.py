"""Independent high-precision low-stiffness numerical cross-check only."""
from pathlib import Path
import json
import mpmath as mp
from fractions import Fraction as F
from run_experiments import get_oracles
from twoway import Model
mp.mp.dps=55
m=Model();
def fun(t,y):
    x,u,v=y
    return [mp.sqrt(1+x)-x+u/16,-u+4*v,x/16-v]
a=mp.odefun(fun,0,[0,0,1],tol=mp.mpf('1e-43'),degree=25)(mp.mpf(1)/4)
r,d=get_oracles(m,0,1,F(1,4))
rend=r.sol(.25);dend=d.sol(.25)
err_r=[abs(v-mp.mpf(float(w))) for v,w in zip(a,rend)]
err_d=[abs(v-mp.mpf(float(w))) for v,w in zip(a,dend)]
assert max(err_r)<mp.mpf('1e-12') and max(err_d)<mp.mpf('1e-12')
report={'scope':'kappa=1, default positive branch; numerical cross-check not rigorous oracle',
        'mpmath_dps':mp.mp.dps,'taylor_degree':25,'mpmath_tolerance':'1e-43',
        'state_T':[mp.nstr(v,52) for v in a],
        'radau_differences':[mp.nstr(v,12) for v in err_r],
        'dop853_differences':[mp.nstr(v,12) for v in err_d],
        'validated_oracle_theorem':False}
(Path(__file__).resolve().parents[1]/'evidence'/'oracle_high_precision.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
