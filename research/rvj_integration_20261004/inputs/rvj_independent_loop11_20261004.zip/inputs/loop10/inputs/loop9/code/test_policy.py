from fractions import Fraction as F
from policy import neutral_defect_charge, carrier_uncertainty_charge, samples_alone_certify_unknown_oscillation

def test_unitary_residual_accumulates_instead_of_stationary_damping_box():
    assert neutral_defect_charge(F(1,2),F(1,100))==F(1,200)
def test_unknown_carrier_phase_is_charged():
    assert carrier_uncertainty_charge(F(10),F(1,1000),F(2))==F(1,50)
def test_samples_cannot_certify_unrestricted_oscillation():
    assert not samples_alone_certify_unknown_oscillation()
