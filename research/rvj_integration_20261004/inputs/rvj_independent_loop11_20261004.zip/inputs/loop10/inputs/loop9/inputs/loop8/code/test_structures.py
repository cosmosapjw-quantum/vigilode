import sympy as S
from fractions import Fraction as F
from generator import bases
from polynomial import value
from enriched import Model,Path,scalar_exp_poly_range
import pytest

def test_nonlinear_idempotence_does_not_make_reflection_involutive():
    def p(v):x,y=v;return (x+y*y,F(0))
    def j(v):return tuple(2*a-b for a,b in zip(p(v),v))
    v=(F(0),F(1));assert p(p(v))==p(v)
    assert j(j(v))==(F(4),F(1)) and j(j(v))!=v

def test_frozen_history_and_current_slab_extrapolation_are_differently_conditioned():
    assert sum(abs(value(p,F(1))) for p in bases(tuple(F(-j) for j in range(5))))==31
    assert sum(abs(value(p,F(2))) for p in bases())==769

def test_richardson_may_destroy_stiff_stability():
    def trap(z):return (1+z/2)/(1-z/2)
    z=F(-100);assert abs(trap(z))<1
    assert (4*trap(z/2)**2-trap(z))/3>1

def test_full_slab_interpolation_is_not_subslab_volterra():
    # Two forcing traces agree before t=h/2 but differ at h; nodal reconstruction
    # changes the earlier integral even though the original retarded operator does not.
    h=F(1);t=F(1,2)
    earlier_change=t*t/(2*h)
    assert earlier_change==F(1,8)

@pytest.mark.parametrize('k',[1,10000])
def test_exponential_polynomial_range_encloses_all_checked_values(k):
    m=Model(k=k);p=Path.build(m,F(1,16),(F(0),F(0),F(4)),(F(1),F(1,32)))
    lo,hi=scalar_exp_poly_range(p,p.V[0],1,F(0),F(1,16),degree=12)
    for j in range(9):
        a,b=p.evaluate(F(j,128))[0]
        assert lo<=a<=b<=hi

def test_integrator_rejects_nonpositive_caps():
    from run_study import integrate
    for cap in [(F(0),),(F(-1),),()]:
        with pytest.raises(ValueError):integrate(Model(),cap=cap)
