"""Minimal contracts; these are not a generic solver or a security boundary."""
from fractions import Fraction as F

def neutral_defect_charge(h, residual):
    h,residual=map(F,(h,residual))
    if min(h,residual)<0:raise ValueError('nonnegative step and residual required')
    return h*residual

def carrier_uncertainty_charge(t, frequency_radius, amplitude_radius_bound):
    t,dw,r=map(F,(t,frequency_radius,amplitude_radius_bound))
    if min(t,dw,r)<0:raise ValueError('nonnegative time, frequency uncertainty and amplitude bound required')
    return min(F(2),t*dw)*r

def samples_alone_certify_unknown_oscillation():
    return False
