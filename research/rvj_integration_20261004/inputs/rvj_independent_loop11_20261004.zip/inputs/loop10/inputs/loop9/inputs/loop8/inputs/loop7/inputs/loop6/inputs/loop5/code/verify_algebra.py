from pathlib import Path
import json
import sympy as sp
from fractions import Fraction as F
from slow_closure import make_candidate
from polynomial import bernstein_coefficients

root=Path(__file__).resolve().parents[1]
z,a,b,x,w1,w2,k,t,q=sp.symbols('z a b x w1 w2 k t q',nonzero=True)
R=(1+2*z/5+z*z/20)/(1-3*z/5+3*z*z/20-z**3/60)
P=1+2*z/5+z*z/20;Q=1-3*z/5+3*z*z/20-z**3/60
checks={}
def zero(name,v):
 ans=sp.simplify(v)==0
 checks[name]=bool(ans)
 assert ans,(name,v)
def ratmat(A):
 I=sp.eye(2)
 return (I+sp.Rational(2,5)*A+A*A/20)*(I-sp.Rational(3,5)*A+sp.Rational(3,20)*A*A-A**3/60).inv()
qq=3*a**5/(a**3+9*a*a+36*a+60)**2
zero('derivative_gap_identity',sp.diff(R.subs(z,-a),a)+R.subs(z,-a)-qq)
for rate in [1,2]:
 M=sp.Matrix([[-a,b],[0,-rate*a]])
 target=sp.Matrix([[R.subs(z,-a), b*sp.diff(R,z).subs(z,-a) if rate==1 else b*(R.subs(z,-a)-R.subs(z,-2*a))/a],[0,R.subs(z,-rate*a)]])
 assert all(sp.cancel(v)==0 for v in ratmat(M)-target)
 checks[f'matrix_family_{rate}']=True
zero('additive_chart_determinant',sp.Matrix([x,w1+x*x/k,w2+x**3/k]).jacobian([x,w1,w2]).det()-1)
zero('closure_discriminant',sp.discriminant(q*q-1-x,q)-4*(1+x))
zero('closure_schur_derivative',(-1-(-1)/(2*q))-(-1+1/(2*q)))
checks['slow_field_does_not_descend_without_witness']=(sp.rem(q-x,q*q-1-x,q)==q-x)
# Independent chain-rule derivatives, not the coefficient recursion in provider.
for sign in [-1,1]:
 f=sign*sp.sqrt(1+x)-x;v=f
 for j in range(1,6):
  c=make_candidate(F(0),F(1,32),sign)
  computed=c['p'][j]/F(1,32)**j
  exact=sp.simplify(v.subs(x,0)/sp.factorial(j))
  assert sp.Rational(computed.numerator,computed.denominator)==exact
  v=sp.diff(v,x)*f
 checks[f'implicit_jet_chain_rule_branch_{sign}']=True
poly=tuple(map(F,[1,-3,5,0,-2,7]));bb=bernstein_coefficients(poly);n=len(poly)-1
zero('bernstein_power_identity',sum(sp.Rational(v.numerator,v.denominator)*t**i for i,v in enumerate(poly))-sum(sp.Rational(v.numerator,v.denominator)*sp.binomial(n,i)*t**i*(1-t)**(n-i) for i,v in enumerate(bb)))
zero('large_a_derivative_bound_leading',sp.limit(a*a*(sp.diff(R,z).subs(z,-a)+1/sum(a**j/sp.factorial(j) for j in range(7))),a,sp.oo)-3)
zero('small_a_gap_order',sp.limit(qq/a**5,a,0)-sp.Rational(1,1200))
zero('rate_merge_confluent_limit',sp.limit((R.subs(z,-a)-R.subs(z,-a*t))/(a*(t-1)),t,1)-sp.diff(R,z).subs(z,-a))
out={'checks':checks,'passed':sum(checks.values()),'failed':len(checks)-sum(checks.values()),'status':'EXACT_SYMBOLIC_CHECKS','claims_not_implied':['general stiff order','native AD or Krylov implementation','performance superiority']}
(root/'evidence/algebra_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
