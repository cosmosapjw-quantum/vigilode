import sys,json
from fractions import Fraction as F
from pathlib import Path
from run_study import integrate,Model,enc
root=Path(__file__).resolve().parents[1];records=[]
for label in sys.argv[1:]:
    old=json.loads((root/'evidence'/f'{label}.json').read_text())
    params={key:(int(v) if key=='branch' else F(v)) for key,v in old['model'].items()};m=Model(**params)
    kwargs={}
    if label=='case_nonuniform_k10000':kwargs['cap']=(F(1,32),F(1,64))
    new=integrate(m,eps=F(old['eps']),T=F(old['T']),policy=old['policy'],u0=F(old['initial_uv'][0]),v0=F(old['initial_uv'][1]),**kwargs)
    expected={k:v for k,v in old.items() if k!='elapsed_seconds_diagnostic'}
    actual=json.loads(json.dumps(new,default=enc))
    same=actual==expected
    rec={'case':label,'exact_full_nontiming_result_match':same,'steps':len(new['history'])}
    records.append(rec);print(rec,flush=True)
    if not same:raise AssertionError(label)
path=root/'evidence'/'final_replay_records.json'
previous=json.loads(path.read_text()) if path.exists() else []
previous=[v for v in previous if v['case'] not in sys.argv[1:]]+records
path.write_text(json.dumps(previous,indent=2))
