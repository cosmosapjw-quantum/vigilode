"""Exploratory, exact-rational causal feedback integrator. Not a production solver.

x'=sigma*sqrt(1+x)-x+alpha*w1, w'=kappa*[[-1,beta],[0,-rate]]w.
Internal coordinate z=x-ell*w, ell={alpha,0} A^{-1}.
Two slow candidates: LIFTED_OUTER (v=0, bounded transient),
RESOLVED_JET (v is fast Taylor polynomial with semigroup remainder).
A partitioned scalar RVJ endpoint correction is used, not the full-system RVJ map.
No future exact trajectory or numerical oracle is imported into this module.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import hashlib,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'inputs/loop5/code'))
from fast_pair import FastModel,choose_fast,weighted_norm
from polynomial import add,scale,mul,deriv,value,abs_bound,bernstein_range,sqrt_interval
from loop4_scalar import nearest,up,pow2,ContractError,PrecisionBlocked

DOMAIN=(F(-1,2),F(1)); QMIN=F(2,3); LIP=F(7,4)

@dataclass(frozen=True)
class Model:
    kappa:F
    beta:F=F(4)
    rate:int=1
    alpha:F=F(1,4)
    epoch:str='loop6-constant-feedback-v1'
    def __post_init__(self):
        for k in ('kappa','beta','alpha'):object.__setattr__(self,k,F(getattr(self,k)))
        if self.kappa<1 or self.rate not in (1,2) or not isinstance(self.epoch,str) or not self.epoch:
            raise ContractError('kappa>=1, rate in {1,2}, nonempty epoch required')
    @property
    def fast(self):return FastModel(self.kappa,self.beta,self.rate,self.epoch)
    @property
    def d(self):return max(F(1),abs(self.beta))
    @property
    def ell(self):return (-self.alpha/self.kappa,-self.alpha*self.beta/(self.kappa*self.rate))
    @property
    def ellnorm(self):return abs(self.ell[0])*self.d+abs(self.ell[1])
    def binding(self):return f'{self.kappa}|{self.beta}|{self.rate}|{self.alpha}|{self.epoch}'
    def A(self,w):return (self.kappa*(-w[0]+self.beta*w[1]),-self.kappa*self.rate*w[1])
    def ell_dot(self,w):return sum((l*v for l,v in zip(self.ell,w)),F(0))

@dataclass(frozen=True)
class Snapshot:
    t:F
    z:F
    w:tuple[F,F]
    ez:F
    ew:F
    branch:int
    binding:str
    generation:int=0
    spent_transient:F=F(0)
    budget_policy:str='time_density'
    def __post_init__(self):
        for k in ('t','z','ez','ew','spent_transient'):object.__setattr__(self,k,F(getattr(self,k)))
        object.__setattr__(self,'w',tuple(map(F,self.w)))
        if self.t<0 or self.ez<0 or self.ew<0 or len(self.w)!=2 or self.branch not in(-1,1) or self.generation<0 or self.spent_transient<0 or self.budget_policy not in ('time_density','split_reserve'):
            raise ContractError('invalid snapshot')
    def digest(self):return hashlib.sha256(repr(self).encode()).hexdigest()

def initial(model:Model,branch:int,w0=(F(0),F(1)),bits:int=112,budget_policy='time_density')->Snapshot:
    w=tuple(map(F,w0));raw=-model.ell_dot(w);z=nearest(raw,bits)
    return Snapshot(F(0),z,w,abs(raw-z),F(0),branch,model.binding(),budget_policy=budget_policy)

def decay_integral(h:F,m:Model)->F:return min(F(h),2/m.kappa)

def endpoint_gain(h:F,m:Model)->F:
    a=m.kappa*h
    # ||exp(sA)||_d <= (1+k*s) exp(-k*s), valid for rate 1 or2.
    eu=1/sum((a**j/F(factorial(j)) for j in range(7)),F(0))
    return min(F(1),(1+a)*eu)

def fast_polynomial(w,h,m,degree=5):
    c=[tuple(w)]
    for j in range(degree+1):
        nxt=m.A(c[-1]);c.append(tuple(a/F(j+1) for a in nxt))
    vv=tuple(tuple(c[j][i]*h**j for j in range(degree+1)) for i in range(2))
    # c[degree+1] = A^(degree+1) w/(degree+1)!.
    rem=weighted_norm(c[degree+1],m.d)
    sup=m.ellnorm*rem*h**(degree+1)
    integral=sup*h/F(degree+2)
    return vv,sup,integral,c

def outer_shift_bounds(w,h,m):
    # ell exp(sA)w, not alpha*w1. Incorporates one inverse fast rate.
    u,v=map(abs,w);B=abs(m.beta);k=m.kappa
    sup=abs(m.alpha)/k*(u+B*v)
    total=abs(m.alpha)/(k*k)*(u+(2 if m.rate==1 else 1)*B*v)
    return sup,min(h*sup,total)

def make_candidate(s:Snapshot,h:F,m:Model,mode:str,bits:int=112):
    if mode=='LIFTED_OUTER':
        vv=((F(0),),(F(0),));sup,integ=outer_shift_bounds(s.w,h,m)
        coeff=[(F(0),F(0)) for _ in range(7)]
    elif mode=='RESOLVED_JET':
        vv,sup,integ,coeff=fast_polynomial(s.w,h,m)
    else:raise ContractError('unknown slow mode')
    xi0=s.z+m.ell_dot(coeff[0])
    if not DOMAIN[0]<=xi0<=DOMAIN[1]:
        return dict(valid=False,reason='CANDIDATE_BASE_OUTSIDE_CHART',mode=mode)
    lo,hi=sqrt_interval(1+xi0,bits+12);q0=s.branch*(lo+hi)/2
    zz=[s.z];qq=[q0];xx=[xi0]
    for j in range(5):
        zz.append((qq[j]-xx[j])/F(j+1))
        k=j+1;xx.append(zz[k]+m.ell_dot(coeff[k]))
        qq.append((xx[k]-sum((qq[i]*qq[k-i] for i in range(1,k)),F(0)))/(2*q0))
    p=[zz[j]*h**j for j in range(6)];rr=tuple(qq[j]*h**j for j in range(6))
    W=-1+1/(2*q0);z=h*W;Q=1-3*z/5+3*z*z/20-z**3/60
    if Q==0:raise ContractError('rational pole')
    phi=(z*z-5*z+12)/(1440*Q)
    p.append(120*h**5*zz[5]*(phi-F(1,120)))
    xi=add(p,add(scale(vv[0],m.ell[0]),scale(vv[1],m.ell[1])))
    return dict(valid=True,p=tuple(p),q=rr,xi=xi,v=vv,shift_sup=sup,
                shift_integral=integ,mode=mode,q_start=tuple(sorted((s.branch*lo,s.branch*hi))),
                work={'slow_candidates':1,'jet_levels':5,'sqrt_intervals':1,
                      'fast_polynomial_actions':6 if mode=='RESOLVED_JET' else 0})

def certify(s:Snapshot,h:F,m:Model,c:dict,bits:int=112):
    if not c.get('valid'):return c
    p,q,xi=c['p'],c['q'],c['xi'];pr=bernstein_range(xi);qr=bernstein_range(q)
    qmin=qr[0] if s.branch==1 else -qr[1]
    if qmin<QMIN:return dict(valid=False,reason='WITNESS_MARGIN',mode=c['mode'])
    dg=add(add(scale(deriv(p),1/h),xi),scale(q,-1))
    ag=add(add(mul(q,q),(-F(1),)),scale(xi,-1))
    Df=abs_bound(dg);Dg=abs_bound(ag);Delta=Df+Dg/(qmin+QMIN)
    inherited_integral=m.ellnorm*s.ew*decay_integral(h,m)
    cross=LIP*inherited_integral
    local_defect=h*Delta+LIP*c['shift_integral']
    whole_z=s.ez+cross+local_defect
    shift_sup=c['shift_sup']+m.ellnorm*s.ew
    whole_x=whole_z+shift_sup
    # xi, p+ell*w_exact, and true x are all guarded by the same strict tube.
    if not (DOMAIN[0]<pr[0]-whole_x and pr[1]+whole_x<DOMAIN[1]):
        return dict(valid=False,reason='WHOLE_COUPLED_TUBE',mode=c['mode'],whole_x=whole_x)
    raw=value(p,F(1));stored=nearest(raw,bits)
    local_raw=local_defect+abs(raw-stored);local=up(local_raw,bits)
    return dict(valid=True,reason='CERTIFIED',mode=c['mode'],value=stored,
                local_error=local,density_error=h*Delta+abs(raw-stored)+(local-local_raw),transient_error=LIP*c['shift_integral'],inherited_cross=cross,radius=s.ez+cross+local,
                whole_z=whole_z,whole_x=whole_x,x_reference_range=pr,
                root_path_error=(Dg+whole_x)/(qmin+QMIN),qmin=qmin,
                differential_defect=Df,algebraic_defect=Dg,Delta=Delta,
                center_shift_sup=c['shift_sup'],center_shift_integral=c['shift_integral'],
                rounding=abs(raw-stored),inflation=local-local_raw,candidate=c)

def physical_bounds(z,w,ez,ew,m,bits):
    xc=z+m.ell_dot(w);xs=nearest(xc,bits);ex=ez+m.ellnorm*ew+abs(xs-xc)
    # y defined from exact x; central output reconstructs from stored xs.
    ys=(nearest(w[0]+xs*xs/m.kappa,bits),nearest(w[1]+xs**3/m.kappa,bits))
    ax=abs(xs)
    B1=m.d*ew+(2*ax*ex+ex*ex)/m.kappa+abs(w[0]+xs*xs/m.kappa-ys[0])
    B2=ew+(3*ax*ax*ex+3*ax*ex*ex+ex**3)/m.kappa+abs(w[1]+xs**3/m.kappa-ys[1])
    return dict(x=xs,x_radius=ex,y=ys,y_bound=(B1,B2))

def budgets(m,tol,T):
    # ez <= eps/16 + L ellnorm T * ew_max + initial/rounding included separately.
    return tol/16,tol/(64*m.d*(1+(1+LIP*T)*m.ellnorm))

def attempt(s,h,m,tol,T,bits=112,forced_mode=None):
    h,tol,T=map(F,(h,tol,T))
    if s.binding!=m.binding():raise ContractError('MODEL_EPOCH_MISMATCH')
    if h<=0 or tol<=0 or T<=0 or not s.t<s.t+h<=T or s.branch not in(-1,1):raise ContractError('invalid trial')
    ezmax,ewmax=budgets(m,tol,T);bz=ezmax*h/T;bw=ewmax*h/T
    reasons=[];work={'slow_candidates':0,'rejected_slow_candidates':0,'bernstein_certificates':0,
                     'jet_levels':0,'sqrt_intervals':0,'fast_polynomial_actions':0}
    modes=[forced_mode] if forced_mode else ['LIFTED_OUTER','RESOLVED_JET']
    slow=None
    for mode in modes:
        c=make_candidate(s,h,m,mode,bits)
        for k,v in c.get('work',{'slow_candidates':1}).items():work[k]=work.get(k,0)+v
        if c['valid']:work['bernstein_certificates']+=1
        check=certify(s,h,m,c,bits)
        density_ok=check.get('valid') and check['local_error']<=bz
        reserve_ok=(check.get('valid') and check['density_error']<=bz/4
                    and s.spent_transient+check['transient_error']<=3*ezmax/4)
        if (density_ok if s.budget_policy=='time_density' else reserve_ok):
            slow=check;break
        reasons.append({'mode':mode,'reason':check.get('reason') if not check.get('valid') else 'LOCAL_FEEDBACK_BUDGET',
                        'local_error':str(check.get('local_error','NA'))})
        work['rejected_slow_candidates']+=1
    if slow is None:return dict(accepted=False,input_digest=s.digest(),reason='NO_SLOW_CANDIDATE',reasons=reasons,work=work)
    fast=choose_fast(s.w,s.ew,h,m.fast,bw,bits)
    work.update(fast['work']);ww=fast['value'];raw_ew=endpoint_gain(h,m)*s.ew+fast['local_error']
    ew=up(raw_ew,bits);extra=ew-raw_ew
    # Extra cumulative-radius rounding must be charged to this step, not hidden.
    if fast['local_error']+extra>bw:
        return dict(accepted=False,input_digest=s.digest(),reason='FAST_RADIUS_INFLATION',work=work)
    zz=slow['value'];ez=slow['radius'];ph=physical_bounds(zz,ww,ez,ew,m,bits)
    if ew>ewmax or max(ph['y_bound']+(ph['x_radius'],))>tol or not DOMAIN[0]<ph['x']-ph['x_radius'] or not ph['x']+ph['x_radius']<DOMAIN[1]:
        return dict(accepted=False,input_digest=s.digest(),reason='PHYSICAL_OR_DOMAIN_BUDGET',work=work)
    spent=s.spent_transient+(slow['transient_error'] if s.budget_policy=='split_reserve' else 0)
    out=Snapshot(s.t+h,zz,ww,ez,ew,s.branch,s.binding,s.generation+1,spent,s.budget_policy)
    return dict(accepted=True,input_digest=s.digest(),snapshot=out,slow=slow,fast=fast,
                physical=ph,work=work,slow_budget=bz,fast_budget=bw,reasons=reasons,h=h)

def commit(s,trial):
    if not trial.get('accepted') or trial.get('input_digest')!=s.digest():raise ContractError('STALE_OR_REJECTED_TRIAL')
    o=trial['snapshot']
    if o.binding!=s.binding or o.branch!=s.branch or o.generation!=s.generation+1 or o.budget_policy!=s.budget_policy:raise ContractError('WITNESS_GENERATION_MISMATCH')
    return o

def integrate(m,branch=1,w0=(F(0),F(1)),tol=F(1,10**8),T=F(1,4),bits=112,max_attempts=4000,nonuniform=False,budget_policy='time_density'):
    T,tol=F(T),F(tol)
    if not 0<T<=F(1,4) or tol<=0:raise ContractError('T in (0,1/4] and positive tolerance required')
    s=initial(m,branch,w0,bits,budget_policy);h=min(T,F(1,8));history=[];rejected=[];counts={}
    for _ in range(max_attempts):
        if s.t==T:break
        cap=(F(1,64) if len(history)%2==0 else F(1,32)) if nonuniform else F(1,8)
        h=min(h,cap,T-s.t);before=s.digest();tr=attempt(s,h,m,tol,T,bits)
        for k,v in tr['work'].items():counts[k]=counts.get(k,0)+v
        if not tr['accepted']:
            assert before==s.digest();rejected.append(dict(t=str(s.t),h=str(h),reason=tr['reason'],details=tr.get('reasons')));h/=2
            if h<pow2(-bits//2):raise PrecisionBlocked('step floor')
            continue
        history.append(tr);s=commit(s,tr)
        growth_error=tr['slow']['density_error'] if budget_policy=='split_reserve' else tr['slow']['local_error']
        growth_budget=tr['slow_budget']/4 if budget_policy=='split_reserve' else tr['slow_budget']
        if growth_error<=growth_budget/64:h*=2
        elif nonuniform:h=min(2*h,F(1,32))
    else:raise PrecisionBlocked('attempt cap')
    return dict(snapshot=s,history=history,rejected=rejected,counts=counts,accepted=len(history),attempts=len(history)+len(rejected),model=m,branch=branch,tol=tol,T=T,w0=tuple(map(F,w0)),budget_policy=budget_policy)
