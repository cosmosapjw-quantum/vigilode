from pathlib import Path
import sympy as S,json
x,z,u,v,k,b,r,c,h,t,a,nu,C,D=S.symbols('x z u v k b r c h t a nu C D')
A=k*S.Matrix([[-1,b],[0,-r]]); ell=S.Matrix([[c,0]])*A.inv();w=S.Matrix([u,v])
F=S.Function('F'); coords=S.Matrix([x-(ell*w)[0],u,v]);vf=S.Matrix([F(x)+c*u,*(A*w)])
checks={}
def zero(name,expr):
 if isinstance(expr,S.MatrixBase):ok=all(S.simplify(a)==0 for a in expr)
 else:ok=S.simplify(expr)==0
 checks[name]=bool(ok)
 assert ok,name
zero('left_inverse_feedback',ell*A-S.Matrix([[c,0]]))
zero('regular_chart_det',coords.jacobian([x,u,v]).det()-1)
zero('transformed_slow_field',(coords.jacobian([x,u,v])*vf)[0]-F(x))
J=S.exp(-k*t)*S.Matrix([[1,b*k*t],[0,1]])
zero('jordan_lift_formula',(ell.subs(r,1)*J*w)[0]+c/k*S.exp(-k*t)*(u+b*(1+k*t)*v))
E=S.Matrix([[S.exp(-k*t),b*(S.exp(-k*t)-S.exp(-2*k*t))],[0,S.exp(-2*k*t)]])
zero('distinct_lift_formula',(ell.subs(r,2)*E*w)[0]+c/k*(S.exp(-k*t)*u+b*(S.exp(-k*t)-S.exp(-2*k*t)/2)*v))
I=(2-(2+k*h)*S.exp(-k*h))/k
zero('semigroup_integral_derivative',S.diff(I,h)-(1+k*h)*S.exp(-k*h))
zero('semigroup_integral_at_zero',I.subs(h,0))
zero('same_endpoint_forcing_area',S.integrate(6*t*(1-t),(t,0,1))-1)
zero('same_endpoint_forcing_left',(6*t*(1-t)).subs(t,0))
zero('same_endpoint_forcing_right',(6*t*(1-t)).subs(t,1))
zero('initial_memory_identity',c/k-c/k*S.exp(-k*h)-c*(1-S.exp(-k*h))/k)
q=S.symbols('q');zero('closure_factorization',q*q-1-x-(q-S.sqrt(1+x))*(q+S.sqrt(1+x)))
M=S.Matrix([[-a,C],[D,-nu]])
zero('small_gain_positive_inverse',(-M).inv()-S.Matrix([[nu,C],[D,a]])/(a*nu-C*D))
# General two-sided extra term. z=x-ell w, w'=A w + g(x).
g1,g2=S.symbols('g1 g2');g=S.Matrix([g1,g2]);vf2=S.Matrix([F(x)+c*u,*(A*w+g)])
zero('two_sided_lift_extra_term',(coords.jacobian([x,u,v])*vf2)[0]-(F(x)-(ell*g)[0]))
# Time/state varying row requires derivative term, not the constant-row formula.
L0,L1=S.Function('L0')(t),S.Function('L1')(t)
X,U,V=[S.Function(s)(t) for s in ('X','U','V')]
zero('moving_row_connection',S.diff(X-L0*U-L1*V,t)-(S.diff(X,t)-L0*S.diff(U,t)-L1*S.diff(V,t)-S.diff(L0,t)*U-S.diff(L1,t)*V))
root=Path(__file__).resolve().parents[1]
(root/'evidence/algebra_checks.json').write_text(json.dumps({'checks':checks,'passed':sum(checks.values()),'failed':0},indent=2))
print(json.dumps(checks,indent=2));print('checks',len(checks))
