"""Exploratory evidence. Audit oracle is not imported by the solver modules."""
from fractions import Fraction as F
from pathlib import Path
import json,gzip,dataclasses,time
import mpmath as mp
from fast_pair import FastModel, action_bound, rational_action, weighted_norm
from loop4_scalar import fast_defect_bound
from hybrid_pair import integrate
from polynomial import value

ROOT=Path(__file__).resolve().parents[1]
E=ROOT/'evidence'
CASES=[dict(k=k,beta=4,rate=rate,branch=1,w0=(F(0),F(1))) for k in (1,40,10000) for rate in (1,2)]
CASES += [dict(k=k,beta=4,rate=rate,branch=-1,w0=(F(0),F(1))) for k in (40,10000) for rate in (1,2)]
CASES += [dict(k=40,beta=20,rate=1,branch=1,w0=(F(0),F(1))),dict(k=1,beta=20,rate=2,branch=1,w0=(F(0),F(1))),dict(k=10000,beta=4,rate=1,branch=1,w0=(F(0),F(0))),dict(k=40,beta=-4,rate=2,branch=-1,w0=(F(-1,3),F(-2,5)))]

def serial(x):
    if isinstance(x,F):return str(x)
    if dataclasses.is_dataclass(x):return {k:serial(v) for k,v in dataclasses.asdict(x).items()}
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    return x

def save(name,data):
    (E/name).write_text(json.dumps(serial(data),indent=2,ensure_ascii=False)+'\n')

def mm(x):
    if isinstance(x,F):return mp.mpf(x.numerator)/x.denominator
    return mp.mpf(x)


def oracles(dps):
    mp.mp.dps=dps
    return {sgn:mp.odefun(lambda t,x,s=sgn:s*mp.sqrt(1+x)-x,0,0,tol=mp.mpf(10)**(-dps+12),degree=50) for sgn in(-1,1)}

def fast_exact(t,k,beta,rate,w):
    a=mm(k)*mm(t);bt=mm(beta);u,v=map(mm,w)
    if rate==1:return (mp.exp(-a)*(u+bt*a*v),mp.exp(-a)*v)
    return (mp.exp(-a)*u+bt*(mp.exp(-a)-mp.exp(-2*a))*v,mp.exp(-2*a)*v)


def audit(out,case,oracle):
    max_errors=[mp.mpf(0)]*5; max_ratio=mp.mpf(0); checks=0;interior=0
    for row in out['history']:
        state=row['snapshot'];t=mm(state.t);x=oracle[case['branch']](t)
        w=fast_exact(state.t,case['k'],case['beta'],case['rate'],case['w0'])
        exact_y=(w[0]+x*x/case['k'],w[1]+x**3/case['k'])
        errors=[abs(mm(state.x)-x),abs(mm(state.w[0])-w[0]),abs(mm(state.w[1])-w[1]),abs(mm(row['physical'][0])-exact_y[0]),abs(mm(row['physical'][1])-exact_y[1])]
        bounds=[state.x_radius,FastModel(case['k'],case['beta'],case['rate']).scale*state.w_radius,state.w_radius,*row['physical_bound']]
        for j,(err,bd) in enumerate(zip(errors,bounds)):
            slack=mp.mpf('1e-85')
            assert err<=mm(bd)+slack, (case,str(t),j,mp.nstr(err,30),str(bd))
            max_errors[j]=max(max_errors[j],err)
            if bd:max_ratio=max(max_ratio,err/mm(bd))
            checks+=1
        c=row['slow']['candidate'];start=state.t-row['h']
        for theta in (F(0),F(1,4),F(1,2),F(3,4),F(1)):
            tt=start+theta*row['h'];xx=oracle[case['branch']](mm(tt));qq=case['branch']*mp.sqrt(1+xx)
            ep=abs(mm(value(c['p'],theta))-xx);eq=abs(mm(value(c['r'],theta))-qq)
            assert ep<=mm(row['slow']['whole_radius'])+mp.mpf('1e-85')
            assert eq<=mm(row['slow']['closure_whole_error'])+mp.mpf('1e-85')
            interior+=1
    return {'max_coordinate_and_physical_error':list(map(lambda x:mp.nstr(x,22),max_errors)),
            'max_error_to_bound':mp.nstr(max_ratio,22),'endpoint_scalar_checks':checks,
            'slow_closure_interior_checks':interior,'actual_endpoint_all_within_certificate':True}


def main():
    E.mkdir(exist_ok=True)
    save('CASE_MATRIX.json',{'kind':'exploratory','cases':CASES,'tolerance':'1/100000000','T':'1/4','oracle_dps':100})
    oo=oracles(100);summ=[];all_traces=[]
    for i,c in enumerate(CASES):
        m=FastModel(F(c['k']),F(c['beta']),c['rate'])
        out=integrate(m,c['branch'],c['w0'])
        q=audit(out,c,oo)
        record={'id':f'E03-{i+1:02d}',**serial(c),'accepted':out['accepted'],'attempts':out['attempts'],'modes':out['modes'],'work':out['counts'],**q}
        summ.append(record);all_traces.append({'case':c,'result':out})
        print(record['id'], c['k'],c['beta'],c['rate'],c['branch'], out['accepted'],out['modes'],q['max_coordinate_and_physical_error'],flush=True)
    save('adaptive_runs.json',summ)
    with gzip.open(E/'adaptive_traces.json.gz','wt',encoding='utf-8') as f:json.dump(serial(all_traces),f)
    refinement=[]
    c=CASES[4]
    for power in (6,8,10):
        out=integrate(FastModel(F(c['k']),F(c['beta']),c['rate']),c['branch'],c['w0'],tol=F(1,10**power))
        refinement.append({'tolerance_power':power,'accepted':out['accepted'],'modes':out['modes'],**audit(out,c,oo)})
    save('tolerance_refinement.json',refinement)
    print('tolerance refinement',[(r['tolerance_power'],r['accepted'],r['modes']) for r in refinement],flush=True)
    # Independent oracle precision refinement; no solver rerouting/refitting.
    oldx=oo[1](mp.mpf('0.25'));oo2=oracles(150);newx=oo2[1](mp.mpf('0.25'))
    save('oracle_precision.json',{'old_dps':100,'new_dps':150,'endpoint_absolute_difference':mp.nstr(abs(oldx-newx),30),'main_oracle':'mpmath.odefun,degree=50','exact_slow_flow_used_in_solver':False})
    # Non-normal action and eigenvalue-only failure, with independent matrix exponential.
    mp.mp.dps=100
    action=[]
    for a in [F(1,10000),F(1,100),F(1),F(10),F(1000),F(10**6)]:
        for beta in [F(-20),F(0),F(4),F(20)]:
            for rate in (1,2):
                for w in [(F(0),F(1)),(F(-1,3),F(-2,5))]:
                    raw=rational_action(a,beta,rate,w);bd=action_bound(a,beta,rate,w)
                    mat=mp.matrix([[-mm(a),mm(beta*a)],[0,-rate*mm(a)]])
                    exact=mp.expm(mat)*mp.matrix(list(map(mm,w)))
                    errors=[abs(mm(raw[j])-exact[j]) for j in range(2)]
                    assert all(errors[j]<=mm(bd[j])+mp.mpf('1e-90') for j in range(2))
                    action.append({'a':str(a),'beta':str(beta),'rate':rate,'w':list(map(str,w)),'error':list(map(lambda z:mp.nstr(z,20),errors)),'bound':list(map(str,bd))})
    save('fast_matrix_enclosures.json',{'count':len(action),'cases':action,'independent_oracle':'mpmath matrix exponential at 100 decimal digits'})
    a=F(1);bt=F(20);ww=(F(0),F(1));raw=rational_action(a,bt,1,ww)
    exact=fast_exact(F(1),1,20,1,ww);err=max(abs(mm(raw[0])-exact[0])/20,abs(mm(raw[1])-exact[1]));naive=mm(fast_defect_bound(a))
    save('eigenvalue_only_negative.json',{'a':'1','beta':'20','initial_w':['0','1'],'weighted_norm_error':mp.nstr(err,25),'scalar_eta_bound':mp.nstr(naive,25),'underestimate_ratio':mp.nstr(err/naive,25),'violates_scalar_only_bound':bool(err>naive)})
    print('matrix enclosures',len(action),'negative ratio',mp.nstr(err/naive,15),flush=True)

if __name__=='__main__':main()
