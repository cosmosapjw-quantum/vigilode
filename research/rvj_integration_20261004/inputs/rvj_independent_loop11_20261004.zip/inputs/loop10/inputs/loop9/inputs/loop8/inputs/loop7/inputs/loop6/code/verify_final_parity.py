"""Rebind saved high-precision audits to the final default reference arithmetic.
New policy metadata is excluded deliberately; numerical values and all bounds
are exact-equality checked for every accepted step. No oracle is called here.
"""
from feedback import F,Model,integrate
from pathlib import Path
import json,gzip
ROOT=Path(__file__).resolve().parents[1]

def encode(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,dict):return {k:encode(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [encode(v) for v in x]
    return x

out=[]
for info in json.loads((ROOT/'evidence/CASE_MATRIX.json').read_text()):
    name=info['name'];m=Model(**info['model']);branch=info['branch'];w0=tuple(map(F,info['w0']))
    old=json.load(gzip.open(ROOT/f'evidence/trace_{name}.json.gz','rt'))
    new=integrate(m,branch,w0,F(old['tol']),F(old['T']),112)
    assert new['accepted']==old['accepted']
    assert len(new['rejected'])==len(old['rejected'])
    for a,b in zip(new['history'],old['history']):
        assert encode(a['physical'])==b['physical'],(name,'physical')
        for k in ('t','z','w','ez','ew','branch','binding','generation'):
            assert encode(getattr(a['snapshot'],k))==b['snapshot'][k],(name,k)
        for k in ('whole_z','whole_x','root_path_error','local_error','value','radius','Delta','mode'):
            assert encode(a['slow'][k])==b['slow'][k],(name,k)
        assert a['fast']['mode']==b['fast']['mode']
    out.append({'case':name,'steps':new['accepted'],'numerical_outputs_and_bounds_exact_equal':True})
print(json.dumps({'cases':out,'total_steps':sum(x['steps'] for x in out),'status':'EXACT_EQUAL'},indent=2))
(ROOT/'evidence/final_default_parity.json').write_text(json.dumps(out,indent=2))
