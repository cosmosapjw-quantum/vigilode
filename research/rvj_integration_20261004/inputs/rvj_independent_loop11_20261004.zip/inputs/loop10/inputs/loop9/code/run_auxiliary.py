"""Exploratory follow-ups: precision, direct physical equation, tighter tolerance and variable steps."""
from run_studies import *

def run():
    m=Model();T=F(1,2)
    # High precision independent envelope oracle; no use by candidate/certifier.
    mp.mp.dps=60
    def mp_rhs(t,a):
        x,y,u,v=a;qq=mp.sqrt(1+x*x+y*y+2*u*u+2*v*v)
        return [qq*(y*u-x*v)/2,qq*(x*u+y*v)/2,-qq*x*y/2,qq*(x*x-y*y)/4]
    hp=mp.odefun(mp_rhs,mp.mpf(0),list(map(mpf,initial_state().a)),tol=mp.mpf('1e-44'),degree=24)
    hpT=hp(mpf(T));lo,lo2=oracle(m,T)
    cross=mp.sqrt(sum(int(w)*(hpT[j]-mpf(lo.sol(float(T))[j]))**2 for j,w in enumerate(WEIGHTS)))
    dump('high_precision_oracle.json',dict(dps=60,degree=24,tolerance='1e-44',envelope_T=hpT,dop853_difference=cross,formal_validated_oracle=False))
    # Original physical equations, independently coded rather than reconstructed envelope RHS.
    om=40.0
    def physical(t,z):
        z1=z[0]+1j*z[1];z2=z[2]+1j*z[3]
        qq=np.sqrt(1+abs(z1)**2+2*abs(z2)**2)
        f1=1j*om*z1+0.5j*qq*np.conj(z1)*z2
        f2=2j*om*z2+0.25j*qq*z1*z1
        return [f1.real,f1.imag,f2.real,f2.imag]
    sol=solve_ivp(physical,(0,.5),list(map(float,initial_state().a)),method='DOP853',rtol=3e-13,atol=2e-15,dense_output=True)
    if not sol.success:raise RuntimeError(sol.message)
    integ=integrate(m);errs=[]
    for c in integ['history']:
        rec=reconstruction(c['new'],F(40));ex=sol.sol(float(c['new'].t))
        err=mp.sqrt(sum(int(w)*(mpf(v)-mpf(e))**2 for w,v,e in zip(WEIGHTS,rec['value'],ex)))
        errs.append(dict(t=c['new'].t,error=err,bound=rec['error'],inside=bool(err<=mpf(rec['error']))))
    dump('direct_physical_oracle.json',dict(omega=40,method='DOP853',rtol='3e-13',atol='2e-15',nfev=sol.nfev,records=errs,formal_validated_oracle=False))
    tolrows=[]
    for tol in (F(1,10**6),F(1,10**8),F(1,10**10),F(1,10**12)):
        out=integrate(m,tol=tol);e=mp.sqrt(sum(int(w)*(mpf(v)-hpT[j])**2 for j,(w,v) in enumerate(zip(WEIGHTS,out['state'].a))));assert e<=mpf(out['state'].error)
        tolrows.append(dict(tol=tol,accepted=out['accepted'],work=out['work'],final_error=e,final_bound=out['state'].error))
    dump('tolerance_refinement.json',tolrows)
    s=initial_state();caps=(F(1,16),F(3,32));seq=[];attempts=0
    while s.t<T:
        h=min(caps[len(seq)%2],T-s.t)
        while True:
            attempts+=1;c=attempt(s,h,m,T,F(1,10**6))
            if c['accepted']:break
            h/=2
            if attempts>1000:raise RuntimeError('aux attempt cap')
        s=commit(s,c,m);seq.append(dict(h=h,t=s.t,error=s.error,path=c['path_digest']))
    e=mp.sqrt(sum(int(w)*(mpf(v)-hpT[j])**2 for j,(w,v) in enumerate(zip(WEIGHTS,s.a))));assert e<=mpf(s.error)
    dump('nonuniform_mesh.json',dict(steps=len(seq),unique_steps=sorted(set(str(r['h']) for r in seq)),attempts=attempts,history=seq,final_error=e,final_bound=s.error))
    # Missing-frequency uncertainty is distinct from amplitude error.
    s=integ['state'];dw=F(1,10**4);r=reconstruction(s,F(10**12),frequency_radius=dw)
    lo_r=reconstruction(s,F(10**12)+dw)
    diff=norm_up(tuple(v-u for v,u in zip(r['value'],lo_r['value'])))
    assert diff<=r['frequency_error']+r['carrier_arithmetic_error']+lo_r['carrier_arithmetic_error']
    dump('frequency_uncertainty.json',dict(common_carrier=10**12,delta_omega=dw,t=T,actual_center_difference=diff,phase_charge=r['frequency_error'],arithmetic_charge=r['carrier_arithmetic_error'],preserved_detuning=True))
    print('high precision, physical oracle, four tolerance runs, nonuniform mesh, frequency charge complete',flush=True)

if __name__=='__main__':run()
