from fractions import Fraction as F
import pytest
import mpmath as mp
from loop4_scalar import ContractError,PrecisionBlocked,exp_minus_interval
from fast_pair import FastModel,rational_action,action_bound,choose_fast,derivative_gap_bound,weighted_norm
from polynomial import value,deriv,bernstein_coefficients,bernstein_range,abs_bound,sqrt_interval
from slow_closure import make_candidate,certify_candidate,slow_attempt
from hybrid_pair import Snapshot,attempt,commit,integrate,physical_error


def mm(x):return mp.mpf(x.numerator)/x.denominator

def test_bernstein_is_exact_at_grid_values():
    from math import comb
    p=tuple(map(F,[2,-3,0,5,-1]));b=bernstein_coefficients(p);n=len(p)-1
    for theta in [F(j,16) for j in range(17)]:
        assert value(p,theta)==sum((b[i]*comb(n,i)*theta**i*(1-theta)**(n-i) for i in range(n+1)),F(0))
        lo,hi=bernstein_range(p);assert lo<=value(p,theta)<=hi

def test_endpoint_only_residual_is_blind_but_bernstein_is_not():
    # y'=0, p(theta)=3theta²-2theta³ has zero derivative at both ends,
    # but has unit wrong endpoint. A whole-path defect bound cannot be zero.
    p=(F(0),F(0),F(3),F(-2));res=deriv(p)
    assert value(res,F(0))==value(res,F(1))==0
    assert value(p,F(1))==1 and abs_bound(res)>=1

@pytest.mark.parametrize('v',[F(0),F(1),F(1,2),F(3,2),F(10**30+1,10**30)])
def test_integer_sqrt_interval(v):
    lo,hi=sqrt_interval(v,100);assert lo*lo<=v<=hi*hi;assert hi-lo<=F(1,2**100)

@pytest.mark.parametrize('a',[F(0),F(1,100),F(1),F(40),F(10000)])
def test_fast_nonnormal_action_enclosure(a):
    mp.mp.dps=100
    for rate in [1,2]:
        for beta in [F(-20),F(0),F(4)]:
            w=(F(-1,3),F(2,5));raw=rational_action(a,beta,rate,w);bd=action_bound(a,beta,rate,w)
            a0=mm(a);bt=mm(beta);u,v=map(mm,w)
            exact=(mp.exp(-a0)*(u+bt*a0*v),mp.exp(-a0)*v) if rate==1 else (mp.exp(-a0)*u+bt*(mp.exp(-a0)-mp.exp(-2*a0))*v,mp.exp(-2*a0)*v)
            for i in range(2):assert abs(mm(raw[i])-exact[i])<=mm(bd[i])+mp.mpf('1e-95')

def test_large_fast_amplitude_falls_back_but_zero_does_not():
    model=FastModel(F(10000),F(20),1)
    r=choose_fast((F(0),F(1)),F(0),F(1,100),model,F(1,10**12))
    assert r['mode']=='EXP_ENCLOSURE' and r['work']['scalar_exp_intervals']==1
    z=choose_fast((F(0),F(0)),F(0),F(1,100),model,F(1,10**12))
    assert z['mode']=='RVJ' and z['value']==(0,0)

@pytest.mark.parametrize('branch',[-1,1])
def test_slow_implicit_tube_and_order_scaling(branch):
    a=slow_attempt(F(0),F(1,32),F(0),branch)
    b=slow_attempt(F(0),F(1,64),F(0),branch)
    assert a['valid'] and b['valid']
    assert a['local_error']>40*b['local_error']
    assert a['rmin']>=F(2,3)
    assert a['p_range'][0]-a['whole_radius']>F(-1,2)

def test_wrong_branch_polynomial_rejected():
    a=make_candidate(F(0),F(1,32),1)
    out=certify_candidate(a['p'],a['r'],F(1,32),F(0),-1)
    assert not out['valid'] and out['reason']=='WITNESS_SIGN_OR_MARGIN'

def test_whole_tube_boundary_failure_is_not_accepted():
    a=make_candidate(F(-49,100),F(1,8),-1)
    out=certify_candidate(a['p'],a['r'],F(1,8),F(1,100),-1)
    assert not out['valid']

def test_epoch_change_and_stale_commit_rejected():
    m=FastModel(F(40),F(4));s=Snapshot(F(0),F(0),(F(0),F(1)),F(0),F(0),1,m.binding())
    with pytest.raises(ContractError):attempt(s,F(1,64),FastModel(F(41),F(4)),F(1,10**8),F(1,4))
    out=attempt(s,F(1,64),m,F(1,10**8),F(1,4));assert out['accepted']
    ss=commit(s,out)
    with pytest.raises(ContractError):commit(ss,out)

def test_reject_keeps_snapshot_unchanged():
    m=FastModel(F(40),F(4));s=Snapshot(F(0),F(0),(F(0),F(1)),F(0),F(0),1,m.binding())
    before=s.digest();out=attempt(s,F(1,8),m,F(1,10**12),F(1,4))
    assert not out['accepted'] and s.digest()==before
    with pytest.raises(ContractError):commit(s,out)

def test_additive_chart_regular_at_zero_and_physical_bound_corners():
    m=FastModel(F(2),F(4));x=F(0);w=(F(1,8),F(-1,4));rx=F(1,16);rw=F(1,32)
    b=physical_error(x,w,rx,rw,m,w)
    for sx in [-1,1]:
        for sw in [-1,1]:
            xx=x+sx*rx;u=w[0]+sw*m.scale*rw;v=w[1]+sw*rw
            assert abs(u+xx*xx/m.kappa-w[0])<=b[0]
            assert abs(v+xx**3/m.kappa-w[1])<=b[1]

@pytest.mark.parametrize('bad',[-1,3,0])
def test_unsupported_fast_family_rejected(bad):
    with pytest.raises(ContractError):FastModel(F(1),F(2),bad)

def test_adaptive_smoke_without_oracle():
    z=integrate(FastModel(F(40),F(4),2),1,tol=F(1,10**6))
    assert z['snapshot'].t==F(1,4)
    assert z['modes']['EXP_ENCLOSURE']>0
    for e in z['history']:
        assert max(e['physical_bound'])<=F(1,10**6)
        assert e['slow']['closure_whole_error']>0

@pytest.mark.parametrize('branch',[-1,1])
def test_initial_root_enclosure_is_ordered_for_both_witnesses(branch):
    c=make_candidate(F(1,4),F(1,64),branch)
    lo,hi=c['q_start']
    assert lo<=hi
    assert min(lo*lo,hi*hi)<=F(5,4)<=max(lo*lo,hi*hi)

def test_certificate_radius_inflation_is_explicitly_charged():
    s=slow_attempt(F(0),F(1,32),F(1,2**120),1)
    assert s['radius']==F(1,2**120)+s['local_error']
    m=FastModel(F(3),F(4),1)
    out=choose_fast((F(1,3),F(2,7)),F(1,2**120),F(1,32),m,F(1,100))
    assert out['radius']==F(1,2**120)+out['local_error']
