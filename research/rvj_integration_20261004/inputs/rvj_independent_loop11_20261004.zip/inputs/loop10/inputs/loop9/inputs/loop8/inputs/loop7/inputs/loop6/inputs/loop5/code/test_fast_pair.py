from fractions import Fraction as F
import mpmath as mp
from fast_pair import action_bound
from loop4_scalar import rational_fast

def test_scalar_lift_must_cover_jordan_offdiagonal():
    mp.mp.dps=90
    a=F(1); beta=F(20); w=(F(0),F(1))
    bound=action_bound(a,beta,1,w)[0]
    # Independent derivative of the scalar rational function at z=-1.
    r=lambda z:(1+2*z/5+z*z/20)/(1-3*z/5+3*z*z/20-z**3/60)
    err=20*abs(mp.diff(r,mp.mpf(-1))-mp.exp(-1))
    assert err <= mp.mpf(bound.numerator)/bound.denominator, (str(err),str(bound))
