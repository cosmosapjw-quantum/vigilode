"""Exploratory audit oracle is outside the integrator. No numerical timing claim.
Oracle: 65-digit mpmath scalar physical-x ODE in fast time until tau=96,
then autonomous slow scalar ODE with an explicitly bounded omitted forcing tail.
Fast exact values are evaluated only in this audit module.
"""
from feedback import *
import mpmath as mp,json,gzip,time,sys
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parents[1]
mp.mp.dps=65

def MP(x):
    x=F(x);return mp.mpf(x.numerator)/x.denominator

def fast_oracle(t,m,w0):
    a=MP(m.kappa)*t;u,v=map(MP,w0);B=MP(m.beta)
    e=mp.exp(-a)
    if m.rate==1:return (e*(u+B*a*v),e*v)
    e2=mp.exp(-2*a);return (e*(u+B*v)-B*e2*v,e2*v)

class Oracle:
    def __init__(self,m,branch,w0,T,dps=65,cut=96):
        self.m,self.branch,self.w0,self.T=m,branch,w0,T;self.cut=mp.mpf(cut)
        self.k=MP(m.kappa);alpha=MP(m.alpha)
        def f(tau,x):
            uu=fast_oracle(tau/self.k,m,w0)[0]
            return (branch*mp.sqrt(1+x)-x+alpha*uu)/self.k
        self.sol=mp.odefun(f,0,0,tol=mp.mpf(10)**(-dps+10),degree=32)
        self.endtau=min(self.cut,self.k*MP(T));self.endx=self.sol(self.endtau)
        self.split=self.endtau/self.k;self.later=None
        self.tail=mp.mpf(0)
        if self.endtau<self.k*MP(T):
            self.later=mp.odefun(lambda t,x:branch*mp.sqrt(1+x)-x,self.split,self.endx,
                                tol=mp.mpf(10)**(-dps+10),degree=32)
            u,v=map(lambda a:abs(MP(a)),w0);B=abs(MP(m.beta));c=self.cut
            # Triangle bound on remaining alpha*w1; nonpositive slow log norm.
            self.tail=abs(alpha)/self.k*mp.exp(-c)*(u+B*v*(c+1))
    def x(self,t):
        if t<=self.split:return self.sol(self.k*t)
        return self.later(t)

def serial(obj):
    if isinstance(obj,F):return str(obj)
    if isinstance(obj,Model):return {k:serial(v) for k,v in obj.__dict__.items()}
    if isinstance(obj,Snapshot):return {k:serial(v) for k,v in obj.__dict__.items()}
    if isinstance(obj,dict):return {k:serial(v) for k,v in obj.items()}
    if isinstance(obj,(tuple,list)):return [serial(x) for x in obj]
    return obj

def audit(run,oracle):
    m=run['model'];w0=run['w0'];history=run['history'];prev=initial(m,run['branch'],w0,112)
    ratios=[];mx=mp.mpf(0);my=[mp.mpf(0),mp.mpf(0)];mz=mp.mpf(0);interior=0
    for tr in history:
        s=tr['snapshot'];t=MP(s.t);xx=oracle.x(t);ww=fast_oracle(t,m,w0)
        yy=(ww[0]+xx*xx/MP(m.kappa),ww[1]+xx**3/MP(m.kappa))
        ph=tr['physical'];ex=abs(MP(ph['x'])-xx);mx=max(mx,ex)
        # Oracle tail is an explicit independent approximation, not a certificate value.
        assert ex+oracle.tail <= MP(ph['x_radius']),('x',m,s.t,ex,MP(ph['x_radius']))
        for i in range(2):
            ey=abs(MP(ph['y'][i])-yy[i]);my[i]=max(my[i],ey)
            tail_y=(2 if i==0 else 3)*oracle.tail/MP(m.kappa)
            bound=MP(ph['y_bound'][i]);assert ey+tail_y<=bound,('y',i,m,s.t,ey,bound)
            if bound:ratios.append(ey/bound)
        # Verify continuum enclosures at diagnostic interior points. Bernstein proves all points.
        for theta in [F(0),F(1,4),F(1,2),F(3,4),F(1)]:
            tt=MP(prev.t+tr['h']*theta);xo=oracle.x(tt);wo=fast_oracle(tt,m,w0)
            po=MP(value(tr['slow']['candidate']['p'],theta));xi=MP(value(tr['slow']['candidate']['xi'],theta))
            qo=MP(value(tr['slow']['candidate']['q'],theta));zo=xo-sum(MP(l)*w for l,w in zip(m.ell,wo))
            dz=abs(zo-po);mxpath=abs(xo-xi);dq=abs(run['branch']*mp.sqrt(1+xo)-qo)
            assert dz+oracle.tail<=MP(tr['slow']['whole_z'])+mp.mpf('1e-58'),('whole_z',m,theta,dz,MP(tr['slow']['whole_z']))
            assert mxpath+oracle.tail<=MP(tr['slow']['whole_x'])+mp.mpf('1e-58'),('whole_x',m,theta)
            assert dq+oracle.tail<=MP(tr['slow']['root_path_error'])+mp.mpf('1e-58'),('root',m,theta)
            mz=max(mz,dz);interior+=1
        prev=s
    end=history[-1]; counts=Counter(tr['slow']['mode'] for tr in history);fast=Counter(tr['fast']['mode'] for tr in history)
    return dict(model=serial(m),branch=run['branch'],w0=serial(w0),tol=str(run['tol']),T=str(run['T']),accepted=run['accepted'],
                rejected=len(run['rejected']),slow_modes=dict(counts),fast_modes=dict(fast),
                max_x_error=mp.nstr(mx,25),max_y_error=[mp.nstr(x,25) for x in my],
                max_error_bound_ratio=mp.nstr(max(ratios,default=0),20),
                final_x=float(end['physical']['x']),final_x_error_bound=float(end['physical']['x_radius']),
                whole_path_diagnostic_checks=interior,oracle_dps=mp.mp.dps,
                oracle_tail_abs_bound=mp.nstr(oracle.tail,12),work=run['counts'])

CASES=[
 ('k1',Model(1),1,(F(0),F(1))),
 ('k40',Model(40),1,(F(0),F(1))),
 ('k10000',Model(10000),1,(F(0),F(1))),
 ('k1e6',Model(1000000),1,(F(0),F(1))),
 ('distinct',Model(1000000,4,2),1,(F(0),F(1))),
 ('signed',Model(40,-4,2,F(-1,4)),1,(F(0),F(1))),
 ('negative_branch',Model(40),-1,(F(0),F(1))),
 ('negative_stiff',Model(1000000),-1,(F(0),F(1))),
 ('mixed_initial',Model(1),1,(F(-1),F(1,2))),
 ('zero_fast',Model(1000000),1,(F(0),F(0))),
 ('zero_feedback',Model(40,4,1,0),1,(F(0),F(1))),
 ('strong_nonnormal',Model(40,20,1,F(1,20)),1,(F(0),F(1))),
]

def main(indices=None):
    outputs=[];oracles={};runs={}
    indices=range(len(CASES)) if indices is None else indices
    for i in indices:
        name,m,b,w0=CASES[i];st=time.perf_counter();run=integrate(m,b,w0,tol=F(1,10**8),T=F(1,4),bits=112)
        print('REFERENCE',name,run['accepted'],len(run['rejected']),flush=True)
        oracle=Oracle(m,b,w0,run['T']);out=audit(run,oracle);out['case']=name
        outputs.append(out);oracles[name]=oracle;runs[name]=run
        (ROOT/f'evidence/case_{name}.json').write_text(json.dumps(out,indent=2))
        with gzip.open(ROOT/f'evidence/trace_{name}.json.gz','wt') as f:json.dump(serial(run),f)
        print('PASS',name,out['max_x_error'],out['slow_modes'],out['fast_modes'],'elapsed',round(time.perf_counter()-st,2),flush=True)
    return outputs,oracles,runs

if __name__=='__main__':
    indices=list(map(int,sys.argv[1:])) if len(sys.argv)>1 else None
    main(indices)
