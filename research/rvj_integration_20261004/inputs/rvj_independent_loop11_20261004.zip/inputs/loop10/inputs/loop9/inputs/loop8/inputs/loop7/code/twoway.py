"""Actual bidirectional loop7 reference, exact rational model and certificates.

x'=q-x+alpha*u, q^2=1+x on a retained signed branch;
u'=k*(-u+beta*v), v'=k*(eta*x-rho*v).
RVJ and Taylor candidates share a full continuous residual certificate.
Not production AD/Krylov and not a generic DAE solver. No future oracle import.
"""
from __future__ import annotations
from fractions import Fraction as F
from dataclasses import dataclass
from math import factorial
import hashlib
from polynomial import add, scale, mul, deriv, value, abs_bound, bernstein_range, sqrt_interval
from loop4_scalar import nearest, up, ContractError, PrecisionBlocked

DOMAIN=(F(-1,2),F(1)); QMIN=F(2,3); A_SLOW=F(1,4)


def fast_return_defect(p,h,k,eta,rho):
    return add(add(scale(deriv(p[2]),1/h),scale(p[2],k*rho)),scale(p[0],-k*eta))


def mm(a,b):
    return tuple(tuple(sum((a[i][k]*b[k][j] for k in range(3)),F(0)) for j in range(3)) for i in range(3))
def mv(a,b):return tuple(sum((a[i][j]*b[j] for j in range(3)),F(0)) for i in range(3))
def ma(a,b):return tuple(tuple(a[i][j]+b[i][j] for j in range(3)) for i in range(3))
def ms(a,c):return tuple(tuple(c*x for x in row) for row in a)
I=tuple(tuple(F(i==j) for j in range(3)) for i in range(3))


def solve3(a,b):
    """Small exact reference solve; no assertion about matrix-free cost."""
    rows=[list(map(F,a[i]))+[F(b[i])] for i in range(3)]
    for j in range(3):
        pivot=next((i for i in range(j,3) if rows[i][j]),None)
        if pivot is None:raise ContractError('SINGULAR_CANDIDATE_OPERATOR')
        rows[j],rows[pivot]=rows[pivot],rows[j]
        z=rows[j][j];rows[j]=[x/z for x in rows[j]]
        for i in range(3):
            if i!=j:
                z=rows[i][j];rows[i]=[x-z*y for x,y in zip(rows[i],rows[j])]
    return tuple(row[3] for row in rows)


def phi5_action(z,v):
    z2=mm(z,z);z3=mm(z2,z)
    den=ma(ma(ma(I,ms(z,F(-3,5))),ms(z2,F(3,20))),ms(z3,F(-1,60)))
    num=ma(ma(ms(I,F(12)),ms(z,F(-5))),z2)
    return solve3(den,tuple(x/F(1440) for x in mv(num,v)))


@dataclass(frozen=True)
class Model:
    k:F=F(1); alpha:F=F(1,16); beta:F=F(4); eta:F=F(1,16); rho:F=F(1)
    branch:int=1; epoch:int=0; weight:F=F(1,4)
    def __post_init__(self):
        for key in ('k','alpha','beta','eta','rho','weight'):
            object.__setattr__(self,key,F(getattr(self,key)))
        if self.k<1 or self.rho not in (1,2) or self.branch not in (-1,1) or self.weight<=0:
            raise ContractError('UNSUPPORTED_MODEL_OR_WITNESS')
        if self.margin<=0:raise ContractError('COMPARISON_NOT_CERTIFIED; not a physical instability verdict')
    @property
    def d(self):return max(F(1),2*abs(self.beta))
    @property
    def b(self):return min(1-abs(self.beta)/self.d,self.rho)
    @property
    def c(self):return abs(self.alpha)*self.d
    @property
    def margin(self):return min(A_SLOW-self.c*self.weight,self.k*(self.b-abs(self.eta)/self.weight))
    @property
    def units(self):return (F(1),self.d*self.weight,self.weight)
    def norm(self,v):return max(abs(x)/w for x,w in zip(v,self.units))
    def binding(self):return hashlib.sha256(repr(self).encode()).hexdigest()


@dataclass(frozen=True)
class State:
    t:F; y:tuple[F,F,F]; error:F=F(0); generation:int=0
    def digest(self):return hashlib.sha256(repr(self).encode()).hexdigest()


def initial_state(m:Model,u=F(0),v=F(1)):
    return State(F(0),(F(0),F(u),F(v)))


def make_jet(m:Model,y,h,bits=96):
    if bits<48:raise ContractError('bits>=48 required')
    x,u,v=map(F,y);h=F(h)
    if h<=0 or not DOMAIN[0]<x<DOMAIN[1]:raise ContractError('INVALID_CANDIDATE_START')
    lo,hi=sqrt_interval(1+x,bits+16);q0=m.branch*(lo+hi)/2
    yy=[(x,u,v)];qq=[q0]
    for j in range(5):
        xj,uj,vj=yy[j]
        yy.append(((qq[j]-xj+m.alpha*uj)/(j+1),m.k*(-uj+m.beta*vj)/(j+1),m.k*(m.eta*xj-m.rho*vj)/(j+1)))
        jj=j+1
        qq.append((yy[jj][0]-sum((qq[i]*qq[jj-i] for i in range(1,jj)),F(0)))/(2*q0))
    polys=tuple(tuple(yy[j][i]*h**j for j in range(6)) for i in range(3))
    root=tuple(qq[j]*h**j for j in range(6))
    J=(( -1+1/(2*q0),m.alpha,F(0)),(F(0),-m.k,m.k*m.beta),(m.k*m.eta,F(0),-m.k*m.rho))
    return {'p':polys,'q':root,'J':J,'a5':yy[5],'h':h,'sqrt_interval':tuple(sorted((m.branch*lo,m.branch*hi)))}


def make_candidate(jet,mode='RVJ'):
    if mode not in ('RVJ','TAYLOR'):raise ContractError('UNKNOWN_CANDIDATE')
    if mode=='TAYLOR':return {'p':jet['p'],'q':jet['q'],'mode':mode,'shifted_solves':0}
    h=jet['h'];phi=phi5_action(ms(jet['J'],h),jet['a5'])
    correction=tuple(h**5*(120*a-b) for a,b in zip(phi,jet['a5']))
    p=tuple(tuple(poly)+(c,) for poly,c in zip(jet['p'],correction))
    return {'p':p,'q':jet['q'],'mode':mode,'shifted_solves':1}


def coupled_defects(m,p,q,h):
    if len(p)!=3 or not q or any(not x for x in p):raise ContractError('EMPTY_PATH')
    d1=add(add(add(scale(deriv(p[0]),1/h),p[0]),scale(q,-1)),scale(p[1],-m.alpha))
    d2=add(add(scale(deriv(p[1]),1/h),scale(p[1],m.k)),scale(p[2],-m.k*m.beta))
    d3=fast_return_defect(p,h,m.k,m.eta,m.rho)
    ag=add(add(mul(q,q),(-F(1),)),scale(p[0],-1))
    rr=bernstein_range(q);rmin=rr[0] if m.branch==1 else -rr[1]
    if rmin<QMIN:return {'valid':False,'reason':'WITNESS_MARGIN','root_range':rr}
    gf=abs_bound(ag);ds=(abs_bound(d1)+gf/(rmin+QMIN),abs_bound(d2),abs_bound(d3))
    return {'valid':True,'differential':ds,'algebraic':gf,'rmin':rmin,'root_range':rr,
            'delta':m.norm(ds),'power_defects':(d1,d2,d3),'power_algebraic':ag}


def small_gain_box(m,h,ex,ew,df,dg):
    """Componentwise error radii; sufficient inequality, not instability test."""
    h,ex,ew,df,dg=map(F,(h,ex,ew,df,dg))
    if h<=0 or min(ex,ew,df,dg)<0:raise ContractError('INVALID_RADIUS_INPUT')
    px=min(h,1/A_SLOW);pw=min(h,1/(m.k*m.b));g=m.c*m.k*abs(m.eta)*px*pw
    if g>=1:raise ContractError('SMALL_GAIN_UNRESOLVED')
    bx=ex+px*df;bw=ew+pw*dg
    return {'x':(bx+m.c*px*bw)/(1-g),'w':(bw+m.k*abs(m.eta)*pw*bx)/(1-g),'gain':g}


def physical(m,y,E,bits=96):
    x,u,v=y
    exact=(x,u+x*x/m.k,v+x*x*x/m.k)
    stored=tuple(nearest(z,bits) for z in exact)
    rr=tuple(abs(a-b) for a,b in zip(exact,stored))
    bounds=(E+rr[0],m.d*m.weight*E+(2*abs(x)*E+E**2)/m.k+rr[1],
            m.weight*E+(3*x*x*E+3*abs(x)*E**2+E**3)/m.k+rr[2])
    return stored,tuple(up(b,bits) for b in bounds)


def certify(m,state,h,candidate,eps,T,bits=96,certificate_policy='DENSITY'):
    h,eps,T=map(F,(h,eps,T))
    if h<=0 or eps<=0 or T<=0 or state.error<0 or h+state.t>T:
        raise ContractError('INVALID_TIME_BUDGET_OR_ERROR')
    p,q=candidate['p'],candidate['q']
    if any(poly[0]!=center for poly,center in zip(p,state.y)):
        raise ContractError('PATH_NOT_BOUND_TO_START')
    d=coupled_defects(m,p,q,h)
    base={'valid':False,'input':state.digest(),'model':m.binding(),'h':h,'mode':candidate['mode']}
    if not d['valid']:return dict(base,reason=d['reason'])
    if certificate_policy not in ('DENSITY','INVARIANT'):
        raise ContractError('UNKNOWN_CERTIFICATE_POLICY')
    pr=bernstein_range(p[0])
    whole=(state.error+h*d['delta'] if certificate_policy=='DENSITY'
           else invariant_box_radius(m,d['differential'],state.error,h))
    if not (DOMAIN[0]<pr[0]-whole and pr[1]+whole<DOMAIN[1]):
        return dict(base,reason='WHOLE_TUBE',whole=whole)
    raw=tuple(value(poly,F(1)) for poly in p);stored=tuple(nearest(z,bits) for z in raw)
    rounding=m.norm(tuple(a-b for a,b in zip(stored,raw)))
    scale=4*max(F(1),m.d*m.weight+2,m.weight+3)
    error_cap=eps/scale
    if certificate_policy=='DENSITY':
        local=up(h*d['delta']+rounding,bits)
        budget=error_cap*h/T;indicator=local;E=state.error+local
    else:
        source_radius=invariant_box_radius(m,d['differential'],F(0),h)
        budget=error_cap/2;indicator=source_radius
        E=up(whole+rounding,bits);local=E-state.error
    if indicator>budget:return dict(base,reason='LOCAL_BUDGET',local=indicator,budget=budget)
    out=State(state.t+h,stored,E,state.generation+1)
    phys,pbounds=physical(m,stored,E,bits)
    if E>error_cap or max(pbounds)>eps:return dict(base,reason='PHYSICAL_BUDGET')
    if not (DOMAIN[0]<stored[0]-E and stored[0]+E<DOMAIN[1]):
        return dict(base,reason='ROUNDED_TUBE')
    sg=small_gain_box(m,h,state.error,m.weight*state.error,d['differential'][0],
                      max(d['differential'][1]/m.d,d['differential'][2]))
    return dict(base,valid=True,reason='CERTIFIED',output=out,local=local,budget=budget,
                radius=E,whole=whole,criterion_value=indicator,criterion_budget=budget,certificate_policy=certificate_policy,physical=phys,physical_bounds=pbounds,
                closure_whole=(d['algebraic']+whole)/(d['rmin']+QMIN),
                defects=d,box=sg,candidate=candidate,rounding=rounding)


def commit(m,state,cert):
    if not cert.get('valid') or cert['input']!=state.digest() or cert['model']!=m.binding():
        raise ContractError('STALE_OR_REJECTED_CERTIFICATE')
    # Trusted reference dictionaries, not signatures or untrusted proof objects.
    if cert['output'].generation!=state.generation+1:raise ContractError('GENERATION_MISMATCH')
    return cert['output']


def integrate(m,u=F(0),v=F(1),eps=F(1,10**6),T=F(1,4),bits=96,
              mode_policy='RVJ_FIRST',max_attempts=3000,cap_pattern=None,certificate_policy='DENSITY'):
    eps,T=F(eps),F(T)
    if eps<=0 or not 0<T<=F(1,4) or max_attempts<=0:raise ContractError('INVALID_RUN')
    if mode_policy not in ('RVJ_FIRST','TAYLOR_FIRST','RVJ_ONLY','TAYLOR_ONLY'):raise ContractError('UNKNOWN_POLICY')
    state=initial_state(m,u,v);h=min(F(1,16),T);history=[];rejects=[]
    counts={'jet_builds':0,'implicit_root_intervals':0,'jet_levels':0,'candidate_solves':0,'candidate_certificates':0,'rejected_candidates':0}
    for attempt in range(max_attempts):
        if state.t==T:return {'status':'COMPLETED','state':state,'history':history,'rejects':rejects,'work':counts,'model':m,'eps':eps,'T':T}
        h=min(h,T-state.t)
        if cap_pattern:h=min(h,F(cap_pattern[len(history)%len(cap_pattern)]))
        if h<F(1,2**34):raise PrecisionBlocked('minimum step reached')
        jet=make_jet(m,state.y,h,bits);counts['jet_builds']+=1;counts['implicit_root_intervals']+=1;counts['jet_levels']+=5
        modes={'RVJ_FIRST':['RVJ','TAYLOR'],'TAYLOR_FIRST':['TAYLOR','RVJ'],'RVJ_ONLY':['RVJ'],'TAYLOR_ONLY':['TAYLOR']}[mode_policy]
        accepted=None
        for mode in modes:
            cc=make_candidate(jet,mode);counts['candidate_solves']+=cc['shifted_solves'];counts['candidate_certificates']+=1
            cert=certify(m,state,h,cc,eps,T,bits,certificate_policy)
            if cert['valid']:accepted=cert;break
            counts['rejected_candidates']+=1
            rejects.append({k:cert[k] for k in ('h','mode','reason','local','budget') if k in cert})
        if accepted is None:h/=2;continue
        state=commit(m,state,accepted);history.append(accepted)
        if accepted['criterion_value']<accepted['criterion_budget']/64:h*=2
    return {'status':'ATTEMPT_CAP','state':state,'history':history,'rejects':rejects,'work':counts,'model':m,'eps':eps,'T':T}


def invariant_box_radius(m,ds,inherited,h):
    """Constant supersolution of the actual coupled Metzler comparison.

    This is a stationary residual-to-damping barrier, not an error estimate.
    The separate first-exit/root guard must still close the whole path.
    """
    inherited,h=F(inherited),F(h)
    if inherited<0 or h<=0 or len(ds)!=3 or min(ds)<0:
        raise ContractError('INVALID_INVARIANT_RADIUS_INPUT')
    slow_gap=A_SLOW-m.c*m.weight
    fast_gap=m.k*(m.b*m.weight-abs(m.eta))
    if min(slow_gap,fast_gap)<=0:raise ContractError('NO_POSITIVE_SUPERSOLUTION')
    dw=max(ds[1]/m.d,ds[2])
    source=max(ds[0]/slow_gap,dw/fast_gap)
    return max(inherited,source)
