from fractions import Fraction as F
import pytest
import mpmath as mp
from hybrid_rvj import *
from witness_lift import C,cc,cubic,tube_certificate,approach_real_fold

def m(v):return mp.mpf(v.numerator)/v.denominator

@pytest.mark.parametrize('a',[F(0),F(1,100),F(1,2),F(1),F(7),F(64),F(1000)])
def test_exponential_interval_and_rational_defect(a):
    mp.mp.dps=130
    lo,hi,_=exp_minus_interval(a)
    true=mp.exp(-m(a));r=rational_fast(a);d=fast_defect_bound(a)
    assert m(lo)<=true<=m(hi)
    assert -mp.mpf('1e-125')<=m(r)-true<=m(d)+mp.mpf('1e-125')

@pytest.mark.parametrize('x,h',[(F(1),F(1,16)),(F(3,2),F(1,8)),(F(1,2),F(1,100))])
def test_slow_exact_local_defect(x,h):
    assert x/(1-h*x)-slow_rvj(x,h)==slow_exact_defect(x,h)
    assert slow_exact_defect(x,h)<=2*x**7*h**6

@pytest.mark.parametrize('k,w',[(F(1),F(0)),(F(40),F(1)),(F(10000),F(1)),(F(10000),F(-1))])
def test_integrated_physical_error_and_rollback(k,w):
    mp.mp.dps=130
    o=integrate(k,w)
    for row in o['history']:
        s=row['state'];tx=1/(1-m(s.t));tw=m(w)*mp.exp(-m(k*s.t))
        ty=tx*tx*(tw+1/m(k))
        assert abs(m(s.x)-tx)<=m(s.rx)
        assert abs(m(s.w)-tw)<=m(s.rw)
        assert abs(m(row['y'])-ty)<=m(row['y_error'])
        assert row['y_error']<=F(1,10**8)
        assert row['tube_x_lower']>=F(1,2) and row['tube_x_upper']<=2
    assert o['state'].t==F(1,4)
    if w and k==10000:
        assert o['modes']['EXP_ENCLOSURE']>=1 and o['modes']['RVJ']>=1
        assert o['state'].w!=0


def test_rejection_does_not_commit_accepted_state():
    s=State(F(0),F(1),F(1));old=s.digest()
    out=attempt(s,F(1,8),F(1000),F(1,4),F(1,10**10),F(1))
    assert not out['accepted'];assert old==s.digest()

def test_future_oracle_is_not_an_integrator_input():
    import inspect
    assert 'oracle' not in inspect.signature(integrate).parameters
    assert 'mpmath' not in inspect.getsource(integrate)

def test_branch_support_equality_does_not_erase_witnesses():
    roots=[F(-1),F(1)]
    assert roots[0]**2==roots[1]**2
    assert roots[0]!=roots[1]  # same support, different admissible slopes

def test_derivative_singularity_rejected():
    assert not tube_certificate(cc(-1),cc(2),cc(2),F(1,100))['valid']

def test_endpoint_regular_does_not_certify_crossing_fold_slab():
    assert not tube_certificate(cc(-1),cc(2),cc(F(21,10)),F(1,10))['valid']

def test_fold_is_bracketed_not_crossed():
    r=approach_real_fold();assert r['steps']==20
    assert r['event_lower']<1==r['event_upper']
    assert not r['physical_continuation_claimed']

@pytest.mark.parametrize('kwargs',[dict(k=0,w0=0),dict(k=1,w0=0,tol=0),dict(k=1,w0=0,T=1)])
def test_invalid_problem_fails_closed(kwargs):
    with pytest.raises(ContractError):integrate(**kwargs)

def test_fast_precision_budget_fails_closed():
    with pytest.raises(PrecisionBlocked):
        choose_fast(F(1),F(0),F(3),F(1,10**100),bits=32)

@pytest.mark.parametrize('w',[F(1),F(-1),F(0)])
def test_dense_window_encloses_arbitrary_initial_layer(w):
    mp.mp.dps=130
    s=State(F(0),F(1),w)
    bb=dense_box(s,F(0),F(1,8),F(40))
    for j in range(17):
        t=F(j,128);x=1/(1-m(t));ww=m(w)*mp.exp(-40*m(t));yy=x*x*(ww+mp.mpf(1)/40)
        for key,v in [('x',x),('w',ww),('y',yy)]:
            assert m(bb[key][0])<=v<=m(bb[key][1])

def test_cofactor_residual_is_not_deleted():
    assert cofactor_forcing_local_bound(F(1,100),F(0),F(1),F(1),F(100),F(1,10))==F(1,10000)
    assert cofactor_forcing_local_bound(F(0),F(1,100),F(3),F(1,2),F(100),F(1,10))==F(3,5000)
