"""Exact checks of the new oscillatory and modal identities."""
import sympy as s,json
from pathlib import Path
z,v=s.symbols('z v',real=True)
R=(1+s.Rational(2,5)*z+z*z/20)/(1-s.Rational(3,5)*z+s.Rational(3,20)*z*z-z**3/60)
G=(1+z/2+z*z/10+z**3/120)/(1-z/2+z*z/10-z**3/120)
checks={}
def ck(name,e):
    ok=bool(e) if isinstance(e,(bool,s.logic.boolalg.BooleanTrue,s.logic.boolalg.BooleanFalse)) else s.simplify(e)==0
    checks[name]=ok
    if not ok:raise AssertionError((name,e))
ck('R23 imaginary modulus',s.cancel(R.subs(z,s.I*v)*R.subs(z,-s.I*v))-(3600+216*v*v+9*v**4)/(3600+216*v*v+9*v**4+v**6))
ck('R23 positive loss numerator',s.cancel((1-R.subs(z,s.I*v)*R.subs(z,-s.I*v))*(3600+216*v*v+9*v**4+v**6))-v**6)
logR=s.series(s.log(R),z,0,8).removeO()
ck('R23 sixth log coefficient',logR.coeff(z,6)-s.Rational(1,7200))
ck('R23 phase coefficient',logR.coeff(z,7)-s.Rational(1,42000))
ck('R33 exact unit modulus',G*G.subs(z,-z)-1)
ck('R33 log phase',s.series(s.log(G),z,0,8).removeO().coeff(z,7)-s.Rational(1,100800))
x,y,u,w,g,q,ga,gb,de=s.symbols('x y u w g q ga gb de',real=True)
a=s.Matrix([x,y,u,w]);H=s.diag(1,1,2,2)
N=s.Matrix([y*u-x*w,x*u+y*w,-x*y,(x*x-y*y)/2])
L=s.Matrix([[-ga,0,0,0],[0,-ga,0,0],[0,0,-gb,-de],[0,0,de,-gb]])
I=(a.T*H*a)[0];F=L*a+g*q*N
ck('nonlinear weighted action cancellation',(a.T*H*N)[0])
ck('damped weighted action',2*(a.T*H*F)[0]+2*ga*(x*x+y*y)+4*gb*(u*u+w*w))
ck('nonlinear norm exact identity',(N.T*H*N)[0]-(x*x+y*y)*I/2)
ck('closure factor identity',q*q-1-I-(q-s.sqrt(1+I))*(q+s.sqrt(1+I)))
qfun=s.sqrt(1+I)
ck('reduced Jacobian matrix',(L+g*qfun*N.jacobian(a)+g*N*(a.T*H)/qfun-(L*a+g*qfun*N).jacobian(a))==s.zeros(4))
# Infinitesimal equivariance suffices to integrate a linear circle action.
K=s.Matrix([[0,-1,0,0],[1,0,0,0],[0,0,0,-2],[0,0,2,0]])
ck('carrier Lie commutation',s.simplify(N.jacobian(a)*K*a-K*N)==s.zeros(4,1))
ck('carrier leaves closure invariant',(a.T*H*K*a)[0])
ck('carrier is H skew',(K.T*H+H*K)==s.zeros(4))
ck('detuning is H skew',((L.subs({ga:0,gb:0})).T*H+H*L.subs({ga:0,gb:0}))==s.zeros(4))
# An invariant oscillatory forcing at five equally spaced nodes aliases a constant.
ck('five sample alias',all(s.simplify(s.exp(8*s.pi*s.I*j/4)-1)==0 for j in range(5)))
t=s.symbols('t',real=True)
ck('aliased convolution wrong integral',s.integrate(s.exp(8*s.pi*s.I*(1-t)),(t,0,1)))
ck('resonant convolution nonzero integral',s.integrate(s.exp(8*s.pi*s.I*(1-t))*s.exp(8*s.pi*s.I*t),(t,0,1))-1)
# Non-normal oscillatory Jordan block: same imaginary eigenvalues, transient growth.
M,om=s.symbols('M om',real=True)
A=s.Matrix([[s.I*om,M],[0,s.I*om]])
U=s.exp(s.I*om*t)*s.Matrix([[1,M*t],[0,1]])
ck('Jordan propagator',s.diff(U,t)-A*U==s.zeros(2))
# Reflection becomes a useful reversing symmetry, not a damping stage.
C=s.diag(1,-1,1,-1)
ck('undamped reversing involution',s.simplify(F.subs({ga:0,gb:0}).subs({x:x,y:-y,u:u,w:-w},simultaneous=True)+C*F.subs({ga:0,gb:0}))==s.zeros(4,1))
# Resonance charge of each conjugate monomial in weights (1,2).
ck('mode1 frequency matching',(-1+2)-1)
ck('mode2 frequency matching',2*1-2)
Path('../evidence/algebra.json').write_text(json.dumps({'checks':checks,'exact_passed':sum(checks.values()),'total':len(checks),'log_R23':str(logR)},indent=2))
print(len(checks),'exact checks passed')
