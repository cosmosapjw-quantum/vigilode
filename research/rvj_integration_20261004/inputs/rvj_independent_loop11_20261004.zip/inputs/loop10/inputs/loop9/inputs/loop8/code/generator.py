"""Untrusted multiprecision predictor, not an oracle or certificate.
Generates a degree4 forcing polynomial by bounded simultaneous collocation sweeps.
The returned coefficients are frozen exact dyadics before separate certification.
"""
from functools import lru_cache
from fractions import Fraction as F
import mpmath as mp
from enriched import Model,Path
from loop4_scalar import nearest
from polynomial import mul,scale,add
NODES=(F(0),F(1,4),F(1,2),F(3,4),F(1))
def mpf(x):
    x=F(x);return mp.mpf(x.numerator)/x.denominator

def bases(nodes=NODES):
    out=[]
    for i,t in enumerate(nodes):
        p=(F(1),)
        for j,u in enumerate(nodes):
            if i!=j:p=scale(mul(p,(-u,F(1))),1/(t-u))
        out.append(p)
    return tuple(out)
BASIS=bases()

@lru_cache(maxsize=256)
def transfer(m,h):
    with mp.workdps(85):
        L=mp.matrix([[mpf(x) for x in row] for row in m.L]);hm=mpf(h);E=[];W=[]
        for t in NODES:
            E.append(mp.expm(hm*mpf(t)*L))
        for j in range(5):
            pp=Path.build(m,h,(F(0),)*3,BASIS[j]);V=pp.V;c=mp.matrix([mpf(x) for x in pp.c]);wj=[]
            for i,t in enumerate(NODES):
                vp=mp.matrix([sum(mpf(a)*mpf(t)**k for k,a in enumerate(v)) for v in V])
                wj.append(vp+E[i]*c)
            W.append(wj)
        return E,W

def make_forcing(m,h,y0,seed=None,max_sweeps=18):
    with mp.workdps(85):
        E,W=transfer(m,F(h));yc=mp.matrix([mpf(v) for v in y0]);hom=[ee*yc for ee in E]
        def root(x):
            if not mp.mpf('-.5')<x<1:raise ValueError('predictor stage left regular domain')
            return m.branch*mp.sqrt(1+x)
        q=[root(hh[0]) for hh in hom] if seed is None else [sum(mpf(a)*mpf(t)**k for k,a in enumerate(seed)) for t in NODES]
        increments=[]
        for sweep in range(max_sweeps):
            qq=[root(hom[i][0]+sum(W[j][i][0]*q[j] for j in range(5))) for i in range(5)]
            inc=max(abs(a-b) for a,b in zip(qq,q));increments.append(str(inc));q=qq
            if inc<mp.mpf('1e-28'):break
        coeff=[F(0)]*5
        for j in range(5):
            fq=nearest(F(mp.nstr(q[j],85)),112)
            for k,a in enumerate(BASIS[j]):coeff[k]+=a*fq
        # Rounding changes method slightly but is explicitly captured by original residual.
        coeff=tuple(nearest(c,112) for c in coeff)
        return coeff,{'sweeps':sweep+1,'root_evaluations':5*(sweep+1)+(5 if seed is None else 0),'last_nodal_increment':increments[-1]}

def extrapolate(previous,hprev,h):
    """Previous polynomial on [-hprev,0], evaluated into [0,h]."""
    p=(F(0),);lin=(F(1),F(h)/F(hprev));power=(F(1),)
    for c in previous:p=add(p,scale(power,c));power=mul(power,lin)
    return p
