"""Exact independent identities; no numerical fitting and no external CAS dependency."""
import sympy as S
from fractions import Fraction as F
from pathlib import Path
import json
from generator import bases
from polynomial import add,scale,value,bernstein_coefficients
from enriched import shifted_coeff
x,z,t,a,h=S.symbols('x z t a h',positive=True)
checks=[]
def check(name,condition):
    condition=bool(condition);checks.append({'name':name,'passed':condition})
    assert condition,name
P=S.diag(1,1,0);J=2*P-S.eye(3)
check('projection_induces_involution',J*J==S.eye(3))
check('projection_involution_splitting',(S.eye(3)-J)/2==S.eye(3)-P)
Q=S.Matrix([[1,2],[0,0]]);Jq=2*Q-S.eye(2)
check('oblique_projection_still_involutive',Jq*Jq==S.eye(2))
check('oblique_reflection_not_isometric',Jq.T*Jq!=S.eye(2))
v=S.Matrix([S.Rational(3,5),S.Rational(4,5)]);R1=S.diag(1,-1);R2=2*v*v.T-S.eye(2)
T=(S.eye(2)+R2*R1)/2
check('reflection_averaging_is_contracting',T.T*T==S.eye(2)*S.Rational(9,25))
r=(1+z/2)/(1-z/2);rex=S.cancel((4*r.subs(z,z/2)**2-r)/3)
check('trapezoidal_time_symmetry',S.cancel(r*r.subs(z,-z)-1)==0)
check('richardson_classical_fourth_order',S.series(rex-S.exp(z),z,0,5).removeO()==0)
check('richardson_stiff_limit_is_unstable',S.limit(rex,z,-S.oo)==S.Rational(5,3))
check('richardson_at_finite_large_negative_z_exceeds_one',rex.subs(z,-100)>1)
s=S.symbols('s',nonnegative=True)
w=(2-2*S.exp(-a*t)+a*t*(-2+a*t))/a**3
check('quadratic_convolution_solves_ode',S.simplify(S.diff(w,t)+a*w-t*t)==0)
check('quadratic_convolution_zero_initial',w.subs(t,0)==0)
f=1+2*s+3*s*s
check('time_reflection_turns_integral_advanced',S.expand(S.integrate(f.subs(s,h-s),(s,0,h-t))-S.integrate(f,(s,t,h)))==0)
K_then_P=S.integrate(f,(s,0,t)).subs(t,0)
P_then_K=S.integrate(f.subs(s,0),(s,0,t))
check('integration_and_endpoint_projection_do_not_commute',S.expand(P_then_K-K_then_P)==t)
check('root_sheet_swap_is_not_dynamic_symmetry',S.expand((-x-z)-(x-z))==-2*x)
np=lambda v:S.Matrix([v[0]+v[1]**2,0])
nj=lambda v:2*np(v)-v
y=S.symbols('y');nv=S.Matrix([x,y])
check('nonlinear_projector_idempotent',S.simplify(np(np(nv))-np(nv))==S.zeros(2,1))
check('nonlinear_projector_reflection_not_involution',S.simplify(nj(nj(nv))-nv)==S.Matrix([4*y*y,0]))
# Exact cardinal interpolation, not sampling bound.
ns=[F(j,4) for j in range(5)];bb=bases()
check('cardinal_basis',all(value(bb[i],ns[j])==int(i==j) for i in range(5) for j in range(5)))
su=(F(0),)
for b in bb:su=add(su,b)
check('partition_of_unity',su==(F(1),))
# On each node interval signs are constant. Bernstein bound on 128 subintervals.
margins=[]
for seg in range(4):
    mid=(ns[seg]+ns[seg+1])/2
    lam=(F(0),)
    for poly in bb:
        sign=1 if value(poly,mid)>0 else -1
        lam=add(lam,scale(poly,sign))
    for j in range(32):
        aa=ns[seg]+F(j,128);width=F(1,128)
        c=shifted_coeff(lam,aa,width,4)
        bounds=bernstein_coefficients(c)
        margins.append(F(9,4)-max(bounds))
check('continuous_Lebesgue_bound_9_over_4',min(margins)>=0)
check('projected_picard_gain_bound',F(3,4)*F(9,4)*F(1,8)==F(27,128))
old=bases(tuple(F(-j) for j in range(5)))
ww=[value(b,F(1)) for b in old];ww2=[value(b,F(2)) for b in bb]
check('history_endpoint_weights',ww==list(map(F,[5,-10,10,-5,1])))
check('history_endpoint_noise_31',sum(map(abs,ww))==31)
check('previous_slab_weights',ww2==list(map(F,[35,-160,280,-224,70])))
check('previous_slab_noise_769',sum(map(abs,ww2))==769)
check('general_one_step_history_noise',all(sum(abs(value(b,F(1))) for b in bases(tuple(F(-j) for j in range(m+1))))==2**(m+1)-1 for m in range(1,9)))
# Exact weighted convolution weights show gain can be much smaller than sup Lebesgue.
conv=[]
for av in [S.Integer(0),S.Integer(1),S.Integer(40)]:
    weights=[]
    for b in bb:
        poly=sum(S.Rational(q.numerator,q.denominator)*s**j for j,q in enumerate(b))
        weights.append(S.integrate(S.exp(-av*(1-s))*poly,(s,0,1)))
    gain=sum(abs(S.N(w,70)) for w in weights)
    bound=S.Rational(9,4)*(1 if av==0 else (1-S.exp(-av))/av)
    check(f'convolution_weighted_gain_a{av}',gain<=S.N(bound,65))
    conv.append({'a':str(av),'exact_weights':[str(w) for w in weights],'gain_numerical':str(gain),'norm_bound':str(bound),'gain_test':'high precision supplementary inequality; exact general proof in note'})
out={'checks':checks,'passed':sum(c['passed'] for c in checks),'failed':sum(not c['passed'] for c in checks),'exact_identity_or_inequality_checks':len(checks)-3,'supplementary_high_precision_weight_checks':3,'lebesgue_certificate':{'subintervals':128,'upper':'9/4','minimum_bernstein_margin':str(min(margins))},'convolution_noise_examples':conv}
root=Path(__file__).resolve().parents[1]
(root/'evidence'/'algebra.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'passed':out['passed'],'failed':out['failed'],'minimum_bernstein_margin':out['lebesgue_certificate']['minimum_bernstein_margin']}))
