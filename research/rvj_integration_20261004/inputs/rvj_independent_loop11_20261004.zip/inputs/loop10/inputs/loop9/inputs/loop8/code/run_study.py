from fractions import Fraction as F
from dataclasses import dataclass
from pathlib import Path as FilePath
import json,time,hashlib,sys
from enriched import Model,Path,certify,exp_matrix_interval
from generator import make_forcing,extrapolate

OUT=FilePath(__file__).resolve().parents[1]/'evidence';OUT.mkdir(exist_ok=True)

def enc(o):
    if isinstance(o,F):return str(o)
    if isinstance(o,Model):return {k:str(getattr(o,k)) for k in ('k','alpha','beta','eta','rho','branch')}
    raise TypeError(type(o))

@dataclass(frozen=True)
class Snapshot:
    t:F;y:tuple;E:F;model:str;generation:int=0
    def digest(self):return hashlib.sha256(repr(self).encode()).hexdigest()

def model_id(m):return hashlib.sha256(repr(m).encode()).hexdigest()
def commit(s,m,path,cert,binding):
    if (binding!=s.digest() or s.model!=model_id(m) or not cert['valid'] or path.y0!=s.y or path.model!=m
        or cert.get('path_binding')!=path.digest() or cert.get('initial_error')!=s.E):
        raise ValueError('STALE_OR_INVALID_COMMIT')
    return Snapshot(s.t+path.h,cert['y'],cert['E'],s.model,s.generation+1)

def integrate(m,eps=F(1,10**6),T=F(1,4),policy='INTERPOLATE_ONLY',u0=F(0),v0=F(1),cap=None,max_attempts=512):
    if policy not in ('INTERPOLATE_ONLY','EXTRAPOLATE_FIRST'):raise ValueError('policy')
    eps,T=F(eps),F(T)
    if eps<=0 or not 0<T<=F(1,4) or max_attempts<1:
        raise ValueError('invalid time/tolerance/attempt budget')
    if cap is not None and (not cap or any(F(v)<=0 for v in cap)):
        raise ValueError('positive step caps required')
    s=Snapshot(F(0),(F(0),F(u0)/m.units[1],F(v0)/m.units[2]),F(0),model_id(m));h=min(T,F(1,16));last=None
    hist=[];rejects=[];counts={'candidate_builds':0,'corrector_sweeps':0,'root_evaluations':0,'certificates':0,'certificate_nodes':0,'certificate_leaves':0,'extrapolation_attempts':0,'extrapolation_accepted':0}
    for _ in range(max_attempts):
        if s.t==T:break
        h=min(h,T-s.t,F(1,8))
        if cap:h=min(h,F(cap[len(hist)%len(cap)]))
        candidates=[];success=None;binding=s.digest()
        seed=extrapolate(last[0],last[1],h) if last else None
        if policy=='EXTRAPOLATE_FIRST' and seed is not None:candidates.append(('EXTRAPOLATION',seed))
        candidates.append(('INTERPOLATION',None))
        for mode,r in candidates:
            info={'sweeps':0,'root_evaluations':0}
            if mode=='EXTRAPOLATION':counts['extrapolation_attempts']+=1
            else:r,info=make_forcing(m,h,s.y,seed=seed)
            counts['candidate_builds']+=1;counts['corrector_sweeps']+=info['sweeps'];counts['root_evaluations']+=info['root_evaluations']
            path=Path.build(m,h,s.y,r);c=certify(path,s.E,eps,max_leaves=96);counts['certificates']+=1
            counts['certificate_nodes']+=c.get('processed',0);counts['certificate_leaves']+=c.get('leaves',0)
            if c['valid']:
                before=s;s=commit(s,m,path,c,binding);last=(r,h);success=c
                if mode=='EXTRAPOLATION':counts['extrapolation_accepted']+=1
                hist.append({'t':s.t,'h':h,'y':s.y,'E':s.E,'whole':c['Z'],'G':c['G'],'physical':c['physical'],'physical_bounds':c['physical_bounds'],'root_bound':c['root_bound'],'xrange':c['xrange'],'r':r,'mode':mode,'info':info,'leaves':c['leaves'],'initial':before.y})
                break
            if binding!=s.digest():raise AssertionError('rejection changed snapshot')
            rejects.append({'t':s.t,'h':h,'mode':mode,'reason':c['reason'],'processed':c.get('processed',0)})
        if success is None:h/=2
        elif success['G']<F(1,16)*(eps/16)*m.nu*(success['rmin']+F(2,3)):h*=2
        if h<F(1,1<<25):break
    return {'status':'COMPLETED' if s.t==T else 'CAP_BLOCKED','model':m,'policy':policy,'eps':eps,'T':T,'history':hist,'rejected':rejects,'counts':counts,'initial_uv':(u0,v0),'final':{'t':s.t,'y':s.y,'E':s.E},'timing_not_authoritative':True}

def run(label,k,policy='INTERPOLATE_ONLY',**kw):
    t=time.perf_counter();m=Model(k=F(k),**kw.pop('params',{}));r=integrate(m,policy=policy,**kw);r['elapsed_seconds_diagnostic']=time.perf_counter()-t
    (OUT/f'{label}.json').write_text(json.dumps(r,default=enc,indent=2))
    print(label,r['status'],len(r['history']),len(r['rejected']),r['counts'],'sec',r['elapsed_seconds_diagnostic'],flush=True)
    return r
if __name__=='__main__':
    k=int(sys.argv[1]) if len(sys.argv)>1 else 1
    policy=sys.argv[2] if len(sys.argv)>2 else 'INTERPOLATE_ONLY'
    run(f'case_k{k}_{policy}',k,policy)
