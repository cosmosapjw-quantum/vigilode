"""Certified action errors for two explicit nonnormal fast families only.

A = kappa*[[-1,beta],[0,-rate]], rate in {1,2}.  No spectral inference
from arbitrary matrices is allowed. Exact Fraction formulas, rounded dyadic
stored output, and a fixed weighted infinity norm. No matrix assembly needed.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import factorial
from loop4_scalar import (rational_fast, fast_defect_bound, exp_minus_interval,
                         round_sig, up, ContractError, PrecisionBlocked)

@dataclass(frozen=True)
class FastModel:
    kappa:F
    beta:F
    rate:int=1
    epoch:str='fixed-model-v1'
    def __post_init__(self):
        object.__setattr__(self,'kappa',F(self.kappa))
        object.__setattr__(self,'beta',F(self.beta))
        if self.kappa<=0 or self.rate not in (1,2) or not isinstance(self.epoch,str) or not self.epoch:
            raise ContractError('positive kappa, rate 1 or 2 and nonempty epoch required')
    @property
    def scale(self)->F:return max(F(1),abs(self.beta))
    def binding(self)->str:return f'{self.kappa}|{self.beta}|{self.rate}|{self.epoch}'


def _check(a:F,beta:F,rate:int,w:tuple[F,F])->tuple[F,F]:
    a,beta=F(a),F(beta)
    if a<0 or rate not in (1,2) or len(w)!=2:raise ContractError('unsupported fast family')
    return a,beta


def qterm(a:F)->F:
    a=F(a)
    if a<0:raise ContractError('a >= 0 required')
    return 3*a**5/(a**3+9*a*a+36*a+60)**2


def derivative_gap_bound(a:F)->F:
    # delta in [0,eta], R'(-a)-exp(-a)=delta-qterm.
    eta=fast_defect_bound(a); qq=qterm(a)
    algebraic=max(qq,abs(eta-qq))
    exp_upper=1/sum((a**j/F(factorial(j)) for j in range(7)),F(0))
    direct=abs(rational_fast(a)-qq)+exp_upper
    return min(algebraic,direct)


def rational_action(a:F,beta:F,rate:int,w:tuple[F,F])->tuple[F,F]:
    a,beta=_check(a,beta,rate,w); u,v=map(F,w)
    r1=rational_fast(a)
    if rate==1:
        # R'(-a)=R(-a)-qterm(a), exact.
        return (r1*u+beta*a*(r1-qterm(a))*v,r1*v)
    r2=rational_fast(2*a)
    return (r1*u+beta*(r1-r2)*v,r2*v)


def action_bound(a:F,beta:F,rate:int,w:tuple[F,F])->tuple[F,F]:
    a,beta=_check(a,beta,rate,w);u,v=map(F,w);e1=fast_defect_bound(a)
    if rate==1:
        return (e1*abs(u)+abs(beta)*a*derivative_gap_bound(a)*abs(v),e1*abs(v))
    e2=fast_defect_bound(2*a)
    # Both scalar gaps are nonnegative; their difference is bounded by max.
    return (e1*abs(u)+abs(beta)*max(e1,e2)*abs(v),e2*abs(v))


def weighted_norm(w:tuple[F,F],scale:F)->F:
    if scale<1:raise ContractError('fixed physical scaling >=1 required')
    return max(abs(w[0])/scale,abs(w[1]))


def choose_fast(w:tuple[F,F],radius:F,h:F,model:FastModel,budget:F,bits:int=128)->dict:
    h,radius,budget=map(F,(h,radius,budget));w=tuple(map(F,w))
    if h<0 or radius<0 or budget<=0 or bits<32:raise ContractError('invalid fast attempt')
    a=model.kappa*h;beta=model.beta;rate=model.rate;d=model.scale
    raw=rational_action(a,beta,rate,w)
    stored=tuple(round_sig(z,bits) for z in raw)
    bd=action_bound(a,beta,rate,w)
    local_raw=weighted_norm(tuple(bd[i]+abs(stored[i]-raw[i]) for i in range(2)),d)
    local=up(local_raw,bits)
    work={'rational_candidates':1,'distinct_filter_arguments':1 if rate==1 else 2,
          'scalar_exp_intervals':0,'exp_enclosure_terms_squares':0}
    if local<=budget:
        return dict(mode='RVJ',value=stored,local_error=local,radius=radius+local,certificate_inflation=local-local_raw,work=work)
    lo1,hi1,ops1=exp_minus_interval(a,bits+16)
    m1=(lo1+hi1)/2;g1=(hi1-lo1)/2
    work['scalar_exp_intervals']=1;work['exp_enclosure_terms_squares']=ops1
    if rate==1:
        v0=w[0]+beta*a*w[1]
        raw=(m1*v0,m1*w[1]);bd=(g1*abs(v0),g1*abs(w[1]))
    else:
        lo2,hi2,ops2=exp_minus_interval(2*a,bits+16)
        m2=(lo2+hi2)/2;g2=(hi2-lo2)/2
        raw=(m1*(w[0]+beta*w[1])-beta*m2*w[1],m2*w[1])
        bd=(g1*abs(w[0]+beta*w[1])+abs(beta)*g2*abs(w[1]),g2*abs(w[1]))
        work['scalar_exp_intervals']=2;work['exp_enclosure_terms_squares']+=ops2
    stored=tuple(round_sig(z,bits) for z in raw)
    local_raw=weighted_norm(tuple(bd[i]+abs(stored[i]-raw[i]) for i in range(2)),d)
    local=up(local_raw,bits)
    if local>budget:raise PrecisionBlocked('verified fast exponential interval exceeds budget')
    # Exact semigroup, not the numerical R, is nonexpansive in this fixed norm.
    return dict(mode='EXP_ENCLOSURE',value=stored,local_error=local,radius=radius+local,certificate_inflation=local-local_raw,work=work)
