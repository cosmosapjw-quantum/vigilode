"""Sufficient scalar two-way comparison box; not a bidirectional ODE solver."""
from fractions import Fraction as F

def feedback_box(ex0,ew0,df,dg,h,slow_decay,fast_decay,coupling_xw,coupling_wx):
    e0,w0,df,dg,h,a,b,c,d=map(F,(ex0,ew0,df,dg,h,slow_decay,fast_decay,coupling_xw,coupling_wx))
    if min(e0,w0,df,dg,c,d)<0 or min(h,a,b)<=0:
        raise ValueError('nonnegative data and strictly positive decays/step required')
    pa=min(h,1/a);pb=min(h,1/b);bx=e0+pa*df;bw=w0+pb*dg;gamma=c*d*pa*pb
    if gamma>=1:
        return {'closed':False,'reason':'SMALL_GAIN_NOT_ESTABLISHED','gain_upper':gamma}
    X=(bx+c*pa*bw)/(1-gamma);W=(bw+d*pb*bx)/(1-gamma)
    return {'closed':True,'x':X,'w':W,'gain_upper':gamma,'psi_slow_upper':pa,'psi_fast_upper':pb,
            'semantics':'conditional comparison inequality; actual model tube still must be checked'}

def inexact_lift_charge(h,model,ell_hat,center,fast_radius):
    """Extra forcing charge for an approximate constant lift row.
    Conditional helper only: the full client must use ell_hat consistently.
    Current A is used in C-ell_hat A; no stale-operator equivalence is presumed.
    """
    h,fast_radius=F(h),F(fast_radius);l0,l1=map(F,ell_hat)
    if h<=0 or fast_radius<0:raise ValueError('invalid charge input')
    residual=(model.alpha+model.kappa*l0,
              -model.beta*model.kappa*l0+model.rate*model.kappa*l1)
    dual=abs(residual[0])*model.d+abs(residual[1])
    center_norm=max(abs(F(center[0]))/model.d,abs(F(center[1])))
    return dual*(center_norm+fast_radius)*min(h,2/model.kappa)
