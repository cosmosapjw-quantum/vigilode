"""Exact/outward reference certificate for constant-L exponential-polynomial paths.

The candidate-generation module is separate. This module never imports scipy or
mpmath. It certifies the frozen rational forcing, not floating exponential output.
All matrices are small 3x3 references in a fixed weighted norm. Not a large-matrix
matrix-free algorithm and not a formal proof assistant.
"""
from fractions import Fraction as F
from dataclasses import dataclass
from math import factorial,comb
from functools import lru_cache
import hashlib
from polynomial import add,scale,mul,deriv,value,bernstein_range
from loop4_scalar import exp_minus_interval, nearest, up
BITS=224

def down(x,bits=BITS):
    x=F(x); n=1<<bits;return F((x.numerator*n)//x.denominator,n)
def iv(lo,hi=None):
    lo=F(lo);hi=lo if hi is None else F(hi)
    if lo>hi:raise ValueError('reversed interval')
    return (lo,hi)
def ia(a,b):return (down(a[0]+b[0]),up(a[1]+b[1],BITS))
def neg(a):return (-a[1],-a[0])
def im(a,b):
    v=[x*y for x in a for y in b];return (down(min(v)),up(max(v),BITS))
def isc(a,c):return im(a,iv(c))
def imag(a):return max(abs(a[0]),abs(a[1]))
def isum(xs):
    v=iv(0)
    for x in xs:v=ia(v,x)
    return v
I=tuple(tuple(F(i==j) for j in range(3)) for i in range(3))
def mv(a,v):return tuple(sum((a[i][j]*v[j] for j in range(3)),F(0)) for i in range(3))
def mm(a,b):return tuple(tuple(sum((a[i][k]*b[k][j] for k in range(3)),F(0)) for j in range(3)) for i in range(3))
def imv(a,v):return tuple(isum(isc(v[j],a[i][j]) for j in range(3)) for i in range(3))
def imm(a,b):return tuple(tuple(isum(im(a[i][k],b[k][j]) for k in range(3)) for j in range(3)) for i in range(3))
def solve(a,v):
    m=[list(a[i])+[v[i]] for i in range(3)]
    for j in range(3):
        k=next((k for k in range(j,3) if m[k][j]),None)
        if k is None:raise ValueError('singular small reference operator')
        m[j],m[k]=m[k],m[j];d=m[j][j];m[j]=[x/d for x in m[j]]
        for k in range(3):
            if k!=j:
                d=m[k][j];m[k]=[x-d*y for x,y in zip(m[k],m[j])]
    return tuple(row[-1] for row in m)

@dataclass(frozen=True)
class Model:
    k:F=F(1); alpha:F=F(1,16); beta:F=F(4); eta:F=F(1,16); rho:F=F(1); branch:int=1
    def __post_init__(self):
        for key in ('k','alpha','beta','eta','rho'):object.__setattr__(self,key,F(getattr(self,key)))
        if self.k<1 or self.rho<1 or self.branch not in (-1,1):raise ValueError('unsupported model')
        if self.nu<=0:raise ValueError('comparison not certified, not an instability verdict')
    @property
    def units(self):return (F(1),max(F(1),2*abs(self.beta))/4,F(1,4))
    @property
    def L(self):
        a=((F(-1),self.alpha,F(0)),(F(0),-self.k,self.k*self.beta),(self.k*self.eta,F(0),-self.k*self.rho))
        w=self.units
        return tuple(tuple(a[i][j]*w[j]/w[i] for j in range(3)) for i in range(3))
    @property
    def nu(self):
        L=self.L
        row=[L[i][i]+sum(abs(L[i][j]) for j in range(3) if j!=i) for i in range(3)]
        row[0]+=F(3,4)
        return -max(row)

@lru_cache(maxsize=4096)
def exp_matrix_interval(L,t):
    """Outward uniformization and scaling/squaring, ||exp(t L)||inf<=1.
    Proves enclosure for exact rational L,t. Matrix may have signed offdiagonals.
    """
    t=F(t)
    if t<0:raise ValueError('forward time only')
    if any(L[i][i]+sum(abs(L[i][j]) for j in range(3) if j!=i)>0 for i in range(3)):
        raise ValueError('nonexpansive weighted operator required')
    if t==0:return tuple(tuple(iv(x) for x in row) for row in I)
    c=max(-L[i][i] for i in range(3))
    if c<=0:raise ValueError('unsupported zero/degenerate generator')
    lam=c*t;s=0
    while lam>F(1,4):lam/=2;s+=1
    B=tuple(tuple(I[i][j]+L[i][j]/c for j in range(3)) for i in range(3))
    assert all(sum(map(abs,row))<=1 for row in B)
    term=I;S=tuple(tuple(iv(x) for x in row) for row in I);coef=F(1)
    n=0
    while True:
        n+=1;term=mm(term,B);coef*=lam/n
        S=tuple(tuple(ia(S[i][j],iv(coef*term[i][j])) for j in range(3)) for i in range(3))
        tail=coef*lam/(n+1)/(1-lam/(n+2))
        if tail<F(1,1<<(BITS+20+s)):break
        if n>256:raise ArithmeticError('uniformization cap')
    el,eu,_=exp_minus_interval(lam,BITS+24+s)
    E=tuple(tuple(ia(im(S[i][j],iv(el,eu)),iv(-tail,tail)) for j in range(3)) for i in range(3))
    for _ in range(s):
        E=imm(E,E)
        # exact semigroup has absolute entries <=1 in this weighted norm
        E=tuple(tuple((max(x[0],F(-1)),min(x[1],F(1))) for x in row) for row in E)
    return E

def exp_action_interval(L,t,c):
    E=exp_matrix_interval(L,F(t))
    return tuple(isum(isc(E[i][j],c[j]) for j in range(3)) for i in range(3))

@dataclass(frozen=True)
class Path:
    model:Model; h:F; y0:tuple; r:tuple; V:tuple; c:tuple
    @classmethod
    def build(cls,m,h,y0,r):
        h=F(h);y0=tuple(map(F,y0));r=tuple(map(F,r))
        if h<=0 or not r or len(y0)!=3:raise ValueError('invalid step/forcing/dimension')
        while len(r)>1 and r[-1]==0:r=r[:-1]
        # V(theta) is exact polynomial particular solution of dY/dtheta=h L Y+h e1 r.
        Z=tuple(tuple(h*x for x in row) for row in m.L)
        coeff=[None]*len(r);nxt=(F(0),)*3
        for j in range(len(r)-1,-1,-1):
            rhs=tuple((j+1)*nxt[i]-(h*r[j] if i==0 else 0) for i in range(3))
            coeff[j]=solve(Z,rhs);nxt=coeff[j]
        V=tuple(tuple(v[i] for v in coeff) for i in range(3))
        c=tuple(y0[i]-V[i][0] for i in range(3))
        return cls(m,h,y0,r,V,c)
    def digest(self):
        """Trusted-process binding to the exact forcing, step, model and initial state."""
        return hashlib.sha256(repr(self).encode()).hexdigest()
    def evaluate(self,theta):
        theta=F(theta)
        if not 0<=theta<=1:raise ValueError('path interval')
        e=exp_action_interval(self.model.L,self.h*theta,self.c)
        return tuple(ia(iv(value(self.V[i],theta)),e[i]) for i in range(3))


def shifted_coeff(p,a,width,n):
    return tuple(sum((p[k]*comb(k,j)*a**(k-j)*width**j for k in range(j,len(p))),F(0)) if j<len(p) else F(0) for j in range(n+1))

def interval_bernstein(coeff):
    n=len(coeff)-1
    bb=[isum(isc(coeff[j],F(comb(i,j),comb(n,j))) for j in range(i+1)) for i in range(n+1)]
    return min(v[0] for v in bb),max(v[1] for v in bb)

def scalar_exp_poly_range(path,P,sign,a,b,degree=12):
    """Range of P(theta)+sign*e1 exp(theta*h L)c; Taylor remainder uses dissipativity.
    No sampled extrema. P has degree<=degree. theta ranges over exact [a,b].
    """
    a,b=F(a),F(b);width=b-a
    if not 0<=a<=b<=1 or len(P)>degree+1:raise ValueError('invalid interval/degree')
    va=exp_action_interval(path.model.L,path.h*a,path.c)
    Z=tuple(tuple(path.h*x for x in row) for row in path.model.L)
    pp=shifted_coeff(P,a,width,degree);v=va;cc=[];wfac=F(1)
    for j in range(degree+1):
        cc.append(ia(iv(pp[j]),isc(v[0],sign*wfac)))
        v=imv(Z,v);wfac*=width/(j+1)
    rem=wfac*max(map(imag,v))
    lo,hi=interval_bernstein(cc)
    return lo-rem,hi+rem

def certify(path,E0,eps,max_leaves=256):
    """Conditional continuum certificate from ORIGINAL nonlinear closure defect.
    Exact path solves linear inhomogeneous equation; all residual is in q forcing.
    """
    E0,eps=F(E0),F(eps);m=path.model
    if E0<0 or eps<=0 or not isinstance(max_leaves,int) or max_leaves<1:
        raise ValueError('nonnegative inherited radius, positive tolerance/resources required')
    rr=bernstein_range(path.r);rmin=rr[0] if m.branch==1 else -rr[1]
    base={'valid':False,'path_binding':path.digest(),'initial_error':E0,'tolerance':eps,'rmin':rmin,'leaves':0,'exp_misses0':exp_matrix_interval.cache_info().misses}
    if rmin<F(2,3):return dict(base,reason='WITNESS_MARGIN')
    cap=eps/(4*max(F(1),m.units[1]+2,m.units[2]+3));target=cap/2
    glim=target*m.nu*(rmin+F(2,3))
    # One bound for ALL slabs: previous slabs can inject the largest defect.
    # A local smaller residual cannot justify resetting the domain guard.
    global_guard=max(E0,target)
    Pg=add(add(mul(path.r,path.r),(F(-1),)),scale(path.V[0],-1))
    # Low-cost valid falsification of the chosen sup budget, NOT an error certificate.
    for t in (F(0),F(1,2),F(1)):
        x=path.evaluate(t)[0];g=ia(iv(value(mul(path.r,path.r),t)-1),neg(x))
        if g[0]>glim or g[1]<-glim:return dict(base,reason='RESIDUAL_BUDGET_POINT',point=str(t))
    stack=[(F(0),F(1))];G=F(0);xmin=None;xmax=None;leaves=0;processed=0
    while stack:
        a,b=stack.pop();processed+=1
        gl,gu=scalar_exp_poly_range(path,Pg,-1,a,b)
        xlo,xhi=scalar_exp_poly_range(path,path.V[0],1,a,b)
        bound=max(abs(gl),abs(gu));Z=max(E0,bound/(m.nu*(rmin+F(2,3))))
        if bound<=glim and F(-1,2)<xlo-global_guard and xhi+global_guard<1:
            G=max(G,bound);xmin=xlo if xmin is None else min(xmin,xlo);xmax=xhi if xmax is None else max(xmax,xhi);leaves+=1
        else:
            if processed>=2*max_leaves or b-a<F(1,1<<34):return dict(base,reason='CERTIFICATE_SUBDIVISION_CAP',processed=processed,leaves=leaves)
            mid=(a+b)/2;stack.extend(((mid,b),(a,mid)))
    Z=max(E0,G/(m.nu*(rmin+F(2,3))))
    raw=path.evaluate(1);y=tuple(nearest((a+b)/2,96) for a,b in raw)
    rounding=max(max(abs(y[i]-a),abs(y[i]-b)) for i,(a,b) in enumerate(raw))
    E=up(Z+rounding,96)
    if E>cap:return dict(base,reason='TOTAL_BUDGET',E=E)
    if not F(-1,2)<y[0]-E or not y[0]+E<1:
        return dict(base,reason='ROUNDED_ENDPOINT_DOMAIN')
    x,u,v=(y[i]*m.units[i] for i in range(3))
    actual=(x,u+x*x/m.k,v+x*x*x/m.k)
    phys=tuple(nearest(v,96) for v in actual);rounds=tuple(abs(a-b) for a,b in zip(actual,phys))
    pb=(E+rounds[0],m.units[1]*E+(2*abs(x)*E+E**2)/m.k+rounds[1],m.units[2]*E+(3*x*x*E+3*abs(x)*E**2+E**3)/m.k+rounds[2])
    if max(pb)>eps:return dict(base,reason='PHYSICAL_BUDGET')
    return dict(base,valid=True,reason='CERTIFIED',E=E,Z=Z,G=G,y=y,physical=phys,physical_bounds=pb,
                root_bound=(G+Z)/(rmin+F(2,3)),xrange=(xmin,xmax),leaves=leaves,processed=processed,
                exp_misses=exp_matrix_interval.cache_info().misses-base['exp_misses0'])
