#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/code"
python -m pytest -q
python verify_algebra.py
python recertify_saved.py
# Optional independent floating numerical recheck:
# python recheck_oracle.py
