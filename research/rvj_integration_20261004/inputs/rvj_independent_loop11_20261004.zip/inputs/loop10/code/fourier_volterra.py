"""Exact coefficient reference for Fourier--Volterra nonlinear homotopy.

A path is sum c[k,j] tau**j exp(i*k*omega*h*tau). Gaussian-rational
coefficients, exact linear convolution, and an original-target residual bound.
This is a small conservative model, not a generic FFT time integrator.
"""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction as F
from math import factorial,comb
from pathlib import Path
import sys,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'inputs/loop9/code'))
from modal import rotate_interval
from loop4_scalar import nearest,up,PrecisionBlocked
from polynomial import bernstein_coefficients,sqrt_interval

@dataclass(frozen=True)
class C:
    r:F=F(0)
    i:F=F(0)
    def __post_init__(self):
        object.__setattr__(self,'r',F(self.r));object.__setattr__(self,'i',F(self.i))
    @staticmethod
    def of(x):return x if isinstance(x,C) else C(x)
    def __add__(self,b):
        b=C.of(b);return C(self.r+b.r,self.i+b.i)
    __radd__=__add__
    def __neg__(self):return C(-self.r,-self.i)
    def __sub__(self,b):return self+-C.of(b)
    def __rsub__(self,b):return C.of(b)+-self
    def __mul__(self,b):
        b=C.of(b);return C(self.r*b.r-self.i*b.i,self.r*b.i+self.i*b.r)
    __rmul__=__mul__
    def __truediv__(self,b):
        b=C.of(b);s=b.r*b.r+b.i*b.i
        if not s:raise ZeroDivisionError('Gaussian divisor zero')
        return self*b.conj()*(1/s)
    def conj(self):return C(self.r,-self.i)
    def abs1(self):return abs(self.r)+abs(self.i)
    def __bool__(self):return bool(self.r or self.i)
    def rounded(self,bits):return C(nearest(self.r,bits),nearest(self.i,bits))
    def to_complex(self):return complex(float(self.r),float(self.i))

ZERO=C();II=C(0,1)
class EP:
    """Sparse polynomial amplitudes of named harmonics; no circular aliasing."""
    def __init__(self,coeff=None):
        self.c={k:C.of(v) for k,v in (coeff or {}).items() if C.of(v)}
        if any(not isinstance(k,int) or not isinstance(j,int) or j<0 for k,j in self.c):raise ValueError('invalid spectral index')
    @staticmethod
    def const(z):return EP({(0,0):C.of(z)})
    def __add__(self,b):
        if not isinstance(b,EP):b=EP.const(b)
        o=dict(self.c)
        for k,v in b.c.items():o[k]=o.get(k,ZERO)+v
        return EP(o)
    __radd__=__add__
    def __neg__(self):return self.scale(-1)
    def __sub__(self,b):return self+-b if isinstance(b,EP) else self+-EP.const(b)
    def __mul__(self,b):
        if not isinstance(b,EP):return self.scale(b)
        o={}
        for (k,j),x in self.c.items():
            for (l,n),y in b.c.items():
                key=(k+l,j+n);o[key]=o.get(key,ZERO)+x*y
        return EP(o)
    __rmul__=__mul__
    def scale(self,z):return EP({key:v*z for key,v in self.c.items()})
    def conj(self):return EP({(-k,j):v.conj() for (k,j),v in self.c.items()})
    def derivative(self,a):
        o={}
        for (k,j),v in self.c.items():
            if j:o[(k,j-1)]=o.get((k,j-1),ZERO)+j*v
            if k:o[(k,j)]=o.get((k,j),ZERO)+C(0,k*a)*v
        return EP(o)
    def primitive(self,a):
        """Exact integral from zero. At zero mismatch all modes coalesce."""
        o={}
        for (k,j),v in self.c.items():
            if not k or not a:
                key=(0,j+1);o[key]=o.get(key,ZERO)+v/F(j+1);continue
            rate=C(0,k*a);b=v/rate
            o[(k,j)]=o.get((k,j),ZERO)+b
            for n in range(j-1,-1,-1):
                b=-(n+1)*b/rate;o[(k,n)]=o.get((k,n),ZERO)+b
            o[(0,0)]=o.get((0,0),ZERO)-b
        return EP(o)
    def at_zero(self):return sum((v for (k,j),v in self.c.items() if j==0),ZERO)
    def truncate(self,K,p,bits=None):
        if K<0 or p<0:raise ValueError('negative degree cap')
        o=EP({key:(v.rounded(bits) if bits else v) for key,v in self.c.items() if abs(key[0])<=K and key[1]<=p})
        return o
    def enforce_start(self,z):return self+EP.const(C.of(z)-self.at_zero())
    def sup_bound(self):
        # Triangle across named frequencies; complex Bernstein hull per amplitude.
        out=F(0)
        for k in sorted({k for k,j in self.c}):
            p=max(j for kk,j in self.c if kk==k)
            re=[self.c.get((k,j),ZERO).r for j in range(p+1)]
            im=[self.c.get((k,j),ZERO).i for j in range(p+1)]
            # degree must not be independently trimmed when pairing hull points
            from math import comb
            br=[sum((re[j]*F(comb(i,j),comb(p,j)) for j in range(i+1)),F(0)) for i in range(p+1)]
            bi=[sum((im[j]*F(comb(i,j),comb(p,j)) for j in range(i+1)),F(0)) for i in range(p+1)]
            out+=max((abs(x)+abs(y) for x,y in zip(br,bi)),default=F(0))
        return out
    def coefficients_l1(self):return sum((x.abs1() for x in self.c.values()),F(0))
    def value_interval(self,a,tau=F(1),bits=128):
        loR=hiR=loI=hiI=F(0)
        for k in sorted({k for k,j in self.c}):
            v=sum((x*tau**j for (kk,j),x in self.c.items() if kk==k),ZERO)
            e=rotate_interval(k*a*tau,bits)
            cr,ci=e['cos'],e['sin']
            def scl(intv,z):
                aa,bb=intv[0]*z,intv[1]*z;return min(aa,bb),max(aa,bb)
            rr=scl(cr,v.r);ss=scl(ci,-v.i);ri=scl(cr,v.i);si=scl(ci,v.r)
            loR+=rr[0]+ss[0];hiR+=rr[1]+ss[1];loI+=ri[0]+si[0];hiI+=ri[1]+si[1]
        v=C(nearest((loR+hiR)/2,bits),nearest((loI+hiI)/2,bits))
        err=max(v.r-loR,hiR-v.r)+max(v.i-loI,hiI-v.i)
        return v,err
    def value_mp(self,a,tau,mp):
        cv=lambda f:mp.mpf(f.numerator)/f.denominator
        return sum((mp.mpc(cv(v.r),cv(v.i))*tau**j*mp.exp(1j*k*cv(a)*tau) for (k,j),v in self.c.items()),mp.mpc(0))
    def frozen(self):return tuple((k,j,str(v.r),str(v.i)) for (k,j),v in sorted(self.c.items()))

def exact_mode_product(a,b):
    o={}
    for k,x in a.items():
        for j,y in b.items():o[k+j]=o.get(k+j,0)+x*y
    return {k:v for k,v in o.items() if v}

@dataclass(frozen=True)
class Model:
    omega:F=F(1)
    g:F=F(1,8)
    eps:F=F(1,8)
    sigma:int=1
    epoch:int=0
    def __post_init__(self):
        for n in ('omega','g','eps'):object.__setattr__(self,n,F(getattr(self,n)))
        if self.sigma not in (-1,1):raise ValueError('signed closure')
    @property
    def q(self):return self.sigma*F(5,4)
    @property
    def growth(self):return F(5,4)*(2*abs(self.g)+3*abs(self.eps))

@dataclass(frozen=True)
class State:
    t:F=F(0)
    a:tuple=(C(F(1,4)),C(F(1,2)))
    error:F=F(0)
    generation:int=0
    def __post_init__(self):
        object.__setattr__(self,'t',F(self.t));object.__setattr__(self,'error',F(self.error))
        object.__setattr__(self,'a',tuple(C.of(z) for z in self.a))
        if len(self.a)!=2 or self.error<0 or self.t<0:raise ValueError('invalid snapshot')

def fingerprint(obj):return hashlib.sha256(repr(obj).encode()).hexdigest()

def phase_candidate(a,phase0,bits=144,degree=20):
    if abs(a)<=1:
        power=C(1);terms={(0,0):phase0}
        for j in range(1,degree+1):
            power=power*C(0,a)/j;terms[(0,j)]=phase0*power
        tail=abs(a)**(degree+1)/factorial(degree+1)
        return EP(terms),tail,'CONFLUENT_TAYLOR_PHASE'
    return EP({(1,0):phase0}),F(0),'FOURIER_EXP_PHASE'

def rhs(path,m,phase,lam=F(1)):
    a,b=path
    realmod=(phase*a+(phase*a).conj()).scale(F(1,2))
    c=EP.const(m.g)+realmod.scale(lam*m.eps)
    return (c*a.conj()*b).scale(C(0,m.q)),(c*a*a).scale(C(0,m.q/2))

def certificate(state,h,m,path,phase,phase_error,phase_mode):
    if h<=0 or h*m.growth>=1:raise ValueError('positive contractive slab required')
    if tuple(x.at_zero() for x in path)!=state.a:raise ValueError('initial condition mismatch')
    B=max(x.sup_bound() for x in path)
    if B>1:return {'accepted':False,'reason':'CANDIDATE_DOMAIN','B':B}
    ff=rhs(path,m,phase,F(1))
    defects=tuple(path[j].derivative(m.omega*h)-ff[j].scale(h) for j in range(2))
    d_alg=max(z.sup_bound() for z in defects)
    d_phase=h*abs(m.q*m.eps)*B**3*phase_error
    delta=d_alg+d_phase
    growth=1/(1-h*m.growth)
    endpoint=[];rnd=F(0)
    for p in path:
        v,rad=p.value_interval(m.omega*h,bits=128);endpoint.append(v);rnd=max(rnd,rad)
    error=up(growth*(state.error+delta)+rnd,128)
    closure=(path[0]*path[0].conj()+(path[1]*path[1].conj()).scale(2))-EP.const(F(9,16))
    out={'accepted':True,'B':B,'differential_normalized':d_alg,'phase_normalized':d_phase,
         'residual_bound':delta,'growth':growth,'endpoint_rounding':rnd,'error':error,
         'algebraic_defect':closure.sup_bound(),'phase_mode':phase_mode,
         'target_lambda':F(1),'endpoint':tuple(endpoint),
         'binding':fingerprint((state,m,h,tuple(x.frozen() for x in path)))}
    out['output_binding']=fingerprint((out['binding'],out['endpoint'],out['error']))
    return out

def build(state,h,m,K=3,p=6,sweeps=5,homotopy=(F(1),),bits=112):
    h=F(h)
    if h<=0 or K<0 or p<1 or sweeps<1 or bits<48 or h*m.growth>=1:raise ValueError('bad step or resource contract')
    if state.generation==0 and state.error==0 and sum((z.r*z.r+z.i*z.i)*w for z,w in zip(state.a,(1,2)))!=F(9,16):raise ValueError('initial action not on certified closure sheet')
    if not homotopy or F(homotopy[-1])!=1 or any(F(x)<0 or F(x)>1 for x in homotopy):raise ValueError('homotopy must reach target lambda=1')
    rt=rotate_interval(m.omega*state.t,bits+32)
    mid=C(sum(rt['cos'])/2,sum(rt['sin'])/2)
    e0=(rt['cos'][1]-rt['cos'][0]+rt['sin'][1]-rt['sin'][0])/2
    phase,tail,mode=phase_candidate(m.omega*h,mid,bits+32)
    # |mid*phase_T - exact_global_phase| <= |mid|*tail+initial phase enclosure
    phase_error=e0+mid.abs1()*tail
    path=tuple(EP.const(z) for z in state.a)
    hist=[]
    for ll in homotopy:
        ll=F(ll)
        for n in range(sweeps):
            ff=rhs(path,m,phase,ll)
            raw=tuple(EP.const(state.a[j])+ff[j].scale(h).primitive(m.omega*h) for j in range(2))
            nxt=tuple(x.truncate(K,p,bits).enforce_start(state.a[j]) for j,x in enumerate(raw))
            hist.append({'lambda':str(ll),'iteration':n+1,'increment':float(max((nxt[j]-path[j]).sup_bound() for j in range(2))),
                         'discarded_pruning_bound':float(max((raw[j]-nxt[j]).sup_bound() for j in range(2))),
                         'coefficient_count':sum(len(x.c) for x in nxt)})
            path=nxt
    cert=certificate(state,h,m,path,phase,phase_error,mode)
    return {'path':path,'certificate':cert,'history':hist,'h':h,'state':state,'model':m,'K':K,'p':p}

def commit(trial,state,m,cap):
    c=trial['certificate'];h=trial['h']
    if not c['accepted'] or c['error']>F(cap):raise ValueError('uncertified/budget-failed candidate')
    want=fingerprint((state,m,h,tuple(x.frozen() for x in trial['path'])))
    if c['binding']!=want or state!=trial['state'] or m!=trial['model']:raise ValueError('stale/mixed trial')
    if c.get('output_binding')!=fingerprint((c['binding'],c['endpoint'],c['error'])):raise ValueError('endpoint/radius binding mismatch')
    return State(state.t+h,c['endpoint'],c['error'],state.generation+1)


def physical(state,m,bits=128):
    vals=[];rads=[]
    for j,z in enumerate(state.a,1):
        rot=EP({(j,0):z});v,r=rot.value_interval(m.omega*state.t,bits=bits)
        vals.append(v);rads.append(state.error+r)
    hbound=sqrt_interval(rads[0]**2+2*rads[1]**2,bits)[1]
    return {'value':tuple(vals),'component_bounds':tuple(rads),'H_error':hbound}
