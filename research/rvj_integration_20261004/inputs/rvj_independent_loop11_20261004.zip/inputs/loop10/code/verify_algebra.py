import json
from pathlib import Path
import sympy as s
x,y,u,v,q,g,e,lam,th,a,t,z=s.symbols('x y u v q g e lam th a t z',real=True)
checks={}
F=s.Matrix(4,4,lambda j,k:(-s.I)**(j*k)/2)
P=s.Matrix(4,4,lambda j,k:int((j+k)%4==0))
J=s.BlockMatrix([[s.zeros(4),s.conjugate(F).T],[F,s.zeros(4)]]).as_explicit()
checks['unitary_DFT']=s.simplify(s.conjugate(F).T*F-s.eye(4))==s.zeros(4)
checks['F2_is_parity']=s.simplify(F*F-P)==s.zeros(4)
checks['F4_identity']=s.simplify(F**4-s.eye(4))==s.zeros(4)
checks['doubled_involution']=s.simplify(J**2-s.eye(8))==s.zeros(8)
Proj=(s.eye(8)+J)/2
checks['doubled_graph_projector']=s.simplify(Proj**2-Proj)==s.zeros(8)
cc=g+lam*e*(x*s.cos(th)-y*s.sin(th))
vf=q*cc*s.Matrix([y*u-x*v,x*u+y*v,-x*y,(x*x-y*y)/2])
I=x*x+y*y+2*(u*u+v*v)
checks['weighted_action']=s.expand(s.Matrix([s.diff(I,h) for h in [x,y,u,v]]).dot(vf))==0
checks['initial_I']=s.Rational(1,4)**2+2*s.Rational(1,2)**2==s.Rational(9,16)
checks['exact_q']=s.Rational(5,4)**2==1+s.Rational(9,16)
prim=s.exp(s.I*a*t)*(t*t/(s.I*a)-2*t/(s.I*a)**2+2/(s.I*a)**3)-2/(s.I*a)**3
checks['primitive_residual']=s.simplify(s.diff(prim,t)-t*t*s.exp(s.I*a*t))==0
checks['primitive_zero']=s.simplify(prim.subs(t,0))==0
checks['primitive_confluent']=s.limit(prim,a,0)==t**3/3
# With same input point, an invertible DFT cannot distinguish physical modes k and k+N.
checks['quadratic_wrap_negative']=(4+2)%5-2==-1
checks['cubic_wrap_negative']=(7+4)%9-4==-2
checks['growth_constant']=s.Rational(5,4)*(s.Rational(2,8)+s.Rational(3,8))==s.Rational(25,32)
# hL<1 bounds the geometric Neumann branch, not every projected coefficient solver.
checks['neumann_inverse_algebra']=s.simplify(1+z/(1-z)-1/(1-z))==0
# Physical non-equivariance: multiplying an equivariant N by Re(z1) leaves a nonzero phase defect.
checks['genuine_mismatch']=s.simplify((cc-(g+lam*e*x)).subs({th:s.pi,x:1,y:0,lam:1,e:1}))==-2
out={'exact_checks':checks,'passed':sum(checks.values()),'failed':sum(not v for v in checks.values())}
path=Path(__file__).resolve().parents[1]/'evidence/algebra.json';path.write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2));assert all(checks.values())
