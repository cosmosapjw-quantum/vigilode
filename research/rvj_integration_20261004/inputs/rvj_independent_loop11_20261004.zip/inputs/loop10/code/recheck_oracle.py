"""Numerical audit without a hidden interior error allowance.
DOP853 reference is floating-point and is not itself a rigorous enclosure.
"""
from run_studies import *
E=ROOT/'evidence';rows=[]
for fn in sorted(E.glob('case_*.json')):
    d=json.loads(fn.read_text());m=Model(F(d['omega']),sigma=d['sigma']);ref=oracle(m,F(d['T']),rtol=8e-14)
    oldt=F(0);olderr=F(0);epviol=0;inviol=0;maxratio=0.;physical_viol=0
    for r in d['records']:
        h=F(r['h']);tt=F(r['t']);end=np.array([complex(float(F(a)),float(F(b))) for a,b in r['value_exact']])
        epviol+=int(max(abs(end-ref.sol(float(tt))))>float(F(r['error'])))
        paths=[EP({(int(k),int(j)):C(F(a),F(b)) for k,j,a,b in p}) for p in r['path']]
        bd=(olderr+F(r['residual']))/(1-h*m.growth)
        for tau in [F(1,4),F(1,2),F(3,4)]:
            value=np.array([p.value_interval(m.omega*h,tau)[0].to_complex() for p in paths])
            err=max(abs(value-ref.sol(float(oldt+h*tau))))
            inviol+=int(err>float(bd));maxratio=max(maxratio,float(err)/float(bd))
        # Physical reconstruction oracle uses ordinary complex exp solely as a diagnostic.
        truth=ref.sol(float(tt))*np.exp(1j*float(m.omega*tt)*np.array([1,2]))
        ph=np.array([complex(float(F(a)),float(F(b))) for a,b in r['physical']['value']])
        herr=float(np.sqrt(abs(ph[0]-truth[0])**2+2*abs(ph[1]-truth[1])**2))
        physical_viol+=int(herr>float(F(r['physical']['H_error'])))
        oldt=tt;olderr=F(r['error'])
    row={'case':d['case'],'endpoint_violations_no_allowance':epviol,'interior_violations_no_allowance':inviol,'max_interior_error_bound_ratio':maxratio,'physical_reconstruction_diagnostic_violations':physical_viol,'oracle_is_validated':False}
    print(row,flush=True);rows.append(row)
(E/'ORACLE_RAW_RECHECK.json').write_text(json.dumps(rows,indent=2))
assert all(r['endpoint_violations_no_allowance']==r['interior_violations_no_allowance']==r['physical_reconstruction_diagnostic_violations']==0 for r in rows)
