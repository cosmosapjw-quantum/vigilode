from fractions import Fraction as F
import pytest
import numpy as np

# This negative baseline intentionally mimics an FFT-grid computation that
# confuses circular convolution with Galerkin multiplication.
def circular_product(a,b,n):
    out={}
    for k,x in a.items():
        for j,y in b.items():
            key=(k+j+n//2)%n-n//2
            out[key]=out.get(key,0)+x*y
    return out

def test_roundtrip_is_not_a_nonlinear_certificate():
    modes={2:1}; n=5
    # Algebraic Galerkin product projected to |k|<=2 must be zero.
    from fourier_volterra import exact_mode_product
    out=exact_mode_product(modes,modes)
    assert all(out.get(k,0)==0 for k in range(-2,3))

def test_filter_roundtrip_is_projection_not_identity():
    a=np.array([1.,2.,3.,4.,5.]);f=np.fft.fft(a,norm='ortho');f[2]=0
    out=np.fft.ifft(f,norm='ortho')
    assert not np.allclose(out,a)
    assert np.allclose(np.fft.fft(out,norm='ortho'),f)
