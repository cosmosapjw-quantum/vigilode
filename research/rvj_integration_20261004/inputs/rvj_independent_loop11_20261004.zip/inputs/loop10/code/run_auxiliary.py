from run_studies import *
import mpmath as mp

def main():
    rows=[]
    for K,p,n in [(0,6,4),(1,6,4),(2,4,4),(3,6,4),(4,8,4)]:
        tr=build(State(),F(1,8),Model(40),K,p,n)
        c=tr['certificate'];rows.append({'K':K,'p':p,'sweeps':n,'error':str(c.get('error')),'defect':str(c.get('residual_bound')),'terms':sum(len(x.c) for x in tr['path'])})
    (OUT/'mode_resolution.json').write_text(json.dumps(rows,indent=2))
    # High-frequency state: continuum certificate does not require time-grid sampling.
    tr=build(State(),F(1,16),Model(10**6),K=3,p=6,sweeps=4)
    c=tr['certificate'];st=commit(tr,State(),Model(10**6),F(1,10**8))
    out={'omega':10**6,'h':'1/16','mode_band':3,'polynomial_degree':6,'sweeps':4,
         'certificate':c,'physical':physical(st,Model(10**6)),
         'oracle':'no independent high-frequency ODE oracle run in this case',
         'path':[x.frozen() for x in tr['path']]}
    (OUT/'ultrafast_certificate.json').write_text(json.dumps(jsonify(out),indent=2))
    # Direct lambda=0 deletion at exact resonance has a first-derivative defect.
    m=Model(0);A=tuple(EP.const(z) for z in State().a);phase=EP.const(1)
    f0=rhs(A,m,phase,0);f1=rhs(A,m,phase,1)
    diff=[(a-b).at_zero() for a,b in zip(f1,f0)]
    (OUT/'averaging_at_resonance_negative.json').write_text(json.dumps(jsonify({'initial_derivative_error':diff,'scope':'fixed lambda0 is not the lambda1 target; exact resonance cannot be silently averaged'}),indent=2))
    print('mode sweep',rows);print('high-frequency bound',float(c['error']))

if __name__=='__main__':main()
