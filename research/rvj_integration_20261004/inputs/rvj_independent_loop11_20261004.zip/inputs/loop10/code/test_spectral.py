from fractions import Fraction as F
import math,dataclasses,copy
import numpy as np
import pytest
from fourier_volterra import *

@pytest.mark.parametrize('n',[3,4,7,8])
def test_F2_parity_F4_identity(n):
    x=np.arange(n)+1j*np.arange(n)**2
    ft=lambda a:np.fft.fft(a,norm='ortho')
    inv=lambda a:np.fft.ifft(a,norm='ortho')
    assert np.allclose(ft(ft(x)),x[(-np.arange(n))%n])
    assert np.allclose(ft(ft(ft(ft(x)))),x)
    # Genuine doubled-space involution, not F itself.
    y=x[::-1]
    def J(pair):return inv(pair[1]),ft(pair[0])
    u,v=J(J((x,y)))
    assert np.allclose(u,x) and np.allclose(v,y)

@pytest.mark.parametrize('n',[9,10,15])
def test_cubic_padding(n):
    theta=2*np.pi*np.arange(n)/n;f=np.exp(2j*theta)
    result=np.fft.fft(np.exp(1j*theta)*f**3)/n
    retained=np.array([result[k%n] for k in range(-2,3)])
    if n==9:assert abs(retained[0]-1)<1e-12
    else:assert max(abs(retained))<1e-12

@pytest.mark.parametrize('a',[F(0),F(1,10**10),F(3,2),F(-8),F(10**6)])
def test_exact_primitive(a):
    p=EP({(0,2):C(2,3),(1,3):C(F(1,3),F(2,5)),(-2,0):C(0,1)})
    prim=p.primitive(a)
    assert prim.at_zero()==C()
    d=prim.derivative(a)
    if a:
        assert not (d-p).c
    else:
        # At a=0 distinct harmonic labels describe the same function.
        collapsed=EP({(0,j):sum((v for (k,n),v in p.c.items() if n==j),ZERO) for j in range(4)})
        assert not (d-collapsed).c

def test_conjugation_involution_and_product():
    a=EP({(2,1):C(1,2),(-1,0):C(3,-1)})
    b=EP({(1,3):C(F(1,7),4)})
    assert a.conj().conj().frozen()==a.frozen()
    assert ((a*b).conj()-a.conj()*b.conj()).c=={}

def test_tail_not_roundtrip():
    p=EP({(4,0):C(1)})
    assert p.truncate(2,6).c=={}
    assert p.sup_bound()==1

def test_near_resonance_phase_remainder():
    pp,tail,mode=phase_candidate(F(1,100),C(1))
    assert mode=='CONFLUENT_TAYLOR_PHASE' and tail>0
    assert tail==F(1,100)**21/math.factorial(21)

def test_homotopy_requires_target():
    with pytest.raises(ValueError):build(State(),F(1,16),Model(),homotopy=(0,F(1,2)))

def test_bad_initial_action_rejected():
    with pytest.raises(ValueError):build(State(a=(C(1),C(1))),F(1,16),Model())

def test_zero_step_rejected():
    with pytest.raises(ValueError):build(State(),F(0),Model())

def test_domain_guard():
    s=State();path=(EP.const(s.a[0])+EP({(0,1):C(10)}),EP.const(s.a[1]))
    ph,tail,mode=phase_candidate(F(0),C(1))
    c=certificate(s,F(1,16),Model(0),path,ph,tail,mode)
    assert not c['accepted'] and c['reason']=='CANDIDATE_DOMAIN'

def test_k0_does_not_silently_remove_non_equivariant_dynamics():
    tr=build(State(),F(1,16),Model(40),K=0,p=6,sweeps=3)
    assert tr['certificate']['residual_bound']>F(1,10**6)

def test_whole_residual_contains_lost_harmonics():
    tr=build(State(),F(1,16),Model(40),K=1,p=5,sweeps=3)
    assert tr['certificate']['algebraic_defect']>=0
    assert tr['certificate']['residual_bound']>0

def test_stale_epoch_and_endpoint_mutation():
    m=Model(0);s=State();tr=build(s,F(1,16),m,sweeps=3)
    with pytest.raises(ValueError):commit(tr,s,dataclasses.replace(m,epoch=1),F(1))
    bad=copy.deepcopy(tr);bad['certificate']['endpoint']=(C(3),C(4))
    with pytest.raises(ValueError):commit(bad,s,m,F(1))
    good=commit(tr,s,m,F(1))
    assert good.t==F(1,16) and good.generation==1

def test_envelope_uniform_growth_bound():
    assert Model(0).growth==Model(10**12).growth==F(25,32)

@pytest.mark.parametrize('n',[4,7,8])
def test_causal_zero_padding_not_circular(n):
    f=np.array([0.,0.,0.,1.]);kernel=np.array([1.,.5,.25,.125])
    result=np.fft.ifft(np.fft.fft(f,n)*np.fft.fft(kernel,n)).real
    exact=np.convolve(f,kernel)
    if n==4:assert not np.allclose(result,exact[:4])
    else:assert np.allclose(result[:4],exact[:4])

def test_midpoint_different_from_true_initial_is_counted():
    tr=build(State(),F(1,16),Model(0),sweeps=3)
    assert tr['certificate']['endpoint_rounding']>=0
    assert tr['certificate']['error']>=tr['certificate']['growth']*tr['certificate']['residual_bound']
