"""Exploratory tests. Numerical oracle is never passed to the certificate."""
import sys,json,time
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp
from fourier_volterra import *
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence'

def jsonify(x):
    if isinstance(x,F):return str(x)
    if isinstance(x,C):return [str(x.r),str(x.i)]
    if isinstance(x,dict):return {str(k):jsonify(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [jsonify(v) for v in x]
    if isinstance(x,np.generic):return x.item()
    return x

def oracle(m,T,rtol=2e-13):
    om=float(m.omega);g=float(m.g);ep=float(m.eps)
    def ff(t,v):
        a,b=v;q=m.sigma*np.sqrt(1+abs(a)**2+2*abs(b)**2)
        c=g+ep*np.real(np.exp(1j*om*t)*a)
        return np.array([1j*q*c*np.conj(a)*b,1j*q*c*a*a/2])
    ans=solve_ivp(ff,(0,float(T)),np.array([.25+0j,.5+0j]),method='DOP853',rtol=rtol,atol=rtol/50,dense_output=True)
    if not ans.success:raise RuntimeError(ans.message)
    return ans

def run_case(name,omega,T=F(1,2),tol=F(1,10**8),sigma=1,policy='DIRECT',cap=F(1,8)):
    m=Model(F(omega),sigma=sigma);state=State();records=[];rejections=0;builds=0;nrhs=0
    glob_gain=1/(1-T*m.growth)
    while state.t<T:
        h=min(cap,T-state.t)
        while True:
            # Cheap predictor first, then stronger candidate; all failed work counted.
            accepted=None
            for K,p,sw in [(2,4,2),(3,6,4)]:
                hs=(F(1),) if policy=='DIRECT' else (F(0),F(1,2),F(1))
                tr=build(state,h,m,K,p,sw,hs)
                builds+=1;nrhs+=len(tr['history'])
                c=tr['certificate']
                if c['accepted']:
                    local=c['error']-c['growth']*state.error
                    if local<=tol*h/(8*T*glob_gain) and c['error']<=tol/4:
                        accepted=tr;break
                rejections+=1
            if accepted:break
            h/=2
            if h<F(1,2**20):raise RuntimeError('STEP_RESOURCE_CAP')
        prev=state;state=commit(accepted,state,m,tol/4)
        ph=physical(state,m)
        if ph['H_error']>tol:raise RuntimeError('physical budget not closed')
        c=accepted['certificate']
        records.append({'t':str(state.t),'h':str(h),'value':[z.to_complex() for z in state.a],
                        'value_exact':state.a,'error':str(state.error),'physical':ph,
                        'phase_mode':c['phase_mode'],'K':accepted['K'],'p':accepted['p'],
                        'residual':str(c['residual_bound']),
                        'algebraic_defect':str(c['algebraic_defect']),
                        'path':[x.frozen() for x in accepted['path']],
                        'start':prev,'trial':accepted})
    ref=oracle(m,T);ref2=oracle(m,T,rtol=8e-14)
    maxerr=0;maxratio=0;viol=0;interior=0;maxoracle=0
    for r in records:
        t=float(F(r['t']));val=np.array(r['value']);err=max(abs(val-ref2.sol(t)))
        maxerr=max(maxerr,float(err));maxratio=max(maxratio,float(err)/float(F(r['error'])))
        maxoracle=max(maxoracle,float(max(abs(ref.sol(t)-ref2.sol(t)))))
        viol+=int(err>float(F(r['error'])))
        tr=r['trial'];c=tr['certificate'];old=r['start']
        for tau in [F(1,4),F(1,2),F(3,4)]:
            v=np.array([p.value_interval(m.omega*tr['h'],tau)[0].to_complex() for p in tr['path']])
            # The endpoint growth bound is also valid throughout [0,h].
            e=c['growth']*(old.error+c['residual_bound'])
            er=max(abs(v-ref2.sol(float(old.t+tau*tr['h']))));viol+=int(er>float(e)+1e-16);interior+=1
        r.pop('value');r.pop('start');r.pop('trial')
    out={'case':name,'omega':str(m.omega),'sigma':sigma,'T':str(T),'tol':str(tol),'policy':policy,
         'accepted_steps':len(records),'candidate_builds':builds,'candidate_rejections':rejections,
         'rhs_convolutions':nrhs,'max_observed_envelope_error':maxerr,'max_error_bound_ratio':maxratio,
         'raw_oracle_bound_violations':viol,'interior_audits':interior,'oracle_difference':maxoracle,
         'oracle_nfev':[ref.nfev,ref2.nfev],'records':records}
    (OUT/f'case_{name}.json').write_text(json.dumps(jsonify(out),indent=2))
    print(name,len(records),'builds',builds,'rhs',nrhs,'error',maxerr,'ratio',maxratio,'viol',viol,flush=True)
    return out

if __name__=='__main__':
    cases={
      'resonance':dict(omega=0),'near':dict(omega=F(1,10**8)),
      'unit':dict(omega=1),'forty':dict(omega=40),
      'fast':dict(omega=10**4),'ultrafast_slab':dict(omega=10**6,T=F(1,16),cap=F(1,16)),
      'negative':dict(omega=-40,sigma=-1),
      'homotopy':dict(omega=40,policy='CONTINUATION'),
      'tight':dict(omega=40,tol=F(1,10**12)),
    }
    for name in sys.argv[1:]:run_case(name,**cases[name])
