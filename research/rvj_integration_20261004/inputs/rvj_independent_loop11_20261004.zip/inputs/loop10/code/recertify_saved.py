"""Recompute certificates for saved exact paths, not numerical solutions."""
from pathlib import Path
import json,sys
from fourier_volterra import *
ROOT=Path(__file__).resolve().parents[1]; E=ROOT/'evidence'
names=sys.argv[1:] or [p.stem[5:] for p in sorted(E.glob('case_*.json'))]
results=[]
for name in names:
    data=json.loads((E/f'case_{name}.json').read_text());m=Model(F(data['omega']),sigma=data['sigma']);state=State();count=0
    for rec in data['records']:
        h=F(rec['h']);path=tuple(EP({(int(k),int(j)):C(F(re),F(im)) for k,j,re,im in rows}) for rows in rec['path'])
        rt=rotate_interval(m.omega*state.t,144)
        mid=C(sum(rt['cos'])/2,sum(rt['sin'])/2)
        e0=(rt['cos'][1]-rt['cos'][0]+rt['sin'][1]-rt['sin'][0])/2
        phase,tail,mode=phase_candidate(m.omega*h,mid,144)
        c=certificate(state,h,m,path,phase,e0+mid.abs1()*tail,mode)
        assert c['accepted']
        assert c['error']==F(rec['error'])
        assert c['residual_bound']==F(rec['residual'])
        assert c['algebraic_defect']==F(rec['algebraic_defect'])
        expect=tuple(C(F(r),F(i)) for r,i in rec['value_exact'])
        assert c['endpoint']==expect
        trial={'certificate':c,'h':h,'path':path,'state':state,'model':m}
        state=commit(trial,state,m,F(data['tol'])/4)
        ph=physical(state,m)
        assert ph['H_error']==F(rec['physical']['H_error'])
        assert ph['H_error']<=F(data['tol'])
        count+=1
    results.append({'case':name,'steps':count,'exact_certificates_match':True,'replayed_candidate_generation':False})
    print(name,count,'exact certificates and physical bounds match',flush=True)
(E/('recertify_'+names[0]+'.json')).write_text(json.dumps(results,indent=2))
