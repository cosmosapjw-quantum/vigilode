#!/usr/bin/env bash
set -eu
cd "$(dirname "$0")"
export PYTHONPATH="$PWD/code${PYTHONPATH:+:$PYTHONPATH}"
python -m pytest tests -q
python code/run_algebra.py
python code/run_math.py
python code/recertify.py
