include(joinpath(@__DIR__,"julia_algorithms.jl"))
using SparseArrays
const BRIDGE=ARGS[1]
corpus=JSON3.read(read(ARGS[2],String))
refs=Dict(String(r.problem)=>[Float64.(collect(v)) for v in r.states] for r in JSON3.read(read(ARGS[3],String)).references)
const KIND_IDS=Dict("sphere-photon2d"=>0,"semilinear-advection-diffusion2d"=>1,"semilinear-advection-diffusion3d"=>2,"sphere-photon3d"=>3,"spherical-diffusion2d"=>4,"allen-cahn2d"=>5,"gray-scott2d"=>6,"burgers2d"=>7,"sine-gordon2d"=>8)
const BAND=Dict(0=>7,1=>8,2=>36,3=>25,4=>8,5=>8,6=>17,7=>13,8=>13)
# All these models are autonomous. The Rust Model ignores t; use a declared
# zero t-gradient. Native Julia time stepper, identical Rust RHS and Jacobian.
function make_spatial(p,sparse_mode)
    n=Int(p.n);id=UInt32(KIND_IDS[String(p.kind)])
    y0=zeros(n)
    @assert ccall((:vb_y0,BRIDGE),Cint,(UInt32,Csize_t,Ptr{Cdouble}),id,n,y0)==0
    function rhs!(dy,y,p,t)
        @assert eltype(y)===Float64 && eltype(dy)===Float64
        ccall((:vb_rhs,BRIDGE),Cint,(UInt32,Csize_t,Ptr{Cdouble},Ptr{Cdouble}),id,n,y,dy)==0||error("shared source RHS")
    end
    function jacdense!(J,y,p,t)
        @assert J isa Matrix{Float64}
        ccall((:vb_jac,BRIDGE),Cint,(UInt32,Csize_t,Ptr{Cdouble},Ptr{Cdouble}),id,n,y,J)==0||error("shared source Jacobian")
    end
    tgrad!(out,y,p,t)=fill!(out,0.)
    # Verify exact initial values, and test directional derivative on the
    # represented model. Not a proof of a new independent reference.
    @assert y0==refs[String(p.id)][1]
    J=zeros(n,n);jacdense!(J,y0,nothing,0.)
    v=[sin(i) for i in 1:n];plus=zeros(n);minus=zeros(n)
    rhs!(plus,y0.+1e-5.*v,nothing,0.);rhs!(minus,y0.-1e-5.*v,nothing,0.)
    fd=(plus.-minus)./2e-5
    audit=norm(fd-J*v,Inf)/max(1.,norm(J*v,Inf))
    if sparse_mode
        # Use the original declared bandwidth; every actual full Jacobian is
        # checked before copying to the CSC. Do not discard nonzero entries.
        bw=BAND[Int(id)]
        I=Int[];K=Int[]
        for j in 1:n,i in max(1,j-bw):min(n,j+bw);push!(I,i);push!(K,j);end
        proto=sparse(I,K,ones(length(I)),n,n);fill!(nonzeros(proto),0.)
        scratch=zeros(n,n)
        function jacsparse!(S,y,p,t)
            jacdense!(scratch,y,p,t)
            for j in 1:n,i in 1:n
                if abs(i-j)>bw && scratch[i,j]!=0.;error("declared bandwidth mismatch");end
            end
            for j in 1:n,k in nzrange(S,j)
                nonzeros(S)[k]=scratch[rowvals(S)[k],j]
            end
        end
        f=ODEFunction(rhs!,jac=jacsparse!,tgrad=tgrad!,jac_prototype=proto)
    else
        f=ODEFunction(rhs!,jac=jacdense!,tgrad=tgrad!,jac_prototype=zeros(n,n))
    end
    ODEProblem(f,y0,(0.,Float64(p.t_end))),audit
end
for p in corpus.problems
    id=String(p.id)
    grid=[Float64(p.t_end)*i/100 for i in 0:100];grid[end]=Float64(p.t_end)
    scales=Float64.(collect(p.atol_scale))
    for sp in (false,true)
        prob,audit=make_spatial(p,sp)
        println(stderr,"BRIDGE_AUDIT ",id," sparse=",sp," directional_rel=",audit)
        algs=filter(x->x[1] in (sp ? ["rodas4p","rodas5pr","trbdf2","qndf","radauiia5"] : ["rosenbrock23","rodas4p","rodas5pr","trbdf2","kvaerno5","qndf","radauiia5","vern7","tsit5"]),vcat(IMPLICIT_ALGS,EXPLICIT_ALGS))
        if sp
            push!(algs,("rodas5p",()->Rodas5P()));push!(algs,("fbdf",()->FBDF()))
        else
            push!(algs,("rodas5p",()->Rodas5P()));push!(algs,("fbdf",()->FBDF()))
        end
        for (name,ctor) in algs
            benchmark_case(prob,id,name*"-shared-rust-"*(sp ? "sparse" : "dense"),ctor,grid,refs[id],scales,[1e-4,1e-6,1e-8];warmups=1,repeats=3)
        end
    end
end
