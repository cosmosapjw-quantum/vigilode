using OrdinaryDiffEq, OrdinaryDiffEqBDF, OrdinaryDiffEqFIRK, OrdinaryDiffEqRosenbrock, OrdinaryDiffEqSDIRK, OrdinaryDiffEqVerner, Sundials, LinearAlgebra, Statistics, JSON3, SHA
BLAS.set_num_threads(1)
# Every name corresponds to the actual installed constructor, not a surrogate.
const IMPLICIT_ALGS = [
 ("rosenbrock23",()->Rosenbrock23()), ("rosenbrock32",()->Rosenbrock32()),
 ("rodas3p",()->Rodas3P()), ("rodas4",()->Rodas4()), ("rodas4p",()->Rodas4P()),
 ("rodas5",()->Rodas5()), ("rodas5pe",()->Rodas5Pe()), ("rodas5pr",()->Rodas5Pr()),
 ("rodas6p",()->Rodas6P()), ("trbdf2",()->TRBDF2()),
 ("kvaerno3",()->Kvaerno3()), ("kvaerno5",()->Kvaerno5()),
 ("kencarp4",()->KenCarp4()), ("esdirk436l2sa2",()->ESDIRK436L2SA2()),
 ("qndf",()->QNDF()), ("abdf2",()->ABDF2()),
 ("radauiia3",()->RadauIIA3()), ("radauiia5",()->RadauIIA5()),
 ("radauiia9",()->RadauIIA9()), ("adaptive-radau",()->AdaptiveRadau())]
const EXPLICIT_ALGS = [
 ("tsit5",()->Tsit5()), ("vern7",()->Vern7()), ("vern9",()->Vern9()),
 ("autotsit5-rosenbrock23",()->AutoTsit5(Rosenbrock23())),
 ("autovern7-rodas5p",()->AutoVern7(Rodas5P())),
 ("cvode-adams",()->CVODE_Adams())]
# Stiff explicit arms intentionally capped at the original 1e6 step limit.
function benchmark_case(prob, id, name, ctor, grid, reference, scales, rtols; cap=1000000, repeats=5, warmups=2, constraints=nothing, atol_factor=scales[1])
    rows=Any[]
    for tol in rtols
        r=Dict{String,Any}("problem"=>id,"arm"=>"julia-"*name,"rtol"=>tol,
            "atol"=>tol*atol_factor,"ok"=>false,"wall_ms_median"=>nothing,
            "error_common"=>nothing,"raw_timing_samples_ns"=>Int[],"output_contract"=>"saveat-grid")
        try
            alg=ctor()
            local sol
            samples=Int[]
            for rep in 1:(warmups+repeats)
                t0=time_ns()
                sol=solve(prob,alg;reltol=tol,abstol=tol*atol_factor,saveat=grid,maxiters=cap)
                dt=Int(time_ns()-t0)
                r["retcode"]=string(sol.retcode)
                if !SciMLBase.successful_retcode(sol.retcode) || length(sol.t)!=length(grid) || length(sol.u)!=length(grid) || !all(isfinite,Iterators.flatten(sol.u)) || any(sol.t .!= grid)
                    r["reason"]="incomplete, nonfinite, or unsuccessful output"
                    break
                end
                if rep>warmups;push!(samples,dt);end
            end
            r["raw_timing_samples_ns"]=samples
            if length(samples)==repeats
                r["ok"]=true;r["wall_ms_median"]=median(samples)/1e6
                r["mad_ms"]=median(abs.(samples.-median(samples)))/1e6
                if reference!==nothing
                    @assert length(reference)==length(grid)
                    r["error_common"]=maximum(sqrt(sum(abs2,(sol.u[k].-reference[k])./(scales.+abs.(reference[k])))/length(scales)) for k in eachindex(grid))
                end
                if constraints!==nothing;r["constraint_residual"]=maximum(constraints(sol.t[k],sol.u[k]) for k in eachindex(grid));end
            end
            if @isdefined(sol)
                for (k,v) in [("nf",:nf),("njac",:njacs),("accepted",:naccept),("rejected",:nreject),("nsolve",:nsolve)]
                    r[k]=hasproperty(sol.stats,v) ? getproperty(sol.stats,v) : nothing
                end
                r["grid_points_completed"]=length(sol.u)
            end
        catch e
            r["ok"]=false;r["wall_ms_median"]=nothing;r["error_common"]=nothing;r["reason"]=sprint(showerror,e)
        end
        println(JSON3.write(r));flush(stdout)
        push!(rows,r)
    end
    rows
end
