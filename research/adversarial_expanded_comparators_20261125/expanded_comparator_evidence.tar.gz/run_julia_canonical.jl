include(joinpath(@__DIR__,"julia_algorithms.jl"))
root=ARGS[1]; ref=ARGS[2]; group=ARGS[3]
source=read(joinpath(root,"bench/julia_comparator_bench.jl"),String)
include_string(Main,first(split(source,"function main()";limit=2)),"canonical_original_definitions.jl")
refs=Dict(String(r.problem)=>[Float64.(collect(v)) for v in r.states] for r in JSON3.read(read(ref,String)).references)
algos=group=="implicit" ? IMPLICIT_ALGS : EXPLICIT_ALGS
for p in get_problems()
    grid=[p.tspan[2]*i/100 for i in 0:100];grid[end]=p.tspan[2]
    prob=ODEProblem(p.ode_fun,copy(p.u0),p.tspan)
    for (name,ctor) in algos
        benchmark_case(prob,p.id,name,ctor,grid,refs[p.id],p.atol_scale,[1e-4,1e-6,1e-8])
    end
end
