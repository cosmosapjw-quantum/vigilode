use std::alloc::{GlobalAlloc, Layout, System};
use std::env;
use std::f64::consts::PI;
use std::ffi::c_void;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Instant;

use diffsol::{
    DenseMatrix, FaerLU, FaerMat, FaerSparseLU, FaerSparseMat, MatrixCommon, OdeBuilder,
    OdeSolverMethod, OdeSolverStopReason, VectorHost,
};
use rodas5p_core::{DenseMatrix as CoreDenseMatrix, LinearMethod, LinearSolverConfig};
use rodas5p_integrators::{
    integrate_pexprb54s4_fused_adaptive_observed, integrate_rodas5p_fast_banded_observed,
    integrate_rodas5p_fast_observed, integrate_rodas5p_fast_small_observed,
    integrate_rodas5p_mf_fast_observed_gmres_into_ls_workspace, AdaptiveStepConfig,
    BandedJacobian, FusedPhiKrylovConfig, OdeProblem, OutputSchedule, ParallelExecution,
    SmallProblem,
};
use serde_json::{json, Value};
use vigilode::coloring::SparsityPattern;
use vigilode::prelude::*;
use vigilode::{
    DerivativeFallback, Direction, Dopri5Ensemble, Dopri5EnsembleJob, SwitchingConfig,
    SwitchingSolver,
};

// ---------------- Counting Allocator + C Interposition ----------------
struct Counting;
static TRACK: AtomicBool = AtomicBool::new(false);
static RUST_CALLS: AtomicU64 = AtomicU64::new(0);
static RUST_BYTES: AtomicU64 = AtomicU64::new(0);
static HEAP_CALLS: AtomicU64 = AtomicU64::new(0);
static HEAP_BYTES: AtomicU64 = AtomicU64::new(0);

unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        if TRACK.load(Ordering::Relaxed) {
            RUST_CALLS.fetch_add(1, Ordering::Relaxed);
            RUST_BYTES.fetch_add(l.size() as u64, Ordering::Relaxed);
        }
        unsafe { System.alloc(l) }
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        if TRACK.load(Ordering::Relaxed) {
            RUST_CALLS.fetch_add(1, Ordering::Relaxed);
            RUST_BYTES.fetch_add(l.size() as u64, Ordering::Relaxed);
        }
        unsafe { System.alloc_zeroed(l) }
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        unsafe { System.dealloc(p, l) }
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
        if TRACK.load(Ordering::Relaxed) {
            RUST_CALLS.fetch_add(1, Ordering::Relaxed);
            RUST_BYTES.fetch_add(n as u64, Ordering::Relaxed);
        }
        unsafe { System.realloc(p, l, n) }
    }
}

#[global_allocator]
static GLOBAL: Counting = Counting;

unsafe extern "C" {
    fn __libc_malloc(size: usize) -> *mut c_void;
    fn __libc_calloc(n: usize, size: usize) -> *mut c_void;
    fn __libc_realloc(p: *mut c_void, size: usize) -> *mut c_void;
    fn __libc_memalign(align: usize, size: usize) -> *mut c_void;
}

#[inline]
fn count_c(bytes: usize) {
    if TRACK.load(Ordering::Relaxed) {
        HEAP_CALLS.fetch_add(1, Ordering::Relaxed);
        HEAP_BYTES.fetch_add(bytes as u64, Ordering::Relaxed);
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn malloc(size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_malloc(size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn calloc(n: usize, size: usize) -> *mut c_void {
    count_c(n.saturating_mul(size));
    unsafe { __libc_calloc(n, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn realloc(p: *mut c_void, size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_realloc(p, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn memalign(align: usize, size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_memalign(align, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn aligned_alloc(align: usize, size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_memalign(align, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_memalign(out: *mut *mut c_void, align: usize, size: usize) -> i32 {
    if !align.is_power_of_two() || !align.is_multiple_of(std::mem::size_of::<*mut c_void>()) {
        return 22;
    }
    count_c(size);
    let p = unsafe { __libc_memalign(align, size) };
    if p.is_null() && size != 0 {
        return 12;
    }
    unsafe { *out = p };
    0
}

#[derive(Clone, Copy, Default)]
struct AllocSnap {
    rust_calls: u64,
    rust_bytes: u64,
    heap_calls: u64,
    heap_bytes: u64,
}

fn alloc_begin() {
    RUST_CALLS.store(0, Ordering::SeqCst);
    RUST_BYTES.store(0, Ordering::SeqCst);
    HEAP_CALLS.store(0, Ordering::SeqCst);
    HEAP_BYTES.store(0, Ordering::SeqCst);
    TRACK.store(true, Ordering::SeqCst);
}

fn alloc_end() -> AllocSnap {
    TRACK.store(false, Ordering::SeqCst);
    AllocSnap {
        rust_calls: RUST_CALLS.load(Ordering::SeqCst),
        rust_bytes: RUST_BYTES.load(Ordering::SeqCst),
        heap_calls: HEAP_CALLS.load(Ordering::SeqCst),
        heap_bytes: HEAP_BYTES.load(Ordering::SeqCst),
    }
}

// ---------------- Native FFI ----------------
type RhsCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *mut f64);
type JacCb = unsafe extern "C" fn(*const c_void, f64, *const f64, i32, i32, i32, *mut f64);
type JvpCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *const f64, *mut f64);
type DfxCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *mut f64);
type MasCb = unsafe extern "C" fn(*const c_void, i32, i32, *mut f64);
type RootCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *mut f64);
type ResCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *const f64, *mut f64);
type IdaJacCb = unsafe extern "C" fn(*const c_void, f64, f64, *const f64, *const f64, i32, i32, *mut f64);

unsafe extern "C" {
    fn fs_dvode(
        ctx: *const c_void,
        rhs: RhsCb,
        jac: Option<JacCb>,
        mf_in: i32,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        rtol: f64,
        atol: f64,
        ml: i32,
        mu: i32,
        max_steps: i32,
        values: *mut f64,
        completed: *mut i32,
        code: *mut i32,
        stats: *mut i32,
    );
    fn fs_hairer(
        which: i32,
        ctx: *const c_void,
        rhs: RhsCb,
        jac: Option<JacCb>,
        dfx: Option<DfxCb>,
        mas: Option<MasCb>,
        ifcn_in: i32,
        idfx_in: i32,
        imas_in: i32,
        n_ind1: i32,
        n_ind2: i32,
        n_ind3: i32,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        rtol: f64,
        atol: f64,
        ml: i32,
        mu: i32,
        max_steps: i32,
        values: *mut f64,
        completed: *mut i32,
        code: *mut i32,
        stats: *mut i32,
    );
    fn fs_cvode(
        ctx: *const c_void,
        rhs: RhsCb,
        jac: Option<JacCb>,
        jvp: Option<JvpCb>,
        root_fn: Option<RootCb>,
        mode: i32,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        rtol: f64,
        atol: f64,
        ml: i32,
        mu: i32,
        max_steps: i64,
        nroots: i32,
        stop_on_root: i32,
        values: *mut f64,
        completed: *mut i32,
        root_times: *mut f64,
        root_count: *mut i32,
        max_roots: i32,
        stats: *mut i64,
    ) -> i32;
    fn fs_ida(
        ctx: *const c_void,
        res_fn: ResCb,
        jac_fn: Option<IdaJacCb>,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        yp0: *const f64,
        id_vec: *const f64,
        rtol: f64,
        atol: f64,
        max_steps: i64,
        calc_ic: i32,
        values: *mut f64,
        completed: *mut i32,
        stats: *mut i64,
    ) -> i32;
}

// ---------------- Shared Model & Metrics ----------------
fn make_grid(t0: f64, t1: f64, pts: usize) -> Vec<f64> {
    let mut g: Vec<f64> = (0..pts)
        .map(|k| t0 + (t1 - t0) * k as f64 / (pts - 1) as f64)
        .collect();
    *g.last_mut().unwrap() = t1;
    g
}

fn max_wrms(states: &[Vec<f64>], reference: &[Vec<f64>], atol_scale: &[f64]) -> Option<f64> {
    if states.len() != reference.len() || states.is_empty() {
        return None;
    }
    let n = atol_scale.len();
    let sqrt_n = (n as f64).sqrt();
    let mut worst = 0.0_f64;
    for (y, r) in states.iter().zip(reference.iter()) {
        if y.len() != n || r.len() != n {
            return None;
        }
        let mut norm = 0.0_f64;
        for i in 0..n {
            if !y[i].is_finite() {
                return None;
            }
            let sc = atol_scale[i] + r[i].abs();
            let e = (y[i] - r[i]) / sc;
            norm = norm.hypot(e / sqrt_n);
        }
        worst = worst.max(norm);
    }
    Some(worst)
}

#[derive(Clone, Default)]
struct ArmRun {
    ok: bool,
    err_msg: String,
    states: Vec<Vec<f64>>,
    nf: Option<u64>,
    njac: Option<u64>,
    njvp: Option<u64>,
    nlu: Option<u64>,
    nsolve: Option<u64>,
    accepted: Option<u64>,
    rejected: Option<u64>,
    extra: Value,
}

fn timed_run<F: FnMut() -> ArmRun>(
    problem: &str,
    arm: &str,
    rtol: f64,
    ref_states: Option<&[Vec<f64>]>,
    atol_scale: &[f64],
    mut f: F,
) -> Value {
    for _ in 0..2 {
        let w = f();
        if !w.ok {
            return json!({
                "problem": problem, "arm": arm, "rtol": rtol, "ok": false,
                "err_msg": w.err_msg, "error_common": null, "wall_ms_median": null,
                "nf": w.nf, "njac": w.njac, "njvp": w.njvp, "nlu": w.nlu, "nsolve": w.nsolve,
                "accepted": w.accepted, "rejected": w.rejected,
                "rust_alloc_calls": null, "heap_alloc_calls": null, "heap_alloc_bytes": null,
                "extra": w.extra, "timing_authority": "diagnostic_only"
            });
        }
    }
    let mut times_ns = Vec::with_capacity(5);
    let mut last = ArmRun::default();
    let mut alloc = AllocSnap::default();
    for rep in 0..5 {
        if rep == 0 {
            alloc_begin();
        }
        let t0 = Instant::now();
        last = f();
        let dt = t0.elapsed().as_nanos() as u64;
        if rep == 0 {
            alloc = alloc_end();
        }
        if !last.ok {
            return json!({
                "problem": problem, "arm": arm, "rtol": rtol, "ok": false,
                "err_msg": last.err_msg, "error_common": null, "wall_ms_median": null,
                "nf": last.nf, "njac": last.njac, "njvp": last.njvp, "nlu": last.nlu, "nsolve": last.nsolve,
                "accepted": last.accepted, "rejected": last.rejected,
                "rust_alloc_calls": alloc.rust_calls, "heap_alloc_calls": alloc.heap_calls,
                "heap_alloc_bytes": alloc.heap_bytes, "extra": last.extra,
                "timing_authority": "diagnostic_only"
            });
        }
        times_ns.push(dt);
    }
    times_ns.sort_unstable();
    let med_ms = times_ns[times_ns.len() / 2] as f64 * 1e-6;
    let err = ref_states.and_then(|r| max_wrms(&last.states, r, atol_scale));
    json!({
        "problem": problem, "arm": arm, "rtol": rtol, "ok": true, "err_msg": "",
        "error_common": err, "wall_ms_median": med_ms,
        "nf": last.nf, "njac": last.njac, "njvp": last.njvp, "nlu": last.nlu, "nsolve": last.nsolve,
        "accepted": last.accepted, "rejected": last.rejected,
        "rust_alloc_calls": alloc.rust_calls, "rust_alloc_bytes": alloc.rust_bytes,
        "heap_alloc_calls": alloc.heap_calls, "heap_alloc_bytes": alloc.heap_bytes,
        "extra": last.extra, "timing_authority": "diagnostic_only"
    })
}

fn col_to_rows(vals: &[f64], n: usize, nt: usize) -> Vec<Vec<f64>> {
    (0..nt)
        .map(|k| vals[k * n..(k + 1) * n].to_vec())
        .collect()
}

// ---------------- Problem Definitions & Native Callbacks ----------------
#[derive(Clone, Copy)]
enum NativeProb {
    Kepler,
    Kreiss,
    Pr1e4,
    AdvDiff256,
    Bruss400,
    DaeRob,
    DaeAna,
    MassIll,
    DaePend,
    Burst,
    RobFd,
    Harmonic,
}

impl NativeProb {
    fn n(self) -> usize {
        match self {
            Self::Kepler => 4,
            Self::Kreiss | Self::DaeAna | Self::MassIll | Self::Burst | Self::Harmonic => 2,
            Self::Pr1e4 => 1,
            Self::AdvDiff256 => 256,
            Self::Bruss400 => 400,
            Self::DaeRob | Self::RobFd => 3,
            Self::DaePend => 5,
        }
    }
    fn rhs(self, t: f64, y: &[f64], dy: &mut [f64]) {
        match self {
            Self::Kepler => {
                let r2 = y[0] * y[0] + y[1] * y[1];
                let inv_r3 = -1.0 / (r2 * r2.sqrt());
                dy[0] = y[2];
                dy[1] = y[3];
                dy[2] = inv_r3 * y[0];
                dy[3] = inv_r3 * y[1];
            }
            Self::Kreiss => {
                dy[0] = -y[0] + 100.0 * y[1];
                dy[1] = -2.0 * y[1];
            }
            Self::Pr1e4 => {
                dy[0] = -1.0e4 * (y[0] - t.sin()) + t.cos();
            }
            Self::AdvDiff256 => {
                let n = 256usize;
                let d = 0.01 * (n as f64) * (n as f64);
                let v = 1.0 * (n as f64);
                for i in 0..n {
                    let im1 = if i == 0 { n - 1 } else { i - 1 };
                    let ip1 = if i + 1 == n { 0 } else { i + 1 };
                    dy[i] = d * (y[im1] - 2.0 * y[i] + y[ip1]) - v * (y[i] - y[im1]);
                }
            }
            Self::Bruss400 => {
                let nc = 200usize;
                let dx = 1.0 / (nc as f64 + 1.0);
                let c = 0.02 / (dx * dx);
                for i in 0..nc {
                    let (u, v) = (y[2 * i], y[2 * i + 1]);
                    let ul = if i == 0 { 1.0 } else { y[2 * (i - 1)] };
                    let vl = if i == 0 { 3.0 } else { y[2 * (i - 1) + 1] };
                    let ur = if i + 1 == nc { 1.0 } else { y[2 * (i + 1)] };
                    let vr = if i + 1 == nc { 3.0 } else { y[2 * (i + 1) + 1] };
                    dy[2 * i] = 1.0 + u * u * v - 4.4 * u + c * (ul - 2.0 * u + ur);
                    dy[2 * i + 1] = 3.4 * u - u * u * v + c * (vl - 2.0 * v + vr);
                }
            }
            Self::DaeRob => {
                dy[0] = -0.04 * y[0] + 1.0e4 * y[1] * y[2];
                dy[1] = 0.04 * y[0] - 1.0e4 * y[1] * y[2] - 3.0e7 * y[1] * y[1];
                dy[2] = y[0] + y[1] + y[2] - 1.0;
            }
            Self::DaeAna => {
                dy[0] = -y[0] + y[1];
                dy[1] = y[0] + y[1] - (2.0 * t.sin() + t.cos());
            }
            Self::MassIll => {
                dy[0] = -y[0];
                dy[1] = -1.0e-8 * y[1];
            }
            Self::DaePend => {
                let (x, z, vx, vz, lam) = (y[0], y[1], y[2], y[3], y[4]);
                dy[0] = vx;
                dy[1] = vz;
                dy[2] = -lam * x;
                dy[3] = -1.0 - lam * z;
                dy[4] = x * x + z * z - 1.0;
            }
            Self::Burst => {
                let lam = 5000.0 * (-40.0 * (t - 3.0) * (t - 3.0)).exp();
                dy[0] = y[1];
                dy[1] = -y[0] - lam * (y[1] + t.sin()) - t.cos();
            }
            Self::RobFd => {
                dy[0] = -0.04 * y[0] + 1.0e4 * y[1] * y[2];
                dy[1] = 0.04 * y[0] - 1.0e4 * y[1] * y[2] - 3.0e7 * y[1] * y[1];
                dy[2] = 3.0e7 * y[1] * y[1];
            }
            Self::Harmonic => {
                dy[0] = y[1];
                dy[1] = -y[0];
            }
        }
    }
    fn dfx(self, t: f64, _y: &[f64], out: &mut [f64]) {
        match self {
            Self::Pr1e4 => {
                out[0] = -1.0e4 * (-t.cos()) - t.sin();
            }
            _ => out.fill(0.0),
        }
    }
    fn jvp(self, t: f64, y: &[f64], v: &[f64], out: &mut [f64]) {
        match self {
            Self::Kepler => {
                let r2 = y[0] * y[0] + y[1] * y[1];
                let r = r2.sqrt();
                let r3 = r2 * r;
                let r5 = r3 * r2;
                let dot = y[0] * v[0] + y[1] * v[1];
                out[0] = v[2];
                out[1] = v[3];
                out[2] = -v[0] / r3 + 3.0 * dot * y[0] / r5;
                out[3] = -v[1] / r3 + 3.0 * dot * y[1] / r5;
            }
            Self::Kreiss => {
                out[0] = -v[0] + 100.0 * v[1];
                out[1] = -2.0 * v[1];
            }
            Self::Pr1e4 => {
                out[0] = -1.0e4 * v[0];
            }
            Self::AdvDiff256 => {
                let n = 256usize;
                let d = 0.01 * (n as f64) * (n as f64);
                let vel = 1.0 * (n as f64);
                for i in 0..n {
                    let im1 = if i == 0 { n - 1 } else { i - 1 };
                    let ip1 = if i + 1 == n { 0 } else { i + 1 };
                    out[i] = d * (v[im1] - 2.0 * v[i] + v[ip1]) - vel * (v[i] - v[im1]);
                }
            }
            Self::Bruss400 => {
                let nc = 200usize;
                let dx = 1.0 / (nc as f64 + 1.0);
                let c = 0.02 / (dx * dx);
                for i in 0..nc {
                    let (u, vv) = (y[2 * i], y[2 * i + 1]);
                    let (du, dv) = (v[2 * i], v[2 * i + 1]);
                    let dul = if i == 0 { 0.0 } else { v[2 * (i - 1)] };
                    let dvl = if i == 0 { 0.0 } else { v[2 * (i - 1) + 1] };
                    let dur = if i + 1 == nc { 0.0 } else { v[2 * (i + 1)] };
                    let dvr = if i + 1 == nc { 0.0 } else { v[2 * (i + 1) + 1] };
                    out[2 * i] = (2.0 * u * vv - 4.4 - 2.0 * c) * du + (u * u) * dv + c * (dul + dur);
                    out[2 * i + 1] = (3.4 - 2.0 * u * vv) * du + (-u * u - 2.0 * c) * dv + c * (dvl + dvr);
                }
            }
            Self::DaeRob => {
                out[0] = -0.04 * v[0] + 1.0e4 * y[2] * v[1] + 1.0e4 * y[1] * v[2];
                out[1] = 0.04 * v[0] + (-1.0e4 * y[2] - 6.0e7 * y[1]) * v[1] - 1.0e4 * y[1] * v[2];
                out[2] = v[0] + v[1] + v[2];
            }
            Self::DaeAna => {
                out[0] = -v[0] + v[1];
                out[1] = v[0] + v[1];
            }
            Self::MassIll => {
                out[0] = -v[0];
                out[1] = -1.0e-8 * v[1];
            }
            Self::DaePend => {
                let (x, z, lam) = (y[0], y[1], y[4]);
                out[0] = v[2];
                out[1] = v[3];
                out[2] = -lam * v[0] - x * v[4];
                out[3] = -lam * v[1] - z * v[4];
                out[4] = 2.0 * x * v[0] + 2.0 * z * v[1];
            }
            Self::Burst => {
                let lam = 5000.0 * (-40.0 * (t - 3.0) * (t - 3.0)).exp();
                out[0] = v[1];
                out[1] = -v[0] - lam * v[1];
            }
            Self::RobFd => {
                out[0] = -0.04 * v[0] + 1.0e4 * y[2] * v[1] + 1.0e4 * y[1] * v[2];
                out[1] = 0.04 * v[0] + (-1.0e4 * y[2] - 6.0e7 * y[1]) * v[1] - 1.0e4 * y[1] * v[2];
                out[2] = 6.0e7 * y[1] * v[1];
            }
            Self::Harmonic => {
                out[0] = v[1];
                out[1] = -v[0];
            }
        }
    }
    fn jac_entries(self, t: f64, y: &[f64], mut emit: impl FnMut(usize, usize, f64)) {
        match self {
            Self::Kepler => {
                let r2 = y[0] * y[0] + y[1] * y[1];
                let r = r2.sqrt();
                let r3 = r2 * r;
                let r5 = r3 * r2;
                emit(0, 2, 1.0);
                emit(1, 3, 1.0);
                emit(2, 0, -1.0 / r3 + 3.0 * y[0] * y[0] / r5);
                emit(2, 1, 3.0 * y[0] * y[1] / r5);
                emit(3, 0, 3.0 * y[0] * y[1] / r5);
                emit(3, 1, -1.0 / r3 + 3.0 * y[1] * y[1] / r5);
            }
            Self::Kreiss => {
                emit(0, 0, -1.0);
                emit(0, 1, 100.0);
                emit(1, 1, -2.0);
            }
            Self::Pr1e4 => {
                emit(0, 0, -1.0e4);
            }
            Self::AdvDiff256 => {
                let n = 256usize;
                let d = 0.01 * (n as f64) * (n as f64);
                let vel = 1.0 * (n as f64);
                for i in 0..n {
                    let im1 = if i == 0 { n - 1 } else { i - 1 };
                    let ip1 = if i + 1 == n { 0 } else { i + 1 };
                    emit(i, im1, d + vel);
                    emit(i, i, -2.0 * d - vel);
                    emit(i, ip1, d);
                }
            }
            Self::Bruss400 => {
                let nc = 200usize;
                let dx = 1.0 / (nc as f64 + 1.0);
                let c = 0.02 / (dx * dx);
                for i in 0..nc {
                    let (u, v) = (y[2 * i], y[2 * i + 1]);
                    emit(2 * i, 2 * i, 2.0 * u * v - 4.4 - 2.0 * c);
                    emit(2 * i, 2 * i + 1, u * u);
                    emit(2 * i + 1, 2 * i, 3.4 - 2.0 * u * v);
                    emit(2 * i + 1, 2 * i + 1, -u * u - 2.0 * c);
                    if i > 0 {
                        emit(2 * i, 2 * (i - 1), c);
                        emit(2 * i + 1, 2 * (i - 1) + 1, c);
                    }
                    if i + 1 < nc {
                        emit(2 * i, 2 * (i + 1), c);
                        emit(2 * i + 1, 2 * (i + 1) + 1, c);
                    }
                }
            }
            Self::DaeRob => {
                emit(0, 0, -0.04);
                emit(0, 1, 1.0e4 * y[2]);
                emit(0, 2, 1.0e4 * y[1]);
                emit(1, 0, 0.04);
                emit(1, 1, -1.0e4 * y[2] - 6.0e7 * y[1]);
                emit(1, 2, -1.0e4 * y[1]);
                emit(2, 0, 1.0);
                emit(2, 1, 1.0);
                emit(2, 2, 1.0);
            }
            Self::DaeAna => {
                emit(0, 0, -1.0);
                emit(0, 1, 1.0);
                emit(1, 0, 1.0);
                emit(1, 1, 1.0);
            }
            Self::MassIll => {
                emit(0, 0, -1.0);
                emit(1, 1, -1.0e-8);
            }
            Self::DaePend => {
                let (x, z, lam) = (y[0], y[1], y[4]);
                emit(0, 2, 1.0);
                emit(1, 3, 1.0);
                emit(2, 0, -lam);
                emit(2, 4, -x);
                emit(3, 1, -lam);
                emit(3, 4, -z);
                emit(4, 0, 2.0 * x);
                emit(4, 1, 2.0 * z);
            }
            Self::Burst => {
                let lam = 5000.0 * (-40.0 * (t - 3.0) * (t - 3.0)).exp();
                emit(0, 1, 1.0);
                emit(1, 0, -1.0);
                emit(1, 1, -lam);
            }
            Self::RobFd => {
                emit(0, 0, -0.04);
                emit(0, 1, 1.0e4 * y[2]);
                emit(0, 2, 1.0e4 * y[1]);
                emit(1, 0, 0.04);
                emit(1, 1, -1.0e4 * y[2] - 6.0e7 * y[1]);
                emit(1, 2, -1.0e4 * y[1]);
                emit(2, 1, 6.0e7 * y[1]);
            }
            Self::Harmonic => {
                emit(0, 1, 1.0);
                emit(1, 0, -1.0);
            }
        }
    }
    fn jac_dense_row_major(self, t: f64, y: &[f64], out: &mut [f64]) {
        let n = self.n();
        out.fill(0.0);
        self.jac_entries(t, y, |i, j, v| out[i * n + j] = v);
    }
    fn jac_dense_col_major(self, t: f64, y: &[f64], ld: usize, pd: &mut [f64]) {
        let n = self.n();
        pd[..ld * n].fill(0.0);
        self.jac_entries(t, y, |i, j, v| pd[j * ld + i] = v);
    }
    fn jac_band_col_major(self, t: f64, y: &[f64], ml: usize, mu: usize, ld: usize, pd: &mut [f64]) {
        let n = self.n();
        pd[..ld * (n - 1) + ml + mu + 1].fill(0.0);
        self.jac_entries(t, y, |i, j, v| {
            if i <= j + ml && j <= i + mu {
                pd[j * ld + (mu + i - j)] = v;
            }
        });
    }
    fn jac_band_row_major(self, t: f64, y: &[f64], ml: usize, mu: usize, out: &mut [f64]) {
        let w = ml + mu + 1;
        out.fill(0.0);
        self.jac_entries(t, y, |i, j, v| {
            if i <= j + ml && j <= i + mu {
                out[i * w + (j + ml - i)] = v;
            }
        });
    }
    fn mass_diag(self) -> Option<Vec<f64>> {
        match self {
            Self::DaeRob => Some(vec![1.0, 1.0, 0.0]),
            Self::DaeAna => Some(vec![1.0, 0.0]),
            Self::MassIll => Some(vec![1.0, 1.0e-8]),
            Self::DaePend => Some(vec![1.0, 1.0, 1.0, 1.0, 0.0]),
            _ => None,
        }
    }
}

unsafe extern "C" fn cb_rhs(ctx: *const c_void, t: f64, y: *const f64, f: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    p.rhs(t, unsafe { std::slice::from_raw_parts(y, n) }, unsafe {
        std::slice::from_raw_parts_mut(f, n)
    });
}
unsafe extern "C" fn cb_jac(
    ctx: *const c_void,
    t: f64,
    y: *const f64,
    ml: i32,
    mu: i32,
    ld: i32,
    pd: *mut f64,
) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    let ys = unsafe { std::slice::from_raw_parts(y, n) };
    if ml < 0 {
        let pds = unsafe { std::slice::from_raw_parts_mut(pd, (ld as usize) * n) };
        p.jac_dense_col_major(t, ys, ld as usize, pds);
    } else {
        let (mlu, muu, ldu) = (ml as usize, mu as usize, ld as usize);
        let pds = unsafe { std::slice::from_raw_parts_mut(pd, ldu * (n - 1) + mlu + muu + 1) };
        p.jac_band_col_major(t, ys, mlu, muu, ldu, pds);
    }
}
unsafe extern "C" fn cb_jvp(ctx: *const c_void, t: f64, y: *const f64, v: *const f64, jv: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    p.jvp(
        t,
        unsafe { std::slice::from_raw_parts(y, n) },
        unsafe { std::slice::from_raw_parts(v, n) },
        unsafe { std::slice::from_raw_parts_mut(jv, n) },
    );
}
unsafe extern "C" fn cb_dfx(ctx: *const c_void, t: f64, y: *const f64, fx: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    p.dfx(t, unsafe { std::slice::from_raw_parts(y, n) }, unsafe {
        std::slice::from_raw_parts_mut(fx, n)
    });
}
unsafe extern "C" fn cb_mas(ctx: *const c_void, n: i32, ld: i32, am: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let nu = n as usize;
    let ldu = ld as usize;
    let ams = unsafe { std::slice::from_raw_parts_mut(am, ldu * nu) };
    ams.fill(0.0);
    if let Some(d) = p.mass_diag() {
        for i in 0..nu {
            ams[i * ldu + i] = d[i];
        }
    }
}
unsafe extern "C" fn cb_root_y0(ctx: *const c_void, _t: f64, y: *const f64, gout: *mut f64) {
    let _ = ctx;
    unsafe { *gout = *y };
}
unsafe extern "C" fn cb_ida_res(
    ctx: *const c_void,
    t: f64,
    y: *const f64,
    yp: *const f64,
    res: *mut f64,
) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    let ys = unsafe { std::slice::from_raw_parts(y, n) };
    let yps = unsafe { std::slice::from_raw_parts(yp, n) };
    let ress = unsafe { std::slice::from_raw_parts_mut(res, n) };
    p.rhs(t, ys, ress);
    let md = p.mass_diag().unwrap();
    for i in 0..n {
        // F = M * yp - f(t, y)
        ress[i] = md[i] * yps[i] - ress[i];
    }
}
unsafe extern "C" fn cb_ida_jac(
    ctx: *const c_void,
    t: f64,
    cj: f64,
    y: *const f64,
    _yp: *const f64,
    n: i32,
    ld: i32,
    pd: *mut f64,
) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let nu = n as usize;
    let ldu = ld as usize;
    let ys = unsafe { std::slice::from_raw_parts(y, nu) };
    let pds = unsafe { std::slice::from_raw_parts_mut(pd, ldu * nu) };
    pds.fill(0.0);
    // dF/dy + cj * dF/dyp = -df/dy + cj * M
    p.jac_entries(t, ys, |i, j, v| pds[j * ldu + i] = -v);
    let md = p.mass_diag().unwrap();
    for i in 0..nu {
        pds[i * ldu + i] += cj * md[i];
    }
}

// ---------------- Generic Runners ----------------
fn run_dvode(
    p: NativeProb,
    mf: i32,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    band: Option<(i32, i32)>,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let (mut completed, mut code) = (0i32, 0i32);
    let mut stats = [0i32; 8];
    let (ml, mu) = band.unwrap_or((-1, -1));
    let jac_opt = if mf == 21 || mf == 24 { Some(cb_jac as JacCb) } else { None };
    unsafe {
        fs_dvode(
            &p as *const NativeProb as *const c_void,
            cb_rhs,
            jac_opt,
            mf,
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            rtol,
            atol,
            ml,
            mu,
            100_000,
            vals.as_mut_ptr(),
            &mut completed,
            &mut code,
            stats.as_mut_ptr(),
        );
    }
    let ok = code == 2 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("ISTATE={code}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some(stats[1] as u64),
        njac: Some(stats[2] as u64),
        njvp: None,
        nlu: Some(stats[3] as u64),
        nsolve: None,
        accepted: Some(stats[0] as u64),
        rejected: Some(stats[6] as u64),
        extra: json!({"nni": stats[4], "ncfn": stats[5]}),
    }
}

fn run_cvode(
    p: NativeProb,
    mode: i32,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    band: Option<(i32, i32)>,
    analytic_jac: bool,
    max_steps: i64,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let mut completed = 0i32;
    let mut root_count = 0i32;
    let mut stats = [0i64; 9];
    let (ml, mu) = band.unwrap_or((-1, -1));
    let jac_opt = if analytic_jac && (mode == 0 || mode == 1) {
        Some(cb_jac as JacCb)
    } else {
        None
    };
    let jvp_opt = if mode == 2 { Some(cb_jvp as JvpCb) } else { None };
    let flag = unsafe {
        fs_cvode(
            &p as *const NativeProb as *const c_void,
            cb_rhs,
            jac_opt,
            jvp_opt,
            None,
            mode,
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            rtol,
            atol,
            ml,
            mu,
            max_steps,
            0,
            0,
            vals.as_mut_ptr(),
            &mut completed,
            std::ptr::null_mut(),
            &mut root_count,
            0,
            stats.as_mut_ptr(),
        )
    };
    let ok = flag == 0 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("CVODE flag={flag}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some((stats[1] + stats[7]) as u64),
        njac: Some(stats[6] as u64),
        njvp: None,
        nlu: Some(stats[2] as u64),
        nsolve: None,
        accepted: Some(stats[0] as u64),
        rejected: Some(stats[3] as u64),
        extra: json!({"nni": stats[4], "ncfn": stats[5], "nfeLS": stats[7]}),
    }
}

#[allow(clippy::too_many_arguments)]
fn run_hairer(
    which: i32,
    p: NativeProb,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    band: Option<(i32, i32)>,
    ifcn: i32,
    idfx: i32,
    imas: i32,
    n_ind1: i32,
    n_ind2: i32,
    n_ind3: i32,
    max_steps: i32,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let (mut completed, mut code) = (0i32, 0i32);
    let mut stats = [0i32; 7];
    let (ml, mu) = band.unwrap_or((-1, -1));
    unsafe {
        fs_hairer(
            which,
            &p as *const NativeProb as *const c_void,
            cb_rhs,
            Some(cb_jac),
            if idfx != 0 { Some(cb_dfx) } else { None },
            if imas != 0 { Some(cb_mas) } else { None },
            ifcn,
            idfx,
            imas,
            n_ind1,
            n_ind2,
            n_ind3,
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            rtol,
            atol,
            ml,
            mu,
            max_steps,
            vals.as_mut_ptr(),
            &mut completed,
            &mut code,
            stats.as_mut_ptr(),
        );
    }
    let ok = code > 0 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("IDID={code}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some(stats[0] as u64),
        njac: Some(stats[1] as u64),
        njvp: None,
        nlu: Some(stats[5] as u64),
        nsolve: Some(stats[6] as u64),
        accepted: Some(stats[3] as u64),
        rejected: Some(stats[4] as u64),
        extra: json!({"nstep": stats[2]}),
    }
}

fn run_ida(
    p: NativeProb,
    grid: &[f64],
    y0: &[f64],
    yp0: &[f64],
    id_vec: &[f64],
    rtol: f64,
    atol: f64,
    calc_ic: bool,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let mut completed = 0i32;
    let mut stats = [0i64; 9];
    let flag = unsafe {
        fs_ida(
            &p as *const NativeProb as *const c_void,
            cb_ida_res,
            Some(cb_ida_jac),
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            yp0.as_ptr(),
            id_vec.as_ptr(),
            rtol,
            atol,
            100_000,
            i32::from(calc_ic),
            vals.as_mut_ptr(),
            &mut completed,
            stats.as_mut_ptr(),
        )
    };
    let ok = flag == 0 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("IDA flag={flag}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some((stats[1] + stats[7]) as u64),
        njac: Some(stats[6] as u64),
        njvp: None,
        nlu: Some(stats[2] as u64),
        nsolve: None,
        accepted: Some(stats[0] as u64),
        rejected: Some(stats[3] as u64),
        extra: json!({"nni": stats[4], "ncfn": stats[5]}),
    }
}

fn make_vigilode_problem(p: NativeProb, jac_mode: &str, band: Option<(usize, usize)>, ft: bool) -> Problem {
    let n = p.n();
    let mut prob = Problem::new(n, move |t, y, dy| {
        p.rhs(t, y, dy);
        Ok(())
    });
    match jac_mode {
        "dense" => {
            prob = prob.jacobian(Jacobian::dense(move |t, y, j| {
                p.jac_dense_row_major(t, y, j);
                Ok(())
            }));
        }
        "banded" => {
            let (ml, mu) = band.unwrap();
            prob = prob
                .jacobian(Jacobian::banded(ml, mu, move |t, y, b| {
                    p.jac_band_row_major(t, y, ml, mu, b);
                    Ok(())
                }))
                .banded(ml, mu);
        }
        "jvp" => {
            prob = prob.jvp(move |t, y, v, out| {
                p.jvp(t, y, v, out);
                Ok(())
            });
        }
        "sparse_jvp" => {
            let mut rows_pat = vec![Vec::new(); n];
            let y_dummy = vec![1.0; n];
            p.jac_entries(0.0, &y_dummy, |i, j, _| rows_pat[i].push(j));
            for r in &mut rows_pat {
                r.sort_unstable();
                r.dedup();
            }
            let pat = SparsityPattern::from_rows(n, &rows_pat).unwrap();
            prob = prob.jacobian(Jacobian::sparse_jvp(pat, move |t, y, v, out| {
                p.jvp(t, y, v, out);
                Ok(())
            }));
        }
        "fd" => {
            prob = prob.jacobian(Jacobian::FiniteDifference);
        }
        _ => panic!("unknown jac_mode"),
    }
    if let Some((ml, mu)) = band {
        if jac_mode == "fd" {
            prob = prob.banded(ml, mu);
        }
    }
    if let Some(md) = p.mass_diag() {
        let mut m = vec![0.0; n * n];
        for i in 0..n {
            m[i * n + i] = md[i];
        }
        prob = prob.mass(m);
    }
    if ft {
        prob = prob.time_derivative(move |t, y, out| {
            p.dfx(t, y, out);
            Ok(())
        });
    } else if !matches!(p, NativeProb::Pr1e4 | NativeProb::DaeAna | NativeProb::Burst) {
        prob = prob.autonomous();
    }
    prob
}

fn run_vigilode_rodas5p(
    prob: &Problem,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    interior: InteriorError,
) -> ArmRun {
    let opts = Options {
        rtol,
        atol: Atol::Scalar(atol),
        max_steps: 100_000,
        dense_output: true,
        interior_error: interior,
        ..Default::default()
    };
    let span = (grid[0], *grid.last().unwrap());
    match Rodas5p::solve(prob, span, y0, &opts) {
        Ok(sol) => {
            let ok = sol.is_success();
            let states: Vec<Vec<f64>> = if ok {
                grid.iter().filter_map(|&t| sol.at(t)).collect()
            } else {
                vec![]
            };
            let ok = ok && states.len() == grid.len();
            let c = sol.stats.counters;
            ArmRun {
                ok,
                err_msg: if ok { String::new() } else { sol.stats.driver_message.clone() },
                states,
                nf: Some(c.rhs_evaluations),
                njac: Some(c.jacobian_builds),
                njvp: Some(c.jvp_vectors),
                nlu: Some(c.direct_factorizations),
                nsolve: Some(c.direct_solve_calls),
                accepted: Some(sol.stats.accepted_steps as u64),
                rejected: Some(sol.stats.rejected_steps as u64),
                extra: json!({"ft_calls": c.ft_calls, "output_clipped_steps": sol.stats.output_clipped_steps}),
            }
        }
        Err(e) => ArmRun {
            ok: false,
            err_msg: e.to_string(),
            ..Default::default()
        },
    }
}

fn run_vigilode_unified(
    prob: &Problem,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    strategy: SolverStrategy,
    dense_out: bool,
    max_krylov: usize,
) -> ArmRun {
    let opts = VigilodeOptions::default()
        .strategy(strategy)
        .rtol(rtol)
        .atol(atol)
        .max_steps(100_000)
        .dense_output(dense_out)
        .max_krylov_dim(max_krylov);
    let span = (grid[0], *grid.last().unwrap());
    match VigilODE::solve(prob, span, y0, opts) {
        Ok(sol) => {
            let ok = sol.success();
            let states = if ok && dense_out {
                let s: Vec<Vec<f64>> = grid.iter().filter_map(|&t| sol.at(t)).collect();
                if s.len() == grid.len() { s } else { vec![] }
            } else if ok {
                // Endpoint only
                vec![sol.final_state.clone()]
            } else {
                vec![]
            };
            let c = sol.stats().counters;
            let routes: Vec<String> = sol.route_history.iter().map(|r| r.to_tier.clone()).collect();
            ArmRun {
                ok: ok && (!dense_out || states.len() == grid.len()),
                err_msg: if ok { String::new() } else { format!("{:?}", sol.status) },
                states,
                nf: Some(c.rhs_evaluations),
                njac: Some(c.jacobian_builds),
                njvp: Some(c.jvp_vectors),
                nlu: Some(c.direct_factorizations),
                nsolve: Some(c.linear_solves + c.direct_solve_calls),
                accepted: Some(sol.stats().accepted_steps as u64),
                rejected: Some(sol.stats().rejected_steps as u64),
                extra: json!({
                    "routes": routes,
                    "fallback_steps": c.fallback_steps,
                    "linear_iterations": c.linear_iterations,
                    "invariant_drift": sol.invariant_drift,
                    "endpoint_only": !dense_out
                }),
            }
        }
        Err(e) => ArmRun {
            ok: false,
            err_msg: e.to_string(),
            ..Default::default()
        },
    }
}

fn run_vigilode_dopri5(prob: &Problem, grid: &[f64], y0: &[f64], rtol: f64, atol: f64, dense: bool) -> ArmRun {
    let opts = Options {
        rtol,
        atol: Atol::Scalar(atol),
        max_steps: 100_000,
        ..Default::default()
    };
    let span = (grid[0], *grid.last().unwrap());
    let res = if dense {
        Dopri5::solve_dense_observed(prob, span, y0, &opts, grid)
    } else {
        Dopri5::solve_observed(prob, span, y0, &opts, grid)
    };
    match res {
        Ok(sol) => {
            let ok = sol.success && sol.t == grid;
            let c = sol.stats.counters;
            ArmRun {
                ok,
                err_msg: if ok { String::new() } else { sol.message },
                states: if ok { sol.y } else { vec![] },
                nf: Some(c.rhs_evaluations),
                njac: Some(0),
                njvp: Some(0),
                nlu: Some(0),
                nsolve: Some(0),
                accepted: Some(sol.stats.accepted_steps as u64),
                rejected: Some(sol.stats.rejected_steps as u64),
                extra: json!({"fsal_reuses": sol.stats.fsal_reuses, "mode": sol.stats.observation_mode}),
            }
        }
        Err(e) => ArmRun {
            ok: false,
            err_msg: e.to_string(),
            ..Default::default()
        },
    }
}

fn run_diffsol(
    p: NativeProb,
    method: &str,
    sparse: bool,
    with_mass: bool,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
) -> ArmRun {
    let n = p.n();
    let t0 = grid[0];
    let y0v = y0.to_vec();
    let atols = vec![atol; n];

    macro_rules! build_and_solve {
        ($mat:ty, $lu:ty, $coloring:expr) => {{
            let mut b = OdeBuilder::<$mat>::new()
                .t0(t0)
                .rtol(rtol)
                .atol(atols.clone())
                .use_coloring($coloring)
                .rhs_implicit(
                    move |x, _p, t, out| p.rhs(t, x.as_slice(), out.as_mut_slice()),
                    move |x, _p, t, v, out| p.jvp(t, x.as_slice(), v.as_slice(), out.as_mut_slice()),
                )
                .init(move |_p, _t, out| out.as_mut_slice().copy_from_slice(&y0v), n);
            if with_mass {
                let md = p.mass_diag().unwrap();
                let builder = b.mass(move |v, _p, _t, beta, y| {
                    let ys = y.as_mut_slice();
                    let vs = v.as_slice();
                    for i in 0..n {
                        ys[i] = md[i] * vs[i] + beta * ys[i];
                    }
                });
                let problem = match builder.build() {
                    Ok(pr) => pr,
                    Err(e) => return ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
                };
                solve_diffsol_method!(problem, $lu)
            } else {
                let problem = match b.build() {
                    Ok(pr) => pr,
                    Err(e) => return ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
                };
                solve_diffsol_method!(problem, $lu)
            }
        }};
    }

    macro_rules! solve_diffsol_method {
        ($problem:expr, $lu:ty) => {{
            macro_rules! exec {
                ($s_res:expr) => {{
                    let mut solver = match $s_res {
                        Ok(s) => s,
                        Err(e) => return ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
                    };
                    let outcome = solver.solve_dense(grid);
                    let stats = solver.get_statistics().clone();
                    match outcome {
                        Ok((mat, _stop)) => {
                            let ok = mat.ncols() == grid.len();
                            let states: Vec<Vec<f64>> = (0..mat.ncols())
                                .map(|k| (0..n).map(|i| mat.get_index(i, k)).collect())
                                .collect();
                            ArmRun {
                                ok,
                                err_msg: if ok { String::new() } else { "incomplete grid".into() },
                                states,
                                nf: None,
                                njac: None,
                                njvp: None,
                                nlu: Some(stats.number_of_linear_solver_setups as u64),
                                nsolve: None,
                                accepted: Some(stats.number_of_steps as u64),
                                rejected: Some(stats.number_of_error_test_failures as u64),
                                extra: json!({"nni": stats.number_of_nonlinear_solver_iterations, "ncfn": stats.number_of_nonlinear_solver_fails}),
                            }
                        }
                        Err(e) => ArmRun {
                            ok: false,
                            err_msg: e.to_string(),
                            nlu: Some(stats.number_of_linear_solver_setups as u64),
                            accepted: Some(stats.number_of_steps as u64),
                            rejected: Some(stats.number_of_error_test_failures as u64),
                            ..Default::default()
                        },
                    }
                }};
            }
            match method {
                "bdf" => exec!($problem.bdf::<$lu>()),
                "tr_bdf2" => exec!($problem.tr_bdf2::<$lu>()),
                "esdirk34" => exec!($problem.esdirk34::<$lu>()),
                "tsit45" => {
                    if with_mass {
                        ArmRun { ok: false, err_msg: "explicit RK unsupported with mass".into(), ..Default::default() }
                    } else {
                        exec!($problem.tsit45())
                    }
                }
                _ => unreachable!(),
            }
        }};
    }

    if sparse {
        build_and_solve!(FaerSparseMat<f64>, FaerSparseLU<f64>, true)
    } else {
        build_and_solve!(FaerMat<f64>, FaerLU<f64>, false)
    }
}

// ---------------- Analytical Helpers ----------------
fn kepler_exact(t: f64, ecc: f64) -> Vec<f64> {
    let m = t.rem_euclid(2.0 * PI);
    let mut e = m;
    for _ in 0..30 {
        e -= (e - ecc * e.sin() - m) / (1.0 - ecc * e.cos());
    }
    let ce = e.cos();
    let se = e.sin();
    let fac = (1.0 - ecc * ecc).sqrt();
    let r = 1.0 - ecc * ce;
    vec![ce - ecc, fac * se, -se / r, fac * ce / r]
}

fn advdiff_exact(n: usize, t: f64) -> Vec<f64> {
    let d = 0.01 * (n as f64) * (n as f64);
    let v = 1.0 * (n as f64);
    let th = 2.0 * PI / (n as f64);
    // Eigenvalue of D*(e^{-i*th} - 2 + e^{i*th}) - v*(1 - e^{-i*th})
    let re = d * (2.0 * th.cos() - 2.0) - v * (1.0 - th.cos());
    let im = -v * th.sin();
    let amp = (re * t).exp();
    (0..n)
        .map(|j| {
            let phi = th * (j as f64) + im * t;
            1.0 + 0.1 * amp * phi.sin()
        })
        .collect()
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let out_path = args.get(1).map(String::as_str).unwrap_or("full_scope_rust.json");
    let ensemble_only = args.iter().any(|a| a == "--ensemble-only");

    let rtols = [1e-4, 1e-6, 1e-8];
    let mut rows: Vec<Value> = Vec::new();
    let mut references = serde_json::Map::new();

    if !ensemble_only {
    // =========================================================================
    // S1: Non-Stiff Conservative & High-Nonnormality ODEs + Parallel Ensemble
    // =========================================================================
    eprintln!(">>> S1: kepler-ecc05");
    let y0_kep = vec![0.5, 0.0, 0.0, 3.0_f64.sqrt()];
    let grid_kep = make_grid(0.0, 20.0 * PI, 101);
    let ref_kep: Vec<Vec<f64>> = grid_kep.iter().map(|&t| kepler_exact(t, 0.5)).collect();
    let atol_kep = vec![1.0; 4];
    let prob_kep_auto = make_vigilode_problem(NativeProb::Kepler, "fd", None, false);
    let prob_kep_jac = make_vigilode_problem(NativeProb::Kepler, "dense", None, false);
    let e0_kep = 0.5 * 3.0 - 1.0 / 0.5;
    let l0_kep = 0.5 * 3.0_f64.sqrt();

    let kep_drift = |y: &[f64]| -> Value {
        if y.len() != 4 {
            return Value::Null;
        }
        let ef = 0.5 * (y[2] * y[2] + y[3] * y[3]) - 1.0 / y[0].hypot(y[1]);
        let lf = y[0] * y[3] - y[1] * y[2];
        json!({"energy_drift": (ef - e0_kep).abs(), "ang_mom_drift": (lf - l0_kep).abs()})
    };

    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("kepler-ecc05", "vigilode-dopri5-obs", rtol, Some(&ref_kep), &atol_kep, || {
            let mut r = run_vigilode_dopri5(&prob_kep_auto, &grid_kep, &y0_kep, rtol, atol, false);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
                r.extra["ang_mom_drift"] = d["ang_mom_drift"].clone();
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "vigilode-dopri5-dense", rtol, Some(&ref_kep), &atol_kep, || {
            let mut r = run_vigilode_dopri5(&prob_kep_auto, &grid_kep, &y0_kep, rtol, atol, true);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
                r.extra["ang_mom_drift"] = d["ang_mom_drift"].clone();
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "vigilode-auto-endpoint", rtol, None, &atol_kep, || {
            let mut r = run_vigilode_unified(&prob_kep_auto, &grid_kep, &y0_kep, rtol, atol, SolverStrategy::Auto, false, 15);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
                r.extra["ang_mom_drift"] = d["ang_mom_drift"].clone();
                let w = max_wrms(&r.states, &[ref_kep.last().unwrap().clone()], &atol_kep);
                r.extra["endpoint_wrms"] = json!(w);
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "vigilode-rodas5p-dense", rtol, Some(&ref_kep), &atol_kep, || {
            let mut r = run_vigilode_rodas5p(&prob_kep_jac, &grid_kep, &y0_kep, rtol, atol, InteriorError::WFilteredEnforce);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
                r.extra["ang_mom_drift"] = d["ang_mom_drift"].clone();
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "diffsol-tsit45", rtol, Some(&ref_kep), &atol_kep, || {
            let mut r = run_diffsol(NativeProb::Kepler, "tsit45", false, false, &grid_kep, &y0_kep, rtol, atol);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
                r.extra["ang_mom_drift"] = d["ang_mom_drift"].clone();
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "diffsol-bdf-dense", rtol, Some(&ref_kep), &atol_kep, || {
            run_diffsol(NativeProb::Kepler, "bdf", false, false, &grid_kep, &y0_kep, rtol, atol)
        }));
        rows.push(timed_run("kepler-ecc05", "dvode-mf10-adams", rtol, Some(&ref_kep), &atol_kep, || {
            let mut r = run_dvode(NativeProb::Kepler, 10, &grid_kep, &y0_kep, rtol, atol, None);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "cvode-adams", rtol, Some(&ref_kep), &atol_kep, || {
            let mut r = run_cvode(NativeProb::Kepler, 3, &grid_kep, &y0_kep, rtol, atol, None, false, 100_000);
            if r.ok {
                let d = kep_drift(r.states.last().unwrap());
                r.extra["energy_drift"] = d["energy_drift"].clone();
            }
            r
        }));
        rows.push(timed_run("kepler-ecc05", "cvode-bdf-dense", rtol, Some(&ref_kep), &atol_kep, || {
            run_cvode(NativeProb::Kepler, 0, &grid_kep, &y0_kep, rtol, atol, None, true, 100_000)
        }));
        rows.push(timed_run("kepler-ecc05", "radau5", rtol, Some(&ref_kep), &atol_kep, || {
            run_hairer(0, NativeProb::Kepler, &grid_kep, &y0_kep, rtol, atol, None, 0, 0, 0, 0, 0, 0, 100_000)
        }));
    }

    eprintln!(">>> S1: nonnormal-kreiss-b100");
    let y0_kr = vec![0.0, 1.0];
    let grid_kr = make_grid(0.0, 5.0, 101);
    let ref_kr: Vec<Vec<f64>> = grid_kr
        .iter()
        .map(|&t| vec![100.0 * ((-t).exp() - (-2.0 * t).exp()), (-2.0 * t).exp()])
        .collect();
    let atol_kr = vec![1.0; 2];
    let prob_kr_fd = make_vigilode_problem(NativeProb::Kreiss, "fd", None, false);
    let prob_kr_jac = make_vigilode_problem(NativeProb::Kreiss, "dense", None, false);
    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("nonnormal-kreiss-b100", "vigilode-auto-endpoint", rtol, None, &atol_kr, || {
            let mut r = run_vigilode_unified(&prob_kr_jac, &grid_kr, &y0_kr, rtol, atol, SolverStrategy::Auto, false, 15);
            if r.ok {
                r.extra["endpoint_wrms"] = json!(max_wrms(&r.states, &[ref_kr.last().unwrap().clone()], &atol_kr));
            }
            r
        }));
        rows.push(timed_run("nonnormal-kreiss-b100", "vigilode-dopri5-dense", rtol, Some(&ref_kr), &atol_kr, || {
            run_vigilode_dopri5(&prob_kr_fd, &grid_kr, &y0_kr, rtol, atol, true)
        }));
        rows.push(timed_run("nonnormal-kreiss-b100", "vigilode-rodas5p-dense", rtol, Some(&ref_kr), &atol_kr, || {
            run_vigilode_rodas5p(&prob_kr_jac, &grid_kr, &y0_kr, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("nonnormal-kreiss-b100", "diffsol-tsit45", rtol, Some(&ref_kr), &atol_kr, || {
            run_diffsol(NativeProb::Kreiss, "tsit45", false, false, &grid_kr, &y0_kr, rtol, atol)
        }));
        rows.push(timed_run("nonnormal-kreiss-b100", "dvode-mf10-adams", rtol, Some(&ref_kr), &atol_kr, || {
            run_dvode(NativeProb::Kreiss, 10, &grid_kr, &y0_kr, rtol, atol, None)
        }));
        rows.push(timed_run("nonnormal-kreiss-b100", "cvode-adams", rtol, Some(&ref_kr), &atol_kr, || {
            run_cvode(NativeProb::Kreiss, 3, &grid_kr, &y0_kr, rtol, atol, None, false, 100_000)
        }));
    }
    } // end if !ensemble_only

    eprintln!(">>> S1: dopri5-ensemble-n1024x16");
    let n_ens = 1024usize;
    let m_ens = 16usize;
    let u0_ens: Vec<f64> = (0..n_ens).map(|i| 0.5 + 0.5 * (i % 17) as f64 / 16.0).collect();
    let rates_ens: Vec<Vec<f64>> = (0..m_ens)
        .map(|mem| {
            (0..n_ens)
                .map(|i| 0.5 + 0.35 * (i % 13) as f64 / 12.0 + mem as f64 * 0.01)
                .collect()
        })
        .collect();
    let probs_ens: Vec<Problem> = (0..m_ens)
        .map(|mem| {
            let r = rates_ens[mem].clone();
            Problem::new(n_ens, move |_t, y, out| {
                for i in 0..n_ens {
                    out[i] = -r[i] * y[i];
                }
                Ok(())
            })
            .autonomous()
        })
        .collect();
    let opts_ens = Options {
        rtol: 1e-6,
        atol: Atol::Scalar(1e-9),
        h0: 1e-3,
        ..Default::default()
    };
    let pool1 = Dopri5Ensemble::new(1).unwrap();
    let pool8 = Dopri5Ensemble::new(8).unwrap();
    for (aid, pool_ref) in [("vigilode-ensemble-1t", &pool1), ("vigilode-ensemble-8t", &pool8)] {
        rows.push(timed_run("dopri5-ensemble-n1024x16", aid, 1e-6, None, &[1.0], || {
            let jobs: Vec<Dopri5EnsembleJob<'_>> = (0..m_ens)
                .map(|mem| Dopri5EnsembleJob {
                    problem: &probs_ens[mem],
                    t_span: (0.0, 4.0),
                    y0: &u0_ens,
                    options: &opts_ens,
                })
                .collect();
            match pool_ref.solve(&jobs) {
                Ok(res) => {
                    let mut worst = 0.0_f64;
                    let mut total_nf = 0u64;
                    let mut ok = true;
                    for (mem, item) in res.into_iter().enumerate() {
                        match item {
                            Ok(sol) if sol.success => {
                                total_nf += sol.stats.counters.rhs_evaluations;
                                for i in 0..n_ens {
                                    let ex = u0_ens[i] * (-rates_ens[mem][i] * 4.0).exp();
                                    worst = worst.max((sol.final_state[i] - ex).abs());
                                }
                            }
                            _ => { ok = false; }
                        }
                    }
                    ArmRun {
                        ok,
                        nf: Some(total_nf),
                        extra: json!({"max_abs_err": worst, "workers": pool_ref.workers()}),
                        ..Default::default()
                    }
                }
                Err(e) => ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
            }
        }));
    }
    rows.push(timed_run("dopri5-ensemble-n1024x16", "diffsol-tsit45-seq16", 1e-6, None, &[1.0], || {
        let mut worst = 0.0_f64;
        let mut ok = true;
        for mem in 0..m_ens {
            let r = rates_ens[mem].clone();
            let u0c = u0_ens.clone();
            let prob = OdeBuilder::<FaerMat<f64>>::new()
                .t0(0.0)
                .rtol(1e-6)
                .atol(vec![1e-9; n_ens])
                .rhs_implicit(
                    move |x, _p, _t, out| {
                        let xs = x.as_slice();
                        let os = out.as_mut_slice();
                        for i in 0..n_ens { os[i] = -r[i] * xs[i]; }
                    },
                    |_x, _p, _t, _v, _out| {},
                )
                .init(move |_p, _t, out| out.as_mut_slice().copy_from_slice(&u0c), n_ens)
                .build()
                .unwrap();
            let mut s = prob.tsit45().unwrap();
            match s.solve_dense(&[0.0, 4.0]) {
                Ok((mat, _)) => {
                    for i in 0..n_ens {
                        let ex = u0_ens[i] * (-rates_ens[mem][i] * 4.0).exp();
                        worst = worst.max((mat.get_index(i, 1) - ex).abs());
                    }
                }
                Err(_) => { ok = false; }
            }
        }
        ArmRun { ok, extra: json!({"max_abs_err": worst}), ..Default::default() }
    }));

    if ensemble_only {
        let doc = json!({
            "schema": "vigilode-full-scope-rust-ensemble-v1",
            "timing_authority": "diagnostic_only",
            "rows": rows,
        });
        std::fs::write(out_path, serde_json::to_string_pretty(&doc).unwrap() + "\n").unwrap();
        eprintln!("Wrote {} ensemble rows to {}", doc["rows"].as_array().unwrap().len(), out_path);
        return;
    }

    // =========================================================================
    // S2 Supplement: Prothero-Robinson (Stiff Forced Order Reduction Trap)
    // =========================================================================
    eprintln!(">>> S2: prothero-robinson-1e4");
    let grid_pr = make_grid(0.0, 10.0, 101);
    let ref_pr: Vec<Vec<f64>> = grid_pr.iter().map(|&t| vec![t.sin()]).collect();
    let y0_pr = vec![0.0];
    let atol_pr = vec![1.0];
    let prob_pr_ft = make_vigilode_problem(NativeProb::Pr1e4, "dense", None, true);
    let prob_pr_fd = make_vigilode_problem(NativeProb::Pr1e4, "dense", None, false);
    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("prothero-robinson-1e4", "vigilode-rodas5p-ft", rtol, Some(&ref_pr), &atol_pr, || {
            run_vigilode_rodas5p(&prob_pr_ft, &grid_pr, &y0_pr, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "vigilode-rodas5p-enforce-ft", rtol, Some(&ref_pr), &atol_pr, || {
            run_vigilode_rodas5p(&prob_pr_ft, &grid_pr, &y0_pr, rtol, atol, InteriorError::Enforce)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "vigilode-rodas5p-fd-ft", rtol, Some(&ref_pr), &atol_pr, || {
            run_vigilode_rodas5p(&prob_pr_fd, &grid_pr, &y0_pr, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "diffsol-bdf-dense", rtol, Some(&ref_pr), &atol_pr, || {
            run_diffsol(NativeProb::Pr1e4, "bdf", false, false, &grid_pr, &y0_pr, rtol, atol)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "diffsol-trbdf2", rtol, Some(&ref_pr), &atol_pr, || {
            run_diffsol(NativeProb::Pr1e4, "tr_bdf2", false, false, &grid_pr, &y0_pr, rtol, atol)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "diffsol-esdirk34", rtol, Some(&ref_pr), &atol_pr, || {
            run_diffsol(NativeProb::Pr1e4, "esdirk34", false, false, &grid_pr, &y0_pr, rtol, atol)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "dvode-mf21", rtol, Some(&ref_pr), &atol_pr, || {
            run_dvode(NativeProb::Pr1e4, 21, &grid_pr, &y0_pr, rtol, atol, None)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "cvode-bdf-dense", rtol, Some(&ref_pr), &atol_pr, || {
            run_cvode(NativeProb::Pr1e4, 0, &grid_pr, &y0_pr, rtol, atol, None, true, 100_000)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "radau5", rtol, Some(&ref_pr), &atol_pr, || {
            run_hairer(0, NativeProb::Pr1e4, &grid_pr, &y0_pr, rtol, atol, None, 0, 0, 0, 0, 0, 0, 100_000)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "rodas-idfx1", rtol, Some(&ref_pr), &atol_pr, || {
            run_hairer(1, NativeProb::Pr1e4, &grid_pr, &y0_pr, rtol, atol, None, 1, 1, 0, 0, 0, 0, 100_000)
        }));
        rows.push(timed_run("prothero-robinson-1e4", "rodas-idfx0", rtol, Some(&ref_pr), &atol_pr, || {
            run_hairer(1, NativeProb::Pr1e4, &grid_pr, &y0_pr, rtol, atol, None, 1, 0, 0, 0, 0, 0, 100_000)
        }));
    }

    // =========================================================================
    // S4: Large Matrix-Free Krylov & Exponential Integrators (N=256, N=400)
    // =========================================================================
    eprintln!(">>> S4: periodic-advdiff-n256");
    let n_ad = 256usize;
    let grid_ad = make_grid(0.0, 1.0, 101);
    let y0_ad: Vec<f64> = (0..n_ad)
        .map(|i| 1.0 + 0.1 * (2.0 * PI * i as f64 / n_ad as f64).sin())
        .collect();
    let ref_ad: Vec<Vec<f64>> = grid_ad.iter().map(|&t| advdiff_exact(n_ad, t)).collect();
    references.insert("periodic-advdiff-n256".into(), json!(ref_ad));
    let atol_ad = vec![1.0; n_ad];

    let prob_ad_jvp = make_vigilode_problem(NativeProb::AdvDiff256, "jvp", None, false);
    let prob_ad_dense = make_vigilode_problem(NativeProb::AdvDiff256, "dense", None, false);
    let prob_ad_spjvp = make_vigilode_problem(NativeProb::AdvDiff256, "sparse_jvp", None, false);

    // Build OdeProblem for PEXPRB54S4
    let ode_ad = OdeProblem::new(
        "periodic-advdiff-n256",
        n_ad,
        Arc::new(move |t, y, out| {
            NativeProb::AdvDiff256.rhs(t, y, out);
            Ok(())
        }),
        None,
        None,
        Some(Arc::new(move |t, y, v, out| {
            NativeProb::AdvDiff256.jvp(t, y, v, out);
            Ok(())
        })),
        None,
        true,
        None,
        None,
    )
    .unwrap();
    let sched_ad = OutputSchedule::new(grid_ad.clone()).unwrap();
    let exec_1t = ParallelExecution::rayon(1).unwrap();

    for &rtol in &rtols {
        let atol = rtol;
        rows.push(timed_run("periodic-advdiff-n256", "vigilode-auto-jvp", rtol, None, &atol_ad, || {
            let mut r = run_vigilode_unified(&prob_ad_jvp, &grid_ad, &y0_ad, rtol, atol, SolverStrategy::HighPerformance, false, 30);
            if r.ok {
                r.extra["endpoint_wrms"] = json!(max_wrms(&r.states, &[ref_ad.last().unwrap().clone()], &atol_ad));
            }
            r
        }));
        rows.push(timed_run("periodic-advdiff-n256", "vigilode-sparse-jvp", rtol, None, &atol_ad, || {
            let mut r = run_vigilode_unified(&prob_ad_spjvp, &grid_ad, &y0_ad, rtol, atol, SolverStrategy::Auto, false, 30);
            if r.ok {
                r.extra["endpoint_wrms"] = json!(max_wrms(&r.states, &[ref_ad.last().unwrap().clone()], &atol_ad));
            }
            r
        }));
        rows.push(timed_run("periodic-advdiff-n256", "vigilode-rodas5p-dense", rtol, Some(&ref_ad), &atol_ad, || {
            run_vigilode_rodas5p(&prob_ad_dense, &grid_ad, &y0_ad, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("periodic-advdiff-n256", "vigilode-pexprb54s4", rtol, Some(&ref_ad), &atol_ad, || {
            let adap = AdaptiveStepConfig { rtol, atol, max_attempts: 100_000, ..Default::default() };
            match integrate_pexprb54s4_fused_adaptive_observed(&ode_ad, (0.0, 1.0), &y0_ad, &adap, &sched_ad, FusedPhiKrylovConfig::default(), &exec_1t) {
                Ok(res) => {
                    let ok = res.observed.success && res.observed.t == grid_ad;
                    let c = res.observed.counters;
                    ArmRun {
                        ok,
                        err_msg: if ok { String::new() } else { res.observed.message },
                        states: if ok { res.observed.y } else { vec![] },
                        nf: Some(c.rhs_evaluations),
                        njvp: Some(c.jvp_vectors),
                        accepted: Some(res.diagnostics.accepted_steps as u64),
                        rejected: Some(res.diagnostics.rejected_steps as u64),
                        extra: json!({"phi_actions": c.phi_actions, "phi_krylov_vectors": c.phi_krylov_vectors}),
                        ..Default::default()
                    }
                }
                Err(e) => ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
            }
        }));
        rows.push(timed_run("periodic-advdiff-n256", "diffsol-bdf-sparse", rtol, Some(&ref_ad), &atol_ad, || {
            run_diffsol(NativeProb::AdvDiff256, "bdf", true, false, &grid_ad, &y0_ad, rtol, atol)
        }));
        rows.push(timed_run("periodic-advdiff-n256", "diffsol-bdf-dense", rtol, Some(&ref_ad), &atol_ad, || {
            run_diffsol(NativeProb::AdvDiff256, "bdf", false, false, &grid_ad, &y0_ad, rtol, atol)
        }));
        rows.push(timed_run("periodic-advdiff-n256", "cvode-bdf-spgmr", rtol, Some(&ref_ad), &atol_ad, || {
            run_cvode(NativeProb::AdvDiff256, 2, &grid_ad, &y0_ad, rtol, atol, None, false, 100_000)
        }));
        rows.push(timed_run("periodic-advdiff-n256", "cvode-bdf-dense", rtol, Some(&ref_ad), &atol_ad, || {
            run_cvode(NativeProb::AdvDiff256, 0, &grid_ad, &y0_ad, rtol, atol, None, true, 100_000)
        }));
        rows.push(timed_run("periodic-advdiff-n256", "dvode-mf21", rtol, Some(&ref_ad), &atol_ad, || {
            run_dvode(NativeProb::AdvDiff256, 21, &grid_ad, &y0_ad, rtol, atol, None)
        }));
        rows.push(timed_run("periodic-advdiff-n256", "radau5", rtol, Some(&ref_ad), &atol_ad, || {
            run_hairer(0, NativeProb::AdvDiff256, &grid_ad, &y0_ad, rtol, atol, None, 0, 0, 0, 0, 0, 0, 100_000)
        }));
    }

    eprintln!(">>> S4: brusselator-1d-jvp-n400");
    let n_br = 400usize;
    let nc_br = 200usize;
    let dx_br = 1.0 / (nc_br as f64 + 1.0);
    let mut y0_br = vec![0.0; n_br];
    for i in 0..nc_br {
        y0_br[2 * i] = 1.0 + (2.0 * PI * (i + 1) as f64 * dx_br).sin();
        y0_br[2 * i + 1] = 3.0;
    }
    let grid_br = make_grid(0.0, 10.0, 101);
    let ref_br_run = run_hairer(0, NativeProb::Bruss400, &grid_br, &y0_br, 1e-11, 1e-13, Some((2, 2)), 0, 0, 0, 0, 0, 0, 500_000);
    assert!(ref_br_run.ok, "bruss400 reference failed");
    let ref_br = ref_br_run.states.clone();
    references.insert("brusselator-1d-jvp-n400".into(), json!(ref_br));
    let atol_br = vec![1.0; n_br];

    let prob_br_jvp = make_vigilode_problem(NativeProb::Bruss400, "jvp", None, false);
    let prob_br_spjvp = make_vigilode_problem(NativeProb::Bruss400, "sparse_jvp", None, false);
    let prob_br_band = make_vigilode_problem(NativeProb::Bruss400, "banded", Some((2, 2)), false);

    for &rtol in &rtols {
        let atol = rtol;
        rows.push(timed_run("brusselator-1d-jvp-n400", "vigilode-auto-jvp", rtol, None, &atol_br, || {
            let mut r = run_vigilode_unified(&prob_br_jvp, &grid_br, &y0_br, rtol, atol, SolverStrategy::HighPerformance, false, 30);
            if r.ok {
                r.extra["endpoint_wrms"] = json!(max_wrms(&r.states, &[ref_br.last().unwrap().clone()], &atol_br));
            }
            r
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "vigilode-sparse-jvp", rtol, None, &atol_br, || {
            let mut r = run_vigilode_unified(&prob_br_spjvp, &grid_br, &y0_br, rtol, atol, SolverStrategy::Auto, false, 30);
            if r.ok {
                r.extra["endpoint_wrms"] = json!(max_wrms(&r.states, &[ref_br.last().unwrap().clone()], &atol_br));
            }
            r
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "vigilode-banded-dense", rtol, Some(&ref_br), &atol_br, || {
            run_vigilode_rodas5p(&prob_br_band, &grid_br, &y0_br, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "diffsol-bdf-sparse", rtol, Some(&ref_br), &atol_br, || {
            run_diffsol(NativeProb::Bruss400, "bdf", true, false, &grid_br, &y0_br, rtol, atol)
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "cvode-bdf-spgmr", rtol, Some(&ref_br), &atol_br, || {
            run_cvode(NativeProb::Bruss400, 2, &grid_br, &y0_br, rtol, atol, None, false, 100_000)
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "cvode-bdf-band", rtol, Some(&ref_br), &atol_br, || {
            run_cvode(NativeProb::Bruss400, 1, &grid_br, &y0_br, rtol, atol, Some((2, 2)), true, 100_000)
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "dvode-mf24", rtol, Some(&ref_br), &atol_br, || {
            run_dvode(NativeProb::Bruss400, 24, &grid_br, &y0_br, rtol, atol, Some((2, 2)))
        }));
        rows.push(timed_run("brusselator-1d-jvp-n400", "radau5-band", rtol, Some(&ref_br), &atol_br, || {
            run_hairer(0, NativeProb::Bruss400, &grid_br, &y0_br, rtol, atol, Some((2, 2)), 0, 0, 0, 0, 0, 0, 100_000)
        }));
    }

    // =========================================================================
    // S5: Singular & Ill-Conditioned Mass Matrices / Index-1 DAEs
    // =========================================================================
    eprintln!(">>> S5: dae-robertson-index1");
    let grid_rob = make_grid(0.0, 40.0, 101);
    let y0_rob = vec![1.0, 0.0, 0.0];
    let yp0_rob = vec![-0.04, 0.04, 0.0];
    let id_rob = vec![1.0, 1.0, 0.0];
    let ref_rob_run = run_hairer(0, NativeProb::DaeRob, &grid_rob, &y0_rob, 1e-12, 1e-15, None, 0, 0, 1, 0, 0, 0, 500_000);
    assert!(ref_rob_run.ok, "dae-rob ref failed");
    let ref_rob = ref_rob_run.states.clone();
    references.insert("dae-robertson-index1".into(), json!(ref_rob));
    let atol_rob = vec![1e-4; 3];
    let prob_rob_mass = make_vigilode_problem(NativeProb::DaeRob, "dense", None, false);

    let rob_alg_res = |states: &[Vec<f64>]| -> f64 {
        states.iter().map(|y| (y[0] + y[1] + y[2] - 1.0).abs()).fold(0.0_f64, f64::max)
    };

    for &rtol in &rtols {
        let atol = rtol * 1e-4;
        rows.push(timed_run("dae-robertson-index1", "vigilode-rodas5p-mass", rtol, Some(&ref_rob), &atol_rob, || {
            let mut r = run_vigilode_rodas5p(&prob_rob_mass, &grid_rob, &y0_rob, rtol, atol, InteriorError::WFilteredEnforce);
            if r.ok { r.extra["max_constraint_residual"] = json!(rob_alg_res(&r.states)); }
            r
        }));
        rows.push(timed_run("dae-robertson-index1", "diffsol-bdf-mass", rtol, Some(&ref_rob), &atol_rob, || {
            let mut r = run_diffsol(NativeProb::DaeRob, "bdf", false, true, &grid_rob, &y0_rob, rtol, atol);
            if r.ok { r.extra["max_constraint_residual"] = json!(rob_alg_res(&r.states)); }
            r
        }));
        rows.push(timed_run("dae-robertson-index1", "diffsol-esdirk34-mass", rtol, Some(&ref_rob), &atol_rob, || {
            let mut r = run_diffsol(NativeProb::DaeRob, "esdirk34", false, true, &grid_rob, &y0_rob, rtol, atol);
            if r.ok { r.extra["max_constraint_residual"] = json!(rob_alg_res(&r.states)); }
            r
        }));
        rows.push(timed_run("dae-robertson-index1", "sundials-ida", rtol, Some(&ref_rob), &atol_rob, || {
            let mut r = run_ida(NativeProb::DaeRob, &grid_rob, &y0_rob, &yp0_rob, &id_rob, rtol, atol, false);
            if r.ok { r.extra["max_constraint_residual"] = json!(rob_alg_res(&r.states)); }
            r
        }));
        rows.push(timed_run("dae-robertson-index1", "radau5-mass", rtol, Some(&ref_rob), &atol_rob, || {
            let mut r = run_hairer(0, NativeProb::DaeRob, &grid_rob, &y0_rob, rtol, atol, None, 0, 0, 1, 0, 0, 0, 100_000);
            if r.ok { r.extra["max_constraint_residual"] = json!(rob_alg_res(&r.states)); }
            r
        }));
        rows.push(timed_run("dae-robertson-index1", "rodas-mass", rtol, Some(&ref_rob), &atol_rob, || {
            let mut r = run_hairer(1, NativeProb::DaeRob, &grid_rob, &y0_rob, rtol, atol, None, 0, 0, 1, 0, 0, 0, 100_000);
            if r.ok { r.extra["max_constraint_residual"] = json!(rob_alg_res(&r.states)); }
            r
        }));
    }

    eprintln!(">>> S5: dae-index1-analytic & mass-ill-conditioned");
    let grid_ana = make_grid(0.0, 5.0, 101);
    let y0_ana = vec![0.0, 1.0];
    let yp0_ana = vec![1.0, 1.0];
    let id_ana = vec![1.0, 0.0];
    let ref_ana: Vec<Vec<f64>> = grid_ana.iter().map(|&t| vec![t.sin(), t.sin() + t.cos()]).collect();
    let atol_ana = vec![1.0; 2];
    let prob_ana_mass = make_vigilode_problem(NativeProb::DaeAna, "dense", None, false);
    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("dae-index1-analytic", "vigilode-rodas5p-mass", rtol, Some(&ref_ana), &atol_ana, || {
            run_vigilode_rodas5p(&prob_ana_mass, &grid_ana, &y0_ana, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("dae-index1-analytic", "diffsol-bdf-mass", rtol, Some(&ref_ana), &atol_ana, || {
            run_diffsol(NativeProb::DaeAna, "bdf", false, true, &grid_ana, &y0_ana, rtol, atol)
        }));
        rows.push(timed_run("dae-index1-analytic", "sundials-ida", rtol, Some(&ref_ana), &atol_ana, || {
            run_ida(NativeProb::DaeAna, &grid_ana, &y0_ana, &yp0_ana, &id_ana, rtol, atol, false)
        }));
        rows.push(timed_run("dae-index1-analytic", "radau5-mass", rtol, Some(&ref_ana), &atol_ana, || {
            run_hairer(0, NativeProb::DaeAna, &grid_ana, &y0_ana, rtol, atol, None, 0, 0, 1, 0, 0, 0, 100_000)
        }));
        rows.push(timed_run("dae-index1-analytic", "rodas-mass", rtol, Some(&ref_ana), &atol_ana, || {
            run_hairer(1, NativeProb::DaeAna, &grid_ana, &y0_ana, rtol, atol, None, 1, 0, 1, 0, 0, 0, 100_000)
        }));
    }

    let grid_ill = make_grid(0.0, 1.0, 101);
    let y0_ill = vec![1.0, 2.0];
    let yp0_ill = vec![-1.0, -2.0];
    let id_ill = vec![1.0, 1.0];
    let ref_ill: Vec<Vec<f64>> = grid_ill.iter().map(|&t| vec![(-t).exp(), 2.0 * (-t).exp()]).collect();
    let atol_ill = vec![1.0; 2];
    let prob_ill_mass = make_vigilode_problem(NativeProb::MassIll, "dense", None, false);
    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("mass-ill-conditioned", "vigilode-rodas5p-mass", rtol, Some(&ref_ill), &atol_ill, || {
            run_vigilode_rodas5p(&prob_ill_mass, &grid_ill, &y0_ill, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("mass-ill-conditioned", "diffsol-bdf-mass", rtol, Some(&ref_ill), &atol_ill, || {
            run_diffsol(NativeProb::MassIll, "bdf", false, true, &grid_ill, &y0_ill, rtol, atol)
        }));
        rows.push(timed_run("mass-ill-conditioned", "sundials-ida", rtol, Some(&ref_ill), &atol_ill, || {
            run_ida(NativeProb::MassIll, &grid_ill, &y0_ill, &yp0_ill, &id_ill, rtol, atol, false)
        }));
        rows.push(timed_run("mass-ill-conditioned", "radau5-mass", rtol, Some(&ref_ill), &atol_ill, || {
            run_hairer(0, NativeProb::MassIll, &grid_ill, &y0_ill, rtol, atol, None, 0, 0, 1, 0, 0, 0, 100_000)
        }));
    }

    // Adversarial DAE boundary checks: inconsistent IC & index-3 pendulum
    eprintln!(">>> S5: adversarial DAE boundaries");
    let y0_inc = vec![0.0, 0.0];
    let grid_inc = make_grid(0.0, 1.0, 11);
    let r_vig_inc = run_vigilode_rodas5p(&prob_ana_mass, &grid_inc, &y0_inc, 1e-6, 1e-8, InteriorError::WFilteredEnforce);
    let r_dif_inc = run_diffsol(NativeProb::DaeAna, "bdf", false, true, &grid_inc, &y0_inc, 1e-6, 1e-8);
    let r_ida_noic = run_ida(NativeProb::DaeAna, &grid_inc, &y0_inc, &[0.0, 0.0], &[1.0, 0.0], 1e-6, 1e-8, false);
    let r_ida_calcic = run_ida(NativeProb::DaeAna, &grid_inc, &y0_inc, &[0.0, 0.0], &[1.0, 0.0], 1e-6, 1e-8, true);
    let r_rad_inc = run_hairer(0, NativeProb::DaeAna, &grid_inc, &y0_inc, 1e-6, 1e-8, None, 0, 0, 1, 0, 0, 0, 100_000);
    for (aid, r) in [
        ("vigilode-rodas5p-mass", r_vig_inc),
        ("diffsol-bdf-mass", r_dif_inc),
        ("sundials-ida-noic", r_ida_noic),
        ("sundials-ida-calcic", r_ida_calcic),
        ("radau5-mass", r_rad_inc),
    ] {
        let alg_err = if r.ok {
            let y = r.states.last().unwrap();
            Some((y[0] + y[1] - (2.0 * 1.0_f64.sin() + 1.0_f64.cos())).abs())
        } else { None };
        rows.push(json!({"problem":"dae-index1-inconsistent","arm":aid,"rtol":1e-6,"ok":r.ok,"err_msg":r.err_msg,"extra":{"final_constraint_err": alg_err, "y_end": r.states.last()}}));
    }

    let prob_pend_mass = make_vigilode_problem(NativeProb::DaePend, "dense", None, false);
    let y0_pend = vec![1.0, 0.0, 0.0, 0.0, 0.0];
    let r_vig_pend = run_vigilode_rodas5p(&prob_pend_mass, &grid_inc, &y0_pend, 1e-6, 1e-8, InteriorError::WFilteredEnforce);
    let r_dif_pend = run_diffsol(NativeProb::DaePend, "bdf", false, true, &grid_inc, &y0_pend, 1e-6, 1e-8);
    let r_ida_pend = run_ida(NativeProb::DaePend, &grid_inc, &y0_pend, &[0.0, 0.0, 0.0, -1.0, 0.0], &[1.0, 1.0, 1.0, 1.0, 0.0], 1e-6, 1e-8, false);
    let r_rad_pend_i1 = run_hairer(0, NativeProb::DaePend, &grid_inc, &y0_pend, 1e-6, 1e-8, None, 0, 0, 1, 2, 2, 1, 100_000);
    for (aid, r) in [
        ("vigilode-rodas5p-mass", r_vig_pend),
        ("diffsol-bdf-mass", r_dif_pend),
        ("sundials-ida", r_ida_pend),
        ("radau5-index2-hint", r_rad_pend_i1),
    ] {
        rows.push(json!({"problem":"dae-pendulum-index3","arm":aid,"rtol":1e-6,"ok":r.ok,"err_msg":r.err_msg,"extra":{"y_end": r.states.last()}}));
    }

    // =========================================================================
    // S6: Regime-Switching, Fallback, Event Root-Finding, Refusals & VG-1
    // =========================================================================
    eprintln!(">>> S6: stiff-burst-switching & robertson-rhs-only-fallback");
    let grid_burst = make_grid(0.0, 6.0, 101);
    let y0_burst = vec![1.0, 0.0];
    let ref_burst_run = run_hairer(0, NativeProb::Burst, &grid_burst, &y0_burst, 1e-12, 1e-14, None, 0, 0, 0, 0, 0, 0, 500_000);
    assert!(ref_burst_run.ok, "burst ref failed");
    let ref_burst = ref_burst_run.states.clone();
    references.insert("stiff-burst-switching".into(), json!(ref_burst));
    let atol_burst = vec![1.0; 2];
    let prob_burst_jac = make_vigilode_problem(NativeProb::Burst, "dense", None, false);

    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("stiff-burst-switching", "vigilode-switcher-ev", rtol, None, &atol_burst, || {
            let mut cfg = SwitchingConfig::adaptive_evidence(DerivativeFallback::ProvidedOnly);
            cfg.carry_explicit_step = true;
            let opts = Options { rtol, atol: Atol::Scalar(atol), max_steps: 100_000, ..Default::default() };
            match SwitchingSolver::solve(&prob_burst_jac, (0.0, 6.0), &y0_burst, &opts, &cfg) {
                Ok(sol) => {
                    let ok = sol.success;
                    let w = if ok { max_wrms(&[sol.final_state.clone()], &[ref_burst.last().unwrap().clone()], &atol_burst) } else { None };
                    ArmRun {
                        ok,
                        err_msg: if ok { String::new() } else { sol.message },
                        states: vec![sol.final_state],
                        nf: Some(sol.stats.rhs_calls),
                        njac: Some(sol.stats.jacobian_builds),
                        nlu: Some(sol.stats.linear_solves),
                        accepted: Some(sol.stats.accepted_steps as u64),
                        rejected: Some(sol.stats.rejected_steps as u64),
                        extra: json!({"switches": sol.stats.switches, "endpoint_wrms": w}),
                        ..Default::default()
                    }
                }
                Err(e) => ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
            }
        }));
        rows.push(timed_run("stiff-burst-switching", "vigilode-dopri5", rtol, Some(&ref_burst), &atol_burst, || {
            run_vigilode_dopri5(&prob_burst_jac, &grid_burst, &y0_burst, rtol, atol, true)
        }));
        rows.push(timed_run("stiff-burst-switching", "vigilode-rodas5p", rtol, Some(&ref_burst), &atol_burst, || {
            run_vigilode_rodas5p(&prob_burst_jac, &grid_burst, &y0_burst, rtol, atol, InteriorError::WFilteredEnforce)
        }));
        rows.push(timed_run("stiff-burst-switching", "diffsol-tsit45", rtol, Some(&ref_burst), &atol_burst, || {
            run_diffsol(NativeProb::Burst, "tsit45", false, false, &grid_burst, &y0_burst, rtol, atol)
        }));
        rows.push(timed_run("stiff-burst-switching", "diffsol-bdf", rtol, Some(&ref_burst), &atol_burst, || {
            run_diffsol(NativeProb::Burst, "bdf", false, false, &grid_burst, &y0_burst, rtol, atol)
        }));
        rows.push(timed_run("stiff-burst-switching", "dvode-mf10-adams", rtol, Some(&ref_burst), &atol_burst, || {
            run_dvode(NativeProb::Burst, 10, &grid_burst, &y0_burst, rtol, atol, None)
        }));
        rows.push(timed_run("stiff-burst-switching", "cvode-adams", rtol, Some(&ref_burst), &atol_burst, || {
            run_cvode(NativeProb::Burst, 3, &grid_burst, &y0_burst, rtol, atol, None, false, 100_000)
        }));
        rows.push(timed_run("stiff-burst-switching", "cvode-bdf-dense", rtol, Some(&ref_burst), &atol_burst, || {
            run_cvode(NativeProb::Burst, 0, &grid_burst, &y0_burst, rtol, atol, None, true, 100_000)
        }));
    }

    // Robertson RHS-only fallback test (no Jacobian given!)
    let grid_robfd = make_grid(0.0, 40.0, 101);
    let y0_robfd = vec![1.0, 0.0, 0.0];
    let ref_robfd_run = run_hairer(0, NativeProb::RobFd, &grid_robfd, &y0_robfd, 1e-12, 1e-16, None, 0, 0, 0, 0, 0, 0, 500_000);
    let ref_robfd = ref_robfd_run.states.clone();
    let atol_robfd = vec![1e-4; 3];
    let prob_robfd = make_vigilode_problem(NativeProb::RobFd, "fd", None, false);
    for &rtol in &[1e-4, 1e-6] {
        let atol = rtol * 1e-4;
        rows.push(timed_run("robertson-rhs-only-fallback", "vigilode-auto-fallback", rtol, None, &atol_robfd, || {
            let mut r = run_vigilode_unified(&prob_robfd, &grid_robfd, &y0_robfd, rtol, atol, SolverStrategy::Auto, false, 15);
            if r.ok {
                r.extra["endpoint_wrms"] = json!(max_wrms(&r.states, &[ref_robfd.last().unwrap().clone()], &atol_robfd));
            }
            r
        }));
        rows.push(timed_run("robertson-rhs-only-fallback", "vigilode-dopri5-only", rtol, Some(&ref_robfd), &atol_robfd, || {
            run_vigilode_dopri5(&prob_robfd, &grid_robfd, &y0_robfd, rtol, atol, false)
        }));
        rows.push(timed_run("robertson-rhs-only-fallback", "dvode-mf22-fd", rtol, Some(&ref_robfd), &atol_robfd, || {
            run_dvode(NativeProb::RobFd, 22, &grid_robfd, &y0_robfd, rtol, atol, None)
        }));
        rows.push(timed_run("robertson-rhs-only-fallback", "dvode-mf10-adams", rtol, Some(&ref_robfd), &atol_robfd, || {
            run_dvode(NativeProb::RobFd, 10, &grid_robfd, &y0_robfd, rtol, atol, None)
        }));
        rows.push(timed_run("robertson-rhs-only-fallback", "cvode-bdf-fd", rtol, Some(&ref_robfd), &atol_robfd, || {
            run_cvode(NativeProb::RobFd, 0, &grid_robfd, &y0_robfd, rtol, atol, None, false, 100_000)
        }));
    }

    // Event root-finding on harmonic oscillator T=8.5, expected roots: pi/2, 3pi/2, 5pi/2
    eprintln!(">>> S6: event-root-finding");
    let expected_roots = [0.5 * PI, 1.5 * PI, 2.5 * PI];
    let y0_ev = vec![1.0, 0.0];
    let prob_ev_all = make_vigilode_problem(NativeProb::Harmonic, "dense", None, false)
        .event(|_t, y| y[0], Direction::Either);
    let prob_ev_term = make_vigilode_problem(NativeProb::Harmonic, "dense", None, false)
        .terminal_event(|_t, y| y[0], Direction::Either);
    let prob_ev_tangent = make_vigilode_problem(NativeProb::Harmonic, "dense", None, false)
        .event(|_t, y| y[0] - 1.0, Direction::Either);

    for &rtol in &rtols {
        let atol = rtol * 1e-2;
        rows.push(timed_run("event-root-finding", "vigilode-rodas5p-events", rtol, None, &[1.0, 1.0], || {
            let opts = Options { rtol, atol: Atol::Scalar(atol), dense_output: true, ..Default::default() };
            match Rodas5p::solve(&prob_ev_all, (0.0, 8.5), &y0_ev, &opts) {
                Ok(sol) => {
                    let ts: Vec<f64> = sol.events.iter().map(|e| e.t).collect();
                    let err = if ts.len() == 3 {
                        Some(ts.iter().zip(expected_roots.iter()).map(|(a, b)| (a - b).abs()).fold(0.0_f64, f64::max))
                    } else { None };
                    let c = sol.stats.counters;
                    ArmRun {
                        ok: sol.is_success() && ts.len() == 3,
                        nf: Some(c.rhs_evaluations),
                        njac: Some(c.jacobian_builds),
                        accepted: Some(sol.stats.accepted_steps as u64),
                        extra: json!({"roots_found": ts, "max_root_err": err, "event_evals": sol.stats.event_evaluations}),
                        ..Default::default()
                    }
                }
                Err(e) => ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
            }
        }));
        rows.push(timed_run("event-terminal-first", "vigilode-rodas5p-terminal", rtol, None, &[1.0, 1.0], || {
            let opts = Options { rtol, atol: Atol::Scalar(atol), dense_output: true, ..Default::default() };
            match Rodas5p::solve(&prob_ev_term, (0.0, 8.5), &y0_ev, &opts) {
                Ok(sol) => {
                    let t_term = sol.stats.terminal_event.and_then(|idx| sol.events.iter().find(|e| e.index == idx).map(|e| e.t));
                    let c = sol.stats.counters;
                    ArmRun {
                        ok: sol.is_success() && t_term.is_some(),
                        nf: Some(c.rhs_evaluations),
                        njac: Some(c.jacobian_builds),
                        accepted: Some(sol.stats.accepted_steps as u64),
                        extra: json!({
                            "terminal_t": t_term,
                            "root_err": t_term.map(|t| (t - 0.5 * PI).abs()),
                            "final_t_truncated": sol.t.last().copied(),
                            "post_processed_note": "integration ran full [0, 8.5] before truncating outputs"
                        }),
                        ..Default::default()
                    }
                }
                Err(e) => ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
            }
        }));
        rows.push(timed_run("event-root-finding", "diffsol-bdf-root", rtol, None, &[1.0, 1.0], || {
            let problem = OdeBuilder::<FaerMat<f64>>::new()
                .t0(0.0).rtol(rtol).atol(vec![atol, atol])
                .rhs_implicit(
                    |x, _p, _t, out| { out[0] = x[1]; out[1] = -x[0]; },
                    |_x, _p, _t, v, out| { out[0] = v[1]; out[1] = -v[0]; },
                )
                .root(|x, _p, _t, out| { out[0] = x[0]; }, 1)
                .init(|_p, _t, out| { out[0] = 1.0; out[1] = 0.0; }, 2)
                .build().unwrap();
            let mut s = problem.bdf::<FaerLU<f64>>().unwrap();
            let mut roots = Vec::new();
            s.set_stop_time(8.5).unwrap();
            loop {
                match s.step().unwrap() {
                    OdeSolverStopReason::InternalTimestep => {}
                    OdeSolverStopReason::TstopReached => break,
                    OdeSolverStopReason::RootFound(tr, _) => {
                        roots.push(tr);
                        if roots.len() >= 10 { break; }
                    }
                }
            }
            let st = s.get_statistics();
            let err = if roots.len() == 3 {
                Some(roots.iter().zip(expected_roots.iter()).map(|(a, b)| (a - b).abs()).fold(0.0_f64, f64::max))
            } else { None };
            ArmRun {
                ok: roots.len() == 3,
                nlu: Some(st.number_of_linear_solver_setups as u64),
                accepted: Some(st.number_of_steps as u64),
                extra: json!({"roots_found": roots, "max_root_err": err}),
                ..Default::default()
            }
        }));
        rows.push(timed_run("event-root-finding", "cvode-bdf-root", rtol, None, &[1.0, 1.0], || {
            let mut vals = vec![f64::NAN; 4];
            let grid2 = [0.0, 8.5];
            let mut completed = 0i32;
            let mut rts = [0.0_f64; 16];
            let mut rcnt = 0i32;
            let mut stats = [0i64; 9];
            let p = NativeProb::Harmonic;
            let flag = unsafe {
                fs_cvode(
                    &p as *const NativeProb as *const c_void,
                    cb_rhs, Some(cb_jac), None, Some(cb_root_y0), 0, 2, 2,
                    grid2.as_ptr(), y0_ev.as_ptr(), rtol, atol, -1, -1, 100_000,
                    1, 0, vals.as_mut_ptr(), &mut completed, rts.as_mut_ptr(), &mut rcnt, 16, stats.as_mut_ptr(),
                )
            };
            let roots: Vec<f64> = rts[..rcnt as usize].to_vec();
            let err = if roots.len() == 3 {
                Some(roots.iter().zip(expected_roots.iter()).map(|(a, b)| (a - b).abs()).fold(0.0_f64, f64::max))
            } else { None };
            ArmRun {
                ok: flag == 0 && roots.len() == 3,
                nf: Some((stats[1] + stats[7]) as u64),
                njac: Some(stats[6] as u64),
                accepted: Some(stats[0] as u64),
                extra: json!({"roots_found": roots, "max_root_err": err}),
                ..Default::default()
            }
        }));
        rows.push(timed_run("event-terminal-first", "cvode-bdf-terminal", rtol, None, &[1.0, 1.0], || {
            let mut vals = vec![f64::NAN; 4];
            let grid2 = [0.0, 8.5];
            let mut completed = 0i32;
            let mut rts = [0.0_f64; 16];
            let mut rcnt = 0i32;
            let mut stats = [0i64; 9];
            let p = NativeProb::Harmonic;
            let flag = unsafe {
                fs_cvode(
                    &p as *const NativeProb as *const c_void,
                    cb_rhs, Some(cb_jac), None, Some(cb_root_y0), 0, 2, 2,
                    grid2.as_ptr(), y0_ev.as_ptr(), rtol, atol, -1, -1, 100_000,
                    1, 1, vals.as_mut_ptr(), &mut completed, rts.as_mut_ptr(), &mut rcnt, 16, stats.as_mut_ptr(),
                )
            };
            let t_term = (rcnt >= 1).then(|| rts[0]);
            ArmRun {
                ok: flag == 0 && t_term.is_some(),
                nf: Some((stats[1] + stats[7]) as u64),
                njac: Some(stats[6] as u64),
                accepted: Some(stats[0] as u64),
                extra: json!({"terminal_t": t_term, "root_err": t_term.map(|t| (t - 0.5 * PI).abs())}),
                ..Default::default()
            }
        }));
    }

    // Adversarial tangent-touch event check (y1(2pi) = 1.0 tangent without sign change)
    let tangent_sol = Rodas5p::solve(
        &prob_ev_tangent,
        (0.0, 8.5),
        &y0_ev,
        &Options { rtol: 1e-6, atol: Atol::Scalar(1e-8), dense_output: true, ..Default::default() },
    ).unwrap();
    rows.push(json!({
        "problem": "event-tangent-adversarial",
        "arm": "vigilode-rodas5p-events",
        "rtol": 1e-6,
        "ok": tangent_sol.is_success(),
        "extra": {"roots_found": tangent_sol.events.len(), "note": "documented limitation: tangent touch without sign change is missed"}
    }));

    // Typed capability refusals
    eprintln!(">>> S6: capability-refusals & VG-1 zero-alloc audit");
    let vec_atol_opts = Options { atol: Atol::Vector(vec![1e-8; 3]), ..Default::default() };
    let dense_opts = Options { dense_output: true, ..Default::default() };
    let nodense_opts = Options { dense_output: false, ..Default::default() };
    let refusal_cases: Vec<(&str, Problem, Options)> = vec![
        ("JvpWithMassOrDenseOutput", prob_ad_jvp.clone(), dense_opts.clone()),
        ("VectorAtolOnMatrixFreeRoute", make_vigilode_problem(NativeProb::RobFd, "jvp", None, false), vec_atol_opts.clone()),
        ("VectorAtolOnSequentialRoute", prob_rob_mass.clone(), vec_atol_opts.clone()),
        ("EventsWithoutDenseOutput", prob_ev_all.clone(), nodense_opts),
        ("BandDeclarationOnJvpProblem", make_vigilode_problem(NativeProb::RobFd, "jvp", None, false).banded(1, 1), Options::default()),
    ];
    let mut refusal_results = Vec::new();
    for (name, pr, op) in refusal_cases {
        let cap = Rodas5p::capabilities(&pr, &op);
        refusal_results.push(json!({"expected": name, "refused": cap.is_err(), "detail": format!("{cap:?}")}));
    }

    // VG-1 Zero-Allocation Audit across hot-loop APIs
    // 1. Small fixed-array driver N=3 (Robertson)
    struct RobSmall;
    impl SmallProblem<3> for RobSmall {
        fn rhs(&self, y: &[f64; 3], out: &mut [f64; 3]) {
            NativeProb::RobFd.rhs(0.0, y, out);
        }
        fn jacobian(&self, y: &[f64; 3], out: &mut [[f64; 3]; 3]) {
            let mut flat = [0.0; 9];
            NativeProb::RobFd.jac_dense_row_major(0.0, y, &mut flat);
            for i in 0..3 { for j in 0..3 { out[i][j] = flat[i * 3 + j]; } }
        }
    }
    let adap_vg = AdaptiveStepConfig { rtol: 1e-6, atol: 1e-10, max_attempts: 100_000, ..Default::default() };
    let sched_end = OutputSchedule::new(vec![0.0, 40.0]).unwrap();
    alloc_begin();
    let _ = integrate_rodas5p_fast_small_observed(&RobSmall, (0.0, 40.0), &[1.0, 0.0, 0.0], &adap_vg, &sched_end).unwrap();
    let a_small = alloc_end();

    // 2. Banded fast N=400
    let ode_br_dense = OdeProblem::new("br400", n_br, Arc::new(|t, y, dy| { NativeProb::Bruss400.rhs(t, y, dy); Ok(()) }), None, None, Some(Arc::new(|t, y, v, out| { NativeProb::Bruss400.jvp(t, y, v, out); Ok(()) })), None, true, None, None).unwrap();
    let band_br = BandedJacobian { lower: 2, upper: 2, fill: Arc::new(|t, y, b| { NativeProb::Bruss400.jac_band_row_major(t, y, 2, 2, b); Ok(()) }) };
    let sched_br_end = OutputSchedule::new(vec![0.0, 10.0]).unwrap();
    alloc_begin();
    let _ = integrate_rodas5p_fast_banded_observed(&ode_br_dense, &band_br, (0.0, 10.0), &y0_br, &adap_vg, &sched_br_end).unwrap();
    let a_band = alloc_end();

    // 3. Matrix-free LS workspace N=256
    let lcfg = LinearSolverConfig { method: LinearMethod::Gmres, maxiter: 30, ..Default::default() };
    let sched_ad_end = OutputSchedule::new(vec![0.0, 1.0]).unwrap();
    let adap_ad = AdaptiveStepConfig { rtol: 1e-6, atol: 1e-6, max_attempts: 100_000, ..Default::default() };
    alloc_begin();
    let _ = integrate_rodas5p_mf_fast_observed_gmres_into_ls_workspace(&ode_ad, (0.0, 1.0), &y0_ad, &lcfg, &adap_ad, &sched_ad_end).unwrap();
    let a_mf = alloc_end();

    // 4. Unified VigilodeWorkspace::step_into (true hot-loop) vs VigilODE::solve_with_workspace
    let mut ws = VigilodeWorkspace::new(n_ad, 30);
    let mut y_out_ws = vec![0.0; n_ad];
    ws.reset(&y0_ad);
    alloc_begin();
    for _ in 0..10 {
        let _ = ws.step_into(&prob_ad_jvp, 0.0, &y0_ad, 1e-5, &mut y_out_ws).unwrap();
    }
    let a_ws_step = alloc_end();

    let uopts = VigilodeOptions::default().strategy(SolverStrategy::HighPerformance).rtol(1e-6).atol(1e-6);
    ws.reset(&y0_ad);
    alloc_begin();
    let _ = VigilODE::solve_with_workspace(&prob_ad_jvp, (0.0, 1.0), &y0_ad, uopts, &mut ws).unwrap();
    let a_unified_ws = alloc_end();

    // 5. Dense fast N=8 (HIRES) -> setup vs solve
    let ode_kr = OdeProblem::new("kr", 2, Arc::new(|t, y, dy| { NativeProb::Kreiss.rhs(t, y, dy); Ok(()) }), None, Some(Arc::new(|t, y| {
        let mut m = CoreDenseMatrix::zeros(2, 2);
        NativeProb::Kreiss.jac_dense_row_major(t, y, m.as_mut_slice());
        Ok(m)
    })), None, None, true, None, None).unwrap();
    let sched_kr_end = OutputSchedule::new(vec![0.0, 5.0]).unwrap();
    alloc_begin();
    let _ = integrate_rodas5p_fast_observed(&ode_kr, (0.0, 5.0), &[0.0, 1.0], &adap_vg, &sched_kr_end).unwrap();
    let a_dense = alloc_end();

    let vg1_audit = json!({
        "rodas5p_fast_small_n3": {"rust_calls": a_small.rust_calls, "rust_bytes": a_small.rust_bytes, "heap_calls": a_small.heap_calls},
        "rodas5p_fast_dense_n2": {"rust_calls": a_dense.rust_calls, "rust_bytes": a_dense.rust_bytes, "heap_calls": a_dense.heap_calls},
        "rodas5p_fast_banded_n400": {"rust_calls": a_band.rust_calls, "rust_bytes": a_band.rust_bytes, "heap_calls": a_band.heap_calls},
        "rodas5p_mf_ls_workspace_n256": {"rust_calls": a_mf.rust_calls, "rust_bytes": a_mf.rust_bytes, "heap_calls": a_mf.heap_calls},
        "vigilode_workspace_step_into_n256_x10": {"rust_calls": a_ws_step.rust_calls, "rust_bytes": a_ws_step.rust_bytes, "heap_calls": a_ws_step.heap_calls},
        "vigilode_solve_with_workspace_n256": {"rust_calls": a_unified_ws.rust_calls, "rust_bytes": a_unified_ws.rust_bytes, "heap_calls": a_unified_ws.heap_calls},
    });

    let doc = json!({
        "schema": "vigilode-full-scope-rust-v1",
        "timing_authority": "diagnostic_only",
        "rows": rows,
        "references": references,
        "capability_refusals": refusal_results,
        "vg1_allocation_audit": vg1_audit,
    });
    std::fs::write(out_path, serde_json::to_string_pretty(&doc).unwrap() + "\n").unwrap();
    eprintln!("Wrote {} Rust/C/Fortran rows to {}", doc["rows"].as_array().unwrap().len(), out_path);
}
