#!/usr/bin/env julia
# Extended Full-Scope Adversarial Benchmark: Julia SciML Comparators
# Covers Scopes S1, S2 (PR), S4 (Large Matrix-Free), S5 (DAEs), S6 (Switching & Events)

using OrdinaryDiffEq
using OrdinaryDiffEqBDF
using OrdinaryDiffEqFIRK
using Sundials
using LinearAlgebra
using SparseArrays
using Statistics
using JSON3
using SHA

function calc_max_wrms(states, ref_states, atol_scale, error_rtol=1.0)
    n_pts = length(ref_states)
    n = length(atol_scale)
    sqrt_n = sqrt(Float64(n))
    worst = 0.0
    for k in 1:n_pts
        y = states[k]
        r = ref_states[k]
        norm = 0.0
        for i in 1:n
            sc = error_rtol * (atol_scale[i] + abs(r[i]))
            e = (y[i] - r[i]) / sc
            norm = hypot(norm, e / sqrt_n)
        end
        worst = max(worst, norm)
    end
    return worst
end

function run_timed(fn)
    # 2 warmups, 5 repetitions
    w_res = nothing
    for _ in 1:2
        w_res = fn()
        if !w_res.ok
            return (ok=false, err_msg=w_res.err_msg, med_ms=nothing, states=w_res.states,
                    nf=w_res.nf, njac=w_res.njac, naccept=w_res.naccept, nreject=w_res.nreject,
                    extra=w_res.extra)
        end
    end
    times_ns = UInt64[]
    last_res = w_res
    for _ in 1:5
        t0 = time_ns()
        last_res = fn()
        push!(times_ns, time_ns() - t0)
        if !last_res.ok
            return (ok=false, err_msg=last_res.err_msg, med_ms=nothing, states=last_res.states,
                    nf=last_res.nf, njac=last_res.njac, naccept=last_res.naccept, nreject=last_res.nreject,
                    extra=last_res.extra)
        end
    end
    med_ms = median(times_ns) / 1e6
    return (ok=true, err_msg="", med_ms=med_ms, states=last_res.states,
            nf=last_res.nf, njac=last_res.njac, naccept=last_res.naccept, nreject=last_res.nreject,
            extra=last_res.extra)
end

function extract_stats(sol)
    st = sol.stats
    nf = hasproperty(st, :nf) ? st.nf : nothing
    njac = hasproperty(st, :njacs) ? st.njacs : nothing
    naccept = hasproperty(st, :naccept) ? st.naccept : nothing
    nreject = hasproperty(st, :nreject) ? st.nreject : nothing
    return nf, njac, naccept, nreject
end

function solve_ode(prob, alg, grid, rtol, atol; maxiters=100000, extra_fn=sol->Dict())
    try
        sol = solve(prob, alg, reltol=rtol, abstol=atol, saveat=grid, maxiters=maxiters)
        ok = SciMLBase.successful_retcode(sol.retcode) && length(sol.u) == length(grid)
        states = ok ? [Float64.(collect(u)) for u in sol.u] : Vector{Float64}[]
        nf, njac, nacc, nrej = extract_stats(sol)
        return (ok=ok, err_msg=ok ? "" : string(sol.retcode), states=states,
                nf=nf, njac=njac, naccept=nacc, nreject=nrej, extra=extra_fn(sol))
    catch e
        return (ok=false, err_msg=sprint(showerror, e), states=Vector{Float64}[],
                nf=nothing, njac=nothing, naccept=nothing, nreject=nothing, extra=Dict())
    end
end

# 1. Kepler e=0.5
function kepler_exact(t, ecc=0.5)
    # Solve M = E - e sin(E) via Newton
    M = mod(t, 2pi)
    E = M
    for _ in 1:30
        E -= (E - ecc * sin(E) - M) / (1.0 - ecc * cos(E))
    end
    cE = cos(E); sE = sin(E)
    fac = sqrt(1.0 - ecc * ecc)
    r = 1.0 - ecc * cE
    x = cE - ecc
    y = fac * sE
    vx = -sE / r
    vy = fac * cE / r
    return [x, y, vx, vy]
end

function kepler_rhs!(dy, y, p, t)
    r2 = y[1]^2 + y[2]^2
    r3 = r2 * sqrt(r2)
    inv_r3 = -1.0 / r3
    dy[1] = y[3]
    dy[2] = y[4]
    dy[3] = inv_r3 * y[1]
    dy[4] = inv_r3 * y[2]
end

# 2. Kreiss nonnormal b=100
function kreiss_rhs!(dy, y, p, t)
    dy[1] = -y[1] + 100.0 * y[2]
    dy[2] = -2.0 * y[2]
end

# 3. Prothero-Robinson lambda=-1e4
function pr_rhs!(dy, y, p, t)
    dy[1] = -10000.0 * (y[1] - sin(t)) + cos(t)
end
function pr_jac!(J, y, p, t)
    J[1, 1] = -10000.0
end

# 4. Periodic Advection-Diffusion N=256
function make_advdiff_256()
    n = 256
    d = 0.01 * n * n
    v = 1.0 * n
    function rhs!(dy, y, p, t)
        @inbounds for i in 1:n
            im1 = i == 1 ? n : i - 1
            ip1 = i == n ? 1 : i + 1
            dy[i] = d * (y[im1] - 2.0 * y[i] + y[ip1]) - v * (y[i] - y[im1])
        end
    end
    function jvp!(Jv, v_vec, y, p, t)
        @inbounds for i in 1:n
            im1 = i == 1 ? n : i - 1
            ip1 = i == n ? 1 : i + 1
            Jv[i] = d * (v_vec[im1] - 2.0 * v_vec[i] + v_vec[ip1]) - v * (v_vec[i] - v_vec[im1])
        end
    end
    I_idx = Int[]; J_idx = Int[]; V_idx = Float64[]
    for i in 1:n
        im1 = i == 1 ? n : i - 1
        ip1 = i == n ? 1 : i + 1
        push!(I_idx, i, i, i); push!(J_idx, im1, i, ip1); push!(V_idx, d + v, -2.0 * d - v, d)
    end
    J_const = sparse(I_idx, J_idx, V_idx, n, n)
    function jac!(J, y, p, t)
        copyto!(J, J_const)
    end
    u0 = [1.0 + 0.1 * sin(2.0 * pi * (i - 1) / n) for i in 1:n]
    return rhs!, jvp!, jac!, J_const, u0
end

# 5. Brusselator 1D N=400 (200 cells)
function make_bruss_400()
    n_cells = 200
    n = 2 * n_cells
    dx = 1.0 / (n_cells + 1)
    c = 0.02 / (dx * dx)
    function rhs!(dy, y, p, t)
        @inbounds for i in 1:n_cells
            u = y[2i - 1]; v = y[2i]
            ul = i == 1 ? 1.0 : y[2i - 3]
            vl = i == 1 ? 3.0 : y[2i - 2]
            ur = i == n_cells ? 1.0 : y[2i + 1]
            vr = i == n_cells ? 3.0 : y[2i + 2]
            dy[2i - 1] = 1.0 + u * u * v - 4.4 * u + c * (ul - 2.0 * u + ur)
            dy[2i]     = 3.4 * u - u * u * v + c * (vl - 2.0 * v + vr)
        end
    end
    function jvp!(Jv, v_vec, y, p, t)
        @inbounds for i in 1:n_cells
            u = y[2i - 1]; v = y[2i]
            du = v_vec[2i - 1]; dv = v_vec[2i]
            dul = i == 1 ? 0.0 : v_vec[2i - 3]
            dvl = i == 1 ? 0.0 : v_vec[2i - 2]
            dur = i == n_cells ? 0.0 : v_vec[2i + 1]
            dvr = i == n_cells ? 0.0 : v_vec[2i + 2]
            Jv[2i - 1] = (2.0 * u * v - 4.4 - 2.0 * c) * du + (u * u) * dv + c * (dul + dur)
            Jv[2i]     = (3.4 - 2.0 * u * v) * du + (-u * u - 2.0 * c) * dv + c * (dvl + dvr)
        end
    end
    # Sparse prototype
    I_idx = Int[]; J_idx = Int[]
    for i in 1:n_cells
        ui = 2i - 1; vi = 2i
        push!(I_idx, ui, ui, vi, vi); push!(J_idx, ui, vi, ui, vi)
        if i > 1
            push!(I_idx, ui, vi); push!(J_idx, ui - 2, vi - 2)
        end
        if i < n_cells
            push!(I_idx, ui, vi); push!(J_idx, ui + 2, vi + 2)
        end
    end
    J_proto = sparse(I_idx, J_idx, ones(length(I_idx)), n, n)
    function jac!(J, y, p, t)
        fill!(J, 0.0)
        @inbounds for i in 1:n_cells
            ui = 2i - 1; vi = 2i
            u = y[ui]; v = y[vi]
            J[ui, ui] = 2.0 * u * v - 4.4 - 2.0 * c
            J[ui, vi] = u * u
            J[vi, ui] = 3.4 - 2.0 * u * v
            J[vi, vi] = -u * u - 2.0 * c
            if i > 1
                J[ui, ui - 2] = c; J[vi, vi - 2] = c
            end
            if i < n_cells
                J[ui, ui + 2] = c; J[vi, vi + 2] = c
            end
        end
    end
    u0 = zeros(n)
    for i in 1:n_cells
        x = i * dx
        u0[2i - 1] = 1.0 + sin(2.0 * pi * x)
        u0[2i] = 3.0
    end
    return rhs!, jvp!, jac!, J_proto, u0
end

# 6. Stiff burst switching
function burst_rhs!(dy, y, p, t)
    lam = 5000.0 * exp(-40.0 * (t - 3.0)^2)
    dy[1] = y[2]
    dy[2] = -y[1] - lam * (y[2] - (-sin(t))) - cos(t)
end
function burst_jac!(J, y, p, t)
    lam = 5000.0 * exp(-40.0 * (t - 3.0)^2)
    J[1, 1] = 0.0; J[1, 2] = 1.0
    J[2, 1] = -1.0; J[2, 2] = -lam
end

function main()
    out_file = length(ARGS) >= 1 ? ARGS[1] : "full_scope_julia.json"
    ref_file = length(ARGS) >= 2 ? ARGS[2] : nothing

    refs = Dict{String, Any}()
    if ref_file !== nothing && isfile(ref_file)
        raw = JSON3.read(read(ref_file, String))
        if haskey(raw, "references")
            for (k, v) in pairs(raw["references"])
                refs[String(k)] = [Float64.(collect(row)) for row in v]
            end
        end
    end

    rows = Any[]
    rtols = [1e-4, 1e-6, 1e-8]

    # ---- S1: Kepler e=0.5 (T = 20*pi) ----
    tspan_kep = (0.0, 20.0 * pi)
    grid_kep = collect(range(0.0, 20.0 * pi, length=101))
    ref_kep = [kepler_exact(t) for t in grid_kep]
    prob_kep = ODEProblem(kepler_rhs!, [0.5, 0.0, 0.0, sqrt(3.0)], tspan_kep)
    for rtol in rtols
        atol = rtol * 1e-2
        for (aid, alg) in [("julia-tsit5", Tsit5()), ("julia-vern9", Vern9()), ("julia-rodas5p", Rodas5P()), ("julia-cvode-adams", CVODE_Adams())]
            res = run_timed(() -> solve_ode(prob_kep, alg, grid_kep, rtol, atol; maxiters=200000, extra_fn=sol -> begin
                u = sol.u[end]
                E0 = 0.5 * (3.0) - 1.0 / 0.5
                Ef = 0.5 * (u[3]^2 + u[4]^2) - 1.0 / hypot(u[1], u[2])
                L0 = 0.5 * sqrt(3.0)
                Lf = u[1] * u[4] - u[2] * u[3]
                Dict("energy_drift" => abs(Ef - E0), "ang_mom_drift" => abs(Lf - L0))
            end))
            err = res.ok ? calc_max_wrms(res.states, ref_kep, fill(1.0, 4)) : nothing
            push!(rows, Dict("problem"=>"kepler-ecc05", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # ---- S1: Kreiss Nonnormal b=100 ----
    tspan_kr = (0.0, 5.0)
    grid_kr = collect(range(0.0, 5.0, length=101))
    ref_kr = [[100.0 * (exp(-t) - exp(-2.0 * t)), exp(-2.0 * t)] for t in grid_kr]
    prob_kr = ODEProblem(kreiss_rhs!, [0.0, 1.0], tspan_kr)
    for rtol in rtols
        atol = rtol * 1e-2
        for (aid, alg) in [("julia-tsit5", Tsit5()), ("julia-rodas5p", Rodas5P()), ("julia-cvode-bdf", CVODE_BDF())]
            res = run_timed(() -> solve_ode(prob_kr, alg, grid_kr, rtol, atol))
            err = res.ok ? calc_max_wrms(res.states, ref_kr, fill(1.0, 2)) : nothing
            push!(rows, Dict("problem"=>"nonnormal-kreiss-b100", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # ---- S2 Supplement: Prothero-Robinson lambda=-1e4 ----
    tspan_pr = (0.0, 10.0)
    grid_pr = collect(range(0.0, 10.0, length=101))
    ref_pr = [[sin(t)] for t in grid_pr]
    prob_pr = ODEProblem(ODEFunction(pr_rhs!, jac=pr_jac!), [0.0], tspan_pr)
    for rtol in rtols
        atol = rtol * 1e-2
        for (aid, alg) in [("julia-rodas5p", Rodas5P()), ("julia-fbdf", FBDF()), ("julia-radauiia5", RadauIIA5()), ("julia-cvode-bdf", CVODE_BDF())]
            res = run_timed(() -> solve_ode(prob_pr, alg, grid_pr, rtol, atol))
            err = res.ok ? calc_max_wrms(res.states, ref_pr, [1.0]) : nothing
            push!(rows, Dict("problem"=>"prothero-robinson-1e4", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # ---- S4: Periodic Advection-Diffusion N=256 ----
    rhs_ad, jvp_ad, jac_ad, J_ad_proto, u0_ad = make_advdiff_256()
    J_ad_dense = Matrix(J_ad_proto)
    grid_ad = collect(range(0.0, 1.0, length=101))
    prob_ad_sparse = ODEProblem(ODEFunction(rhs_ad, jac=jac_ad, jac_prototype=J_ad_proto), u0_ad, (0.0, 1.0))
    prob_ad_dense = ODEProblem(ODEFunction(rhs_ad, jac=(J,y,p,t)->copyto!(J, J_ad_dense)), u0_ad, (0.0, 1.0))
    prob_ad_jvp = ODEProblem(ODEFunction(rhs_ad, jvp=jvp_ad), u0_ad, (0.0, 1.0))
    ref_ad = get(refs, "periodic-advdiff-n256", nothing)
    for rtol in rtols
        atol = rtol
        for (aid, p_use, alg) in [
            ("julia-cvode-gmres", prob_ad_jvp, CVODE_BDF(linear_solver=:GMRES)),
            ("julia-cvode-bdf", prob_ad_dense, CVODE_BDF()),
            ("julia-fbdf", prob_ad_sparse, FBDF()),
            ("julia-rodas5p", prob_ad_sparse, Rodas5P()),
        ]
            res = run_timed(() -> solve_ode(p_use, alg, grid_ad, rtol, atol))
            err = (res.ok && ref_ad !== nothing) ? calc_max_wrms(res.states, ref_ad, fill(1.0, 256)) : nothing
            push!(rows, Dict("problem"=>"periodic-advdiff-n256", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # ---- S4: Brusselator 1D N=400 ----
    rhs_br, jvp_br, jac_br, J_br_proto, u0_br = make_bruss_400()
    grid_br = collect(range(0.0, 10.0, length=101))
    prob_br_sparse = ODEProblem(ODEFunction(rhs_br, jac=jac_br, jac_prototype=J_br_proto), u0_br, (0.0, 10.0))
    prob_br_jvp = ODEProblem(ODEFunction(rhs_br, jvp=jvp_br), u0_br, (0.0, 10.0))
    ref_br = get(refs, "brusselator-1d-jvp-n400", nothing)
    for rtol in rtols
        atol = rtol
        for (aid, p_use, alg) in [
            ("julia-cvode-gmres", prob_br_jvp, CVODE_BDF(linear_solver=:GMRES)),
            ("julia-fbdf", prob_br_sparse, FBDF()),
            ("julia-rodas5p", prob_br_sparse, Rodas5P()),
        ]
            res = run_timed(() -> solve_ode(p_use, alg, grid_br, rtol, atol))
            err = (res.ok && ref_br !== nothing) ? calc_max_wrms(res.states, ref_br, fill(1.0, 400)) : nothing
            push!(rows, Dict("problem"=>"brusselator-1d-jvp-n400", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # ---- S5: DAEs & Mass Matrices ----
    # 5a: dae-robertson-index1
    function rob_dae_ode!(dy, y, p, t)
        dy[1] = -0.04 * y[1] + 1e4 * y[2] * y[3]
        dy[2] = 0.04 * y[1] - 1e4 * y[2] * y[3] - 3e7 * y[2]^2
        dy[3] = y[1] + y[2] + y[3] - 1.0
    end
    function rob_dae_res!(res, dy, y, p, t)
        res[1] = dy[1] + 0.04 * y[1] - 1e4 * y[2] * y[3]
        res[2] = dy[2] - 0.04 * y[1] + 1e4 * y[2] * y[3] + 3e7 * y[2]^2
        res[3] = y[1] + y[2] + y[3] - 1.0
    end
    M_rob = [1.0 0.0 0.0; 0.0 1.0 0.0; 0.0 0.0 0.0]
    grid_rob = collect(range(0.0, 40.0, length=101))
    ref_rob_dae = get(refs, "dae-robertson-index1", nothing)
    prob_rob_mass = ODEProblem(ODEFunction(rob_dae_ode!, mass_matrix=M_rob), [1.0, 0.0, 0.0], (0.0, 40.0))
    prob_rob_dae = DAEProblem(rob_dae_res!, [-0.04, 0.04, 0.0], [1.0, 0.0, 0.0], (0.0, 40.0), differential_vars=[true, true, false])
    for rtol in rtols
        atol = rtol * 1e-4
        for (aid, p_use, alg) in [
            ("julia-rodas5p", prob_rob_mass, Rodas5P()),
            ("julia-fbdf", prob_rob_mass, FBDF()),
            ("julia-dfbdf", prob_rob_dae, DFBDF()),
            ("julia-ida", prob_rob_dae, IDA()),
        ]
            res = run_timed(() -> solve_ode(p_use, alg, grid_rob, rtol, atol; extra_fn=sol -> begin
                max_res = maximum(abs(u[1] + u[2] + u[3] - 1.0) for u in sol.u)
                Dict("max_constraint_residual" => max_res)
            end))
            err = (res.ok && ref_rob_dae !== nothing) ? calc_max_wrms(res.states, ref_rob_dae, fill(1e-4, 3)) : nothing
            push!(rows, Dict("problem"=>"dae-robertson-index1", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # 5b: dae-index1-analytic
    function dae_ana_ode!(dy, y, p, t)
        dy[1] = -y[1] + y[2]
        dy[2] = y[1] + y[2] - (2.0 * sin(t) + cos(t))
    end
    function dae_ana_res!(res, dy, y, p, t)
        res[1] = dy[1] + y[1] - y[2]
        res[2] = y[1] + y[2] - (2.0 * sin(t) + cos(t))
    end
    M_ana = [1.0 0.0; 0.0 0.0]
    grid_ana = collect(range(0.0, 5.0, length=101))
    ref_ana = [[sin(t), sin(t) + cos(t)] for t in grid_ana]
    prob_ana_mass = ODEProblem(ODEFunction(dae_ana_ode!, mass_matrix=M_ana), [0.0, 1.0], (0.0, 5.0))
    prob_ana_dae = DAEProblem(dae_ana_res!, [1.0, 1.0], [0.0, 1.0], (0.0, 5.0), differential_vars=[true, false])
    for rtol in rtols
        atol = rtol * 1e-2
        for (aid, p_use, alg) in [
            ("julia-rodas5p", prob_ana_mass, Rodas5P()),
            ("julia-fbdf", prob_ana_mass, FBDF()),
            ("julia-dfbdf", prob_ana_dae, DFBDF()),
            ("julia-ida", prob_ana_dae, IDA()),
        ]
            res = run_timed(() -> solve_ode(p_use, alg, grid_ana, rtol, atol; extra_fn=sol -> begin
                max_res = maximum(abs(sol.u[k][1] + sol.u[k][2] - (2.0*sin(sol.t[k]) + cos(sol.t[k]))) for k in eachindex(sol.t))
                Dict("max_constraint_residual" => max_res)
            end))
            err = res.ok ? calc_max_wrms(res.states, ref_ana, [1.0, 1.0]) : nothing
            push!(rows, Dict("problem"=>"dae-index1-analytic", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # 5c: mass-ill-conditioned (eps = 1e-8)
    M_ill = [1.0 0.0; 0.0 1e-8]
    function ill_ode!(dy, y, p, t)
        dy[1] = -y[1]
        dy[2] = -1e-8 * y[2]
    end
    function ill_res!(res, dy, y, p, t)
        res[1] = dy[1] + y[1]
        res[2] = 1e-8 * (dy[2] + y[2])
    end
    grid_ill = collect(range(0.0, 1.0, length=101))
    ref_ill = [[exp(-t), 2.0 * exp(-t)] for t in grid_ill]
    prob_ill_mass = ODEProblem(ODEFunction(ill_ode!, mass_matrix=M_ill), [1.0, 2.0], (0.0, 1.0))
    prob_ill_dae = DAEProblem(ill_res!, [-1.0, -2.0], [1.0, 2.0], (0.0, 1.0), differential_vars=[true, true])
    for rtol in rtols
        atol = rtol * 1e-2
        for (aid, p_use, alg) in [
            ("julia-rodas5p", prob_ill_mass, Rodas5P()),
            ("julia-fbdf", prob_ill_mass, FBDF()),
            ("julia-dfbdf", prob_ill_dae, DFBDF()),
            ("julia-ida", prob_ill_dae, IDA()),
        ]
            res = run_timed(() -> solve_ode(p_use, alg, grid_ill, rtol, atol))
            err = res.ok ? calc_max_wrms(res.states, ref_ill, [1.0, 1.0]) : nothing
            push!(rows, Dict("problem"=>"mass-ill-conditioned", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # ---- S6: Stiff Burst Switching & Events ----
    grid_burst = collect(range(0.0, 6.0, length=101))
    ref_burst = get(refs, "stiff-burst-switching", nothing)
    prob_burst = ODEProblem(ODEFunction(burst_rhs!, jac=burst_jac!), [1.0, 0.0], (0.0, 6.0))
    for rtol in rtols
        atol = rtol * 1e-2
        for (aid, alg) in [("julia-tsit5", Tsit5()), ("julia-rodas5p", Rodas5P()), ("julia-fbdf", FBDF()), ("julia-cvode-bdf", CVODE_BDF())]
            res = run_timed(() -> solve_ode(prob_burst, alg, grid_burst, rtol, atol; maxiters=100000))
            err = (res.ok && ref_burst !== nothing) ? calc_max_wrms(res.states, ref_burst, [1.0, 1.0]) : nothing
            push!(rows, Dict("problem"=>"stiff-burst-switching", "arm"=>aid, "rtol"=>rtol, "ok"=>res.ok, "err_msg"=>res.err_msg,
                "error_common"=>err, "wall_ms_median"=>res.med_ms, "nf"=>res.nf, "njac"=>res.njac,
                "accepted"=>res.naccept, "rejected"=>res.nreject, "extra"=>res.extra))
        end
    end

    # 6b: Event root finding on harmonic oscillator y'' + y = 0, T=8.5, roots pi/2, 3pi/2, 5pi/2
    function harm_rhs!(dy, y, p, t)
        dy[1] = y[2]; dy[2] = -y[1]
    end
    prob_ev = ODEProblem(harm_rhs!, [1.0, 0.0], (0.0, 8.5))
    for rtol in rtols
        atol = rtol * 1e-2
        roots_found = Float64[]
        cb_all = ContinuousCallback((u, t, integrator) -> u[1], integrator -> push!(roots_found, integrator.t))
        res_all = run_timed(() -> begin
            empty!(roots_found)
            sol = solve(prob_ev, Rodas5P(), reltol=rtol, abstol=atol, callback=cb_all)
            ok = SciMLBase.successful_retcode(sol.retcode)
            nf, njac, nacc, nrej = extract_stats(sol)
            expected = [pi/2, 3pi/2, 5pi/2]
            max_root_err = length(roots_found) == 3 ? maximum(abs.(roots_found .- expected)) : nothing
            (ok=ok, err_msg=ok ? "" : string(sol.retcode), states=[sol.u[end]], nf=nf, njac=njac,
             naccept=nacc, nreject=nrej, extra=Dict("roots_found"=>copy(roots_found), "max_root_err"=>max_root_err))
        end)
        push!(rows, Dict("problem"=>"event-root-finding", "arm"=>"julia-rodas5p-callback", "rtol"=>rtol,
            "ok"=>res_all.ok, "err_msg"=>res_all.err_msg, "error_common"=>nothing, "wall_ms_median"=>res_all.med_ms,
            "nf"=>res_all.nf, "njac"=>res_all.njac, "accepted"=>res_all.naccept, "rejected"=>res_all.nreject, "extra"=>res_all.extra))

        # Terminal event at 3rd crossing? Stop on first crossing pi/2 for direct terminal comparison
        term_t = Ref(NaN)
        cb_term = ContinuousCallback((u, t, integrator) -> u[1], integrator -> begin term_t[] = integrator.t; terminate!(integrator) end)
        res_term = run_timed(() -> begin
            term_t[] = NaN
            sol = solve(prob_ev, Rodas5P(), reltol=rtol, abstol=atol, callback=cb_term)
            ok = SciMLBase.successful_retcode(sol.retcode)
            nf, njac, nacc, nrej = extract_stats(sol)
            (ok=ok, err_msg=ok ? "" : string(sol.retcode), states=[sol.u[end]], nf=nf, njac=njac,
             naccept=nacc, nreject=nrej, extra=Dict("terminal_t"=>term_t[], "root_err"=>abs(term_t[] - pi/2), "final_t"=>sol.t[end]))
        end)
        push!(rows, Dict("problem"=>"event-terminal-first", "arm"=>"julia-rodas5p-terminal", "rtol"=>rtol,
            "ok"=>res_term.ok, "err_msg"=>res_term.err_msg, "error_common"=>nothing, "wall_ms_median"=>res_term.med_ms,
            "nf"=>res_term.nf, "njac"=>res_term.njac, "accepted"=>res_term.naccept, "rejected"=>res_term.nreject, "extra"=>res_term.extra))
    end

    # ---- 6c: Adversarial DAE boundary checks ----
    # Inconsistent initial data: y0=[0,0] for y1+y2 = 2sin(t)+cos(t)
    prob_inc_mass = ODEProblem(ODEFunction(dae_ana_ode!, mass_matrix=M_ana), [0.0, 0.0], (0.0, 1.0))
    prob_inc_dae = DAEProblem(dae_ana_res!, [0.0, 0.0], [0.0, 0.0], (0.0, 1.0), differential_vars=[true, false])
    for (aid, p_use, alg, kw) in [
        ("julia-rodas5p-checkinit", prob_inc_mass, Rodas5P(), (initializealg=SciMLBase.CheckInit(),)),
        ("julia-rodas5p-defaultinit", prob_inc_mass, Rodas5P(), NamedTuple()),
        ("julia-ida-default", prob_inc_dae, IDA(), NamedTuple()),
    ]
        st = try
            sol = solve(p_use, alg; reltol=1e-6, abstol=1e-8, kw...)
            Dict("ok"=>SciMLBase.successful_retcode(sol.retcode), "retcode"=>string(sol.retcode), "y_end"=>collect(sol.u[end]))
        catch e
            Dict("ok"=>false, "retcode"=>"EXCEPTION: " * sprint(showerror, e), "y_end"=>nothing)
        end
        push!(rows, Dict("problem"=>"dae-index1-inconsistent", "arm"=>aid, "rtol"=>1e-6,
            "ok"=>st["ok"], "err_msg"=>st["retcode"], "error_common"=>nothing, "wall_ms_median"=>nothing,
            "nf"=>nothing, "njac"=>nothing, "accepted"=>nothing, "rejected"=>nothing, "extra"=>st))
    end

    # ---- S1: Ensemble N=1024 x 16 ----
    n_ens = 1024
    m_ens = 16
    rates = [[0.5 + 0.35 * ((i - 1) % 13) / 12.0 + (mem - 1) * 0.01 for i in 1:n_ens] for mem in 1:m_ens]
    u0_ens = [0.5 + 0.5 * ((i - 1) % 17) / 16.0 for i in 1:n_ens]
    probs_ens = [ODEProblem((du, u, p, t) -> begin @inbounds for i in 1:n_ens; du[i] = -rates[mem][i] * u[i]; end end, copy(u0_ens), (0.0, 4.0)) for mem in 1:m_ens]
    res_ens = run_timed(() -> begin
        worst_err = 0.0
        for mem in 1:m_ens
            sol = solve(probs_ens[mem], Tsit5(), reltol=1e-6, abstol=1e-9, save_everystep=false)
            if !SciMLBase.successful_retcode(sol.retcode)
                return (ok=false, err_msg=string(sol.retcode), states=Vector{Float64}[], nf=nothing, njac=nothing, naccept=nothing, nreject=nothing, extra=Dict())
            end
            u_end = sol.u[end]
            for i in 1:n_ens
                exact_i = u0_ens[i] * exp(-rates[mem][i] * 4.0)
                worst_err = max(worst_err, abs(u_end[i] - exact_i))
            end
        end
        (ok=true, err_msg="", states=Vector{Float64}[], nf=nothing, njac=nothing, naccept=nothing, nreject=nothing, extra=Dict("max_abs_err"=>worst_err))
    end)
    push!(rows, Dict("problem"=>"dopri5-ensemble-n1024x16", "arm"=>"julia-tsit5-seq16", "rtol"=>1e-6,
        "ok"=>res_ens.ok, "err_msg"=>res_ens.err_msg, "error_common"=>get(res_ens.extra, "max_abs_err", nothing),
        "wall_ms_median"=>res_ens.med_ms, "nf"=>nothing, "njac"=>nothing, "accepted"=>nothing, "rejected"=>nothing, "extra"=>res_ens.extra))

    doc = Dict(
        "schema" => "vigilode-full-scope-julia-v1",
        "timing_authority" => "diagnostic_only",
        "julia_version" => string(VERSION),
        "rows" => rows,
    )
    open(out_file, "w") do io
        JSON3.pretty(io, doc)
    end
    println("Wrote ", length(rows), " Julia rows to ", out_file)
end

main()
