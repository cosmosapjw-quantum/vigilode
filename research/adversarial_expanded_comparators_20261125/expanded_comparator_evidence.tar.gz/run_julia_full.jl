include(joinpath(@__DIR__,"julia_algorithms_full.jl"))
using SparseArrays
source=read(ARGS[1],String)
include_string(Main,first(split(source,"function main()";limit=2)),"full_scope_original_definitions.jl")
ref=JSON3.read(read(ARGS[2],String))
refs=Dict(String(k)=>[Float64.(collect(x)) for x in v] for (k,v) in pairs(ref.references))
rtols=[1e-4,1e-6,1e-8]
grid(T)=collect(range(0.0,T,length=101))
select(names)=filter(x->x[1] in names,vcat(IMPLICIT_ALGS,EXPLICIT_ALGS))
# Representative distinct families on every original full-grid ODE and
# mass case. No arbitrary split-ODE or symplectic reformulation here.
const ODE_NAMES=["rosenbrock23","rodas4p","rodas5pr","rodas6p","trbdf2","kvaerno5","kencarp4","qndf","radauiia3","radauiia9","vern7","autotsit5-rosenbrock23","autovern7-rodas5p"]
const MASS_NAMES=["rosenbrock23","rodas4p","rodas5pr","rodas6p","trbdf2","kvaerno5","qndf","radauiia5","radauiia9"]
function runprob(id,prob,ts,ref,scales,af,names=ODE_NAMES;constraints=nothing)
    for (name,ctor) in select(names)
        benchmark_case(prob,id,name,ctor,ts,ref,scales,rtols;cap=100000,warmups=2,repeats=5,atol_factor=af,constraints=constraints)
    end
end
tk=grid(20pi)
runprob("kepler-ecc05",ODEProblem(kepler_rhs!,[0.5,0.0,0.0,sqrt(3.0)],(0.,20pi)),tk,[kepler_exact(t) for t in tk],ones(4),1e-2)
tk=grid(5.)
runprob("nonnormal-kreiss-b100",ODEProblem(kreiss_rhs!,[0.,1.],(0.,5.)),tk,[[100*(exp(-t)-exp(-2t)),exp(-2t)] for t in tk],ones(2),1e-2)
tk=grid(10.)
runprob("prothero-robinson-1e4",ODEProblem(ODEFunction(pr_rhs!,jac=pr_jac!),[0.],(0.,10.)),tk,[[sin(t)] for t in tk],ones(1),1e-2)
for (id,make,T,n) in [("periodic-advdiff-n256",make_advdiff_256,1.,256),("brusselator-1d-jvp-n400",make_bruss_400,10.,400)]
    rhs,jvp,jac,proto,y0=make()
    p=ODEProblem(ODEFunction(rhs,jac=jac,jac_prototype=proto),y0,(0.,T))
    runprob(id,p,grid(T),refs[id],ones(n),1.)
end
runprob("stiff-burst-switching",ODEProblem(ODEFunction(burst_rhs!,jac=burst_jac!),[1.,0.],(0.,6.)),grid(6.),refs["stiff-burst-switching"],ones(2),1e-2)
function rob!(dy,y,p,t)
    dy[1]=-0.04*y[1]+1e4*y[2]*y[3]
    dy[2]=0.04*y[1]-1e4*y[2]*y[3]-3e7*y[2]^2
    dy[3]=y[1]+y[2]+y[3]-1.
end
function ana!(dy,y,p,t)
    dy[1]=-y[1]+y[2]
    dy[2]=y[1]+y[2]-(2sin(t)+cos(t))
end
function ill!(dy,y,p,t)
    dy[1]=-y[1];dy[2]=-1e-8*y[2]
end
p=ODEProblem(ODEFunction(rob!,mass_matrix=[1. 0. 0.;0. 1. 0.;0. 0. 0.]),[1.,0.,0.],(0.,40.))
runprob("dae-robertson-index1",p,grid(40.),refs["dae-robertson-index1"],fill(1e-4,3),1e-4,MASS_NAMES;constraints=(t,y)->abs(sum(y)-1.))
p=ODEProblem(ODEFunction(ana!,mass_matrix=[1. 0.;0. 0.]),[0.,1.],(0.,5.))
tk=grid(5.)
runprob("dae-index1-analytic",p,tk,[[sin(t),sin(t)+cos(t)] for t in tk],ones(2),1e-2,MASS_NAMES;constraints=(t,y)->abs(sum(y)-(2sin(t)+cos(t))))
p=ODEProblem(ODEFunction(ill!,mass_matrix=[1. 0.;0. 1e-8]),[1.,2.],(0.,1.))
tk=grid(1.)
runprob("mass-ill-conditioned",p,tk,[[exp(-t),2exp(-t)] for t in tk],ones(2),1e-2,MASS_NAMES)
# Native event callbacks. Distinguish a solver success code from correct event count.
function harm!(dy,y,p,t);dy[1]=y[2];dy[2]=-y[1];end
p=ODEProblem(harm!,[1.,0.],(0.,8.5))
for (name,ctor) in select(["rosenbrock23","rodas4p","rodas5pr","trbdf2","kvaerno5","qndf","radauiia5","vern7","autotsit5-rosenbrock23"])
 for terminal in (false,true), tol in rtols
    row=Dict{String,Any}("problem"=>terminal ? "event-terminal-first" : "event-root-finding","arm"=>"julia-"*name*(terminal ? "-terminal" : "-callback"),"rtol"=>tol,"ok"=>false,"wall_ms_median"=>nothing,"error_common"=>nothing)
    try
        times=Int[]; roots=Float64[];local sol
        for k in 1:7
            empty!(roots)
            affect!(integrator)=begin push!(roots,integrator.t);if terminal;terminate!(integrator);end;end
            cb=ContinuousCallback((u,t,integrator)->u[1],affect!)
            start=time_ns();sol=solve(p,ctor();reltol=tol,abstol=tol*1e-2,callback=cb,maxiters=100000);dt=Int(time_ns()-start)
            expected=terminal ? 1 : 3
            if !SciMLBase.successful_retcode(sol.retcode)||length(roots)!=expected||(terminal ? sol.t[end]!=roots[1] : sol.t[end]!=8.5)
                row["reason"]="event-count, termination, or retcode mismatch";break
            end
            k>2 && push!(times,dt)
        end
        row["roots_found"]=copy(roots);row["final_t"]=sol.t[end];row["retcode"]=string(sol.retcode)
        row["raw_timing_samples_ns"]=times
        if length(times)==5
            row["ok"]=true;row["wall_ms_median"]=median(times)/1e6
            row["max_root_err"]=maximum(abs.(roots.-(terminal ? [pi/2] : [pi/2,3pi/2,5pi/2])))
        end
        row["nf"]=sol.stats.nf;row["accepted"]=sol.stats.naccept;row["rejected"]=sol.stats.nreject
    catch e
        row["reason"]=sprint(showerror,e)
    end
    println(JSON3.write(row));flush(stdout)
 end
end
