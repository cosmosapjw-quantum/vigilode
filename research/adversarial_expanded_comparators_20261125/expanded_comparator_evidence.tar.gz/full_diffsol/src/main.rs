use std::alloc::{GlobalAlloc, Layout, System};
use std::env;
use std::f64::consts::PI;
use std::ffi::c_void;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::Instant;

use diffsol::{
    DenseMatrix, FaerLU, FaerMat, FaerSparseLU, FaerSparseMat, MatrixCommon, OdeBuilder,
    OdeSolverMethod, OdeSolverStopReason, VectorHost,
};
use rodas5p_core::{DenseMatrix as CoreDenseMatrix, LinearMethod, LinearSolverConfig};
use rodas5p_integrators::{
    integrate_pexprb54s4_fused_adaptive_observed, integrate_rodas5p_fast_banded_observed,
    integrate_rodas5p_fast_observed, integrate_rodas5p_fast_small_observed,
    integrate_rodas5p_mf_fast_observed_gmres_into_ls_workspace, AdaptiveStepConfig,
    BandedJacobian, FusedPhiKrylovConfig, OdeProblem, OutputSchedule, ParallelExecution,
    SmallProblem,
};
use serde_json::{json, Value};
use vigilode::coloring::SparsityPattern;
use vigilode::prelude::*;
use vigilode::{
    DerivativeFallback, Direction, Dopri5Ensemble, Dopri5EnsembleJob, SwitchingConfig,
    SwitchingSolver,
};

// ---------------- Counting Allocator + C Interposition ----------------
struct Counting;
static TRACK: AtomicBool = AtomicBool::new(false);
static RUST_CALLS: AtomicU64 = AtomicU64::new(0);
static RUST_BYTES: AtomicU64 = AtomicU64::new(0);
static HEAP_CALLS: AtomicU64 = AtomicU64::new(0);
static HEAP_BYTES: AtomicU64 = AtomicU64::new(0);

unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: Layout) -> *mut u8 {
        if TRACK.load(Ordering::Relaxed) {
            RUST_CALLS.fetch_add(1, Ordering::Relaxed);
            RUST_BYTES.fetch_add(l.size() as u64, Ordering::Relaxed);
        }
        unsafe { System.alloc(l) }
    }
    unsafe fn alloc_zeroed(&self, l: Layout) -> *mut u8 {
        if TRACK.load(Ordering::Relaxed) {
            RUST_CALLS.fetch_add(1, Ordering::Relaxed);
            RUST_BYTES.fetch_add(l.size() as u64, Ordering::Relaxed);
        }
        unsafe { System.alloc_zeroed(l) }
    }
    unsafe fn dealloc(&self, p: *mut u8, l: Layout) {
        unsafe { System.dealloc(p, l) }
    }
    unsafe fn realloc(&self, p: *mut u8, l: Layout, n: usize) -> *mut u8 {
        if TRACK.load(Ordering::Relaxed) {
            RUST_CALLS.fetch_add(1, Ordering::Relaxed);
            RUST_BYTES.fetch_add(n as u64, Ordering::Relaxed);
        }
        unsafe { System.realloc(p, l, n) }
    }
}

#[global_allocator]
static GLOBAL: Counting = Counting;

unsafe extern "C" {
    fn __libc_malloc(size: usize) -> *mut c_void;
    fn __libc_calloc(n: usize, size: usize) -> *mut c_void;
    fn __libc_realloc(p: *mut c_void, size: usize) -> *mut c_void;
    fn __libc_memalign(align: usize, size: usize) -> *mut c_void;
}

#[inline]
fn count_c(bytes: usize) {
    if TRACK.load(Ordering::Relaxed) {
        HEAP_CALLS.fetch_add(1, Ordering::Relaxed);
        HEAP_BYTES.fetch_add(bytes as u64, Ordering::Relaxed);
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn malloc(size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_malloc(size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn calloc(n: usize, size: usize) -> *mut c_void {
    count_c(n.saturating_mul(size));
    unsafe { __libc_calloc(n, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn realloc(p: *mut c_void, size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_realloc(p, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn memalign(align: usize, size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_memalign(align, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn aligned_alloc(align: usize, size: usize) -> *mut c_void {
    count_c(size);
    unsafe { __libc_memalign(align, size) }
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn posix_memalign(out: *mut *mut c_void, align: usize, size: usize) -> i32 {
    if !align.is_power_of_two() || !align.is_multiple_of(std::mem::size_of::<*mut c_void>()) {
        return 22;
    }
    count_c(size);
    let p = unsafe { __libc_memalign(align, size) };
    if p.is_null() && size != 0 {
        return 12;
    }
    unsafe { *out = p };
    0
}

#[derive(Clone, Copy, Default)]
struct AllocSnap {
    rust_calls: u64,
    rust_bytes: u64,
    heap_calls: u64,
    heap_bytes: u64,
}

fn alloc_begin() {
    RUST_CALLS.store(0, Ordering::SeqCst);
    RUST_BYTES.store(0, Ordering::SeqCst);
    HEAP_CALLS.store(0, Ordering::SeqCst);
    HEAP_BYTES.store(0, Ordering::SeqCst);
    TRACK.store(true, Ordering::SeqCst);
}

fn alloc_end() -> AllocSnap {
    TRACK.store(false, Ordering::SeqCst);
    AllocSnap {
        rust_calls: RUST_CALLS.load(Ordering::SeqCst),
        rust_bytes: RUST_BYTES.load(Ordering::SeqCst),
        heap_calls: HEAP_CALLS.load(Ordering::SeqCst),
        heap_bytes: HEAP_BYTES.load(Ordering::SeqCst),
    }
}

// ---------------- Native FFI ----------------
type RhsCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *mut f64);
type JacCb = unsafe extern "C" fn(*const c_void, f64, *const f64, i32, i32, i32, *mut f64);
type JvpCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *const f64, *mut f64);
type DfxCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *mut f64);
type MasCb = unsafe extern "C" fn(*const c_void, i32, i32, *mut f64);
type RootCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *mut f64);
type ResCb = unsafe extern "C" fn(*const c_void, f64, *const f64, *const f64, *mut f64);
type IdaJacCb = unsafe extern "C" fn(*const c_void, f64, f64, *const f64, *const f64, i32, i32, *mut f64);

unsafe extern "C" {
    fn fs_dvode(
        ctx: *const c_void,
        rhs: RhsCb,
        jac: Option<JacCb>,
        mf_in: i32,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        rtol: f64,
        atol: f64,
        ml: i32,
        mu: i32,
        max_steps: i32,
        values: *mut f64,
        completed: *mut i32,
        code: *mut i32,
        stats: *mut i32,
    );
    fn fs_hairer(
        which: i32,
        ctx: *const c_void,
        rhs: RhsCb,
        jac: Option<JacCb>,
        dfx: Option<DfxCb>,
        mas: Option<MasCb>,
        ifcn_in: i32,
        idfx_in: i32,
        imas_in: i32,
        n_ind1: i32,
        n_ind2: i32,
        n_ind3: i32,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        rtol: f64,
        atol: f64,
        ml: i32,
        mu: i32,
        max_steps: i32,
        values: *mut f64,
        completed: *mut i32,
        code: *mut i32,
        stats: *mut i32,
    );
    fn fs_cvode(
        ctx: *const c_void,
        rhs: RhsCb,
        jac: Option<JacCb>,
        jvp: Option<JvpCb>,
        root_fn: Option<RootCb>,
        mode: i32,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        rtol: f64,
        atol: f64,
        ml: i32,
        mu: i32,
        max_steps: i64,
        nroots: i32,
        stop_on_root: i32,
        values: *mut f64,
        completed: *mut i32,
        root_times: *mut f64,
        root_count: *mut i32,
        max_roots: i32,
        stats: *mut i64,
    ) -> i32;
    fn fs_ida(
        ctx: *const c_void,
        res_fn: ResCb,
        jac_fn: Option<IdaJacCb>,
        n: i32,
        nt: i32,
        times: *const f64,
        y0: *const f64,
        yp0: *const f64,
        id_vec: *const f64,
        rtol: f64,
        atol: f64,
        max_steps: i64,
        calc_ic: i32,
        values: *mut f64,
        completed: *mut i32,
        stats: *mut i64,
    ) -> i32;
}

// ---------------- Shared Model & Metrics ----------------
fn make_grid(t0: f64, t1: f64, pts: usize) -> Vec<f64> {
    let mut g: Vec<f64> = (0..pts)
        .map(|k| t0 + (t1 - t0) * k as f64 / (pts - 1) as f64)
        .collect();
    *g.last_mut().unwrap() = t1;
    g
}

fn max_wrms(states: &[Vec<f64>], reference: &[Vec<f64>], atol_scale: &[f64]) -> Option<f64> {
    if states.len() != reference.len() || states.is_empty() {
        return None;
    }
    let n = atol_scale.len();
    let sqrt_n = (n as f64).sqrt();
    let mut worst = 0.0_f64;
    for (y, r) in states.iter().zip(reference.iter()) {
        if y.len() != n || r.len() != n {
            return None;
        }
        let mut norm = 0.0_f64;
        for i in 0..n {
            if !y[i].is_finite() {
                return None;
            }
            let sc = atol_scale[i] + r[i].abs();
            let e = (y[i] - r[i]) / sc;
            norm = norm.hypot(e / sqrt_n);
        }
        worst = worst.max(norm);
    }
    Some(worst)
}

#[derive(Clone, Default)]
struct ArmRun {
    ok: bool,
    err_msg: String,
    states: Vec<Vec<f64>>,
    nf: Option<u64>,
    njac: Option<u64>,
    njvp: Option<u64>,
    nlu: Option<u64>,
    nsolve: Option<u64>,
    accepted: Option<u64>,
    rejected: Option<u64>,
    extra: Value,
}

fn timed_run<F: FnMut() -> ArmRun>(
    problem: &str,
    arm: &str,
    rtol: f64,
    ref_states: Option<&[Vec<f64>]>,
    atol_scale: &[f64],
    mut f: F,
) -> Value {
    for _ in 0..2 {
        let w = f();
        if !w.ok {
            return json!({
                "problem": problem, "arm": arm, "rtol": rtol, "ok": false,
                "err_msg": w.err_msg, "error_common": null, "wall_ms_median": null,
                "nf": w.nf, "njac": w.njac, "njvp": w.njvp, "nlu": w.nlu, "nsolve": w.nsolve,
                "accepted": w.accepted, "rejected": w.rejected,
                "rust_alloc_calls": null, "heap_alloc_calls": null, "heap_alloc_bytes": null,
                "extra": w.extra, "timing_authority": "diagnostic_only"
            });
        }
    }
    let mut times_ns = Vec::with_capacity(5);
    let mut last = ArmRun::default();
    let mut alloc = AllocSnap::default();
    for rep in 0..5 {
        if rep == 0 {
            alloc_begin();
        }
        let t0 = Instant::now();
        last = f();
        let dt = t0.elapsed().as_nanos() as u64;
        if rep == 0 {
            alloc = alloc_end();
        }
        if !last.ok {
            return json!({
                "problem": problem, "arm": arm, "rtol": rtol, "ok": false,
                "err_msg": last.err_msg, "error_common": null, "wall_ms_median": null,
                "nf": last.nf, "njac": last.njac, "njvp": last.njvp, "nlu": last.nlu, "nsolve": last.nsolve,
                "accepted": last.accepted, "rejected": last.rejected,
                "rust_alloc_calls": alloc.rust_calls, "heap_alloc_calls": alloc.heap_calls,
                "heap_alloc_bytes": alloc.heap_bytes, "extra": last.extra,
                "timing_authority": "diagnostic_only"
            });
        }
        times_ns.push(dt);
    }
    times_ns.sort_unstable();
    let med_ms = times_ns[times_ns.len() / 2] as f64 * 1e-6;
    let err = ref_states.and_then(|r| max_wrms(&last.states, r, atol_scale));
    json!({
        "problem": problem, "arm": arm, "rtol": rtol, "ok": true, "err_msg": "",
        "error_common": err, "wall_ms_median": med_ms,
        "nf": last.nf, "njac": last.njac, "njvp": last.njvp, "nlu": last.nlu, "nsolve": last.nsolve,
        "accepted": last.accepted, "rejected": last.rejected,
        "rust_alloc_calls": alloc.rust_calls, "rust_alloc_bytes": alloc.rust_bytes,
        "heap_alloc_calls": alloc.heap_calls, "heap_alloc_bytes": alloc.heap_bytes,
        "extra": last.extra, "timing_authority": "diagnostic_only"
    })
}

fn col_to_rows(vals: &[f64], n: usize, nt: usize) -> Vec<Vec<f64>> {
    (0..nt)
        .map(|k| vals[k * n..(k + 1) * n].to_vec())
        .collect()
}

// ---------------- Problem Definitions & Native Callbacks ----------------
#[derive(Clone, Copy)]
enum NativeProb {
    Kepler,
    Kreiss,
    Pr1e4,
    AdvDiff256,
    Bruss400,
    DaeRob,
    DaeAna,
    MassIll,
    DaePend,
    Burst,
    RobFd,
    Harmonic,
}

impl NativeProb {
    fn n(self) -> usize {
        match self {
            Self::Kepler => 4,
            Self::Kreiss | Self::DaeAna | Self::MassIll | Self::Burst | Self::Harmonic => 2,
            Self::Pr1e4 => 1,
            Self::AdvDiff256 => 256,
            Self::Bruss400 => 400,
            Self::DaeRob | Self::RobFd => 3,
            Self::DaePend => 5,
        }
    }
    fn rhs(self, t: f64, y: &[f64], dy: &mut [f64]) {
        match self {
            Self::Kepler => {
                let r2 = y[0] * y[0] + y[1] * y[1];
                let inv_r3 = -1.0 / (r2 * r2.sqrt());
                dy[0] = y[2];
                dy[1] = y[3];
                dy[2] = inv_r3 * y[0];
                dy[3] = inv_r3 * y[1];
            }
            Self::Kreiss => {
                dy[0] = -y[0] + 100.0 * y[1];
                dy[1] = -2.0 * y[1];
            }
            Self::Pr1e4 => {
                dy[0] = -1.0e4 * (y[0] - t.sin()) + t.cos();
            }
            Self::AdvDiff256 => {
                let n = 256usize;
                let d = 0.01 * (n as f64) * (n as f64);
                let v = 1.0 * (n as f64);
                for i in 0..n {
                    let im1 = if i == 0 { n - 1 } else { i - 1 };
                    let ip1 = if i + 1 == n { 0 } else { i + 1 };
                    dy[i] = d * (y[im1] - 2.0 * y[i] + y[ip1]) - v * (y[i] - y[im1]);
                }
            }
            Self::Bruss400 => {
                let nc = 200usize;
                let dx = 1.0 / (nc as f64 + 1.0);
                let c = 0.02 / (dx * dx);
                for i in 0..nc {
                    let (u, v) = (y[2 * i], y[2 * i + 1]);
                    let ul = if i == 0 { 1.0 } else { y[2 * (i - 1)] };
                    let vl = if i == 0 { 3.0 } else { y[2 * (i - 1) + 1] };
                    let ur = if i + 1 == nc { 1.0 } else { y[2 * (i + 1)] };
                    let vr = if i + 1 == nc { 3.0 } else { y[2 * (i + 1) + 1] };
                    dy[2 * i] = 1.0 + u * u * v - 4.4 * u + c * (ul - 2.0 * u + ur);
                    dy[2 * i + 1] = 3.4 * u - u * u * v + c * (vl - 2.0 * v + vr);
                }
            }
            Self::DaeRob => {
                dy[0] = -0.04 * y[0] + 1.0e4 * y[1] * y[2];
                dy[1] = 0.04 * y[0] - 1.0e4 * y[1] * y[2] - 3.0e7 * y[1] * y[1];
                dy[2] = y[0] + y[1] + y[2] - 1.0;
            }
            Self::DaeAna => {
                dy[0] = -y[0] + y[1];
                dy[1] = y[0] + y[1] - (2.0 * t.sin() + t.cos());
            }
            Self::MassIll => {
                dy[0] = -y[0];
                dy[1] = -1.0e-8 * y[1];
            }
            Self::DaePend => {
                let (x, z, vx, vz, lam) = (y[0], y[1], y[2], y[3], y[4]);
                dy[0] = vx;
                dy[1] = vz;
                dy[2] = -lam * x;
                dy[3] = -1.0 - lam * z;
                dy[4] = x * x + z * z - 1.0;
            }
            Self::Burst => {
                let lam = 5000.0 * (-40.0 * (t - 3.0) * (t - 3.0)).exp();
                dy[0] = y[1];
                dy[1] = -y[0] - lam * (y[1] + t.sin()) - t.cos();
            }
            Self::RobFd => {
                dy[0] = -0.04 * y[0] + 1.0e4 * y[1] * y[2];
                dy[1] = 0.04 * y[0] - 1.0e4 * y[1] * y[2] - 3.0e7 * y[1] * y[1];
                dy[2] = 3.0e7 * y[1] * y[1];
            }
            Self::Harmonic => {
                dy[0] = y[1];
                dy[1] = -y[0];
            }
        }
    }
    fn dfx(self, t: f64, _y: &[f64], out: &mut [f64]) {
        match self {
            Self::Pr1e4 => {
                out[0] = -1.0e4 * (-t.cos()) - t.sin();
            }
            _ => out.fill(0.0),
        }
    }
    fn jvp(self, t: f64, y: &[f64], v: &[f64], out: &mut [f64]) {
        match self {
            Self::Kepler => {
                let r2 = y[0] * y[0] + y[1] * y[1];
                let r = r2.sqrt();
                let r3 = r2 * r;
                let r5 = r3 * r2;
                let dot = y[0] * v[0] + y[1] * v[1];
                out[0] = v[2];
                out[1] = v[3];
                out[2] = -v[0] / r3 + 3.0 * dot * y[0] / r5;
                out[3] = -v[1] / r3 + 3.0 * dot * y[1] / r5;
            }
            Self::Kreiss => {
                out[0] = -v[0] + 100.0 * v[1];
                out[1] = -2.0 * v[1];
            }
            Self::Pr1e4 => {
                out[0] = -1.0e4 * v[0];
            }
            Self::AdvDiff256 => {
                let n = 256usize;
                let d = 0.01 * (n as f64) * (n as f64);
                let vel = 1.0 * (n as f64);
                for i in 0..n {
                    let im1 = if i == 0 { n - 1 } else { i - 1 };
                    let ip1 = if i + 1 == n { 0 } else { i + 1 };
                    out[i] = d * (v[im1] - 2.0 * v[i] + v[ip1]) - vel * (v[i] - v[im1]);
                }
            }
            Self::Bruss400 => {
                let nc = 200usize;
                let dx = 1.0 / (nc as f64 + 1.0);
                let c = 0.02 / (dx * dx);
                for i in 0..nc {
                    let (u, vv) = (y[2 * i], y[2 * i + 1]);
                    let (du, dv) = (v[2 * i], v[2 * i + 1]);
                    let dul = if i == 0 { 0.0 } else { v[2 * (i - 1)] };
                    let dvl = if i == 0 { 0.0 } else { v[2 * (i - 1) + 1] };
                    let dur = if i + 1 == nc { 0.0 } else { v[2 * (i + 1)] };
                    let dvr = if i + 1 == nc { 0.0 } else { v[2 * (i + 1) + 1] };
                    out[2 * i] = (2.0 * u * vv - 4.4 - 2.0 * c) * du + (u * u) * dv + c * (dul + dur);
                    out[2 * i + 1] = (3.4 - 2.0 * u * vv) * du + (-u * u - 2.0 * c) * dv + c * (dvl + dvr);
                }
            }
            Self::DaeRob => {
                out[0] = -0.04 * v[0] + 1.0e4 * y[2] * v[1] + 1.0e4 * y[1] * v[2];
                out[1] = 0.04 * v[0] + (-1.0e4 * y[2] - 6.0e7 * y[1]) * v[1] - 1.0e4 * y[1] * v[2];
                out[2] = v[0] + v[1] + v[2];
            }
            Self::DaeAna => {
                out[0] = -v[0] + v[1];
                out[1] = v[0] + v[1];
            }
            Self::MassIll => {
                out[0] = -v[0];
                out[1] = -1.0e-8 * v[1];
            }
            Self::DaePend => {
                let (x, z, lam) = (y[0], y[1], y[4]);
                out[0] = v[2];
                out[1] = v[3];
                out[2] = -lam * v[0] - x * v[4];
                out[3] = -lam * v[1] - z * v[4];
                out[4] = 2.0 * x * v[0] + 2.0 * z * v[1];
            }
            Self::Burst => {
                let lam = 5000.0 * (-40.0 * (t - 3.0) * (t - 3.0)).exp();
                out[0] = v[1];
                out[1] = -v[0] - lam * v[1];
            }
            Self::RobFd => {
                out[0] = -0.04 * v[0] + 1.0e4 * y[2] * v[1] + 1.0e4 * y[1] * v[2];
                out[1] = 0.04 * v[0] + (-1.0e4 * y[2] - 6.0e7 * y[1]) * v[1] - 1.0e4 * y[1] * v[2];
                out[2] = 6.0e7 * y[1] * v[1];
            }
            Self::Harmonic => {
                out[0] = v[1];
                out[1] = -v[0];
            }
        }
    }
    fn jac_entries(self, t: f64, y: &[f64], mut emit: impl FnMut(usize, usize, f64)) {
        match self {
            Self::Kepler => {
                let r2 = y[0] * y[0] + y[1] * y[1];
                let r = r2.sqrt();
                let r3 = r2 * r;
                let r5 = r3 * r2;
                emit(0, 2, 1.0);
                emit(1, 3, 1.0);
                emit(2, 0, -1.0 / r3 + 3.0 * y[0] * y[0] / r5);
                emit(2, 1, 3.0 * y[0] * y[1] / r5);
                emit(3, 0, 3.0 * y[0] * y[1] / r5);
                emit(3, 1, -1.0 / r3 + 3.0 * y[1] * y[1] / r5);
            }
            Self::Kreiss => {
                emit(0, 0, -1.0);
                emit(0, 1, 100.0);
                emit(1, 1, -2.0);
            }
            Self::Pr1e4 => {
                emit(0, 0, -1.0e4);
            }
            Self::AdvDiff256 => {
                let n = 256usize;
                let d = 0.01 * (n as f64) * (n as f64);
                let vel = 1.0 * (n as f64);
                for i in 0..n {
                    let im1 = if i == 0 { n - 1 } else { i - 1 };
                    let ip1 = if i + 1 == n { 0 } else { i + 1 };
                    emit(i, im1, d + vel);
                    emit(i, i, -2.0 * d - vel);
                    emit(i, ip1, d);
                }
            }
            Self::Bruss400 => {
                let nc = 200usize;
                let dx = 1.0 / (nc as f64 + 1.0);
                let c = 0.02 / (dx * dx);
                for i in 0..nc {
                    let (u, v) = (y[2 * i], y[2 * i + 1]);
                    emit(2 * i, 2 * i, 2.0 * u * v - 4.4 - 2.0 * c);
                    emit(2 * i, 2 * i + 1, u * u);
                    emit(2 * i + 1, 2 * i, 3.4 - 2.0 * u * v);
                    emit(2 * i + 1, 2 * i + 1, -u * u - 2.0 * c);
                    if i > 0 {
                        emit(2 * i, 2 * (i - 1), c);
                        emit(2 * i + 1, 2 * (i - 1) + 1, c);
                    }
                    if i + 1 < nc {
                        emit(2 * i, 2 * (i + 1), c);
                        emit(2 * i + 1, 2 * (i + 1) + 1, c);
                    }
                }
            }
            Self::DaeRob => {
                emit(0, 0, -0.04);
                emit(0, 1, 1.0e4 * y[2]);
                emit(0, 2, 1.0e4 * y[1]);
                emit(1, 0, 0.04);
                emit(1, 1, -1.0e4 * y[2] - 6.0e7 * y[1]);
                emit(1, 2, -1.0e4 * y[1]);
                emit(2, 0, 1.0);
                emit(2, 1, 1.0);
                emit(2, 2, 1.0);
            }
            Self::DaeAna => {
                emit(0, 0, -1.0);
                emit(0, 1, 1.0);
                emit(1, 0, 1.0);
                emit(1, 1, 1.0);
            }
            Self::MassIll => {
                emit(0, 0, -1.0);
                emit(1, 1, -1.0e-8);
            }
            Self::DaePend => {
                let (x, z, lam) = (y[0], y[1], y[4]);
                emit(0, 2, 1.0);
                emit(1, 3, 1.0);
                emit(2, 0, -lam);
                emit(2, 4, -x);
                emit(3, 1, -lam);
                emit(3, 4, -z);
                emit(4, 0, 2.0 * x);
                emit(4, 1, 2.0 * z);
            }
            Self::Burst => {
                let lam = 5000.0 * (-40.0 * (t - 3.0) * (t - 3.0)).exp();
                emit(0, 1, 1.0);
                emit(1, 0, -1.0);
                emit(1, 1, -lam);
            }
            Self::RobFd => {
                emit(0, 0, -0.04);
                emit(0, 1, 1.0e4 * y[2]);
                emit(0, 2, 1.0e4 * y[1]);
                emit(1, 0, 0.04);
                emit(1, 1, -1.0e4 * y[2] - 6.0e7 * y[1]);
                emit(1, 2, -1.0e4 * y[1]);
                emit(2, 1, 6.0e7 * y[1]);
            }
            Self::Harmonic => {
                emit(0, 1, 1.0);
                emit(1, 0, -1.0);
            }
        }
    }
    fn jac_dense_row_major(self, t: f64, y: &[f64], out: &mut [f64]) {
        let n = self.n();
        out.fill(0.0);
        self.jac_entries(t, y, |i, j, v| out[i * n + j] = v);
    }
    fn jac_dense_col_major(self, t: f64, y: &[f64], ld: usize, pd: &mut [f64]) {
        let n = self.n();
        pd[..ld * n].fill(0.0);
        self.jac_entries(t, y, |i, j, v| pd[j * ld + i] = v);
    }
    fn jac_band_col_major(self, t: f64, y: &[f64], ml: usize, mu: usize, ld: usize, pd: &mut [f64]) {
        let n = self.n();
        pd[..ld * (n - 1) + ml + mu + 1].fill(0.0);
        self.jac_entries(t, y, |i, j, v| {
            if i <= j + ml && j <= i + mu {
                pd[j * ld + (mu + i - j)] = v;
            }
        });
    }
    fn jac_band_row_major(self, t: f64, y: &[f64], ml: usize, mu: usize, out: &mut [f64]) {
        let w = ml + mu + 1;
        out.fill(0.0);
        self.jac_entries(t, y, |i, j, v| {
            if i <= j + ml && j <= i + mu {
                out[i * w + (j + ml - i)] = v;
            }
        });
    }
    fn mass_diag(self) -> Option<Vec<f64>> {
        match self {
            Self::DaeRob => Some(vec![1.0, 1.0, 0.0]),
            Self::DaeAna => Some(vec![1.0, 0.0]),
            Self::MassIll => Some(vec![1.0, 1.0e-8]),
            Self::DaePend => Some(vec![1.0, 1.0, 1.0, 1.0, 0.0]),
            _ => None,
        }
    }
}

unsafe extern "C" fn cb_rhs(ctx: *const c_void, t: f64, y: *const f64, f: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    p.rhs(t, unsafe { std::slice::from_raw_parts(y, n) }, unsafe {
        std::slice::from_raw_parts_mut(f, n)
    });
}
unsafe extern "C" fn cb_jac(
    ctx: *const c_void,
    t: f64,
    y: *const f64,
    ml: i32,
    mu: i32,
    ld: i32,
    pd: *mut f64,
) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    let ys = unsafe { std::slice::from_raw_parts(y, n) };
    if ml < 0 {
        let pds = unsafe { std::slice::from_raw_parts_mut(pd, (ld as usize) * n) };
        p.jac_dense_col_major(t, ys, ld as usize, pds);
    } else {
        let (mlu, muu, ldu) = (ml as usize, mu as usize, ld as usize);
        let pds = unsafe { std::slice::from_raw_parts_mut(pd, ldu * (n - 1) + mlu + muu + 1) };
        p.jac_band_col_major(t, ys, mlu, muu, ldu, pds);
    }
}
unsafe extern "C" fn cb_jvp(ctx: *const c_void, t: f64, y: *const f64, v: *const f64, jv: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    p.jvp(
        t,
        unsafe { std::slice::from_raw_parts(y, n) },
        unsafe { std::slice::from_raw_parts(v, n) },
        unsafe { std::slice::from_raw_parts_mut(jv, n) },
    );
}
unsafe extern "C" fn cb_dfx(ctx: *const c_void, t: f64, y: *const f64, fx: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    p.dfx(t, unsafe { std::slice::from_raw_parts(y, n) }, unsafe {
        std::slice::from_raw_parts_mut(fx, n)
    });
}
unsafe extern "C" fn cb_mas(ctx: *const c_void, n: i32, ld: i32, am: *mut f64) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let nu = n as usize;
    let ldu = ld as usize;
    let ams = unsafe { std::slice::from_raw_parts_mut(am, ldu * nu) };
    ams.fill(0.0);
    if let Some(d) = p.mass_diag() {
        for i in 0..nu {
            ams[i * ldu + i] = d[i];
        }
    }
}
unsafe extern "C" fn cb_root_y0(ctx: *const c_void, _t: f64, y: *const f64, gout: *mut f64) {
    let _ = ctx;
    unsafe { *gout = *y };
}
unsafe extern "C" fn cb_ida_res(
    ctx: *const c_void,
    t: f64,
    y: *const f64,
    yp: *const f64,
    res: *mut f64,
) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let n = p.n();
    let ys = unsafe { std::slice::from_raw_parts(y, n) };
    let yps = unsafe { std::slice::from_raw_parts(yp, n) };
    let ress = unsafe { std::slice::from_raw_parts_mut(res, n) };
    p.rhs(t, ys, ress);
    let md = p.mass_diag().unwrap();
    for i in 0..n {
        // F = M * yp - f(t, y)
        ress[i] = md[i] * yps[i] - ress[i];
    }
}
unsafe extern "C" fn cb_ida_jac(
    ctx: *const c_void,
    t: f64,
    cj: f64,
    y: *const f64,
    _yp: *const f64,
    n: i32,
    ld: i32,
    pd: *mut f64,
) {
    let p = unsafe { &*(ctx as *const NativeProb) };
    let nu = n as usize;
    let ldu = ld as usize;
    let ys = unsafe { std::slice::from_raw_parts(y, nu) };
    let pds = unsafe { std::slice::from_raw_parts_mut(pd, ldu * nu) };
    pds.fill(0.0);
    // dF/dy + cj * dF/dyp = -df/dy + cj * M
    p.jac_entries(t, ys, |i, j, v| pds[j * ldu + i] = -v);
    let md = p.mass_diag().unwrap();
    for i in 0..nu {
        pds[i * ldu + i] += cj * md[i];
    }
}

// ---------------- Generic Runners ----------------
fn run_dvode(
    p: NativeProb,
    mf: i32,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    band: Option<(i32, i32)>,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let (mut completed, mut code) = (0i32, 0i32);
    let mut stats = [0i32; 8];
    let (ml, mu) = band.unwrap_or((-1, -1));
    let jac_opt = if mf == 21 || mf == 24 { Some(cb_jac as JacCb) } else { None };
    unsafe {
        fs_dvode(
            &p as *const NativeProb as *const c_void,
            cb_rhs,
            jac_opt,
            mf,
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            rtol,
            atol,
            ml,
            mu,
            100_000,
            vals.as_mut_ptr(),
            &mut completed,
            &mut code,
            stats.as_mut_ptr(),
        );
    }
    let ok = code == 2 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("ISTATE={code}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some(stats[1] as u64),
        njac: Some(stats[2] as u64),
        njvp: None,
        nlu: Some(stats[3] as u64),
        nsolve: None,
        accepted: Some(stats[0] as u64),
        rejected: Some(stats[6] as u64),
        extra: json!({"nni": stats[4], "ncfn": stats[5]}),
    }
}

fn run_cvode(
    p: NativeProb,
    mode: i32,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    band: Option<(i32, i32)>,
    analytic_jac: bool,
    max_steps: i64,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let mut completed = 0i32;
    let mut root_count = 0i32;
    let mut stats = [0i64; 9];
    let (ml, mu) = band.unwrap_or((-1, -1));
    let jac_opt = if analytic_jac && (mode == 0 || mode == 1) {
        Some(cb_jac as JacCb)
    } else {
        None
    };
    let jvp_opt = if mode == 2 { Some(cb_jvp as JvpCb) } else { None };
    let flag = unsafe {
        fs_cvode(
            &p as *const NativeProb as *const c_void,
            cb_rhs,
            jac_opt,
            jvp_opt,
            None,
            mode,
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            rtol,
            atol,
            ml,
            mu,
            max_steps,
            0,
            0,
            vals.as_mut_ptr(),
            &mut completed,
            std::ptr::null_mut(),
            &mut root_count,
            0,
            stats.as_mut_ptr(),
        )
    };
    let ok = flag == 0 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("CVODE flag={flag}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some((stats[1] + stats[7]) as u64),
        njac: Some(stats[6] as u64),
        njvp: None,
        nlu: Some(stats[2] as u64),
        nsolve: None,
        accepted: Some(stats[0] as u64),
        rejected: Some(stats[3] as u64),
        extra: json!({"nni": stats[4], "ncfn": stats[5], "nfeLS": stats[7]}),
    }
}

#[allow(clippy::too_many_arguments)]
fn run_hairer(
    which: i32,
    p: NativeProb,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    band: Option<(i32, i32)>,
    ifcn: i32,
    idfx: i32,
    imas: i32,
    n_ind1: i32,
    n_ind2: i32,
    n_ind3: i32,
    max_steps: i32,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let (mut completed, mut code) = (0i32, 0i32);
    let mut stats = [0i32; 7];
    let (ml, mu) = band.unwrap_or((-1, -1));
    unsafe {
        fs_hairer(
            which,
            &p as *const NativeProb as *const c_void,
            cb_rhs,
            Some(cb_jac),
            if idfx != 0 { Some(cb_dfx) } else { None },
            if imas != 0 { Some(cb_mas) } else { None },
            ifcn,
            idfx,
            imas,
            n_ind1,
            n_ind2,
            n_ind3,
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            rtol,
            atol,
            ml,
            mu,
            max_steps,
            vals.as_mut_ptr(),
            &mut completed,
            &mut code,
            stats.as_mut_ptr(),
        );
    }
    let ok = code > 0 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("IDID={code}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some(stats[0] as u64),
        njac: Some(stats[1] as u64),
        njvp: None,
        nlu: Some(stats[5] as u64),
        nsolve: Some(stats[6] as u64),
        accepted: Some(stats[3] as u64),
        rejected: Some(stats[4] as u64),
        extra: json!({"nstep": stats[2]}),
    }
}

fn run_ida(
    p: NativeProb,
    grid: &[f64],
    y0: &[f64],
    yp0: &[f64],
    id_vec: &[f64],
    rtol: f64,
    atol: f64,
    calc_ic: bool,
) -> ArmRun {
    let n = p.n();
    let nt = grid.len();
    let mut vals = vec![f64::NAN; n * nt];
    let mut completed = 0i32;
    let mut stats = [0i64; 9];
    let flag = unsafe {
        fs_ida(
            &p as *const NativeProb as *const c_void,
            cb_ida_res,
            Some(cb_ida_jac),
            n as i32,
            nt as i32,
            grid.as_ptr(),
            y0.as_ptr(),
            yp0.as_ptr(),
            id_vec.as_ptr(),
            rtol,
            atol,
            100_000,
            i32::from(calc_ic),
            vals.as_mut_ptr(),
            &mut completed,
            stats.as_mut_ptr(),
        )
    };
    let ok = flag == 0 && completed as usize == nt;
    ArmRun {
        ok,
        err_msg: if ok { String::new() } else { format!("IDA flag={flag}, completed={completed}/{nt}") },
        states: if ok { col_to_rows(&vals, n, nt) } else { vec![] },
        nf: Some((stats[1] + stats[7]) as u64),
        njac: Some(stats[6] as u64),
        njvp: None,
        nlu: Some(stats[2] as u64),
        nsolve: None,
        accepted: Some(stats[0] as u64),
        rejected: Some(stats[3] as u64),
        extra: json!({"nni": stats[4], "ncfn": stats[5]}),
    }
}

fn make_vigilode_problem(p: NativeProb, jac_mode: &str, band: Option<(usize, usize)>, ft: bool) -> Problem {
    let n = p.n();
    let mut prob = Problem::new(n, move |t, y, dy| {
        p.rhs(t, y, dy);
        Ok(())
    });
    match jac_mode {
        "dense" => {
            prob = prob.jacobian(Jacobian::dense(move |t, y, j| {
                p.jac_dense_row_major(t, y, j);
                Ok(())
            }));
        }
        "banded" => {
            let (ml, mu) = band.unwrap();
            prob = prob
                .jacobian(Jacobian::banded(ml, mu, move |t, y, b| {
                    p.jac_band_row_major(t, y, ml, mu, b);
                    Ok(())
                }))
                .banded(ml, mu);
        }
        "jvp" => {
            prob = prob.jvp(move |t, y, v, out| {
                p.jvp(t, y, v, out);
                Ok(())
            });
        }
        "sparse_jvp" => {
            let mut rows_pat = vec![Vec::new(); n];
            let y_dummy = vec![1.0; n];
            p.jac_entries(0.0, &y_dummy, |i, j, _| rows_pat[i].push(j));
            for r in &mut rows_pat {
                r.sort_unstable();
                r.dedup();
            }
            let pat = SparsityPattern::from_rows(n, &rows_pat).unwrap();
            prob = prob.jacobian(Jacobian::sparse_jvp(pat, move |t, y, v, out| {
                p.jvp(t, y, v, out);
                Ok(())
            }));
        }
        "fd" => {
            prob = prob.jacobian(Jacobian::FiniteDifference);
        }
        _ => panic!("unknown jac_mode"),
    }
    if let Some((ml, mu)) = band {
        if jac_mode == "fd" {
            prob = prob.banded(ml, mu);
        }
    }
    if let Some(md) = p.mass_diag() {
        let mut m = vec![0.0; n * n];
        for i in 0..n {
            m[i * n + i] = md[i];
        }
        prob = prob.mass(m);
    }
    if ft {
        prob = prob.time_derivative(move |t, y, out| {
            p.dfx(t, y, out);
            Ok(())
        });
    } else if !matches!(p, NativeProb::Pr1e4 | NativeProb::DaeAna | NativeProb::Burst) {
        prob = prob.autonomous();
    }
    prob
}

fn run_vigilode_rodas5p(
    prob: &Problem,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    interior: InteriorError,
) -> ArmRun {
    let opts = Options {
        rtol,
        atol: Atol::Scalar(atol),
        max_steps: 100_000,
        dense_output: true,
        interior_error: interior,
        ..Default::default()
    };
    let span = (grid[0], *grid.last().unwrap());
    match Rodas5p::solve(prob, span, y0, &opts) {
        Ok(sol) => {
            let ok = sol.is_success();
            let states: Vec<Vec<f64>> = if ok {
                grid.iter().filter_map(|&t| sol.at(t)).collect()
            } else {
                vec![]
            };
            let ok = ok && states.len() == grid.len();
            let c = sol.stats.counters;
            ArmRun {
                ok,
                err_msg: if ok { String::new() } else { sol.stats.driver_message.clone() },
                states,
                nf: Some(c.rhs_evaluations),
                njac: Some(c.jacobian_builds),
                njvp: Some(c.jvp_vectors),
                nlu: Some(c.direct_factorizations),
                nsolve: Some(c.direct_solve_calls),
                accepted: Some(sol.stats.accepted_steps as u64),
                rejected: Some(sol.stats.rejected_steps as u64),
                extra: json!({"ft_calls": c.ft_calls, "output_clipped_steps": sol.stats.output_clipped_steps}),
            }
        }
        Err(e) => ArmRun {
            ok: false,
            err_msg: e.to_string(),
            ..Default::default()
        },
    }
}

fn run_vigilode_unified(
    prob: &Problem,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
    strategy: SolverStrategy,
    dense_out: bool,
    max_krylov: usize,
) -> ArmRun {
    let opts = VigilodeOptions::default()
        .strategy(strategy)
        .rtol(rtol)
        .atol(atol)
        .max_steps(100_000)
        .dense_output(dense_out)
        .max_krylov_dim(max_krylov);
    let span = (grid[0], *grid.last().unwrap());
    match VigilODE::solve(prob, span, y0, opts) {
        Ok(sol) => {
            let ok = sol.success();
            let states = if ok && dense_out {
                let s: Vec<Vec<f64>> = grid.iter().filter_map(|&t| sol.at(t)).collect();
                if s.len() == grid.len() { s } else { vec![] }
            } else if ok {
                // Endpoint only
                vec![sol.final_state.clone()]
            } else {
                vec![]
            };
            let c = sol.stats().counters;
            let routes: Vec<String> = sol.route_history.iter().map(|r| r.to_tier.clone()).collect();
            ArmRun {
                ok: ok && (!dense_out || states.len() == grid.len()),
                err_msg: if ok { String::new() } else { format!("{:?}", sol.status) },
                states,
                nf: Some(c.rhs_evaluations),
                njac: Some(c.jacobian_builds),
                njvp: Some(c.jvp_vectors),
                nlu: Some(c.direct_factorizations),
                nsolve: Some(c.linear_solves + c.direct_solve_calls),
                accepted: Some(sol.stats().accepted_steps as u64),
                rejected: Some(sol.stats().rejected_steps as u64),
                extra: json!({
                    "routes": routes,
                    "fallback_steps": c.fallback_steps,
                    "linear_iterations": c.linear_iterations,
                    "invariant_drift": sol.invariant_drift,
                    "endpoint_only": !dense_out
                }),
            }
        }
        Err(e) => ArmRun {
            ok: false,
            err_msg: e.to_string(),
            ..Default::default()
        },
    }
}

fn run_vigilode_dopri5(prob: &Problem, grid: &[f64], y0: &[f64], rtol: f64, atol: f64, dense: bool) -> ArmRun {
    let opts = Options {
        rtol,
        atol: Atol::Scalar(atol),
        max_steps: 100_000,
        ..Default::default()
    };
    let span = (grid[0], *grid.last().unwrap());
    let res = if dense {
        Dopri5::solve_dense_observed(prob, span, y0, &opts, grid)
    } else {
        Dopri5::solve_observed(prob, span, y0, &opts, grid)
    };
    match res {
        Ok(sol) => {
            let ok = sol.success && sol.t == grid;
            let c = sol.stats.counters;
            ArmRun {
                ok,
                err_msg: if ok { String::new() } else { sol.message },
                states: if ok { sol.y } else { vec![] },
                nf: Some(c.rhs_evaluations),
                njac: Some(0),
                njvp: Some(0),
                nlu: Some(0),
                nsolve: Some(0),
                accepted: Some(sol.stats.accepted_steps as u64),
                rejected: Some(sol.stats.rejected_steps as u64),
                extra: json!({"fsal_reuses": sol.stats.fsal_reuses, "mode": sol.stats.observation_mode}),
            }
        }
        Err(e) => ArmRun {
            ok: false,
            err_msg: e.to_string(),
            ..Default::default()
        },
    }
}

fn run_diffsol(
    p: NativeProb,
    method: &str,
    sparse: bool,
    with_mass: bool,
    grid: &[f64],
    y0: &[f64],
    rtol: f64,
    atol: f64,
) -> ArmRun {
    let n = p.n();
    let t0 = grid[0];
    let y0v = y0.to_vec();
    let atols = vec![atol; n];

    macro_rules! build_and_solve {
        ($mat:ty, $lu:ty, $coloring:expr) => {{
            let mut b = OdeBuilder::<$mat>::new()
                .t0(t0)
                .rtol(rtol)
                .atol(atols.clone())
                .use_coloring($coloring)
                .rhs_implicit(
                    move |x, _p, t, out| p.rhs(t, x.as_slice(), out.as_mut_slice()),
                    move |x, _p, t, v, out| p.jvp(t, x.as_slice(), v.as_slice(), out.as_mut_slice()),
                )
                .init(move |_p, _t, out| out.as_mut_slice().copy_from_slice(&y0v), n);
            if with_mass {
                let md = p.mass_diag().unwrap();
                let builder = b.mass(move |v, _p, _t, beta, y| {
                    let ys = y.as_mut_slice();
                    let vs = v.as_slice();
                    for i in 0..n {
                        ys[i] = md[i] * vs[i] + beta * ys[i];
                    }
                });
                let problem = match builder.build() {
                    Ok(pr) => pr,
                    Err(e) => return ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
                };
                solve_diffsol_method!(problem, $lu)
            } else {
                let problem = match b.build() {
                    Ok(pr) => pr,
                    Err(e) => return ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
                };
                solve_diffsol_method!(problem, $lu)
            }
        }};
    }

    macro_rules! solve_diffsol_method {
        ($problem:expr, $lu:ty) => {{
            macro_rules! exec {
                ($s_res:expr) => {{
                    let mut solver = match $s_res {
                        Ok(s) => s,
                        Err(e) => return ArmRun { ok: false, err_msg: e.to_string(), ..Default::default() },
                    };
                    let outcome = solver.solve_dense(grid);
                    let stats = solver.get_statistics().clone();
                    match outcome {
                        Ok((mat, _stop)) => {
                            let ok = mat.ncols() == grid.len();
                            let states: Vec<Vec<f64>> = (0..mat.ncols())
                                .map(|k| (0..n).map(|i| mat.get_index(i, k)).collect())
                                .collect();
                            ArmRun {
                                ok,
                                err_msg: if ok { String::new() } else { "incomplete grid".into() },
                                states,
                                nf: None,
                                njac: None,
                                njvp: None,
                                nlu: Some(stats.number_of_linear_solver_setups as u64),
                                nsolve: None,
                                accepted: Some(stats.number_of_steps as u64),
                                rejected: Some(stats.number_of_error_test_failures as u64),
                                extra: json!({"nni": stats.number_of_nonlinear_solver_iterations, "ncfn": stats.number_of_nonlinear_solver_fails}),
                            }
                        }
                        Err(e) => ArmRun {
                            ok: false,
                            err_msg: e.to_string(),
                            nlu: Some(stats.number_of_linear_solver_setups as u64),
                            accepted: Some(stats.number_of_steps as u64),
                            rejected: Some(stats.number_of_error_test_failures as u64),
                            ..Default::default()
                        },
                    }
                }};
            }
            match method {
                "bdf" => exec!($problem.bdf::<$lu>()),
                "tr_bdf2" => exec!($problem.tr_bdf2::<$lu>()),
                "esdirk34" => exec!($problem.esdirk34::<$lu>()),
                "tsit45" => {
                    if with_mass {
                        ArmRun { ok: false, err_msg: "explicit RK unsupported with mass".into(), ..Default::default() }
                    } else {
                        exec!($problem.tsit45())
                    }
                }
                _ => unreachable!(),
            }
        }};
    }

    if sparse {
        build_and_solve!(FaerSparseMat<f64>, FaerSparseLU<f64>, true)
    } else {
        build_and_solve!(FaerMat<f64>, FaerLU<f64>, false)
    }
}

// ---------------- Analytical Helpers ----------------
fn kepler_exact(t: f64, ecc: f64) -> Vec<f64> {
    let m = t.rem_euclid(2.0 * PI);
    let mut e = m;
    for _ in 0..30 {
        e -= (e - ecc * e.sin() - m) / (1.0 - ecc * e.cos());
    }
    let ce = e.cos();
    let se = e.sin();
    let fac = (1.0 - ecc * ecc).sqrt();
    let r = 1.0 - ecc * ce;
    vec![ce - ecc, fac * se, -se / r, fac * ce / r]
}

fn advdiff_exact(n: usize, t: f64) -> Vec<f64> {
    let d = 0.01 * (n as f64) * (n as f64);
    let v = 1.0 * (n as f64);
    let th = 2.0 * PI / (n as f64);
    // Eigenvalue of D*(e^{-i*th} - 2 + e^{i*th}) - v*(1 - e^{-i*th})
    let re = d * (2.0 * th.cos() - 2.0) - v * (1.0 - th.cos());
    let im = -v * th.sin();
    let amp = (re * t).exp();
    (0..n)
        .map(|j| {
            let phi = th * (j as f64) + im * t;
            1.0 + 0.1 * amp * phi.sin()
        })
        .collect()
}

fn roots_for_method(method:&str,rtol:f64,terminal:bool)->ArmRun{
    let built=OdeBuilder::<FaerMat<f64>>::new().t0(0.).rtol(rtol).atol(vec![rtol*1e-2;2])
        .rhs_implicit(|x,_p,_t,out|{out[0]=x[1];out[1]=-x[0];}, |_x,_p,_t,v,out|{out[0]=v[1];out[1]=-v[0];})
        .root(|x,_p,_t,out|out[0]=x[0],1).init(|_p,_t,out|{out[0]=1.;out[1]=0.;},2).build();
    let problem=match built{Ok(p)=>p,Err(e)=>return ArmRun{err_msg:e.to_string(),..Default::default()}};
    macro_rules! go {($expr:expr)=>{{
        let mut s=match $expr{Ok(s)=>s,Err(e)=>return ArmRun{err_msg:e.to_string(),..Default::default()}};
        let mut roots=Vec::new();let mut final_t=0.;let mut complete=false;let mut message=String::new();
        if let Err(e)=s.set_stop_time(8.5){return ArmRun{err_msg:e.to_string(),..Default::default()};}
        for _ in 0..100000{
            match s.step(){
                Ok(OdeSolverStopReason::InternalTimestep)=>{},
                Ok(OdeSolverStopReason::TstopReached)=>{final_t=8.5;complete=!terminal;break;},
                Ok(OdeSolverStopReason::RootFound(t,_))=>{roots.push(t);if terminal{final_t=t;complete=true;break;}if roots.len()>3{message="extra root".into();break;}},
                Err(e)=>{message=e.to_string();break;},
            }
        }
        let expected=if terminal{vec![PI/2.]}else{vec![PI/2.,3.*PI/2.,5.*PI/2.]};
        let err=(roots.len()==expected.len()).then(||roots.iter().zip(&expected).map(|(a,b)|(a-b).abs()).fold(0.,f64::max));
        let st=s.get_statistics();let ok=complete&&err.is_some();
        ArmRun{ok,err_msg:if ok{String::new()}else{format!("event contract: {message}")},nlu:Some(st.number_of_linear_solver_setups as u64),accepted:Some(st.number_of_steps as u64),rejected:Some(st.number_of_error_test_failures as u64),extra:json!({"roots_found":roots,"max_root_err":err,"final_t":final_t,"terminal":terminal}),..Default::default()}
    }}}
    match method{"bdf"=>go!(problem.bdf::<FaerLU<f64>>()),"tr_bdf2"=>go!(problem.tr_bdf2::<FaerLU<f64>>()),"esdirk34"=>go!(problem.esdirk34::<FaerLU<f64>>()),"tsit45"=>go!(problem.tsit45()),_=>unreachable!()}
}
fn main(){
    let args:Vec<String>=env::args().collect();
    let raw:Value=serde_json::from_str(&std::fs::read_to_string(&args[2]).unwrap()).unwrap();
    let refs=&raw["references"];
    let mut rows=Vec::new();
    let mut cases=Vec::new();
    let g=make_grid(0.,20.*PI,101);let r=g.iter().map(|&t|kepler_exact(t,0.5)).collect::<Vec<_>>();
    cases.push(("kepler-ecc05",NativeProb::Kepler,g,vec![0.5,0.,0.,3f64.sqrt()],r,vec![1.;4],1e-2,false,false));
    let g=make_grid(0.,5.,101);let r=g.iter().map(|&t|vec![100.*((-t).exp()-(-2.*t).exp()),(-2.*t).exp()]).collect::<Vec<_>>();
    cases.push(("nonnormal-kreiss-b100",NativeProb::Kreiss,g,vec![0.,1.],r,vec![1.;2],1e-2,false,false));
    let g=make_grid(0.,10.,101);let r=g.iter().map(|&t|vec![t.sin()]).collect::<Vec<_>>();
    cases.push(("prothero-robinson-1e4",NativeProb::Pr1e4,g,vec![0.],r,vec![1.],1e-2,false,false));
    let g=make_grid(0.,1.,101);let y=(0..256).map(|i|1.+0.1*(2.*PI*i as f64/256.).sin()).collect::<Vec<_>>();
    cases.push(("periodic-advdiff-n256",NativeProb::AdvDiff256,g,y,serde_json::from_value(refs["periodic-advdiff-n256"].clone()).unwrap(),vec![1.;256],1.,false,true));
    let g=make_grid(0.,10.,101);let dx=1./201.;let mut y=vec![0.;400];
    for i in 0..200{y[2*i]=1.+(2.*PI*(i+1)as f64*dx).sin();y[2*i+1]=3.;}
    cases.push(("brusselator-1d-jvp-n400",NativeProb::Bruss400,g,y,serde_json::from_value(refs["brusselator-1d-jvp-n400"].clone()).unwrap(),vec![1.;400],1.,false,true));
    cases.push(("dae-robertson-index1",NativeProb::DaeRob,make_grid(0.,40.,101),vec![1.,0.,0.],serde_json::from_value(refs["dae-robertson-index1"].clone()).unwrap(),vec![1e-4;3],1e-4,true,false));
    let g=make_grid(0.,5.,101);let r=g.iter().map(|&t|vec![t.sin(),t.sin()+t.cos()]).collect::<Vec<_>>();
    cases.push(("dae-index1-analytic",NativeProb::DaeAna,g,vec![0.,1.],r,vec![1.;2],1e-2,true,false));
    let g=make_grid(0.,1.,101);let r=g.iter().map(|&t|vec![(-t).exp(),2.*(-t).exp()]).collect::<Vec<_>>();
    cases.push(("mass-ill-conditioned",NativeProb::MassIll,g,vec![1.,2.],r,vec![1.;2],1e-2,true,false));
    cases.push(("stiff-burst-switching",NativeProb::Burst,make_grid(0.,6.,101),vec![1.,0.],serde_json::from_value(refs["stiff-burst-switching"].clone()).unwrap(),vec![1.;2],1e-2,false,false));
    for (id,p,g,y,r,sc,af,mass,sparse) in cases{
        for method in ["bdf","tr_bdf2","esdirk34","tsit45"]{
            if mass&&method=="tsit45"{continue;}
            for sp in [false,true]{
                if sp&&(!sparse||method=="tsit45"){continue;}
                let arm=format!("diffsol-{}-{}",method.replace("_",""),if mass{"mass"}else if sp{"sparse"}else{"dense"});
                for tol in [1e-4,1e-6,1e-8]{
                    let row=timed_run(id,&arm,tol,Some(&r),&sc,||{
                        let mut run=run_diffsol(p,method,sp,mass,&g,&y,tol,tol*af);
                        if run.ok{
                            if run.states.len()!=g.len()||run.states.iter().any(|x|x.iter().any(|z|!z.is_finite())){run.ok=false;run.err_msg="invalid grid or nonfinite".into();}
                            else{
                                let initial_delta=run.states[0].iter().zip(&y).map(|(a,b)|(a-b).abs()).fold(0.,f64::max);
                                run.extra["initial_delta"]=json!(initial_delta);
                                if id=="dae-robertson-index1"{run.extra["max_constraint_residual"]=json!(run.states.iter().map(|x|(x.iter().sum::<f64>()-1.).abs()).fold(0.,f64::max));}
                                if id=="dae-index1-analytic"{run.extra["max_constraint_residual"]=json!(run.states.iter().zip(&g).map(|(x,t)|(x[0]+x[1]-2.*t.sin()-t.cos()).abs()).fold(0.,f64::max));}
                            }
                        }run
                    });
                    println!("{row}");rows.push(row);
                }
            }
        }
    }
    for method in ["bdf","tr_bdf2","esdirk34","tsit45"]{for terminal in [false,true]{for tol in [1e-4,1e-6,1e-8]{
        let id=if terminal{"event-terminal-first"}else{"event-root-finding"};
        let arm=format!("diffsol-{}-{}",method.replace("_",""),if terminal{"terminal"}else{"root"});
        let row=timed_run(id,&arm,tol,None,&[1.;2],||roots_for_method(method,tol,terminal));
        println!("{row}");rows.push(row);
    }}}
    std::fs::write(&args[1],serde_json::to_string_pretty(&json!({"schema":"vigilode-expanded-full-diffsol-v1","timing_authority":"diagnostic_only","rows":rows})).unwrap()).unwrap();
}
