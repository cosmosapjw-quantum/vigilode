#include <cvode/cvode.h>
#include <cvode/cvode_ls.h>
#include <ida/ida.h>
#include <ida/ida_ls.h>
#include <nvector/nvector_serial.h>
#include <sundials/sundials_context.h>
#include <sunlinsol/sunlinsol_band.h>
#include <sunlinsol/sunlinsol_dense.h>
#include <sunlinsol/sunlinsol_spgmr.h>
#include <sunmatrix/sunmatrix_band.h>
#include <sunmatrix/sunmatrix_dense.h>
#include <sunnonlinsol/sunnonlinsol_fixedpoint.h>
#include <math.h>
#include <string.h>

typedef void (*fs_rhs_cb)(const void *ctx, double t, const double *y, double *f);
typedef void (*fs_jac_cb)(const void *ctx, double t, const double *y, int ml, int mu,
                          int ld, double *pd);
typedef void (*fs_jvp_cb)(const void *ctx, double t, const double *y, const double *v,
                          double *jv);
typedef void (*fs_root_cb)(const void *ctx, double t, const double *y, double *gout);
typedef void (*fs_res_cb)(const void *ctx, double t, const double *y, const double *yp,
                          double *res);
typedef void (*fs_ida_jac_cb)(const void *ctx, double t, double cj, const double *y,
                              const double *yp, int n, int ld, double *pd);

typedef struct {
  const void *ctx;
  fs_rhs_cb rhs;
  fs_jac_cb jac;
  fs_jvp_cb jvp;
  fs_root_cb root;
  int ml, mu;
  int nroots;
} cv_user;

typedef struct {
  const void *ctx;
  fs_res_cb res;
  fs_ida_jac_cb jac;
  int n;
} ida_user;

static int cv_f(realtype t, N_Vector y, N_Vector ydot, void *ud) {
  cv_user *u = (cv_user *)ud;
  u->rhs(u->ctx, t, N_VGetArrayPointer(y), N_VGetArrayPointer(ydot));
  return 0;
}

static int cv_jac_dense(realtype t, N_Vector y, N_Vector fy, SUNMatrix J, void *ud,
                        N_Vector t1, N_Vector t2, N_Vector t3) {
  cv_user *u = (cv_user *)ud;
  (void)fy; (void)t1; (void)t2; (void)t3;
  u->jac(u->ctx, t, N_VGetArrayPointer(y), -1, -1, (int)SUNDenseMatrix_Rows(J),
         SUNDenseMatrix_Data(J));
  return 0;
}

static int cv_jac_band(realtype t, N_Vector y, N_Vector fy, SUNMatrix J, void *ud,
                       N_Vector t1, N_Vector t2, N_Vector t3) {
  cv_user *u = (cv_user *)ud;
  (void)fy; (void)t1; (void)t2; (void)t3;
  sunindextype smu = SUNBandMatrix_StoredUpperBandwidth(J);
  sunindextype ldim = SUNBandMatrix_LDim(J);
  u->jac(u->ctx, t, N_VGetArrayPointer(y), u->ml, u->mu, (int)ldim,
         SUNBandMatrix_Data(J) + (smu - u->mu));
  return 0;
}

static int cv_jtimes(N_Vector v, N_Vector Jv, realtype t, N_Vector y, N_Vector fy,
                     void *ud, N_Vector tmp) {
  cv_user *u = (cv_user *)ud;
  (void)fy; (void)tmp;
  u->jvp(u->ctx, t, N_VGetArrayPointer(y), N_VGetArrayPointer(v),
         N_VGetArrayPointer(Jv));
  return 0;
}

static int cv_root(realtype t, N_Vector y, realtype *gout, void *ud) {
  cv_user *u = (cv_user *)ud;
  u->root(u->ctx, t, N_VGetArrayPointer(y), gout);
  return 0;
}

/* mode: 0 = BDF Dense, 1 = BDF Band, 2 = BDF SPGMR (Krylov JVP), 3 = Adams FixedPoint */
int fs_cvode(const void *ctx, fs_rhs_cb rhs, fs_jac_cb jac, fs_jvp_cb jvp,
             fs_root_cb root_fn, int mode, int n, int nt, const double *times,
             const double *y0, double rtol, double atol, int ml, int mu,
             long max_steps, int nroots, int stop_on_root, double *values,
             int *completed, double *root_times, int *root_count,
             int max_roots, long *stats) {
  SUNContext sctx = NULL;
  void *mem = NULL;
  N_Vector y = NULL, ytmp = NULL;
  SUNMatrix A = NULL;
  SUNLinearSolver LS = NULL;
  SUNNonlinearSolver NLS = NULL;
  cv_user u = {ctx, rhs, jac, jvp, root_fn, ml, mu, nroots};
  int flag = 0, next = 1;
  long steps = 0;
  realtype tret = times[0];
  for (int k = 0; k < n * nt; ++k) values[k] = NAN;
  for (int k = 0; k < 9; ++k) stats[k] = 0;
  *completed = 0;
  *root_count = 0;
  if (SUNContext_Create(NULL, &sctx)) return -1001;
  y = N_VNew_Serial(n, sctx);
  ytmp = N_VNew_Serial(n, sctx);
  if (!y || !ytmp) { flag = -1002; goto done; }
  memcpy(N_VGetArrayPointer(y), y0, sizeof(double) * n);
  memcpy(values, y0, sizeof(double) * n);
  *completed = 1;
  mem = CVodeCreate(mode == 3 ? CV_ADAMS : CV_BDF, sctx);
  if (!mem) { flag = -1003; goto done; }
  if (CVodeInit(mem, cv_f, times[0], y)) { flag = -1004; goto done; }
  if (CVodeSStolerances(mem, rtol, atol)) { flag = -1005; goto done; }
  if (CVodeSetUserData(mem, &u)) { flag = -1006; goto done; }
  if (CVodeSetMaxNumSteps(mem, max_steps)) { flag = -1006; goto done; }

  if (mode == 0) {
    A = SUNDenseMatrix(n, n, sctx);
    LS = A ? SUNLinSol_Dense(y, A, sctx) : NULL;
    if (!A || !LS) { flag = -1007; goto done; }
    if (CVodeSetLinearSolver(mem, LS, A)) { flag = -1008; goto done; }
    if (jac && CVodeSetJacFn(mem, cv_jac_dense)) { flag = -1009; goto done; }
  } else if (mode == 1) {
    A = SUNBandMatrix(n, mu, ml, sctx);
    LS = A ? SUNLinSol_Band(y, A, sctx) : NULL;
    if (!A || !LS) { flag = -1007; goto done; }
    if (CVodeSetLinearSolver(mem, LS, A)) { flag = -1008; goto done; }
    if (jac && CVodeSetJacFn(mem, cv_jac_band)) { flag = -1009; goto done; }
  } else if (mode == 2) {
    LS = SUNLinSol_SPGMR(y, SUN_PREC_NONE, 30, sctx);
    if (!LS) { flag = -1007; goto done; }
    if (CVodeSetLinearSolver(mem, LS, NULL)) { flag = -1008; goto done; }
    if (jvp && CVodeSetJacTimes(mem, NULL, cv_jtimes)) { flag = -1009; goto done; }
  } else if (mode == 3) {
    NLS = SUNNonlinSol_FixedPoint(y, 0, sctx);
    if (!NLS) { flag = -1007; goto done; }
    if (CVodeSetNonlinearSolver(mem, NLS)) { flag = -1008; goto done; }
  }

  if (nroots > 0 && root_fn) {
    if (CVodeRootInit(mem, nroots, cv_root)) { flag = -1010; goto done; }
  }

  while (next < nt) {
    if (steps >= max_steps) { flag = CV_TOO_MUCH_WORK; break; }
    flag = CVode(mem, times[nt - 1], y, &tret, CV_ONE_STEP);
    if (flag < 0) break;
    if (flag == CV_ROOT_RETURN) {
      if (*root_count < max_roots) {
        root_times[*root_count] = tret;
        (*root_count)++;
      }
      if (stop_on_root) {
        flag = 0;
        break;
      }
      continue;
    }
    ++steps;
    while (next < nt && times[next] <= tret) {
      if (times[next] == tret) {
        memcpy(values + (size_t)next * n, N_VGetArrayPointer(y), sizeof(double) * n);
      } else {
        int g = CVodeGetDky(mem, times[next], 0, ytmp);
        if (g) { flag = g; goto stats; }
        memcpy(values + (size_t)next * n, N_VGetArrayPointer(ytmp), sizeof(double) * n);
      }
      ++next;
      *completed = next;
    }
  }
  if (next == nt) flag = 0;
stats:
  CVodeGetNumSteps(mem, &stats[0]);
  CVodeGetNumRhsEvals(mem, &stats[1]);
  CVodeGetNumErrTestFails(mem, &stats[3]);
  CVodeGetNumNonlinSolvIters(mem, &stats[4]);
  CVodeGetNumNonlinSolvConvFails(mem, &stats[5]);
  if (mode != 3) {
    CVodeGetNumLinSolvSetups(mem, &stats[2]);
    CVodeGetNumJacEvals(mem, &stats[6]);
    CVodeGetNumLinRhsEvals(mem, &stats[7]);
  }
  stats[8] = next;
done:
  if (NLS) SUNNonlinSolFree(NLS);
  if (LS) SUNLinSolFree(LS);
  if (A) SUNMatDestroy(A);
  if (mem) CVodeFree(&mem);
  if (ytmp) N_VDestroy(ytmp);
  if (y) N_VDestroy(y);
  if (sctx) SUNContext_Free(&sctx);
  return flag;
}

static int ida_res(realtype tt, N_Vector yy, N_Vector yp, N_Vector rr, void *ud) {
  ida_user *u = (ida_user *)ud;
  u->res(u->ctx, tt, N_VGetArrayPointer(yy), N_VGetArrayPointer(yp),
         N_VGetArrayPointer(rr));
  return 0;
}

static int ida_jac_dense(realtype tt, realtype cj, N_Vector yy, N_Vector yp,
                         N_Vector rr, SUNMatrix J, void *ud, N_Vector t1,
                         N_Vector t2, N_Vector t3) {
  ida_user *u = (ida_user *)ud;
  (void)rr; (void)t1; (void)t2; (void)t3;
  u->jac(u->ctx, tt, cj, N_VGetArrayPointer(yy), N_VGetArrayPointer(yp),
         u->n, (int)SUNDenseMatrix_Rows(J), SUNDenseMatrix_Data(J));
  return 0;
}

int fs_ida(const void *ctx, fs_res_cb res_fn, fs_ida_jac_cb jac_fn, int n, int nt,
           const double *times, const double *y0, const double *yp0,
           const double *id_vec, double rtol, double atol, long max_steps,
           int calc_ic, double *values, int *completed, long *stats) {
  SUNContext sctx = NULL;
  void *mem = NULL;
  N_Vector y = NULL, yp = NULL, id = NULL, ytmp = NULL;
  SUNMatrix A = NULL;
  SUNLinearSolver LS = NULL;
  ida_user u = {ctx, res_fn, jac_fn, n};
  int flag = 0, next = 1;
  long steps = 0;
  realtype tret = times[0];
  for (int k = 0; k < n * nt; ++k) values[k] = NAN;
  for (int k = 0; k < 9; ++k) stats[k] = 0;
  *completed = 0;
  if (SUNContext_Create(NULL, &sctx)) return -1001;
  y = N_VNew_Serial(n, sctx);
  yp = N_VNew_Serial(n, sctx);
  id = N_VNew_Serial(n, sctx);
  ytmp = N_VNew_Serial(n, sctx);
  if (!y || !yp || !id || !ytmp) { flag = -1002; goto done; }
  memcpy(N_VGetArrayPointer(y), y0, sizeof(double) * n);
  memcpy(N_VGetArrayPointer(yp), yp0, sizeof(double) * n);
  memcpy(N_VGetArrayPointer(id), id_vec, sizeof(double) * n);
  memcpy(values, y0, sizeof(double) * n);
  *completed = 1;
  mem = IDACreate(sctx);
  if (!mem) { flag = -1003; goto done; }
  if (IDAInit(mem, ida_res, times[0], y, yp)) { flag = -1004; goto done; }
  if (IDASStolerances(mem, rtol, atol)) { flag = -1005; goto done; }
  if (IDASetUserData(mem, &u)) { flag = -1006; goto done; }
  if (IDASetId(mem, id)) { flag = -1006; goto done; }
  if (IDASetMaxNumSteps(mem, max_steps)) { flag = -1006; goto done; }
  A = SUNDenseMatrix(n, n, sctx);
  LS = A ? SUNLinSol_Dense(y, A, sctx) : NULL;
  if (!A || !LS) { flag = -1007; goto done; }
  if (IDASetLinearSolver(mem, LS, A)) { flag = -1008; goto done; }
  if (jac_fn && IDASetJacFn(mem, ida_jac_dense)) { flag = -1009; goto done; }
  if (calc_ic) {
    flag = IDACalcIC(mem, IDA_YA_YDP_INIT, times[nt - 1]);
    if (flag < 0) goto stats;
  }
  while (next < nt) {
    if (steps >= max_steps) { flag = IDA_TOO_MUCH_WORK; break; }
    flag = IDASolve(mem, times[nt - 1], &tret, y, yp, IDA_ONE_STEP);
    if (flag < 0) break;
    ++steps;
    while (next < nt && times[next] <= tret) {
      if (times[next] == tret) {
        memcpy(values + (size_t)next * n, N_VGetArrayPointer(y), sizeof(double) * n);
      } else {
        int g = IDAGetDky(mem, times[next], 0, ytmp);
        if (g) { flag = g; goto stats; }
        memcpy(values + (size_t)next * n, N_VGetArrayPointer(ytmp), sizeof(double) * n);
      }
      ++next;
      *completed = next;
    }
  }
  if (next == nt) flag = 0;
stats:
  IDAGetNumSteps(mem, &stats[0]);
  IDAGetNumResEvals(mem, &stats[1]);
  IDAGetNumLinSolvSetups(mem, &stats[2]);
  IDAGetNumErrTestFails(mem, &stats[3]);
  IDAGetNumNonlinSolvIters(mem, &stats[4]);
  IDAGetNumNonlinSolvConvFails(mem, &stats[5]);
  IDAGetNumJacEvals(mem, &stats[6]);
  IDAGetNumLinResEvals(mem, &stats[7]);
  stats[8] = next;
done:
  if (LS) SUNLinSolFree(LS);
  if (A) SUNMatDestroy(A);
  if (mem) IDAFree(&mem);
  if (ytmp) N_VDestroy(ytmp);
  if (id) N_VDestroy(id);
  if (yp) N_VDestroy(yp);
  if (y) N_VDestroy(y);
  if (sctx) SUNContext_Free(&sctx);
  return flag;
}
