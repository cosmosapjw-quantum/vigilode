use std::{env, path::PathBuf, process::Command};

const FFLAGS_F77: &[&str] = &["-O3", "-fPIC", "-std=legacy", "-fallow-argument-mismatch"];
const FFLAGS_F90: &[&str] = &["-O3", "-fPIC"];
const CFLAGS: &[&str] = &["-O3", "-fPIC", "-std=c11", "-Wall"];

fn run(mut c: Command) -> Vec<u8> {
    let shown = format!("{c:?}");
    let out = c
        .output()
        .unwrap_or_else(|e| panic!("cannot run {shown}: {e}"));
    assert!(
        out.status.success(),
        "failed {shown}\n{}{}",
        String::from_utf8_lossy(&out.stdout),
        String::from_utf8_lossy(&out.stderr)
    );
    out.stdout
}

fn defined_globals(obj: &PathBuf) -> Vec<String> {
    let mut c = Command::new("nm");
    c.args(["-g", "--defined-only", "-P"]).arg(obj);
    String::from_utf8(run(c))
        .unwrap()
        .lines()
        .filter_map(|l| {
            let mut it = l.split_whitespace();
            let name = it.next()?;
            let kind = it.next()?;
            matches!(kind, "T").then(|| name.to_string())
        })
        .collect()
}

fn main() {
    let root = PathBuf::from(env::var("CARGO_MANIFEST_DIR").unwrap());
    let native = PathBuf::from("/home/cosmosapjw/worktrees/vigilode-csas-20261125/crates/vigilode-bench/native");
    let out = PathBuf::from(env::var("OUT_DIR").unwrap());

    println!("cargo:rerun-if-changed=f_bridge.f90");
    println!("cargo:rerun-if-changed=c_bridge.c");

    let mut objects = Vec::new();
    let compile_f = |src: PathBuf, flags: &[&str], name: &str| {
        let obj = out.join(format!("{name}.o"));
        let mut c = Command::new("gfortran");
        c.current_dir(&out)
            .args(flags)
            .arg("-c")
            .arg(&src)
            .arg("-o")
            .arg(&obj);
        run(c);
        obj
    };

    for name in ["vode", "dgefa", "dgesl", "dgbfa", "dgbsl"] {
        objects.push(compile_f(
            native.join(format!("netlib/{name}.f")),
            FFLAGS_F77,
            name,
        ));
    }

    let radau = compile_f(
        native.join("hairer/radau_decsol.f"),
        FFLAGS_F77,
        "radau_decsol",
    );
    let rodas = compile_f(
        native.join("hairer/rodas_decsol.f"),
        FFLAGS_F77,
        "rodas_decsol",
    );
    let radau_syms = defined_globals(&radau);
    let mut objcopy = Command::new("objcopy");
    for s in defined_globals(&rodas) {
        if radau_syms.contains(&s) {
            objcopy.arg(format!("--localize-symbol={s}"));
        }
    }
    objcopy.arg(&rodas);
    run(objcopy);

    objects.push(radau);
    objects.push(rodas);
    objects.push(compile_f(root.join("f_bridge.f90"), FFLAGS_F90, "f_bridge"));

    let cobj = out.join("c_bridge.o");
    let mut cc = Command::new("gcc");
    cc.args(CFLAGS)
        .arg("-c")
        .arg(root.join("c_bridge.c"))
        .arg("-o")
        .arg(&cobj);
    run(cc);
    objects.push(cobj);

    let archive = out.join("libfullscopenative.a");
    let _ = std::fs::remove_file(&archive);
    let mut ar = Command::new("ar");
    ar.arg("crs").arg(&archive).args(&objects);
    run(ar);

    println!("cargo:rustc-link-search=native={}", out.display());
    println!("cargo:rustc-link-lib=static=fullscopenative");
    for lib in [
        "sundials_cvode",
        "sundials_ida",
        "sundials_nvecserial",
        "sundials_sunmatrixdense",
        "sundials_sunmatrixband",
        "sundials_sunlinsoldense",
        "sundials_sunlinsolband",
        "sundials_sunlinsolspgmr",
        "sundials_sunnonlinsolfixedpoint",
        "sundials_sunnonlinsolnewton",
        "blas",
        "gfortran",
        "m",
    ] {
        println!("cargo:rustc-link-lib={lib}");
    }
    for sym in [
        "malloc",
        "calloc",
        "realloc",
        "posix_memalign",
        "aligned_alloc",
        "memalign",
    ] {
        println!("cargo:rustc-link-arg-bins=-Wl,--export-dynamic-symbol={sym}");
    }
}
