module fs_bridge
  use iso_c_binding
  use, intrinsic :: ieee_arithmetic
  implicit none
  abstract interface
    subroutine rhs_cb(ctx, t, y, f) bind(C)
      import c_ptr, c_double
      type(c_ptr), value :: ctx
      real(c_double), value :: t
      real(c_double), intent(in) :: y(*)
      real(c_double), intent(out) :: f(*)
    end subroutine
    subroutine jac_cb(ctx, t, y, ml, mu, ld, pd) bind(C)
      import c_ptr, c_double, c_int
      type(c_ptr), value :: ctx
      real(c_double), value :: t
      real(c_double), intent(in) :: y(*)
      integer(c_int), value :: ml, mu, ld
      real(c_double), intent(out) :: pd(*)
    end subroutine
    subroutine dfx_cb(ctx, t, y, fx) bind(C)
      import c_ptr, c_double
      type(c_ptr), value :: ctx
      real(c_double), value :: t
      real(c_double), intent(in) :: y(*)
      real(c_double), intent(out) :: fx(*)
    end subroutine
    subroutine mas_cb(ctx, n, ld, am) bind(C)
      import c_ptr, c_double, c_int
      type(c_ptr), value :: ctx
      integer(c_int), value :: n, ld
      real(c_double), intent(out) :: am(*)
    end subroutine
  end interface
  procedure(rhs_cb), pointer :: p_rhs => null()
  procedure(jac_cb), pointer :: p_jac => null()
  procedure(dfx_cb), pointer :: p_dfx => null()
  procedure(mas_cb), pointer :: p_mas => null()
  type(c_ptr) :: g_ctx = c_null_ptr
  integer :: g_banded = 0, g_ml = 0, g_mu = 0
  integer :: g_n = 0, g_nt = 0, g_next = 0
  real(c_double), pointer :: g_times(:) => null()
  real(c_double), pointer :: g_values(:,:) => null()
contains

  subroutine bind_problem(ctx, rhs, jac, dfx, mas, n, nt, times, values, ml, mu)
    type(c_ptr), value :: ctx, times, values
    type(c_funptr), value :: rhs, jac, dfx, mas
    integer(c_int), value :: n, nt, ml, mu
    g_ctx = ctx
    call c_f_procpointer(rhs, p_rhs)
    if (c_associated(jac)) then
      call c_f_procpointer(jac, p_jac)
    else
      nullify(p_jac)
    end if
    if (c_associated(dfx)) then
      call c_f_procpointer(dfx, p_dfx)
    else
      nullify(p_dfx)
    end if
    if (c_associated(mas)) then
      call c_f_procpointer(mas, p_mas)
    else
      nullify(p_mas)
    end if
    g_n = n; g_nt = nt
    call c_f_pointer(times, g_times, [nt])
    call c_f_pointer(values, g_values, [n, nt])
    g_values = ieee_value(0.0_c_double, ieee_quiet_nan)
    if (ml < 0) then
      g_banded = 0; g_ml = n; g_mu = n
    else
      g_banded = 1; g_ml = ml; g_mu = mu
    end if
  end subroutine

  subroutine fcn(n, x, y, f, rpar, ipar)
    integer :: n, ipar(*)
    double precision :: x, y(n), f(n), rpar(*)
    call p_rhs(g_ctx, x, y, f)
  end subroutine

  subroutine vjac(n, t, y, ml, mu, pd, nrowpd, rpar, ipar)
    integer :: n, ml, mu, nrowpd, ipar(*)
    double precision :: t, y(n), pd(nrowpd, *), rpar(*)
    if (.not. associated(p_jac)) return
    if (g_banded == 0) then
      call p_jac(g_ctx, t, y, -1_c_int, -1_c_int, int(nrowpd, c_int), pd)
    else
      call p_jac(g_ctx, t, y, int(ml, c_int), int(mu, c_int), int(nrowpd, c_int), pd)
    end if
  end subroutine

  subroutine hjac(n, x, y, dfy, ldfy, rpar, ipar)
    integer :: n, ldfy, ipar(*)
    double precision :: x, y(n), dfy(ldfy, *), rpar(*)
    if (.not. associated(p_jac)) return
    if (g_banded == 0) then
      call p_jac(g_ctx, x, y, -1_c_int, -1_c_int, int(ldfy, c_int), dfy)
    else
      call p_jac(g_ctx, x, y, int(g_ml, c_int), int(g_mu, c_int), int(ldfy, c_int), dfy)
    end if
  end subroutine

  subroutine hmas(n, am, lmas, rpar, ipar)
    integer :: n, lmas, ipar(*)
    double precision :: am(lmas, *), rpar(*)
    if (associated(p_mas)) then
      call p_mas(g_ctx, int(n, c_int), int(lmas, c_int), am)
    end if
  end subroutine

  subroutine hdfx(n, x, y, fx, rpar, ipar)
    integer :: n, ipar(*)
    double precision :: x, y(n), fx(n), rpar(*)
    if (associated(p_dfx)) then
      call p_dfx(g_ctx, x, y, fx)
    end if
  end subroutine

  subroutine solout_radau(nr, xold, x, y, cont, werr, lrc, n, rpar, ipar, irtrn)
    integer :: nr, lrc, n, ipar(*), irtrn, i
    double precision :: xold, x, y(n), cont(lrc), werr(n), rpar(*), tk
    double precision, external :: contr5
    do while (g_next <= g_nt)
      tk = g_times(g_next)
      if (tk > x) exit
      if (tk == x) then
        g_values(:, g_next) = y
      else
        do i = 1, n
          g_values(i, g_next) = contr5(i, tk, cont, lrc)
        end do
      end if
      g_next = g_next + 1
    end do
  end subroutine

  subroutine solout_rodas(nr, xold, x, y, cont, lrc, n, rpar, ipar, irtrn)
    integer :: nr, lrc, n, ipar(*), irtrn, i
    double precision :: xold, x, y(n), cont(lrc), rpar(*), tk
    double precision, external :: contro
    do while (g_next <= g_nt)
      tk = g_times(g_next)
      if (tk > x) exit
      if (tk == x) then
        g_values(:, g_next) = y
      else
        do i = 1, n
          g_values(i, g_next) = contro(i, tk, cont, lrc)
        end do
      end if
      g_next = g_next + 1
    end do
  end subroutine

  subroutine fs_dvode(ctx, rhs, jac, mf_in, n, nt, times, y0, rtol, atol, ml, mu, &
      max_steps, values, completed, code, stats) bind(C, name='fs_dvode')
    type(c_ptr), value :: ctx, times, values
    type(c_funptr), value :: rhs, jac
    integer(c_int), value :: mf_in, n, nt, ml, mu, max_steps
    real(c_double), value :: rtol, atol
    real(c_double), intent(in) :: y0(n)
    integer(c_int), intent(out) :: completed, code, stats(8)
    double precision, allocatable :: rw(:), y(:)
    integer, allocatable :: iw(:)
    double precision :: t, tout, rt(1), at(1), rpar(1)
    integer :: lrw, liw, mf, istate, ipar(1), k
    external dvode, xsetf
    stats = 0; completed = 0; code = -99
    if (n < 1 .or. nt < 2) return
    call bind_problem(ctx, rhs, jac, c_null_funptr, c_null_funptr, n, nt, times, values, ml, mu)
    mf = mf_in
    if (mf == 10) then
      lrw = 20 + 16*n
      liw = 30
    else if (mf == 21 .or. mf == 22) then
      lrw = 22 + 9*n + 2*n*n
      liw = 30 + n
    else
      lrw = 22 + 11*n + (3*ml + 2*mu)*n
      liw = 30 + n
    end if
    allocate(rw(lrw), iw(liw), y(n))
    rw = 0.0d0; iw = 0; y = y0
    if (mf == 24 .or. mf == 25) then
      iw(1) = ml; iw(2) = mu
    end if
    iw(6) = max_steps
    rt(1) = rtol; at(1) = atol
    istate = 1; t = g_times(1); rpar = 0.0d0; ipar = 0
    g_values(:, 1) = y; completed = 1
    call xsetf(0)
    do k = 2, nt
      tout = g_times(k)
      call dvode(fcn, n, y, t, tout, 1, rt, at, 1, istate, 1, rw, lrw, iw, liw, vjac, mf, rpar, ipar)
      if (istate < 0) exit
      g_values(:, k) = y
      completed = k
    end do
    code = istate
    stats = [iw(11), iw(12), iw(13), iw(19), iw(20), iw(21), iw(22), iw(14)]
    deallocate(rw, iw, y)
  end subroutine

  subroutine fs_hairer(which, ctx, rhs, jac, dfx, mas, ifcn_in, idfx_in, imas_in, &
      n_ind1, n_ind2, n_ind3, n, nt, times, y0, rtol, atol, ml, mu, max_steps, &
      values, completed, code, stats) bind(C, name='fs_hairer')
    integer(c_int), value :: which, ifcn_in, idfx_in, imas_in, n_ind1, n_ind2, n_ind3
    integer(c_int), value :: n, nt, ml, mu, max_steps
    type(c_ptr), value :: ctx, times, values
    type(c_funptr), value :: rhs, jac, dfx, mas
    real(c_double), value :: rtol, atol
    real(c_double), intent(in) :: y0(n)
    integer(c_int), intent(out) :: completed, code, stats(7)
    double precision, allocatable :: work(:), y(:)
    integer, allocatable :: iwork(:)
    double precision :: x, xend, h, rt, at, rpar(1)
    integer :: lwork, liwork, ljac, le, lmas, mljac, mujac, mlmas, mumas, idid, ipar(1)
    integer :: ifcn, idfx, imas, ijac
    external radau5, rodas
    stats = 0; completed = 0; code = -99
    if (n < 1 .or. nt < 2) return
    call bind_problem(ctx, rhs, jac, dfx, mas, n, nt, times, values, ml, mu)
    ifcn = ifcn_in; idfx = idfx_in; imas = imas_in
    ijac = 1
    if (.not. associated(p_jac)) ijac = 0
    if (ml < 0) then
      mljac = n; mujac = n; ljac = n; le = n
    else
      mljac = ml; mujac = mu; ljac = ml + mu + 1; le = 2*ml + mu + 1
    end if
    if (imas == 0) then
      lmas = 0; mlmas = 0; mumas = 0
    else
      lmas = n; mlmas = n; mumas = n
    end if
    if (which == 0) then
      lwork = n*(ljac + lmas + 3*le + 12) + 20
      liwork = 3*n + 20
    else
      lwork = n*(ljac + lmas + le + 14) + 20
      liwork = n + 20
    end if
    allocate(work(lwork), iwork(liwork), y(n))
    work = 0.0d0; iwork = 0; y = y0
    x = g_times(1); xend = g_times(nt); h = 0.0d0
    rt = rtol; at = atol; rpar = 0.0d0; ipar = 0; idid = 0
    g_next = 1
    if (which == 0) then
      iwork(2) = max_steps
      if (imas == 1) then
        iwork(5) = n_ind1
        iwork(6) = n_ind2
        iwork(7) = n_ind3
      end if
      call radau5(n, fcn, x, y, xend, h, rt, at, 0, hjac, ijac, mljac, mujac, &
          hmas, imas, mlmas, mumas, solout_radau, 1, work, lwork, iwork, liwork, rpar, ipar, idid)
    else
      iwork(1) = max_steps
      call rodas(n, fcn, ifcn, x, y, xend, h, rt, at, 0, hjac, ijac, mljac, mujac, &
          hdfx, idfx, hmas, imas, mlmas, mumas, solout_rodas, 1, work, lwork, iwork, liwork, &
          rpar, ipar, idid)
    end if
    if (idid > 0 .and. g_next == nt .and. x == xend) then
      g_values(:, nt) = y
      g_next = nt + 1
    end if
    completed = g_next - 1
    code = idid
    stats = iwork(14:20)
    deallocate(work, iwork, y)
  end subroutine
end module
