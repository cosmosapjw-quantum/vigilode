from pathlib import Path
p=Path('crates/vigilode-bench/src/arms.rs');s=p.read_text()
def edit(a,b):
 global s
 assert s.count(a)==1,(a,s.count(a))
 s=s.replace(a,b)
edit('    DiffsolBdfSparse,\n','''    DiffsolBdfSparse,
    /// Diffsol built-in TR-BDF2, dense LU.
    DiffsolTrbdf2Dense,
    /// Diffsol built-in TR-BDF2, sparse coloured LU.
    DiffsolTrbdf2Sparse,
    /// Diffsol built-in ESDIRK34, dense LU.
    DiffsolEsdirk34Dense,
    /// Diffsol built-in ESDIRK34, sparse coloured LU.
    DiffsolEsdirk34Sparse,
    /// Diffsol built-in explicit Tsitouras RK 4(5).
    DiffsolTsit45,
''')
edit('pub const ALL: [Arm; 17]', 'pub const ALL: [Arm; 22]')
edit('        Arm::DiffsolBdfSparse,\n','''        Arm::DiffsolBdfSparse,
        Arm::DiffsolTrbdf2Dense,
        Arm::DiffsolTrbdf2Sparse,
        Arm::DiffsolEsdirk34Dense,
        Arm::DiffsolEsdirk34Sparse,
        Arm::DiffsolTsit45,
''')
edit('            Self::DiffsolBdfDense | Self::DiffsolBdfSparse => "diffsol-bdf",','''            Self::DiffsolBdfDense | Self::DiffsolBdfSparse => "diffsol-bdf",
            Self::DiffsolTrbdf2Dense | Self::DiffsolTrbdf2Sparse => "diffsol-trbdf2",
            Self::DiffsolEsdirk34Dense | Self::DiffsolEsdirk34Sparse => "diffsol-esdirk34",
            Self::DiffsolTsit45 => "diffsol-tsit45",''')
edit('                | Arm::DiffsolBdfSparse\n','''                | Arm::DiffsolBdfSparse
                | Arm::DiffsolTrbdf2Sparse
                | Arm::DiffsolEsdirk34Sparse
''')
edit('''            Arm::DiffsolBdfDense | Arm::DiffsolBdfSparse => {
                "OdeSolverMethod::solve_dense(t_eval) (BDF interpolation, stop time = last grid point)"
            }''','''            Arm::DiffsolBdfDense | Arm::DiffsolBdfSparse => {
                "OdeSolverMethod::solve_dense(t_eval) (BDF interpolation, stop time = last grid point)"
            }
            Arm::DiffsolTrbdf2Dense | Arm::DiffsolTrbdf2Sparse |
            Arm::DiffsolEsdirk34Dense | Arm::DiffsolEsdirk34Sparse | Arm::DiffsolTsit45 =>
                "OdeSolverMethod::solve_dense(t_eval) (native RK interpolation, stop time = last grid point)",''')
edit('            Arm::DiffsolBdfDense => vec![','            Arm::DiffsolBdfDense | Arm::DiffsolTrbdf2Dense | Arm::DiffsolEsdirk34Dense => vec![')
edit('            Arm::DiffsolBdfSparse => vec![','            Arm::DiffsolBdfSparse | Arm::DiffsolTrbdf2Sparse | Arm::DiffsolEsdirk34Sparse => vec![')
edit('            Arm::CvodeBdfDense | Arm::CvodeBdfBand => vec![','''            Arm::DiffsolTsit45 => vec!["native explicit Tsit45; no implicit linear solver; shared analytic source builder"],
            Arm::CvodeBdfDense | Arm::CvodeBdfBand => vec![''')
edit('        Arm::DiffsolBdfSparse => diffsol_sparse(model, grid, &y0, rtol, atol),','''        Arm::DiffsolBdfSparse => diffsol_sparse(model, grid, &y0, rtol, atol),
        Arm::DiffsolTrbdf2Dense => diffsol_trbdf2_dense(model,grid,&y0,rtol,atol),
        Arm::DiffsolTrbdf2Sparse => diffsol_trbdf2_sparse(model,grid,&y0,rtol,atol),
        Arm::DiffsolEsdirk34Dense => diffsol_esdirk34_dense(model,grid,&y0,rtol,atol),
        Arm::DiffsolEsdirk34Sparse => diffsol_esdirk34_sparse(model,grid,&y0,rtol,atol),
        Arm::DiffsolTsit45 => diffsol_tsit45(model,grid,&y0,rtol,atol),''')
edit('    ($name:ident, $mat:ty, $lu:ty, $coloring:expr) => {','    ($name:ident, $mat:ty, $coloring:expr, $method:ident $(, $lu:ty)?) => {')
edit('problem.bdf::<$lu>()','problem.$method $(::<$lu>)? ()')
edit('''diffsol_arm!(diffsol_dense, FaerMat<f64>, FaerLU<f64>, false);
diffsol_arm!(diffsol_sparse, FaerSparseMat<f64>, FaerSparseLU<f64>, true);''','''diffsol_arm!(diffsol_dense, FaerMat<f64>, false, bdf, FaerLU<f64>);
diffsol_arm!(diffsol_sparse, FaerSparseMat<f64>, true, bdf, FaerSparseLU<f64>);
diffsol_arm!(diffsol_trbdf2_dense, FaerMat<f64>, false, tr_bdf2, FaerLU<f64>);
diffsol_arm!(diffsol_trbdf2_sparse, FaerSparseMat<f64>, true, tr_bdf2, FaerSparseLU<f64>);
diffsol_arm!(diffsol_esdirk34_dense, FaerMat<f64>, false, esdirk34, FaerLU<f64>);
diffsol_arm!(diffsol_esdirk34_sparse, FaerSparseMat<f64>, true, esdirk34, FaerSparseLU<f64>);
diffsol_arm!(diffsol_tsit45, FaerMat<f64>, false, tsit45);''')
p.write_text(s)
p=Path('crates/vigilode-bench/tests/adapters.rs');s=p.read_text()
a='''        assert!(
            calls.jac + calls.jvp > 0,
            "{arm:?} used the shared Jacobian"
        );'''
assert s.count(a)==1
s=s.replace(a,'''        if arm != Arm::DiffsolTsit45 {
            assert!(calls.jac + calls.jvp > 0, "{arm:?} used the shared Jacobian");
        }''')
p.write_text(s)
