# G1 PHYS–MATH AUDIT

## Conventions and dimensions

- Test systems are dimensionless regular ODEs; the constant-mass case uses a nonsingular noncommuting mass matrix.
- Shifted operator sign is unchanged:
  \[
  W=M-h\gamma J.
  \]
- q1/q2 are causal-propagation truncation depths, not physical dimensions or time orders.
- All WRMS certificate quantities are dimensionless.

## Passed

1. Explicit Jacobian builds, direct factorizations, fast-path Newton iterations are exactly zero.
2. q1 endpoint/state/work is retained during q2 escalation.
3. Protected fallback recovers the original matrix-free RODAS5P endpoint.
4. Finite one-step generic corpus has zero false accepts against protected JF output.
5. Complex damping/oscillation, stiff nonlinear relaxation, nonnormal coupling, semilinear PDE traces, Robertson kinetics and noncommuting mass are represented.
6. No post-hoc clipping or state correction is used.

## Load-bearing concerns

### P0 — none in the implemented transaction semantics

No source-level sign, unit, explicit-J or rollback violation was found.

### P1 — acceleration objective fails

Adaptive strictly sub-8 fraction is zero. The q2 lane is depth 8, and fallback is depth 16. The method preserves step count but not critical-path economy.

### P1 — operational certificate is not a theorem

The contraction-tail estimate assumes the observed output corrections characterize the uncomputed tail. Nonnormal nonlinear amplification can invalidate this inference. The finite false-accept screen is evidence, not proof.

### P1 — no independent fast-path fifth-order result

The adaptive result mixes q2 and protected fallback. Therefore the global fifth-order behavior cannot be attributed to the fast path alone.

### P2 — common-grid clipping

The fair common-grid authority applies equally to both compared RODAS lanes, so the negative relative timing result is valid. But it limits independent tolerance/order interpretation for high-order candidates.

### P2 — small state dimensions

The adaptive analytic corpus is small. Larger semidiscrete systems could change relative batching economics, but the current 5.1× RHS and 8.9× JVP overhead is too large to claim a likely reversal without new evidence.

## Verdict

- Correctness/transactional structure: PASS WITH BOUNDED EVIDENCE.
- Generic low-depth acceleration: FAIL.
- Fifth-order fast-path promotion: NOT ESTABLISHED.
