# G1 PHYS–MATH–CODE AUDIT

## Equation-to-code map

| Mathematical object | Code path |
|---|---|
| \(Wv=Mv-h\gamma Jv\) | `build_step_context_matrix_free`, `MatrixFreeCommonWSolver` |
| q1 truncated inverse | `truncated_inverse_rows_with_last_term(..., q=1)` |
| retained q1 endpoint | `stages`, `last_q1_causal_term`, `q1_candidate_y` |
| q2 extra causal term | `coupling_apply(last_q1_causal_term)` + one common-W solve |
| remaining-defect diagnostic | post-q2 matrix-free common-W solve |
| operational gate | `operational_gate` |
| protected fallback | `sequential_stages` on matrix-free context |
| transactional adaptive commit | `integrate_transactional_q1_q2_adaptive_observed` |
| total work | `WorkCounters::accumulate`, `HomotopyWorkLedger` |

## Genuinely fixed

1. Missing JVP fails before explicit Jacobian construction.
2. Speculative work is retained on q2 escalation and fallback.
3. q1 and q2 *path attempts* are now distinguished from the final selected lane in JSON diagnostics.
4. q2 escalation does not recompute the q1 start/path.
5. Rejected adaptive trials do not commit requested outputs.
6. BDF and Radau byte-freeze tests remain active.
7. Physical-client token exclusion remains active.
8. Generic eight-family calibration is now an executable deterministic CLI gate.

## Remaining risks

### P1 — q2 certificate batch erases the nominal 7-depth gain

The causal correction itself upgrades q1 from 6 to 7 batches, but the remaining-defect diagnostic adds an eighth batch. Removing it without a replacement certificate would improve timing by weakening correctness evidence, which is forbidden.

### P1 — fallback duplicates expensive work

Fallback adds eight protected sequential stages after eight speculative batches. This produces depth 16 and dominates nonlinear problems that fail the operational gate.

### P2 — provided JVP requirement

The strict path deliberately refuses explicit-J fallback. A production generic solver still needs a fresh, quality-controlled finite-difference/AD JVP mode; this G1 implementation assumes a valid user JVP.

### P2 — timing granularity

The adaptive suite is small. Five pinned T1 campaigns give stable aggregate conclusions, but individual row timing remains microbenchmark-scale.

## Test sufficiency

Added tests cover:

- explicit-J fail-closed;
- q1 depth 6;
- q2 depth 8;
- fallback depth 16 and speculative work;
- adaptive rollback;
- exact JVP parity;
- work-counter saturation/accumulation;
- generic eight-family coverage.

This is sufficient to close G1 semantics and kill the candidate under the declared finite gates. It is not a proof over arbitrary ODEs.
