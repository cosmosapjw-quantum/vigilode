# G1 — Transactional q1→q2 Generic Solver Research Report

## 1. 연구 질문

보호된 matrix-free RODAS5P의 step economy를 유지하면서 8-stage sequential critical path를 다음 방식으로 줄일 수 있는가?

\[
q=1,c=2\;\text{fast attempt}
\longrightarrow
q=2\;\text{retained-endpoint escalation}
\longrightarrow
\text{protected sequential JF fallback}.
\]

필수 제약은 다음과 같다.

\[
N_J^{\rm explicit}=0,
\qquad
N_{\rm factor}=0,
\qquad
N_{\rm Newton}^{\rm fast}=0.
\]

성능 승격은 동일 external global error에서 protected sequential JF RODAS5P 대비 median speedup 1.15 이상, fallback 10% 이하, fast fraction 90% 이상, median critical depth 8 이하를 요구했다.

## 2. 구현

### 2.1 strict matrix-free step context

Fast path는 오직

\[
Wv=Mv-h\gamma Jv
\]

를 사용한다. 명시적 Jacobian이나 shifted matrix는 구성하지 않는다. 문제에 user-supplied JVP가 없으면 explicit Jacobian으로 우회하지 않고 fail-closed한다.

### 2.2 q1 attempt

- decoupled start;
- direct endpoint tangent;
- q1 truncated inverse를 사용한 endpoint correction 2회;
- output-correction contraction과 original target residual을 이용한 operational gate.

q1 accepted critical depth는 common-W batch 6이다.

### 2.3 retained q2 escalation

q1의 두 번째 correction에서 이미 계산한 마지막 causal term을 보존한다. q2는 decoupled predictor부터 재시작하지 않고 다음 causal power만 추가한다. 이후 남은 output defect를 평가하기 위한 matrix-free diagnostic batch를 한 번 수행한다.

따라서 q2 accepted depth는 8이다. 이 경로는 Jacobian/Newton-free지만 sequential RODAS5P의 8-stage depth보다 얕지는 않다.

### 2.4 protected fallback

q2 gate 실패, nonfinite, linear-solve failure 시 같은 timestep에서 sequential matrix-free RODAS5P를 실행한다. speculative q1/q2 RHS, JVP, common-W work는 장부에서 삭제하지 않는다. Fallback critical depth는 16이다.

## 3. generic one-step calibration

계약에 적힌 8 family를 모두 실행했다.

1. complex Dahlquist;
2. oscillatory Prothero–Robinson;
3. stiff van der Pol;
4. Robertson;
5. nonlinear nonnormal block;
6. diffusion–reaction;
7. advection–diffusion–reaction;
8. constant noncommuting mass.

결과:

```text
cases                    8
completed                8
q1 fast                  3
q2 escalated             4
sequential fallback      1
fast fraction        0.875
fallback fraction    0.125
false accepts             0
median depth              8
P95 depth              13.2
explicit-J builds         0
factorizations            0
fast-path Newton          0
```

Oscillatory PR만 fallback했다. 그러나 fast fraction과 fallback gate는 각각 0.90, 0.10을 근소하게 넘지 못했고, median depth도 sequential baseline과 같은 8이었다.

## 4. adaptive common-grid screen

동일 Rust binary와 공통 analytic output grid에서 12 candidates, 4 problems, 3 tolerances를 실행했다. 5개의 one-thread timing campaign과 3개의 four-thread campaign은 같은 scientific checksum을 냈다.

```text
runs per campaign  144
T1 campaigns         5
T4 campaigns         3
scientific checksum
4357ff067db303eb4408674970e35d8adb66562d6460bf2ae8c199f830839b7b
```

Transactional candidate의 accepted steps:

```text
accepted steps                  57
q1 fast                          0
q2 depth-parity                 39
protected fallback              18
strictly sub-8 fraction          0
nonfallback fraction        0.6842
fallback fraction           0.3158
median depth                     8
P95 depth                       16
```

q1은 adaptive trajectory에서 한 번도 terminal lane으로 accept되지 않았다. q2는 일부 nonlinear/mass/nonnormal steps를 처리했지만 depth가 8이며, Prothero–Robinson과 일부 nonnormal step은 fallback했다.

## 5. 비용

동일 problem/tolerance에서 protected JF RODAS5P와 paired comparison:

| Quantity | Transactional / protected median |
|---|---:|
| wall time | 4.6192 |
| RHS evaluations | 5.125 |
| JVP vectors | 8.8792 |
| accepted steps | 1.000 |
| external error | 0.9768 |

즉 step economy는 보존했지만, step당 추가 work가 너무 커 wall time이 약 4.6배로 증가했다.

동일 external-error target matching에서도:

\[
S_{\rm median}=0.2229,
\]

즉 protected JF RODAS5P가 약 4.49배 빨랐다.

## 6. 동결 comparator

- SABR5P: target coverage 75%, median speedup 0.505;
- homotopy q7: coverage 100%, median speedup 0.409;
- frozen BDF2: 현재 높은-정확도 target coverage 0%;
- frozen Radau IIA3: coverage 75%, covered subset median speedup 2.187.

Radau IIA3의 결과는 강한 dense high-order comparator 결과지만 explicit Jacobian/full Newton 계열이며 본 연구의 Jacobian-free/Newton-free 구조 조건을 만족하지 않는다. BDF/Radau source는 G1에서 변경하지 않았다.

## 7. 수학적 한계

Operational certificate는 nonlinear rigorous bound가 아니다. Embedded error에 대한 6/5 power scaling은 local \(O(h^6)\) algebraic defect를 유도하려는 설계 가설이며, arbitrary nonnormal nonlinear system에서의 정리가 아니다.

현재 finite one-step corpus에서 false accept는 0이지만, adaptive fast-path의 독립 5차 order는 승격하지 않는다. adaptive trajectory가 q2와 protected fallback의 혼합이고, common output grid가 high-order step을 clip하기 때문이다.

## 8. 최종 판정

G1 kill rule은 다섯 방식으로 발생했다.

1. adaptive nonfallback fraction < 0.90;
2. adaptive fallback fraction > 0.10;
3. median depth가 8보다 작지 않음;
4. same-error speedup < 1.15;
5. generic one-step gate도 fast/fallback threshold를 근소하게 실패.

따라서 transactional q1→q2는 **범용 acceleration engine으로 HOLD**한다. 구현은 stage-structured research comparator/plugin으로 보존한다.

다음 core branch는 더 많은 q/path/certificate 튜닝이 아니라 parallel fifth-order exponential Rosenbrock/EPIRK sibling이다.
