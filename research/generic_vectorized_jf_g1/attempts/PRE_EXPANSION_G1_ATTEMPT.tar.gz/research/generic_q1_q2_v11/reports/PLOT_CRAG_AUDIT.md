# G1 Plot-based CRAG Adversarial Audit

## Plot reading

### `ONE_STEP_LANE_FRACTIONS.png`

The bounded eight-family calibration nearly reaches the original fast/fallback gate: 7/8 nonfallback, but only 3/8 are strictly sub-8 q1 accepts. The single oscillatory PR fallback is enough to violate the 10% fallback cap.

### `ADAPTIVE_LANE_FRACTIONS.png`

No adaptive accepted step uses q1. About 68.4% terminate in q2 and 31.6% require protected fallback. Calling the 68.4% “fast” would be misleading because q2 has depth 8.

### `CRITICAL_PATH_DEPTH.png`

Both one-step and adaptive medians sit exactly on the eight-stage baseline. P95 rises to 13.2/16 due fallback. The central architectural objective—shorter sequential depth—is not achieved.

### `SAME_ERROR_SPEEDUP.png`

Transactional q1→q2 reaches all protected JF RODAS targets but has median speedup 0.223. BDF2 has no coverage at those high-accuracy targets and is labelled explicitly rather than plotted as zero. Radau IIA3 is fast on 75% of targets but is a frozen explicit-J/Newton comparator, not a structural survivor.

### `PAIRED_COST_RATIOS.png`

Step count is identical, while RHS, JVP and wall costs increase by factors about 5.1, 8.9 and 4.6. This directly reproduces the original failure pattern: good step economy is overwhelmed by within-step work.

## CRAG

### C — Correctness

The lane/depth plots use accepted steps and include fallback work. BDF missing coverage is not converted into a numerical zero. PASS.

### R — Retrieval/contrast

The plots are consistent with the protected RODAS baseline: q2 is depth parity, fallback doubles critical depth. They do not use case-level Rayon throughput as solver-internal speedup. PASS.

### A — Augmentation

The negative result survives two views:

1. one-step eight-family calibration;
2. adaptive same-error trajectories.

It also survives a stricter mutation in which only sub-8 q1 counts as fast: adaptive fast fraction becomes exactly zero.

### G — Generation/prediction

Adding larger dimensions could make common-W batching cheaper, but it cannot by itself remove q2 depth parity or fallback duplication. A different time-integration structure is predicted to be necessary.

## Adversarial mutations

- **Drop certificate batch:** nominal q2 depth becomes 7, but correctness authority is weakened; not an admissible performance result.
- **Ignore fallback work:** candidate remains q2-depth 8 in most successful steps and still pays much larger RHS/JVP work.
- **Count q2 as low-depth:** rejected because q2 depth equals the sequential baseline.
- **Use only easy one-step rows:** raises apparent fast fraction but violates the sealed generic corpus and hides oscillatory PR failure.

## Claim status

- **Surviving:** transactional q1→q2 is strict matrix-free/Newton-free and safely falls back.
- **Narrowed:** q2 is a depth-parity correctness lane for several systems.
- **Rejected:** q1→q2 is a generic accelerated solver meeting G1 objectives.
