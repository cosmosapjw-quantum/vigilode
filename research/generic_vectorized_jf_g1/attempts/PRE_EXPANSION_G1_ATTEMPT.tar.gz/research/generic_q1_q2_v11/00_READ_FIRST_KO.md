# Generic q1→q2 transactional engine — G1 closeout

## 결론

G1은 strict matrix-free RODAS5P stage system에 다음 transactional path를 실제 구현했다.

1. `q=1`, endpoint correction 2회;
2. gate 실패 시 q1 endpoint와 work를 보존한 채 `q=2` causal term 한 번 추가;
3. 다시 실패하면 protected sequential matrix-free RODAS5P로 fallback;
4. certified success 전에는 state를 commit하지 않고, speculative work는 모두 보존.

구조 contract는 통과했다.

```text
explicit Jacobian builds = 0
direct factorizations     = 0
fast-path Newton          = 0
false accepts             = 0  (finite one-step calibration)
```

그러나 acceleration gate는 실패했다.

```text
8-family one-step fast fraction      0.875
8-family one-step fallback fraction  0.125
adaptive nonfallback fraction        0.6842
adaptive fallback fraction           0.3158
adaptive strictly sub-8 fraction     0
adaptive median depth                8
adaptive P95 depth                  16
same-error median speedup          0.2229x
```

즉 q2는 여러 문제에서 Newton/Jacobian 없이 정확한 depth-parity endpoint를 만들지만, adaptive trajectory에서 q1은 한 번도 accept되지 않았고 q2는 sequential depth를 줄이지 못한다. fallback까지 포함하면 후보는 protected JF RODAS5P보다 약 4.5배 느리다.

## 판정

- **PROMOTE:** transactional implementation, work ledger, generic calibration gate.
- **HOLD:** q1→q2를 generic accelerated solver로 승격.
- **NEXT:** BDF/Radau나 물리 client로 우회하지 않고 parallel fifth-order exponential Rosenbrock/EPIRK sibling을 연다.
