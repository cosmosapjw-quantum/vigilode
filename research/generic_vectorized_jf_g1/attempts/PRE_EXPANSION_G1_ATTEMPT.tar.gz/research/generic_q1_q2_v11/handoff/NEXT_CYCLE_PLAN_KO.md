# G2 계획 — Parallel fifth-order exponential Rosenbrock / EPIRK sibling

G1은 transaction semantics를 닫았지만 original acceleration objective를 실패했다. 다음 core node는 BDF/Radau, physical client, BGMRES-DR, 더 많은 homotopy path parameter가 아니다.

## G2A — coefficient and phi-action authority

1. order-five parallel exponential Rosenbrock scheme의 exact coefficient/stiff-order source를 잠근다.
2. small dense matrix에서 \(\varphi_k(hA)v\)를 high-precision oracle로 계산한다.
3. matrix-free adaptive Krylov phi-action을 구현하고 모든 RHS/JVP/orthogonalization work를 센다.
4. EXPRB2와 EXPRB43를 correctness anchor로 구현한다.
5. 그 뒤에만 parallel order-five method를 구현한다.

## G2B — generic calibration

G1과 같은 eight-family corpus를 사용한다. threshold는 physical clients를 보기 전에 동결한다.

## G2C — same-error authority

Protected sequential JF RODAS5P와 동일 external error에서:

\[
N_{\rm step,candidate}\le1.2N_{\rm step,RODAS},
\qquad
S_{\rm median}\ge1.15
\]

을 요구한다.

## Stop rule

phi-action overhead가 8-stage JF RODAS work보다 크거나 order-five/oscillatory/nonnormal gate가 실패하면, 기능 확장 전에 HOLD한다.
