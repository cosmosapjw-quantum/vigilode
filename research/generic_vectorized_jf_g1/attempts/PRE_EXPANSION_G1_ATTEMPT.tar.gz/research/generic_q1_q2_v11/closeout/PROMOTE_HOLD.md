# G1 PROMOTE / HOLD

## PROMOTE — infrastructure only

- strict matrix-free q1→q2 state machine;
- retained-endpoint q2 escalation;
- original-system protected fallback;
- speculative/fallback work preservation;
- diagnostic path-vs-selected-lane distinction;
- generic eight-family one-step gate;
- adaptive same-error integration in the common authority;
- deterministic T1/T4 scientific reporting.

## HOLD — numerical method

- q1→q2 as default generic solver;
- any same-error acceleration claim;
- sub-8 critical-path claim;
- standalone fifth-order fast-path claim;
- certificate simplification for speed;
- physical-client execution;
- BDF/Radau modification.

## Kill rule

Triggered:

- adaptive nonfallback fraction `0.6842 < 0.90`;
- adaptive fallback `0.3158 > 0.10`;
- median depth `8`, P95 `16`;
- same-error speedup `0.2229 < 1.15`;
- one-step fast/fallback gate also narrowly missed.

## Decision

```text
G1_TRANSACTIONAL_Q1_Q2 = HOLD
NEXT_CORE_NODE = PARALLEL_FIFTH_ORDER_EXPONENTIAL_ROSENBROCK_EPIRK
```
