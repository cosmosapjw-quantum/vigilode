# G1/G2 literature source map

## Protected baseline

- G. Steinebach, “Construction of Rosenbrock–Wanner method Rodas5P and numerical benchmarks within the Julia Differential Equations package,” BIT Numerical Mathematics 63, 27 (2023), DOI `10.1007/s10543-023-00967-x`.
  - Use: protected high-order Rosenbrock-Wanner baseline; order-reduction motivation and Rodas-family benchmark.

## Parallel stage iteration context

- P. J. van der Houwen and B. P. Sommeijer, parallel iterated Runge–Kutta lineage, DOI `10.1137/0912054`.
  - Use: iteration count can replace stage count as sequential critical depth when the iteration is designed for stability and accuracy.

- P. J. van der Houwen and J. J. B. de Swart, “Triangularly Implicit Iteration Methods for ODE-IVP Solvers,” DOI `10.1137/S1064827595287456`.
  - Use: early-iteration convergence matters; retaining triangular information can outperform fully decoupled iteration.

- G. Čaklović et al., “Improving Efficiency of Parallel Across the Method Spectral Deferred Corrections,” DOI `10.1137/24M1649800`.
  - Use: nonstationary sweeps and finite-product error propagation as a structural comparator, not a justification for post-hoc tuning.

## Next sibling family

- “Parallel exponential Rosenbrock methods,” Computers & Mathematics with Applications 71 (2016) 1137–1150, DOI `10.1016/j.camwa.2016.01.020`.
  - Use: order-five exponential Rosenbrock schemes can be arranged with parallel critical cost comparable to a three-stage method.

- M. Tokman, J. Loffeld, P. Tranquilli, “New Adaptive Exponential Propagation Iterative Methods of Runge–Kutta Type,” DOI `10.1137/110849961`.
  - Use: adaptive EPIRK methods designed around adaptive Krylov phi-actions.

- J. Loffeld and M. Tokman, “Implementation of Parallel Adaptive-Krylov Exponential Solvers for Stiff Problems,” DOI `10.1137/13094462X`.
  - Use: parallel adaptive-Krylov implementation and comparison against Newton–Krylov implicit solvers.

- Paul Tranquilli and Adrian Sandu, “Rosenbrock–Krylov Methods for Large Systems of Differential Equations,” DOI `10.1137/130923336`.
  - Use: distinct complete-integrator comparator; Krylov properties enter time-discretization order conditions.
