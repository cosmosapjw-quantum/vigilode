#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import tarfile
from pathlib import Path

import matplotlib.pyplot as plt

BASELINE = "protected-sequential-jf-rodas5p-gmres-adaptive"
CANDIDATE_T1 = "transactional-q1-q2-rodas5p-t1-adaptive"
CANDIDATE_T4 = "transactional-q1-q2-rodas5p-t4-adaptive"
PRIMARY_CANDIDATES = {
    CANDIDATE_T1: "Transactional q1→q2 (1 thread)",
    CANDIDATE_T4: "Transactional q1→q2 (4 threads)",
}
COMPARATORS = {
    "bdf2-adaptive-reference": "BDF2 frozen",
    "radau-iia3-adaptive-reference": "Radau IIA3 frozen",
}


def median(xs):
    return statistics.median(xs) if xs else None


def quantile(xs, q):
    if not xs:
        return None
    ys = sorted(xs)
    x = q * (len(ys) - 1)
    lo, hi = math.floor(x), math.ceil(x)
    if lo == hi:
        return ys[lo]
    return ys[lo] * (hi - x) + ys[hi] * (x - lo)


def load(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def rows_by_candidate(doc):
    out = {}
    for row in doc["runs"]:
        out.setdefault(row["candidate_id"], []).append(row)
    return out


def row_key(row):
    return row["problem_id"], float(row["rtol"])


def successful(rows):
    return [row for row in rows if row["status"] == "success"]


def counter(row, name):
    return int(row["work"]["counters"].get(name, 0))


def target_match(base_rows, candidate_rows):
    candidates = successful(candidate_rows)
    matches = []
    for base in successful(base_rows):
        target = float(base["errors"]["max_grid_l2"])
        feasible = [
            row
            for row in candidates
            if row["problem_id"] == base["problem_id"]
            and float(row["errors"]["max_grid_l2"])
            <= target * (1.0 + 1.0e-10) + 1.0e-15
        ]
        if not feasible:
            matches.append(
                {
                    "problem_id": base["problem_id"],
                    "baseline_rtol": base["rtol"],
                    "covered": False,
                }
            )
            continue
        chosen = min(feasible, key=lambda row: row["wall_seconds"])
        matches.append(
            {
                "problem_id": base["problem_id"],
                "baseline_rtol": base["rtol"],
                "covered": True,
                "candidate_rtol": chosen["rtol"],
                "target_error": target,
                "candidate_error": chosen["errors"]["max_grid_l2"],
                "speedup": base["wall_seconds"] / chosen["wall_seconds"],
                "step_ratio": chosen["work"]["internal_steps"]
                / max(base["work"]["internal_steps"], 1),
                "rhs_ratio": counter(chosen, "rhs_evaluations")
                / max(counter(base, "rhs_evaluations"), 1),
                "jvp_ratio": counter(chosen, "jvp_vectors")
                / max(counter(base, "jvp_vectors"), 1),
            }
        )
    return matches


def transactional_summary(rows):
    rows = successful(rows)
    diagnostics = [row["transactional"] for row in rows if row.get("transactional")]
    accepted_q1 = sum(item["accepted_q1_fast_steps"] for item in diagnostics)
    accepted_q2 = sum(item["accepted_q2_escalated_steps"] for item in diagnostics)
    accepted_fb = sum(item["accepted_sequential_fallback_steps"] for item in diagnostics)
    accepted = accepted_q1 + accepted_q2 + accepted_fb
    depths = [value for item in diagnostics for value in item["accepted_critical_path_depths"]]
    batches = [value for item in diagnostics for value in item["accepted_w_solve_batches"]]
    return {
        "runs": len(rows),
        "accepted_steps": accepted,
        "accepted_q1_fast_steps": accepted_q1,
        "accepted_q2_escalated_steps": accepted_q2,
        "accepted_sequential_fallback_steps": accepted_fb,
        "strict_sub8_fraction": accepted_q1 / max(accepted, 1),
        "nonfallback_fraction": (accepted_q1 + accepted_q2) / max(accepted, 1),
        "fallback_fraction": accepted_fb / max(accepted, 1),
        "median_critical_path_depth": median(depths),
        "p95_critical_path_depth": quantile(depths, 0.95),
        "median_common_w_batches": median(batches),
        "p95_common_w_batches": quantile(batches, 0.95),
        "explicit_jacobian_builds": sum(counter(row, "jacobian_builds") for row in rows),
        "direct_factorizations": sum(counter(row, "direct_factorizations") for row in rows),
        "fast_path_newton_iterations": sum(
            counter(row, "nonlinear_iterations")
            for row in rows
            if row["transactional"]["accepted_sequential_fallback_steps"] == 0
        ),
        "failures": 0,
    }


def paired_rows(campaigns, candidate_id):
    rows = []
    for campaign_index, document in enumerate(campaigns, 1):
        groups = rows_by_candidate(document)
        baseline = {row_key(row): row for row in successful(groups[BASELINE])}
        candidate = {row_key(row): row for row in successful(groups[candidate_id])}
        for key, base in baseline.items():
            if key not in candidate:
                continue
            cand = candidate[key]
            rows.append(
                {
                    "campaign": campaign_index,
                    "candidate_id": candidate_id,
                    "problem_id": key[0],
                    "rtol": key[1],
                    "wall_speedup": base["wall_seconds"] / cand["wall_seconds"],
                    "candidate_over_baseline_wall": cand["wall_seconds"]
                    / base["wall_seconds"],
                    "step_ratio": cand["work"]["internal_steps"]
                    / max(base["work"]["internal_steps"], 1),
                    "error_ratio": cand["errors"]["max_grid_l2"]
                    / max(base["errors"]["max_grid_l2"], 1.0e-300),
                    "rhs_ratio": counter(cand, "rhs_evaluations")
                    / max(counter(base, "rhs_evaluations"), 1),
                    "jvp_ratio": counter(cand, "jvp_vectors")
                    / max(counter(base, "jvp_vectors"), 1),
                }
            )
    return rows


def summarize_paired(rows):
    names = [
        "wall_speedup",
        "candidate_over_baseline_wall",
        "step_ratio",
        "error_ratio",
        "rhs_ratio",
        "jvp_ratio",
    ]
    summary = {name: median([row[name] for row in rows]) for name in names}
    summary.update(
        {
            "wall_speedup_q25": quantile([row["wall_speedup"] for row in rows], 0.25),
            "wall_speedup_q75": quantile([row["wall_speedup"] for row in rows], 0.75),
            "rows": len(rows),
        }
    )
    return summary


def plot_bar(labels, values, ylabel, title, path, threshold=None):
    figure, axis = plt.subplots(figsize=(7.2, 4.5))
    axis.bar(labels, values)
    if threshold is not None:
        axis.axhline(threshold, linestyle="--", linewidth=1.2)
    axis.set_ylabel(ylabel)
    axis.set_title(title)
    axis.tick_params(axis="x", rotation=22)
    figure.tight_layout()
    figure.savefig(path, dpi=180)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--campaign-dir", type=Path, required=True)
    parser.add_argument("--gate", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out
    for subdirectory in [
        "results",
        "tables",
        "plots",
        "raw",
        "reports",
        "receipts",
        "handoff",
        "closeout",
        "scripts",
    ]:
        (out / subdirectory).mkdir(parents=True, exist_ok=True)

    t1_paths = sorted(args.campaign_dir.glob("T1_*.json"))
    t4_paths = sorted(args.campaign_dir.glob("T4_*.json"))
    if not t1_paths or not t4_paths:
        raise SystemExit("missing campaigns")
    t1 = [load(path) for path in t1_paths]
    t4 = [load(path) for path in t4_paths]
    checksums = {document["scientific_checksum"] for document in t1 + t4}
    run_counts = {len(document["runs"]) for document in t1 + t4}
    if len(checksums) != 1 or len(run_counts) != 1:
        raise SystemExit("scientific identity mismatch")

    gate = load(args.gate)
    canonical = t1[0]
    groups = rows_by_candidate(canonical)
    adaptive = {
        candidate_id: transactional_summary(groups[candidate_id])
        for candidate_id in PRIMARY_CANDIDATES
    }

    paired = {
        candidate_id: paired_rows(t1, candidate_id) for candidate_id in PRIMARY_CANDIDATES
    }
    paired_summary = {
        candidate_id: summarize_paired(rows) for candidate_id, rows in paired.items()
    }

    target_ids = [*PRIMARY_CANDIDATES, *COMPARATORS]
    all_target = {candidate_id: [] for candidate_id in target_ids}
    campaign_rows = []
    for campaign_index, document in enumerate(t1, 1):
        campaign_groups = rows_by_candidate(document)
        for candidate_id in target_ids:
            all_target[candidate_id].extend(
                target_match(campaign_groups[BASELINE], campaign_groups[candidate_id])
            )
        campaign_rows.append(
            {
                "threads": 1,
                "campaign": campaign_index,
                "scientific_suite_wall_seconds": document["execution"][
                    "scientific_suite_wall_seconds"
                ],
                "scientific_checksum": document["scientific_checksum"],
            }
        )
    for campaign_index, document in enumerate(t4, 1):
        campaign_rows.append(
            {
                "threads": 4,
                "campaign": campaign_index,
                "scientific_suite_wall_seconds": document["execution"][
                    "scientific_suite_wall_seconds"
                ],
                "scientific_checksum": document["scientific_checksum"],
            }
        )

    target_summary = {}
    for candidate_id, matches in all_target.items():
        covered = [match for match in matches if match["covered"]]
        target_summary[candidate_id] = {
            "targets": len(matches),
            "covered": len(covered),
            "coverage_fraction": len(covered) / max(len(matches), 1),
            "median_speedup": median([match["speedup"] for match in covered]),
            "median_step_ratio": median([match["step_ratio"] for match in covered]),
            "median_rhs_ratio": median([match["rhs_ratio"] for match in covered]),
            "median_jvp_ratio": median([match["jvp_ratio"] for match in covered]),
        }

    t1_times = [document["execution"]["scientific_suite_wall_seconds"] for document in t1]
    t4_times = [document["execution"]["scientific_suite_wall_seconds"] for document in t4]
    timing = {
        "t1_campaigns": len(t1_times),
        "t4_campaigns": len(t4_times),
        "t1_median_seconds": median(t1_times),
        "t4_median_seconds": median(t4_times),
        "case_level_throughput_speedup": median(t1_times) / median(t4_times),
        "scientific_checksum": next(iter(checksums)),
        "runs_per_campaign": next(iter(run_counts)),
    }

    gate_summary = gate["summary"]
    best_candidate = max(
        PRIMARY_CANDIDATES,
        key=lambda candidate_id: target_summary[candidate_id]["median_speedup"] or -math.inf,
    )
    best_speedup = target_summary[best_candidate]["median_speedup"]
    primary_adaptive = adaptive[CANDIDATE_T1]
    kill_reasons = []
    if primary_adaptive["nonfallback_fraction"] < 0.9:
        kill_reasons.append("adaptive nonfallback fraction below 0.90")
    if primary_adaptive["fallback_fraction"] > 0.1:
        kill_reasons.append("adaptive fallback fraction above 0.10")
    if primary_adaptive["median_critical_path_depth"] >= 8 and (best_speedup or 0.0) < 1.15:
        kill_reasons.append("median depth is not below 8 and best same-error speedup is below 1.15")
    if gate_summary["fast_fraction"] < 0.9:
        kill_reasons.append("eight-family one-step fast fraction below 0.90")
    if gate_summary["fallback_fraction"] > 0.1:
        kill_reasons.append("eight-family one-step fallback fraction above 0.10")

    analysis = {
        "schema": "generic-q1-q2-g1-analysis-v2",
        "scientific_checksum": next(iter(checksums)),
        "canonical_campaigns": {
            "t1": len(t1),
            "t4": len(t4),
            "runs_per_campaign": next(iter(run_counts)),
        },
        "generic_one_step_gate": gate_summary,
        "adaptive_transactional": adaptive,
        "paired_same_control": paired_summary,
        "same_external_error_target": target_summary,
        "best_transactional_variant": best_candidate,
        "best_transactional_same_error_speedup": best_speedup,
        "timing_campaign": timing,
        "promotion_gates": {
            "false_convergence_required": 0,
            "nonhostile_fast_fraction_min": 0.9,
            "fallback_fraction_max": 0.1,
            "median_batch_depth_max": 8,
            "p95_batch_depth_target": 6,
            "same_error_speedup_min": 1.15,
            "step_ratio_max": 1.2,
            "global_order_min": 4.8,
        },
        "global_order_status": (
            "not promoted: the candidate is already killed by fallback/depth/cost gates; "
            "the adaptive path mixes q2 and protected fallback, so no independent all-fast "
            "fifth-order claim is made"
        ),
        "kill_rule_triggered": bool(kill_reasons),
        "kill_reasons": kill_reasons,
        "verdict": (
            "HOLD_TRANSACTIONAL_Q1_Q2_OPEN_PARALLEL_EXPONENTIAL_SIBLING"
            if kill_reasons
            else "PROMOTE"
        ),
    }

    (out / "results" / "G1_ANALYSIS.json").write_text(
        json.dumps(analysis, indent=2, sort_keys=True) + "\n"
    )
    (out / "results" / "G1_GENERIC_CALIBRATION.json").write_text(
        json.dumps(gate, indent=2) + "\n"
    )
    (out / "results" / "G1_ADAPTIVE_CANONICAL_T1.json").write_text(
        json.dumps(canonical, indent=2) + "\n"
    )
    (out / "results" / "G1_ADAPTIVE_CANONICAL_T4.json").write_text(
        json.dumps(t4[0], indent=2) + "\n"
    )

    all_paired_rows = [row for rows in paired.values() for row in rows]
    with open(out / "tables" / "PAIRED_TRANSACTIONAL_VS_PROTECTED.csv", "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(all_paired_rows[0]))
        writer.writeheader()
        writer.writerows(all_paired_rows)
    with open(out / "tables" / "TIMING_CAMPAIGNS.csv", "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(campaign_rows[0]))
        writer.writeheader()
        writer.writerows(campaign_rows)
    target_rows = []
    for candidate_id, matches in all_target.items():
        for match in matches:
            target_rows.append({"candidate_id": candidate_id, **match})
    target_fields = sorted({field for row in target_rows for field in row})
    with open(out / "tables" / "TARGET_MATCHING.csv", "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=target_fields)
        writer.writeheader()
        writer.writerows(target_rows)

    plot_bar(
        ["One-step\nq1", "One-step\nq2", "One-step\nfallback"],
        [
            gate_summary["q1_fast"] / gate_summary["completed"],
            gate_summary["q2_escalated"] / gate_summary["completed"],
            gate_summary["sequential_fallback"] / gate_summary["completed"],
        ],
        "Fraction",
        "Eight-family one-step terminal lane",
        out / "plots" / "ONE_STEP_LANE_FRACTIONS.png",
    )
    plot_bar(
        ["Adaptive\nsub-8 q1", "Adaptive\ndepth-8 q2", "Adaptive\nfallback"],
        [
            primary_adaptive["accepted_q1_fast_steps"] / primary_adaptive["accepted_steps"],
            primary_adaptive["accepted_q2_escalated_steps"] / primary_adaptive["accepted_steps"],
            primary_adaptive["accepted_sequential_fallback_steps"]
            / primary_adaptive["accepted_steps"],
        ],
        "Accepted-step fraction",
        "Adaptive transactional lane distribution",
        out / "plots" / "ADAPTIVE_LANE_FRACTIONS.png",
    )
    plot_bar(
        ["One-step median", "One-step P95", "Adaptive median", "Adaptive P95"],
        [
            gate_summary["median_critical_path_depth"],
            gate_summary["p95_critical_path_depth"],
            primary_adaptive["median_critical_path_depth"],
            primary_adaptive["p95_critical_path_depth"],
        ],
        "Common-W critical-path depth",
        "Critical-path depth against the eight-stage baseline",
        out / "plots" / "CRITICAL_PATH_DEPTH.png",
        threshold=8,
    )
    speed_ids = [*PRIMARY_CANDIDATES, *COMPARATORS]
    speed_labels = [*PRIMARY_CANDIDATES.values(), *COMPARATORS.values()]
    speed_values = [target_summary[candidate_id]["median_speedup"] for candidate_id in speed_ids]
    figure, axis = plt.subplots(figsize=(7.6, 4.6))
    plotted = [float("nan") if value is None else value for value in speed_values]
    axis.bar(speed_labels, plotted)
    axis.axhline(1.15, linestyle="--", linewidth=1.2)
    for index, value in enumerate(speed_values):
        if value is None:
            axis.text(index, 0.05, "no target coverage", ha="center", va="bottom", rotation=90)
    axis.set_ylabel("Speedup vs protected JF RODAS5P")
    axis.set_title("Same-external-error target-matched speedup")
    axis.tick_params(axis="x", rotation=22)
    figure.tight_layout()
    figure.savefig(out / "plots" / "SAME_ERROR_SPEEDUP.png", dpi=180)
    plt.close(figure)

    labels = ["T1 wall", "T1 RHS", "T1 JVP", "T4 wall", "T4 RHS", "T4 JVP"]
    values = [
        paired_summary[CANDIDATE_T1]["candidate_over_baseline_wall"],
        paired_summary[CANDIDATE_T1]["rhs_ratio"],
        paired_summary[CANDIDATE_T1]["jvp_ratio"],
        paired_summary[CANDIDATE_T4]["candidate_over_baseline_wall"],
        paired_summary[CANDIDATE_T4]["rhs_ratio"],
        paired_summary[CANDIDATE_T4]["jvp_ratio"],
    ]
    plot_bar(
        labels,
        values,
        "Transactional / protected ratio",
        "Paired cost ratios at identical controls",
        out / "plots" / "PAIRED_COST_RATIOS.png",
        threshold=1,
    )

    raw_paths = t1_paths + t4_paths + [args.gate]
    with tarfile.open(out / "raw" / "G1_CANONICAL_RAW.tar.gz", "w:gz") as archive:
        for path in raw_paths:
            archive.add(path, arcname=path.name)
    hashes = []
    for path in sorted(out.rglob("*")):
        if path.is_file() and path != out / "receipts" / "ARTIFACT_SHA256SUMS.txt":
            hashes.append(
                f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(out)}"
            )
    (out / "receipts" / "ARTIFACT_SHA256SUMS.txt").write_text("\n".join(hashes) + "\n")
    print(json.dumps(analysis, indent=2))


if __name__ == "__main__":
    main()
