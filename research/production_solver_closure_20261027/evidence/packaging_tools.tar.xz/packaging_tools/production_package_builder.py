#!/usr/bin/env python3
"""Build the publication package after input freeze; never invoke native builds.

Run from the repository, or supply --root. --inventory-output defaults to a
staging-list file in the system temporary directory. The pinned baseline is
compared with the complete current index/worktree, including after publication.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import tempfile

NODE = "research/production_solver_closure_20261027"
BASELINE = "206298b4068d923bb47c7160b111b7439098660c"
GENERATED = {"SOURCE_MANIFEST.json", "MANIFEST.json", "evidence/RAW_MANIFEST.json", "evidence/raw_measurements.tar.xz", "evidence/PACKAGE_VERIFICATION.json", "evidence/GIT_FILE_INVENTORY.json"}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def confined(root, name):
    relative = PurePosixPath(name)
    if not name or "\\" in name or relative.is_absolute() or ".." in relative.parts or relative.as_posix() != name:
        raise SystemExit(f"unsafe package path: {name}")
    destination = root
    for part in relative.parts:
        destination /= part
        if destination.is_symlink():
            raise SystemExit(f"symlink package input refused: {name}")
    if not destination.resolve().is_relative_to(root.resolve()):
        raise SystemExit(f"package path escapes root: {name}")
    return destination


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--inventory-output", type=Path, default=Path(tempfile.gettempdir()) / "vigilode-production-git-files.txt")
    parser.add_argument("--baseline", default=BASELINE)
    args = parser.parse_args()
    root = args.root.resolve() if args.root else Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], text=True).strip()).resolve()
    node = confined(root, NODE)
    output = args.inventory_output.resolve()
    if output.is_relative_to(node):
        raise SystemExit("--inventory-output must be outside the research node")

    def git_paths(*arguments):
        return {p for p in subprocess.check_output(["git", arguments[0], "-z", *arguments[1:]], cwd=root).decode().split("\0") if p}

    literature = json.loads((node / "evidence/LITERATURE_MAP.json").read_text())
    excluded = {row["path"] for row in literature["exclude_from_public_bundle"]}
    generated = {f"{NODE}/{name}" for name in GENERATED}
    for name in excluded | generated:
        confined(root, name)
    denied = excluded | generated
    files = []
    for path in sorted(node.rglob("*")):
        name = path.relative_to(root).as_posix()
        if path.is_symlink():
            raise SystemExit(f"symlink package input refused: {name}")
        if not path.is_file() or name in denied:
            continue
        if "__pycache__" in path.parts or path.relative_to(node).as_posix().startswith("report/qa/"):
            continue
        files.append(path)
    archive = node / "evidence/raw_measurements.tar.xz"
    members = {}
    with tarfile.open(archive, "w:xz", preset=6, format=tarfile.PAX_FORMAT) as tar:
        for path in files:
            name = path.relative_to(root).as_posix()
            data = path.read_bytes()
            entry = tarfile.TarInfo(name)
            entry.size = len(data)
            entry.mode = 0o644
            entry.mtime = entry.uid = entry.gid = 0
            entry.uname = entry.gname = ""
            tar.addfile(entry, io.BytesIO(data))
            members[name] = {"sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)}
    raw = {"schema_version": 1, "scope": "complete project-owned node evidence and report support; excludes fetched external full text and reproducible page-preview images",
           "archive": archive.relative_to(root).as_posix(), "archive_sha256": sha(archive), "archive_bytes": archive.stat().st_size, "members": members,
           "external_metadata_map": f"{NODE}/evidence/LITERATURE_MAP.json", "extraction": f"python3 {NODE}/verify_package.py --extract-evidence"}
    write_json(node / "evidence/RAW_MANIFEST.json", raw)

    def concise(path):
        rel = path.relative_to(node).as_posix()
        if "/raw/" in "/" + rel or rel.startswith(("report/tex_support/", "report/qa/")):
            return False
        if path.suffix in {".log", ".stderr", ".stdout", ".callgrind", ".aux", ".out", ".toc", ".synctex", ".pyc"}:
            return False
        if rel.startswith("report/build/") and path.suffix != ".pdf":
            return False
        if rel.endswith("SOURCE_INPUTS.json"):
            return False
        return path.stat().st_size <= 100_000 or path.suffix in {".pdf", ".png"}

    # A commit argument includes index and working-tree changes; unlike an
    # index-only diff this survives staging and a publication commit.
    changed = git_paths("diff", "--name-only", "--diff-filter=ACMR", args.baseline)
    deleted = git_paths("diff", "--name-only", "--diff-filter=D", args.baseline)
    new = git_paths("ls-files", "--others", "--exclude-standard", "--", "crates", ".github")
    ordinary = (changed | new | {p.relative_to(root).as_posix() for p in files if concise(p)}) - denied
    ordinary = {name for name in ordinary if confined(root, name).is_file()}
    published = ordinary | {f"{NODE}/{name}" for name in ["SOURCE_MANIFEST.json", "MANIFEST.json", "evidence/RAW_MANIFEST.json", "evidence/raw_measurements.tar.xz", "evidence/GIT_FILE_INVENTORY.json"]}
    inventory = {"schema_version": 1, "files": sorted(published), "deleted_files": sorted(deleted - denied), "excluded_external_receipts": sorted(excluded),
                 "note": "Raw project-owned receipts remain in the hash-checked archive even when not individual Git entries. This inventory includes its own path."}
    inventory_path = node / "evidence/GIT_FILE_INVENTORY.json"
    write_json(inventory_path, inventory)

    # Full tracked crate Rust/build inputs are checked even when unchanged from
    # the baseline; publication still includes only the intended changed files.
    tracked = git_paths("ls-files", "--", "crates")
    build_inputs = {name for name in tracked | new if name.endswith(".rs") or PurePosixPath(name).name in {"Cargo.toml", "Cargo.lock", "build.rs"}}
    root_inputs = ["Cargo.toml", "Cargo.lock", "build.rs", "rust-toolchain", "rust-toolchain.toml", ".cargo/config", ".cargo/config.toml"]
    build_inputs.update(name for name in root_inputs if confined(root, name).is_file())
    for path in (root / "crates").rglob("Cargo.toml"):
        build_inputs.add(path.relative_to(root).as_posix())
    for path in (root / "crates").rglob("Cargo.lock"):
        build_inputs.add(path.relative_to(root).as_posix())
    source_names = (ordinary | build_inputs) - denied
    source_names = {name for name in source_names if confined(root, name).is_file()}
    source_names.add(f"{NODE}/evidence/RAW_MANIFEST.json")
    source_paths = {name: sha(confined(root, name)) for name in sorted(source_names)}
    for name in source_paths.keys() & members.keys():
        if source_paths[name] != members[name]["sha256"]:
            raise SystemExit(f"input changed between archive and source snapshot: {name}")
    write_json(node / "SOURCE_MANIFEST.json", {"schema_version": 1, "scope": "published ordinary files and complete tracked crate Rust/build inputs; raw archive has its own member manifest", "baseline_commit": args.baseline, "sha256": source_paths})
    manifest = {"schema_version": 1, "status": "prepared_for_publication", "baseline_pr": 91, "baseline_commit": args.baseline,
                "branch": "research/production-solver-closure-20261027", "publication_identity_rule": "The commit containing this file is the implementation identity; provider publication receipt is delivered separately after the push.",
                "source_manifest_sha256": sha(node / "SOURCE_MANIFEST.json"), "raw_manifest_sha256": sha(node / "evidence/RAW_MANIFEST.json"), "git_inventory_sha256": sha(inventory_path),
                "report_pdf": "report/build/production_solver_closure.pdf", "report_pdf_sha256": sha(node / "report/build/production_solver_closure.pdf"),
                "correction_loops": {"structural": 3, "homotopy": 1, "adapter": 3}, "maximum_per_research_task": 3,
                "validation": "evidence/VALIDATION_SUMMARY.json", "integration_hygiene": "CI_HYGIENE.md", "local_dag": "DEVELOPMENT_PLAN.json", "handoff": "LOCAL_CODEX_HANDOFF_KO.md",
                "readiness": "Scoped code/configuration and cloud evidence complete; actual client release/LTO qualification remains pending_local.", "public_evidence_file_count": len(members), "raw_archive_bytes": archive.stat().st_size}
    write_json(node / "MANIFEST.json", manifest)
    for name, expected in source_paths.items():
        if sha(confined(root, name)) != expected:
            raise SystemExit(f"source input changed during packing: {name}")
    for name, expected in members.items():
        if sha(confined(root, name)) != expected["sha256"]:
            raise SystemExit(f"archive input changed during packing: {name}")
    if output in {confined(root, name) for name in published | source_names}:
        raise SystemExit("inventory output overlaps a package input")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(sorted(published)) + "\n")
    print(json.dumps({"archive_bytes": archive.stat().st_size, "archive_members": len(members), "git_files": len(published), "source_manifest_files": len(source_paths), "inventory_output": str(output)}))


if __name__ == "__main__":
    main()
