#!/usr/bin/env python3
"""Owned toy repositories only; never builds/extracts the actual research package."""
import hashlib,io,json,pathlib,shutil,subprocess,tarfile,tempfile
ROOT=pathlib.Path('/workspace/scratch/06cfffc081e2')
BUILDER=ROOT/'tmp/production_package_builder.py'
VERIFIER=ROOT/'vigilode/research/production_solver_closure_20261027/verify_package.py'
NODE='research/production_solver_closure_20261027'
results=[]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def w(p,value):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value)
def j(p):return json.loads(p.read_text())
def jw(p,v):w(p,json.dumps(v,indent=2)+'\n')
def run(argv,cwd,ok=True,contains=None):
 p=subprocess.run(argv,cwd=cwd,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 if ok:assert p.returncode==0,(argv,p.stdout,p.stderr)
 else:assert p.returncode!=0,(argv,p.stdout,p.stderr)
 if contains:assert contains in p.stdout+p.stderr,(contains,p.stdout,p.stderr)
 return p.stdout.strip()
def check(name,fn):fn();results.append({'name':name,'pass':True})
with tempfile.TemporaryDirectory(prefix='vigilode-package-contract-') as td:
 t=pathlib.Path(td);r=t/'repository';r.mkdir();n=r/NODE
 run(['git','init','-q'],r);run(['git','config','user.email','toy@example.invalid'],r);run(['git','config','user.name','Packaging toy'],r)
 w(r/'Cargo.toml','[workspace]\nmembers=["crates/toy"]\n');w(r/'Cargo.lock','# pinned toy lock\n')
 w(r/'rust-toolchain.toml','[toolchain]\nchannel="1.94.1"\n');w(r/'crates/toy/Cargo.toml','[package]\nname="toy"\nversion="0.0.0"\n')
 w(r/'crates/toy/src/lib.rs','pub fn original() {}\n');run(['git','add','.'],r);run(['git','commit','-qm','baseline'],r)
 base=run(['git','rev-parse','HEAD'],r)
 w(r/'crates/toy/src/lib.rs','pub fn changed() {}\n');w(r/'crates/toy/tests/new.rs','#[test] fn tiny() {}\n')
 w(n/'.gitignore','**/raw/\n');jw(n/'DEVELOPMENT_PLAN.json',{'nodes':[{'id':'ONE','dependencies':[],'correction_loops_used':1,'correction_loops_max':3}]})
 external=f'{NODE}/evidence/external.json';jw(n/'evidence/LITERATURE_MAP.json',{'exclude_from_public_bundle':[{'path':external}]})
 w(r/external,'{"externally_fetched_text":"excluded toy marker"}\n');w(n/'README.md','owned document\n');w(n/'evidence/raw/original.log','owned raw payload\n')
 w(n/'report/build/production_solver_closure.pdf','%PDF-owned-toy\n');shutil.copyfile(VERIFIER,n/'verify_package.py')
 inv=t/'inventory.txt'
 def build():return run(['python3',str(BUILDER),'--root',str(r),'--baseline',base,'--inventory-output',str(inv)],r)
 def verify(*args,ok=True,contains=None,root=r):return run(['python3',str(root/NODE/'verify_package.py'),*args],root,ok,contains)
 def links():
  raw=n/'evidence/RAW_MANIFEST.json';source=n/'SOURCE_MANIFEST.json';manifest=n/'MANIFEST.json'
  s=j(source);s['sha256'][f'{NODE}/evidence/RAW_MANIFEST.json']=h(raw);jw(source,s)
  m=j(manifest);m['raw_manifest_sha256']=h(raw);m['source_manifest_sha256']=h(source);jw(manifest,m)
 check('unstaged_first_build_and_verify',lambda:(build(),verify(),verify('--source-only')))
 initial_inventory=j(n/'evidence/GIT_FILE_INVENTORY.json')['files']
 required=['Cargo.lock','Cargo.toml','rust-toolchain.toml','crates/toy/Cargo.toml','crates/toy/src/lib.rs','crates/toy/tests/new.rs']
 assert all(x in j(n/'SOURCE_MANIFEST.json')['sha256'] for x in required);results.append({'name':'unchanged_build_inputs_and_new_code_hashed','pass':True})
 assert external not in initial_inventory and external not in j(n/'evidence/RAW_MANIFEST.json')['members'];results.append({'name':'fetched_text_excluded','pass':True})
 assert f'{NODE}/evidence/GIT_FILE_INVENTORY.json' in initial_inventory;results.append({'name':'inventory_includes_self_path','pass':True})
 check('staged_rebuild_retains_inventory',lambda:(run(['git','add','-A'],r),build(),verify()))
 assert j(n/'evidence/GIT_FILE_INVENTORY.json')['files']==initial_inventory
 run(['git','add','-A'],r);run(['git','commit','-qm','publication toy'],r)
 check('postcommit_rebuild_without_hash_cycle',lambda:(build(),verify()))
 assert j(n/'evidence/GIT_FILE_INVENTORY.json')['files']==initial_inventory
 s=j(n/'SOURCE_MANIFEST.json')['sha256'];assert f'{NODE}/SOURCE_MANIFEST.json' not in s and f'{NODE}/MANIFEST.json' not in s
 # Only published + baseline files form the clean checkout; ignored raw files are absent.
 clean=t/'clean';clean.mkdir()
 tracked=run(['git','ls-files'],r).splitlines()
 for name in set(tracked)|set(initial_inventory):
  if name==external:continue
  p=r/name
  if p.is_file():dest=clean/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest)
 check('clean_checkout_verify_and_idempotent_extract',lambda:(verify(root=clean),verify('--extract-evidence',root=clean),verify('--extract-evidence',root=clean)))
 report=n/'report/build/production_solver_closure.pdf';old=report.read_bytes();report.write_bytes(old+b'changed')
 check('modified_report_refused',lambda:verify(ok=False,contains='report PDF identity mismatch'));report.write_bytes(old)
 lock=r/'Cargo.lock';old=lock.read_bytes();lock.write_bytes(old+b'changed')
 check('modified_unchanged_lock_refused',lambda:verify(ok=False,contains='source Cargo.lock identity mismatch'));lock.write_bytes(old)
 readme=n/'README.md';old=readme.read_bytes();readme.write_bytes(old+b'changed')
 s=j(n/'SOURCE_MANIFEST.json');s['sha256'][f'{NODE}/README.md']=h(readme);jw(n/'SOURCE_MANIFEST.json',s);links()
 check('archive_source_overlap_refused',lambda:verify(ok=False,contains='archive/source overlap mismatch'));readme.write_bytes(old);build()
 rawlog=n/'evidence/raw/original.log';old=rawlog.read_bytes();rawlog.write_bytes(b'local edit')
 check('changed_local_raw_evidence_not_overwritten',lambda:verify('--extract-evidence',ok=False,contains='refuse to overwrite changed local evidence'));rawlog.write_bytes(old)
 outside=t/'outside';outside.mkdir();shutil.rmtree(rawlog.parent);rawlog.parent.symlink_to(outside,target_is_directory=True)
 check('symlink_ancestor_refused_without_external_write',lambda:verify('--extract-evidence',ok=False,contains='symlink traversal refused'))
 assert not list(outside.iterdir());rawlog.parent.unlink();w(rawlog,'owned raw payload\n')
 archive=n/'evidence/raw_measurements.tar.xz';original=archive.read_bytes();raw_original=(n/'evidence/RAW_MANIFEST.json').read_bytes()
 with tarfile.open(archive,'r:xz') as tar:entries=[(m,tar.extractfile(m).read()) for m in tar.getmembers()]
 with tarfile.open(archive,'w:xz') as tar:
  for m,data in entries+[entries[0]]:tar.addfile(m,io.BytesIO(data))
 raw=j(n/'evidence/RAW_MANIFEST.json');raw['archive_sha256']=h(archive);raw['archive_bytes']=archive.stat().st_size;jw(n/'evidence/RAW_MANIFEST.json',raw);links()
 check('duplicate_archive_member_refused',lambda:verify(ok=False,contains='duplicate archive member'))
 archive.write_bytes(original);(n/'evidence/RAW_MANIFEST.json').write_bytes(raw_original);links()
 raw=j(n/'evidence/RAW_MANIFEST.json');raw['archive']='/tmp/not-allowed.tar.xz';jw(n/'evidence/RAW_MANIFEST.json',raw);links()
 check('absolute_manifest_archive_path_refused',lambda:verify(ok=False,contains='unsafe package path'))
 (n/'evidence/RAW_MANIFEST.json').write_bytes(raw_original);links()
 check('final_toy_reverification',lambda:verify())
receipt={'schema_version':1,'scope':'owned toy packaging contracts; actual research archive not created; no native solver run','status':'pass','tests':results,'verifier_sha256':h(VERIFIER),'builder_sha256':h(BUILDER),'check_script_sha256':h(pathlib.Path(__file__))}
jw(ROOT/'tmp/production_packaging_contracts.json',receipt)
print(json.dumps(receipt,indent=2))
