# Correction3: branch equivalence and measurement identity

Final production CI reported `clippy::collapsible_if` at the observed-step
storage branch and adaptive-entry configuration validation. The correction
contains exactly the two hunks in `pass3_branch_cleanup.diff`. Only
`crates/vigilode/src/switching.rs` was rustfmt'd by this task.

Before SHA-256:
`ebea1dd7b76da45def13f6d9e1137f693786f23308f2e0cc589debc82b658347`.
After SHA-256:
`119f2a70d5d8be82816e9c236f4b06644faffe2df545a93b824deeb6ce356bbf`.

## Observed-step branch

Let A be `config.reuse_observed_entry_step`, B be `!pilot_fatal`, and O be
`observed_entry_step(&pilot.record)`. The old form was
`if A && B { if let Some(observed) = O { body } }`; the new form is
`if A && B && let Some(observed) = O { body }`.

Both evaluate A first, evaluate B only when A is true, and evaluate O exactly
once only when A and B are true. Both execute the unchanged body only for
`Some(observed)`. The body writes the same observation and performs the same
conditional entry-seed calculation. O is `Option<f64>`, so restructuring the
condition introduces no destructor with an observable lifetime difference.

## Validation branch

The old form was `if let Some(a) = &c.entry_probe_adaptation { if Q(a) {
return Err(message) } }`; the new form is `if let Some(a) =
&c.entry_probe_adaptation && Q(a) { return Err(message) }`.

Both borrow the same option, skip Q for `None`, and evaluate the same ordered
short-circuit disjunction for `Some(a)`. Every predicate, its order, the error
text and the return point are unchanged. The borrowed configuration remains
alive in both forms. No numerical operation, callback, comparison margin,
accepted state, fixture or policy setting changes.

The statements R1--R4 in `../THEORY.md` therefore need no modification. This
pass closes two lint findings and is conservatively counted as the third and
last correction. Its native contract rerun and complete trajectory equality
audit are recorded separately in `../PASS3_RECEIPT.json`.

## Historical performance evidence

The paired timing and Callgrind results retain executable SHA-256
`8671afe3561e0b658c857ca7fe4ee5f892781fcadac69b2d491c21c595680702`
and the pre-correction switching hash above. The executable was preserved at
`/workspace/scratch/06cfffc081e2/tmp/adapter_pre_style_8671afe3/production_return_bench_20261027`
before rebuilding. All raw profiles remain unchanged. A final exact equality
audit can transfer the existing oracle conclusions to identical trajectories;
it does not transfer measured instruction counts or elapsed timings to a new
executable.
