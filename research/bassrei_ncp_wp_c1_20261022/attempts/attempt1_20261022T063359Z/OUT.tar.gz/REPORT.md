# BASS/rei NCP C1 campaign: INVALID

Infrastructure issues (verdict INVALID, no ledger row):

- no PLAN.json
- reference S1-G2 missing or cut (MISSING/MISSING)
- reference S1-G3 missing or cut (MISSING/MISSING)
- reference S2-G2 missing or cut (MISSING/MISSING)
- reference S2-G3 missing or cut (MISSING/MISSING)
- reference S2-G4 missing or cut (MISSING/MISSING)
- reference S3-G2 missing or cut (MISSING/MISSING)
- reference S4N1 missing or cut (MISSING/MISSING)
- reference S4S missing or cut (MISSING/MISSING)
- reference S4R missing or cut (MISSING/MISSING)
- PARITY.json missing or partial
- VigilODE S1-G2/vg_dense rung item missing
- VigilODE S1-G2/vg_banded rung item missing
- VigilODE S1-G2/vg_client_exact rung item missing
- VigilODE S1-G2/vg_client_krylov rung item missing
- VigilODE S1-G3/vg_banded rung item missing
- VigilODE S1-G3/vg_client_exact rung item missing
- VigilODE S1-G3/vg_client_krylov rung item missing
- VigilODE S2-G2/vg_dense rung item missing
- VigilODE S2-G2/vg_banded rung item missing
- VigilODE S2-G2/vg_client_exact rung item missing
- VigilODE S2-G2/vg_client_krylov rung item missing
- VigilODE S2-G3/vg_banded rung item missing
- VigilODE S2-G3/vg_client_exact rung item missing
- VigilODE S2-G3/vg_client_krylov rung item missing
- VigilODE S2-G4/vg_banded rung item missing
- VigilODE S2-G4/vg_client_exact rung item missing
- VigilODE S2-G4/vg_client_krylov rung item missing
- VigilODE S3-G2/vg_bordered_dense rung item missing
- VigilODE S3-G2/vg_bordered_client rung item missing
- VigilODE S4N1/vg_chem_dense rung item missing
- VigilODE S4S/vg_chem_dense rung item missing
- VigilODE S4R/vg_chem_dense rung item missing
- identity group S2-G2/vg_dense incomplete
- identity group S2-G2/vg_banded incomplete
- identity group S2-G2/vg_client_exact incomplete
- identity group S2-G2/vg_client_krylov incomplete
- identity group S1-G3/vg_banded incomplete
- identity group S3-G2/vg_bordered_dense incomplete
- identity group S3-G2/vg_bordered_client incomplete

| gate | pass |
|---|---|
| G1_references | False |
| G2_reference_parity | False |
| G3_vigilode_rung | False |
| G4_cross_core_identity | False |
| G5_allocation | False |
| G6_coverage | False |
| G7_provenance | True |

## Matched rungs (loosest rtol meeting B_app/B_src; solve seconds diagnostic_only; * = censored at the loosest rung)


## ABBA (B/A solve-time medians, diagnostic_only)

