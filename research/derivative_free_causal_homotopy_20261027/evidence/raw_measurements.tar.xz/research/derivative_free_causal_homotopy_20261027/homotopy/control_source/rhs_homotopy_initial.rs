//! RHS-map-only homotopy with a screened depth-one Anderson extrapolation.
//!
//! The callback computes the fixed-point map itself. This module requests no
//! Jacobian, JVP, finite-difference derivative, AD, matrix factorization, or
//! Newton correction. A caller that builds those operations into its map must
//! account for them separately; the interface does not erase that work.
//!
//! At each continuation station, the map is
//! `G_lambda(x) = (1-lambda) anchor + lambda G(x)`. History is reset when lambda
//! changes. An extrapolation replaces a fully evaluated Picard candidate only
//! when its original-map residual is smaller. For an exact contraction of
//! factor q on a common invariant domain, the selected residual decreases by
//! at least q per update, and the root error is at most residual / (1-q).
//! The binary64 residual returned here is an operational measurement: callers
//! supplying a rigorous error bound must also bound evaluation and rounding.

use serde::Serialize;

/// A direct fixed-point map. Callback outputs must be fully overwritten.
/// The callback and domain predicate must describe one unchanged map/epoch.
pub trait RhsOnlyMap {
    fn dimension(&self) -> usize;
    fn evaluate(&self, x: &[f64], out: &mut [f64]) -> Result<(), String>;
    fn admits(&self, x: &[f64]) -> bool {
        x.len() == self.dimension() && x.iter().all(|v| v.is_finite())
    }
    fn model_epoch(&self) -> Option<u64> {
        None
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub enum RhsAcceleration {
    Picard,
    /// Try every admissible depth-one extrapolation until its rejection cap.
    Screened,
    /// Try only when the last accepted residual ratio exceeds the threshold.
    /// This is a work heuristic; the actual residual screen still decides.
    SlowOnly,
}

#[derive(Clone, Debug, Serialize)]
pub struct RhsHomotopyConfig {
    /// Strictly increasing values in (0,1], ending at exactly 1.
    pub lambdas: Vec<f64>,
    pub residual_l2_tolerance: f64,
    pub max_iterations_per_lambda: usize,
    /// Includes the starting residual, baseline candidates, rejected trials,
    /// and every continuation station. Charged before callback dispatch.
    pub max_map_evaluations: u64,
    pub acceleration: RhsAcceleration,
    pub min_residual_ratio: f64,
    /// Required actual-residual improvement over the Picard candidate.
    pub improvement_factor: f64,
    pub max_coefficient: f64,
    pub max_rejected_trials_per_lambda: usize,
}
impl Default for RhsHomotopyConfig {
    fn default() -> Self {
        Self {
            lambdas: vec![1.0],
            residual_l2_tolerance: 1e-11,
            max_iterations_per_lambda: 4096,
            max_map_evaluations: 16384,
            acceleration: RhsAcceleration::SlowOnly,
            min_residual_ratio: 0.5,
            improvement_factor: 0.9,
            max_coefficient: 1024.0,
            max_rejected_trials_per_lambda: 2,
        }
    }
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct RhsHomotopyWork {
    pub map_attempted: u64,
    pub map_completed: u64,
    pub picard_updates: u64,
    pub extrapolation_trials: u64,
    pub extrapolations_accepted: u64,
    pub extrapolations_rejected: u64,
    pub domain_skipped_trials: u64,
    pub coefficient_skips: u64,
    pub policy_skips: u64,
    pub continuation_stations: u64,
    /// Scalar dot-product passes over the state; no least-squares matrix.
    pub residual_dot_passes: u64,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
pub enum RhsHomotopyFailureKind {
    Input,
    Budget,
    Domain,
    Callback,
    NonFinite,
    ModelChanged,
    IterationLimit,
}

#[derive(Clone, Debug, Serialize)]
pub struct RhsHomotopyFailure {
    pub kind: RhsHomotopyFailureKind,
    pub message: String,
}

#[derive(Clone, Debug, Serialize)]
pub struct RhsHomotopyPoint {
    pub lambda: f64,
    pub state: Vec<f64>,
    pub residual_l2: f64,
    pub iterations: usize,
    pub map_evaluations: u64,
}

#[derive(Clone, Debug, Default, Serialize)]
pub struct RhsHomotopyAttempt {
    /// Present only after a lambda=1 residual passes the requested tolerance.
    pub root: Option<Vec<f64>>,
    pub points: Vec<RhsHomotopyPoint>,
    pub work: RhsHomotopyWork,
    pub failure: Option<RhsHomotopyFailure>,
}

fn failure(kind: RhsHomotopyFailureKind, message: &str) -> RhsHomotopyFailure {
    RhsHomotopyFailure {
        kind,
        message: message.into(),
    }
}
fn l2(x: &[f64]) -> f64 {
    x.iter().fold(0.0_f64, |r, &v| r.hypot(v))
}

struct Value {
    state: Vec<f64>,
    mapped: Vec<f64>,
    residual: Vec<f64>,
    norm: f64,
}

fn evaluate<M: RhsOnlyMap + ?Sized>(
    map: &M,
    anchor: &[f64],
    state: Vec<f64>,
    lambda: f64,
    epoch: Option<u64>,
    cfg: &RhsHomotopyConfig,
    work: &mut RhsHomotopyWork,
) -> Result<Value, RhsHomotopyFailure> {
    if state.len() != anchor.len() || state.iter().any(|v| !v.is_finite()) {
        return Err(failure(
            RhsHomotopyFailureKind::NonFinite,
            "candidate contains nonfinite arithmetic",
        ));
    }
    if map.model_epoch() != epoch {
        return Err(failure(
            RhsHomotopyFailureKind::ModelChanged,
            "map epoch changed before callback",
        ));
    }
    if !map.admits(&state) {
        return Err(failure(
            RhsHomotopyFailureKind::Domain,
            "candidate is outside the callback domain",
        ));
    }
    if work.map_attempted >= cfg.max_map_evaluations {
        return Err(failure(
            RhsHomotopyFailureKind::Budget,
            "map evaluation budget exhausted before dispatch",
        ));
    }
    work.map_attempted += 1;
    let mut mapped = vec![f64::NAN; state.len()];
    map.evaluate(&state, &mut mapped)
        .map_err(|e| RhsHomotopyFailure {
            kind: RhsHomotopyFailureKind::Callback,
            message: e,
        })?;
    if map.model_epoch() != epoch {
        return Err(failure(
            RhsHomotopyFailureKind::ModelChanged,
            "map epoch changed during callback",
        ));
    }
    if mapped.iter().any(|v| !v.is_finite()) {
        return Err(failure(
            RhsHomotopyFailureKind::NonFinite,
            "map did not fully write finite output",
        ));
    }
    work.map_completed += 1;
    for (g, a) in mapped.iter_mut().zip(anchor) {
        *g = (1.0 - lambda) * a + lambda * *g;
    }
    let residual: Vec<_> = mapped.iter().zip(&state).map(|(g, x)| g - x).collect();
    let norm = l2(&residual);
    if !norm.is_finite() {
        return Err(failure(
            RhsHomotopyFailureKind::NonFinite,
            "homotopy map or residual overflowed",
        ));
    }
    Ok(Value {
        state,
        mapped,
        residual,
        norm,
    })
}

fn valid(cfg: &RhsHomotopyConfig, dimension: usize, anchor: &[f64]) -> bool {
    dimension > 0
        && dimension == anchor.len()
        && anchor.iter().all(|v| v.is_finite())
        && cfg.residual_l2_tolerance.is_finite()
        && cfg.residual_l2_tolerance > 0.0
        && cfg.max_iterations_per_lambda > 0
        && cfg.max_map_evaluations > 0
        && cfg.min_residual_ratio.is_finite()
        && cfg.min_residual_ratio >= 0.0
        && cfg.improvement_factor.is_finite()
        && cfg.improvement_factor > 0.0
        && cfg.improvement_factor <= 1.0
        && cfg.max_coefficient.is_finite()
        && cfg.max_coefficient > 0.0
        && cfg.lambdas.last() == Some(&1.0)
        && cfg
            .lambdas
            .iter()
            .all(|v| v.is_finite() && *v > 0.0 && *v <= 1.0)
        && cfg.lambdas.windows(2).all(|v| v[0] < v[1])
}

/// Solve a direct fixed-point target using only callback values and vector
/// arithmetic. No input state is mutated; partial station successes and all
/// attempted callback work survive a failure. A callback error is fatal even
/// when it occurs at an optional extrapolated candidate.
pub fn solve_rhs_homotopy<M: RhsOnlyMap + ?Sized>(
    map: &M,
    anchor: &[f64],
    cfg: &RhsHomotopyConfig,
) -> RhsHomotopyAttempt {
    let mut out = RhsHomotopyAttempt::default();
    if !valid(cfg, map.dimension(), anchor) {
        out.failure = Some(failure(
            RhsHomotopyFailureKind::Input,
            "invalid RHS homotopy input/configuration",
        ));
        return out;
    }
    let epoch = map.model_epoch();
    let result = run(map, anchor, cfg, epoch, &mut out);
    match result {
        Ok(root) => out.root = Some(root),
        Err(e) => out.failure = Some(e),
    }
    out
}

fn run<M: RhsOnlyMap + ?Sized>(
    map: &M,
    anchor: &[f64],
    cfg: &RhsHomotopyConfig,
    epoch: Option<u64>,
    out: &mut RhsHomotopyAttempt,
) -> Result<Vec<f64>, RhsHomotopyFailure> {
    let mut seed = anchor.to_vec();
    for &lambda in &cfg.lambdas {
        out.work.continuation_stations += 1;
        let calls_before = out.work.map_attempted;
        // Residuals from different lambda values cannot share Anderson history.
        let mut previous: Option<Value> = None;
        let mut rejected = 0;
        let mut current = evaluate(map, anchor, seed, lambda, epoch, cfg, &mut out.work)?;
        let mut iteration = 0;
        while current.norm > cfg.residual_l2_tolerance {
            if iteration == cfg.max_iterations_per_lambda {
                return Err(failure(
                    RhsHomotopyFailureKind::IterationLimit,
                    "station exhausted its update limit",
                ));
            }
            let baseline = evaluate(
                map,
                anchor,
                current.mapped.clone(),
                lambda,
                epoch,
                cfg,
                &mut out.work,
            )?;
            let mut selected = baseline;
            out.work.picard_updates += 1;
            // Do not spend a speculative map call after the Picard root passes.
            if selected.norm > cfg.residual_l2_tolerance
                && cfg.acceleration != RhsAcceleration::Picard
            {
                if let Some(old) = &previous {
                    let slow = current.norm >= cfg.min_residual_ratio * old.norm;
                    if rejected < cfg.max_rejected_trials_per_lambda
                        && (cfg.acceleration == RhsAcceleration::Screened || slow)
                    {
                        // Normalize both vectors before forming dot products.
                        // This prevents overflow/underflow from squaring their
                        // common absolute residual scale.
                        let scale = current
                            .residual
                            .iter()
                            .chain(&old.residual)
                            .fold(0.0_f64, |s, &v| s.max(v.abs()));
                        let mut numerator = 0.0;
                        let mut denominator = 0.0;
                        if scale > 0.0 {
                            for (&r, &r_old) in current.residual.iter().zip(&old.residual) {
                                let dr = r / scale - r_old / scale;
                                numerator += (r / scale) * dr;
                                denominator += dr * dr;
                            }
                        }
                        out.work.residual_dot_passes += 1;
                        let gamma = numerator / denominator;
                        if gamma.is_finite() && gamma.abs() <= cfg.max_coefficient {
                            let trial: Vec<_> = current
                                .mapped
                                .iter()
                                .zip(&old.mapped)
                                .map(|(g, g_old)| g - gamma * (g - g_old))
                                .collect();
                            if trial.iter().all(|v| v.is_finite()) && map.admits(&trial) {
                                out.work.extrapolation_trials += 1;
                                let extrapolated = evaluate(
                                    map,
                                    anchor,
                                    trial,
                                    lambda,
                                    epoch,
                                    cfg,
                                    &mut out.work,
                                )?;
                                if extrapolated.norm <= cfg.improvement_factor * selected.norm {
                                    selected = extrapolated;
                                    out.work.extrapolations_accepted += 1;
                                } else {
                                    rejected += 1;
                                    out.work.extrapolations_rejected += 1;
                                }
                            } else {
                                rejected += 1;
                                out.work.domain_skipped_trials += 1;
                            }
                        } else {
                            out.work.coefficient_skips += 1;
                        }
                    } else {
                        out.work.policy_skips += 1;
                    }
                }
            }
            previous = Some(current);
            current = selected;
            iteration += 1;
        }
        seed = current.state;
        out.points.push(RhsHomotopyPoint {
            lambda,
            state: seed.clone(),
            residual_l2: current.norm,
            iterations: iteration,
            map_evaluations: out.work.map_attempted - calls_before,
        });
    }
    Ok(seed)
}
