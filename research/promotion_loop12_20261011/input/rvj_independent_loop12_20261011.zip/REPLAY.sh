#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m pytest -q
python symbolic_checks.py
if [[ "${1:-}" == "--study" ]]; then
  python run_studies.py
  python extra_studies.py
  python verify_selected_order.py
fi
