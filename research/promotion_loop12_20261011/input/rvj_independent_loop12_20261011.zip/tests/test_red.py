from fractions import Fraction as F
from rvj_packet.packet import kernel_tail, volterra_monomial

def test_dropped_cluster_tail_is_not_zero():
    assert kernel_tail(F(1),F(1,2),0)==F(1,2)

def test_causal_convolution_is_not_pointwise_product():
    assert volterra_monomial(2,1)==(4,F(1,12))
