from fractions import Fraction as F
from dataclasses import replace
import ast
from pathlib import Path
import pytest
from rvj_packet.packet import *

def example(n=9,width=F(1)):
    xi=tuple(F(2*i,n-1)-1 for i in range(n))
    a=tuple(C(F(1,4)+x/16,F((i%5)-2,64)) for i,x in enumerate(xi))
    return Model(xi,(F(1,n),)*n,a,width=width)

def test_convolution_unit_constant(): assert conv([ONE],[ONE])==[Z,ONE]
def test_poly_convolution_commutes():
    a=[C(1,2),C(2,-1)]; b=[C(-3,1),I,ONE]
    assert conv(a,b)==conv(b,a)
def test_complex_product_not_holomorphic_shortcut():
    p=[C(1,2),C(3,-1)]
    assert evaluate(force(p,F(1,8)),F(1,3))==I*F(1,8)*evaluate(p,F(1,3)).norm2()*evaluate(p,F(1,3))
def test_odd_moments_of_distribution_do_not_delete_initial_odd_data():
    p=compile_packet(example(),F(1,2),4)
    assert p.mu[1]==0 and p.nu[1]!=Z

def test_exact_full_compressed_discrete_parity():
    model=example(7);a=Work();b=Work()
    p=compile_packet(model,F(1,4),4,a)
    c=candidate(p,6,3,None,a)
    full=full_waveform_mean(model,F(1,4),4,6,3,b)
    assert c.mean==full
    assert b.volterra_terms==len(model.xi)*a.volterra_terms

def test_reconstruction_mean_is_causal_map_not_unrelated_projection():
    p=compile_packet(example(),F(1,2),6);c=candidate(p,8,4)
    ans=reconstruct(c)
    expected=evaluate(add(p.free,scale(conv(p.kernel,force(c.mean,p.model.chi)),p.horizon)),F(1))
    assert sum((w*z for w,z in zip(p.model.weights,ans)),Z)==expected

def test_initial_condition_is_exact():
    p=compile_packet(example(),F(1,2),8);c=candidate(p)
    assert c.mean[0]==sum((w*a for w,a in zip(p.model.weights,p.model.initial)),Z)

def test_full_tail_not_suppressed_by_small_reduced_residual():
    m=example();p=compile_packet(m,F(1,2),0);c=candidate(p,10,6)
    ct=certificate(c)
    assert ct['kernel_model']>F(1,10) and ct['volterra_defect']<F(1,10**5)
    with pytest.raises(ValueError): commit(c,ct,F(1,10**7))

def test_high_order_certificate_accepts_requested_modes():
    p=compile_packet(example(),F(1,2),8);c=candidate(p)
    ct=certificate(c); assert max(ct['mode_bounds'])<F(1,10**7)
    assert len(commit(c,ct,F(1,10**7)))==9

def test_involution_even_odd_evaluation_preserves_all_coefficients():
    poly=[C(1,2),I,C(3),C(-1,2),C(2,-1)]
    assert even_odd_pair(poly,F(2,3))==(evaluate(poly,F(2,3)),evaluate(poly,F(-2,3)))

def test_wrong_model_not_accepted():
    p=compile_packet(example(),F(1,2),8);c=candidate(p);ct=certificate(c)
    other=replace(c,mean=(c.mean[0],)+tuple(x+F(1,1000) for x in c.mean[1:]))
    with pytest.raises(ValueError): commit(other,ct,F(1,10**7))

def test_complex_energy_guard():
    with pytest.raises(ValueError): Model((F(0),),(F(1),),(C(2),))
def test_negative_weight_rejected():
    with pytest.raises(ValueError): Model((F(-1),F(1)),(F(-1),F(2)),(C(0),C(0)))
def test_cluster_width_coordinate_rejected():
    with pytest.raises(ValueError): Model((F(2),),(F(1),),(C(0),))
def test_domain_guard_not_inferred_from_low_residual():
    p=compile_packet(example(),F(1,2),8);bad=Candidate(p,(C(2),),0,1)
    with pytest.raises(ValueError): certificate(bad)
def test_phase_enclosure_modulus():
    for angle in [F(0),F(1,7),F(10**6)]:
        z,e,_=carrier_enclosure(angle)
        assert abs(z.norm2()-1)<=e*(2+e)
def test_carrier_does_not_change_mean_solver():
    m=example();c=candidate(compile_packet(m,F(1,2),8))
    n=replace(m,carrier=F(10**8));d=candidate(compile_packet(n,F(1,2),8))
    assert c.mean==d.mean

def test_no_online_derivative_or_solver_imports():
    tree=ast.parse(Path('rvj_packet/packet.py').read_text())
    modules=[]
    for item in ast.walk(tree):
        if isinstance(item,ast.Import): modules += [a.name for a in item.names]
        elif isinstance(item,ast.ImportFrom): modules += [item.module]
    assert set(modules)<=set(['__future__','dataclasses','fractions','math','hashlib','json'])
    funcs={n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)}
    assert not {'jvp','vjp','jacobian','gmres','finite_difference'}.intersection(funcs)
