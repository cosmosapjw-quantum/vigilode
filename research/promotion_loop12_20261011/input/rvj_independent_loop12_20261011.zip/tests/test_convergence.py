from fractions import Fraction as F
from pathlib import Path
import json
from rvj_packet.packet import *
from rvj_packet.convergence import sufficient_parameters, exp_upper, theoretical_bound

def test_exponential_bounds_are_rational_certificates():
    assert exp_upper(F(3,4),12)<F(17,8)
    assert exp_upper(F(1,2),12)<F(5,3)

def test_constructive_choices_close_error_bound():
    for tol in [F(1,10**7),F(1,10**12)]:
        cfg=sufficient_parameters(tol)
        assert cfg['mapping_bound']<F(3,4)
        assert cfg['q_R']<1 and cfg['q_1']<1
        assert cfg['physical_max_bound']<=tol

def test_smaller_tolerance_requires_no_decrease_in_resources():
    a=sufficient_parameters(F(1,10**7));b=sufficient_parameters(F(1,10**12))
    assert b['order']>=a['order'] and b['degree']>=a['degree'] and b['sweeps']>=a['sweeps']
