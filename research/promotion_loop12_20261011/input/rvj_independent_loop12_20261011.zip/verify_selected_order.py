from rvj_packet.packet import *
from run_studies import example,oracle
from pathlib import Path
import numpy as np,json
m=example(257,width=F(4));T=F(1,2);c=candidate(compile_packet(m,T,16),20,8);ce=certificate(c)
so,sc=oracle(m,T);f=force(c.mean,m.chi);maximum=0.;ratio=0.;cross=0.
for tau in [F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(1)]:
    be=[];ga=[];ww=ONE
    for j in range(17):
        if j:ww=ww*(I*m.width*T)/j
        be.append(ww*tau**j);acc=Z
        for k,ff in enumerate(f):acc=acc+ff*F(factorial(j)*factorial(k),factorial(j+k+1))*tau**(j+k+1)
        ga.append(T*ww*acc)
    vals=np.array([complex(evaluate(be,x)*a+evaluate(ga,x)) for x,a in zip(m.xi,m.initial)])
    truth=so.sol(float(T*tau));errors=np.abs(vals-truth)
    maximum=max(maximum,float(max(errors)))
    ratio=max(ratio,float(max(e/float(b) for e,b in zip(errors,ce['mode_bounds']))))
    cross=max(cross,float(max(abs(truth-sc.sol(float(T*tau))))))
assert ratio<1
obj={'n':257,'width':4,'order':16,'degree':20,'sweeps':8,'observed_max_individual_error':maximum,'max_error_to_bound':ratio,'max_bound':float(max(ce['mode_bounds'])),'oracle_cross':cross,'oracle':'DOP853 at two tolerances; no oracle used by selector','continuum_certificate':'exact polynomial Volterra defect plus analytic full-model kernel tail'}
Path('evidence/SELECTED_ORDER_ORACLE.json').write_text(json.dumps(obj,indent=2));print(obj)
