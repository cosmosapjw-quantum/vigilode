from rvj_packet.packet import *
from run_studies import example,tojson
from pathlib import Path
from time import perf_counter
import json, mpmath as mp
OUT=Path('evidence')
rows=[]
for n in [7,31,127]:
    m=example(n);h=F(1,4);p=4;d=6;s=3
    wc=Work();wd=Work()
    tic=perf_counter();pk=compile_packet(m,h,p,wc);ca=candidate(pk,d,s,None,wc);tc=perf_counter()-tic
    tic=perf_counter();direct=full_waveform_mean(m,h,p,d,s,wd);td=perf_counter()-tic
    assert ca.mean==direct
    rows.append({'n':n,'order':p,'degree':d,'sweeps':s,'exact_same_discrete_mean':True,
      'compiled_work_including_moments':wc.dict(),'full_work':wd.dict(),
      'kernel_contraction_ratio':wd.volterra_terms/wc.volterra_terms,
      'seconds_once_compressed_including_moments':tc,'seconds_once_direct':td,
      'timing_classification':'single exploratory sample, exact arithmetic; not production speed guarantee'})
    print(rows[-1],flush=True)
(OUT/'EXACT_COST_PARITY.json').write_text(json.dumps(rows,indent=2))

# Independently computed high precision exact solution at coalescence.
m=example(17,width=F(0));T=F(1,2);p=compile_packet(m,T,0);ca=candidate(p,10,6);ce=certificate(ca)
def mm(q):return mp.mpf(q.numerator)/q.denominator
def mc(z):return mp.mpc(mm(z.re),mm(z.im))
with mp.workdps(100):
    m0=mc(p.nu[0]); worst=mp.mpf(0);ratio=mp.mpf(0)
    f=force(ca.mean,m.chi)
    for t in [F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(1)]:
        mexact=m0*mp.exp(1j*mm(m.chi)*abs(m0)**2*mm(T*t))
        for a,bb in zip(m.initial,ce['mode_bounds']):
            exact=mc(a)+mexact-m0
            approx=mc(evaluate(add([a],scale(conv([ONE],f),T)),t))
            e=abs(exact-approx);worst=max(worst,e);ratio=max(ratio,e/mm(bb))
    assert ratio<1
    res={'analytic_solution_100digits':True,'max_state_error':str(worst),'max_ratio':str(ratio),
      'certificate_bound':str(max(ce['mode_bounds'])),
      'floating_DOP853_discrepancy_not_used_as_disproof':True}
(OUT/'COALESCENCE_HIGH_PRECISION.json').write_text(json.dumps(res,indent=2));print(res,flush=True)

# Adaptive kernel order: original frequencies and initial data never changed.
m=example(257,width=F(4));T=F(1,2);work=Work();full=compile_packet(m,T,16,work);trials=[]
for order in [4,8,12,16]:
    p=Packet(m,T,order,full.mu[:order+1],full.nu[:order+1],full.free[:order+1],full.kernel[:order+1])
    ca=candidate(p,max(10,order+4),8,112,work);cc=certificate(ca,work)
    trials.append({'order':order,'max_mode_bound':str(max(cc['mode_bounds'])),
                  'accepted':max(cc['mode_bounds'])<=F(1,10**7)})
    if trials[-1]['accepted']: break
print(trials,flush=True)
(OUT/'ADAPTIVE_ORDER.json').write_text(json.dumps({'shared_moment_setup':True,'trials':trials,
  'all_trial_work':work.dict(),'no_oracle_in_selection':True,'physical_target_unchanged':True},indent=2))
