from rvj_packet.packet import *
from time import perf_counter
from pathlib import Path
import json, numpy as np
from scipy.integrate import solve_ivp
OUT=Path('evidence');OUT.mkdir(exist_ok=True)

def tojson(x):
    if isinstance(x,F): return str(x)
    if isinstance(x,C): return {'re':str(x.re),'im':str(x.im)}
    if isinstance(x,tuple): return [tojson(t) for t in x]
    if isinstance(x,dict): return {k:tojson(v) for k,v in x.items()}
    if isinstance(x,list): return [tojson(t) for t in x]
    return x

def example(n,width=F(1),chi=F(1,8),carrier=F(0)):
    xi=tuple(F(2*i,n-1)-1 for i in range(n))
    a=tuple(C(F(1,4)+x/16,F((i%5)-2,64)) for i,x in enumerate(xi))
    return Model(xi,(F(1,n),)*n,a,width=width,chi=chi,carrier=carrier)

def oracle(mod,T):
    x=np.array([float(t) for t in mod.xi]);w=np.array([float(t) for t in mod.weights])
    y=np.array([complex(v) for v in mod.initial]);delta=float(mod.width);chi=float(mod.chi)
    def f(t,z):
        m=w@z
        return 1j*delta*x*z+1j*chi*abs(m)**2*m
    a=solve_ivp(f,[0,float(T)],y,method='DOP853',rtol=2.5e-14,atol=1e-15,dense_output=True)
    b=solve_ivp(f,[0,float(T)],y,method='DOP853',rtol=3e-13,atol=2e-15,dense_output=True)
    if not(a.success and b.success): raise RuntimeError('oracle failed')
    return a,b

def main():
    rows=[]
    for n,width,order,degree,sweeps in [(17,F(0),0,10,6),(17,F(1),0,10,6),
       (17,F(1),4,10,6),(17,F(1),8,10,6),(257,F(1),8,10,6),
       (257,F(4),12,16,8),(1025,F(1),8,10,6)]:
        mod=example(n,width);work=Work();T=F(1,2)
        t=perf_counter();packet=compile_packet(mod,T,order,work)
        cand=candidate(packet,degree,sweeps,112,work);cert=certificate(cand,work)
        out=reconstruct(cand,work);elapsed=perf_counter()-t
        a,b=oracle(mod,T);weights=np.array([float(v) for v in mod.weights])
        worstmean=worstmode=0.;meanratio=moderatio=0.;cross=0.
        force_coeff=force(cand.mean,mod.chi)
        for tau in [F(0),F(1,8),F(1,4),F(1,2),F(3,4),F(1)]:
            true=a.sol(float(T*tau));coarse=b.sol(float(T*tau));cross=max(cross,float(np.max(np.abs(true-coarse))))
            approxmean=complex(evaluate(cand.mean,tau));me=abs(weights@true-approxmean)
            worstmean=max(worstmean,float(me));meanratio=max(meanratio,float(me)/float(cert['mean_bound']))
            beta=[]; gam=[]; wp=ONE
            for j in range(order+1):
                if j: wp=wp*(I*mod.width*T)/j
                beta.append(wp*tau**j)
                acc=Z
                for k,ck in enumerate(force_coeff):
                    acc=acc+ck*F(factorial(j)*factorial(k),factorial(j+k+1))*tau**(j+k+1)
                gam.append(wp*acc*T)
            approx=[complex(evaluate(beta,xi)*z0+evaluate(gam,xi)) for xi,z0 in zip(mod.xi,mod.initial)]
            err=np.abs(true-np.array(approx));worstmode=max(worstmode,float(np.max(err)))
            moderatio=max(moderatio,float(max(e/float(bb) for e,bb in zip(err,cert['mode_bounds']))))
        row={'n':n,'width':str(width),'horizon':str(T),'order':order,'degree':degree,'sweeps':sweeps,
             'certificate':tojson(cert),'max_mean_error':worstmean,'max_individual_error':worstmode,
             'mean_ratio':meanratio,'individual_ratio':moderatio,'oracle_cross':cross,
             'oracle_nfev':a.nfev,'work':work.dict(),'seconds_once_not_benchmark':elapsed,
             'zero_J_JVP_VJP_finite_difference_Krylov':True,
             'accepted_at_1e7':max(cert['mode_bounds'])<=F(1,10**7)}
        if width==0:
            row['floating_oracle_resolution']='insufficient for sub-machine-epsilon certificate; separate analytic90digit check required'
        rows.append(row); print({k:row[k] for k in ['n','width','order','max_individual_error','individual_ratio','accepted_at_1e7']},flush=True)
        (OUT/'MAIN_RESULTS.json').write_text(json.dumps(rows,indent=2))
    # Real physical reconstruction: common phase shared, no hidden frequency sampling.
    mod=example(17,carrier=F(10**8));can=candidate(compile_packet(mod,F(1,2),8))
    cc=certificate(can);out,err,counts=physical_output(can,cc)
    import mpmath as mp
    with mp.workdps(90):
        phase=mp.exp(1j*mp.mpf(50000000))
        ce,rad,_=carrier_enclosure(F(50000000));phase_error=abs(mp.mpc(mp.mpf(ce.re.numerator)/ce.re.denominator,mp.mpf(ce.im.numerator)/ce.im.denominator)-phase)
    (OUT/'PHASE.json').write_text(json.dumps({'carrier':str(mod.carrier),'counts':counts,
       'enclosure_radius':str(rad),'observed_phase_error_90digit':str(phase_error),
       'physical_max_bound':str(max(err))},indent=2))

if __name__=='__main__': main()
