"""Independent exact algebraic checks; not a proof assistant."""
from pathlib import Path
import sympy as S
import json
x=S.symbols('x0:3',real=True); y=S.symbols('y0:3',real=True)
w1,w2,k,om,de,ch=S.symbols('w1 w2 k om de ch',real=True)
w=S.Matrix([w1,w2,1-w1-w2]); xi=S.symbols('r0:3',real=True)
mx=sum(w[j]*x[j] for j in range(3));my=sum(w[j]*y[j] for j in range(3))
gre=-ch*(mx*mx+my*my)*my;gim=ch*(mx*mx+my*my)*mx
fx=[-k*x[j]-(om+de*xi[j])*y[j]+gre for j in range(3)]
fy=[(om+de*xi[j])*x[j]-k*y[j]+gim for j in range(3)]
checks={}
def add(name,expr):
    if isinstance(expr,S.MatrixBase): ok=all(S.simplify(v)==0 for v in expr)
    else:ok=S.simplify(expr)==0
    checks[name]=bool(ok)
    if not ok:raise AssertionError((name,expr))
energy=sum(w[j]*(x[j]**2+y[j]**2) for j in range(3))
add('weighted_energy',2*sum(w[j]*(x[j]*fx[j]+y[j]*fy[j]) for j in range(3))+2*k*energy)
P=S.ones(3,1)*w.T;J=2*P-S.eye(3)
add('projector',P*P-P);add('involution',J*J-S.eye(3))
add('invertible_mean_transverse_chart',S.Matrix([[w1,w2,1-w1-w2],[1,0,-1],[0,1,-1]]).det()-1)
for j in [0,1]:
    add(f'coalescent_transverse_{j}',(fx[j]-sum(w[i]*fx[i] for i in range(3))+k*(x[j]-mx)+om*(y[j]-my)).subs(de,0))
for r in range(4):
    Mr=sum(w[j]*xi[j]**r*(x[j]+S.I*y[j]) for j in range(3))
    Mnext=sum(w[j]*xi[j]**(r+1)*(x[j]+S.I*y[j]) for j in range(3))
    add(f'exact_moment_{r}',sum(w[j]*xi[j]**r*(fx[j]+S.I*fy[j]) for j in range(3))-(-k+S.I*om)*Mr-S.I*de*Mnext-sum(w[j]*xi[j]**r for j in range(3))*(gre+S.I*gim))
t,s=S.symbols('t s',positive=True)
for j in range(4):
    for r in range(4):add(f'causal_beta_integral_{j}_{r}',S.integrate((t-s)**j*s**r,(s,0,t))-S.factorial(j)*S.factorial(r)*t**(j+r+1)/S.factorial(j+r+1))
# Directly remove the explicit hJ action in the old shifted-resolvent jet.
A=S.Matrix([[-1,-4,0],[4,-3,-1],[0,1,-2]])
h=S.Rational(1,8);ga=S.Rational(1,2);R=(S.eye(3)-ga*h*A).inv();v=S.Matrix([1,2,-1])
add('center_inverse_identity',h*R*A-(R-S.eye(3))/ga)
va=R*v;vb=va
for n in range(5):
    va=R*h*A*va;vb=(R*vb-vb)/ga
    add(f'no_J_action_resolvent_recurrence_{n}',va-vb)
# Quotient normal-coordinate involution retains odd first moments.
u,vv=S.symbols('u v');pr=S.Poly(u+2*vv+3*vv**2,vv)
add('even_odd_recombination',(pr.as_expr().subs(vv,-vv)+pr.as_expr())/2+(pr.as_expr()-pr.as_expr().subs(vv,-vv))/2-pr.as_expr())
# Counterexample preserved: old independent-state deletion cannot be decoded.
checks['odd_initial_moment_not_deleted']=(S.Rational(1,2)*(-1)*(1-S.Rational(1,16))+S.Rational(1,2)*(1)*(1+S.Rational(1,16)))!=0
Path('evidence/SYMBOLIC_CHECKS.json').write_text(json.dumps({'checks':checks,'passed':sum(checks.values()),'failed':sum(not v for v in checks.values()),'status':'EXACT_ALGEBRA_CHECKED_NOT_FORMAL_PROOF'},indent=2))
print(f'{sum(checks.values())} exact checks passed; no numerical root finder used')
