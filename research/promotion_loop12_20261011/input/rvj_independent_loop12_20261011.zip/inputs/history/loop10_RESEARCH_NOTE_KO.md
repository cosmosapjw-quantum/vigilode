# RVJ 독립 연구 루프 10
## Fourier 왕복, involution, 비선형 convolution과 homotopy의 결합

날짜: 2026-10-04. Vigilode와 그 local 검증에서 분리된 수학·reference-code 연구다. 원격 repo/PR을 읽거나 변경하지 않았다. 모든 실행은 exploratory이며 정확 대수, 직접 유도, exact-coefficient/ouward reference, floating oracle와 비용을 분리한다. 새 후보의 이름은 `FOURIER_VOLterra_HOMOTOPY_REFERENCE`다. 기존 raw RVJ5와 같은 방법이 아니다. Generic RVJ의 stiff-uniform/approximate-W/embedded 반례는 그대로 유지한다. Independent final review와 production 승격은 HOLD다.

## 0. 연구 결정

Fourier+inverse Fourier의 왕복은 역함수의 합성이며 Fourier 자체의 involution 성질과 다르다. 그러나 primal/spectral 쌍으로 공간을 확장하면 정확한 involution을 만들 수 있다. 이 연산은 표현의 일관성을 보장하지만, mode truncation과 alias, 누락된 비선형 항을 복구하지 않는다.

이번에는 (1) genuine doubled-space involution, (2) phase-Fourier product와 causal time convolution의 구별, (3) polynomial degree에 따른 de-aliasing 조건, (4) 작은 주파수 mismatch에서 정칙인 전체함수 moment, (5) nonlinear coupling homotopy와 원방정식 residual의 결합을 유도했다. 실제 구현은 residual phase가 남는 2-complex-mode 비선형계를 사용한다. Fourier 계수의 직접 convolution reference이며 production FFT 구현이 아니다.

주요 결과: 6개의 전체 구간 실행은 T=1/2에서 각 4개의 accepted step으로 완료되었다. 같은 짧은 T=1/8에서 direct와 0→1/2→1 homotopy는 각각 6회와18회의 nonlinear RHS-convolution 평가를 사용했다. 둘 다 같은 physical tolerance를 만족하므로 이 정칙 예제에서는 homotopy가 비용 이득을 주지 않았다. K=0/1의 작은 모드 cap에서는 원방정식 residual bound가 커진다. FFT roundtrip은 이 누락을 검출하지 못한다.

## 1. 부모 연구와 출처의 구분

부모 Loop9의 다음 과제는 exact U(1) equivariance에서 벗어난 monomial을 추가하고 resonance/mismatch를 보존하는 것이었다. 현재 parent ZIP과 그 안의 모든943개 파일의 byte identity를 재확인했다. 부모 전체 numerical campaign을 재실행한 것은 아니다.

보존된 curved-mirror v12의 sections/07_algebraic_track_c.tex 203–209행은 iota(m,d)=(m,-d)라는 endpoint exchange를 설명하고, sections/08_boundary_audit.tex 92–118행은 선형 rank-one P_a에서 2P_a-I를 만든다. 이 geometric involution은 아래 doubled-Fourier involution의 대수적 비교 맥락이다. 원문 involution이 ODE의 수렴 또는 FFT truncation의 정확성을 증명하는 것은 아니다. 원본 full replay의 missing author inputs는 여전히 BLOCKED_SOURCE이며 재실행하지 않았다.

문헌 조회는 LITERATURE.json에 기록한다. FFTW 공식 문서에서는 raw forward/backward가 N배를 반환한다는 정규화를 확인했다. Chartier 등 two-scale/derivative-free UA 논문과 Bardos–Tadmor의 de-aliasing 한계는 공식 abstract까지 확인했다. 아래 새로운 certificate는 그 논문들의 full theorem을 상속하지 않고 직접 증명한다. SciSpace 결과의 불명확한 서지 필드는 공식 source로 확인하지 않은 채 사용하지 않는다.

## 2. Fourier inverse와 involution

### 2.1 정규화

Schwartz 함수에서

    (Ff)(xi)=(2*pi)^(-1/2) integral exp(-i*x*xi) f(x) dx

로 정의한다. L2에는 unitary extension으로 확장한다. 적절한 의미에서

    F^-1 F=I, F^2=P, (Pf)(x)=f(-x), F^4=I.

F^-1 F의 역함수 관계는 F^2=I라는 involution과 다르다. 짝함수 부분공간에서는 P=I라 F가 involution이지만 전체 공간에서는 아니다. Unit-normalized DFT에도 modulo-N reversal로 같은 관계가 성립한다. FFTW의 unnormalized convention에서는 raw forward/backward가 N I이므로 소프트웨어 정규화를 별도로 기록해야 한다.

### 2.2 사용자의 왕복 아이디어를 실제 involution으로 만드는 법

primal/spectral 직합 공간에서

    J_F(f,c)=(F^-1 c,F f),
    J_F=[[0,F^-1],[F,0]]

로 두면 J_F^2=I이다. F가 unitary이면 J_F는 self-adjoint unitary이고

    Pi_graph=(I+J_F)/2

는 c=Ff인 consistency graph의 orthogonal projector다. 두 번 왕복하여 원래 쌍으로 돌아온다는 의미가 엄밀해진다. 반면 일회 projection은 불일치 쌍의 평균을 graph로 옮기는 것이지 원래 ODE 해로 옮기는 것이 아니다.

모드 projector P_K를 사용한 연속 함수의 왕복은

    F^-1 P_K F = Pi_K != I

다. 유한 grid의 DFT/IFFT가 완벽히 roundtrip해도 grid에 보이지 않는 서로 다른 함수는 구분하지 못한다. `J_F^2=I`를 physical accuracy의 certificate로 사용해서는 안 된다.

### 2.3 conjugation과 nonlinear convolution

주기함수 f(theta)=sum_k c_k exp(i*k*theta)의 convention을 사용한다. 이때

    (fg)_k=sum_l c_l d_(k-l),
    (conj f)_k=conj(c_-k).

전자는 선형/circular convolution을 구별해야 하고, 후자는 conjugate-linear involution이다. Scalar 함수에서는 곱의 순서가 무관하지만 matrix-valued convolution의 star는 순서를 뒤집는다. 이 두 식으로 reality와 conjugate-mode consistency를 검사할 수 있다. ODE의 physical time-reversal 대칭과 동일한 것은 아니다.

## 3. 서로 다른 두 convolution, 그리고 causality

Phase의 Fourier convolution은 nonlinear product의 mode mixing이다. Time의 retarded convolution은

    (K_A f)(t)=integral_0^t exp((t-s)A) f(s) ds

라는 동역학적 전달이다. 두 연산을 FFT 곱셈 하나로 동일시하지 않는다. 특히 length-N circular time convolution은 마지막 시각의 입력을 앞 시각으로 wrap할 수 있다. 길이4 입력(0,0,0,1)과 kernel(1,1/2,1/4,1/8)의 예에서 N=4 circular convolution은 앞부분이 비영이지만 causal 선형 convolution의 첫4개는(0,0,0,1)이다. N>=7 zero-padding이면 전체 선형 convolution을 재현한다.

물리 시간 Fourier를 쓰려면 initial data도 남겨야 한다. y_+(t)=H(t)y(t)이면 distribution 의미에서

    (d/dt-A)y_+=Hf+y0 delta_0.

따라서 symmetric Fourier convention에서

    (i*xi I-A) F[y_+] = F[Hf]+y0/sqrt(2*pi).

Purely oscillatory neutral spectrum에는 retarded/Laplace boundary prescription이 필요하다. 우변의 초기항이나 인과적 prescription을 지우면 다른 문제를 푼다. 본 구현은 finite-time Volterra primitive를 직접 사용하고, 시간의 periodic FFT 경계조건을 도입하지 않는다.

## 4. 모드 절단의 오차와 alias의 정확한 분리

절대수렴 Fourier 계수 공간에서 ||c||_1=sum|c_k|이며

    ||c*d||_1 <= ||c||_1 ||d||_1,
    sup_theta |sum c_k exp(i*k*theta)| <= ||c||_1.

이 algebra는 nonlinear product와 잔여 mode tail을 감싸는 데 유용하다. Smoothness 또는 analytic strip이 주어져야 미지의 함수 자체의 tail에 a priori 수렴률을 붙일 수 있다.

저장된 후보 U_K의 Fourier-Galerkin 방정식에 대해

    r_full=(partial_t+Omega partial_theta)U_K-N(U_K)
          =r_retained-(I-P_K)N(U_K).

따라서 retained residual이0이어도 전체 residual은0이 아닐 수 있다. 현재 reference는 저장 후보의 nonlinear RHS를 truncation 없이 다시 전개하고 그 전체 coefficient residual을 감싼다. Candidate 생성 단계의 pruning error를 이미 최종 residual이 반영하므로 그것을 다시 독립적인 state error로 더하여 double-count하지 않는다. Pruning bound는 진단값으로 따로 남긴다.

### De-aliasing에 필요한 grid size

입력 band가 |k|<=K이고 nonlinear degree가 p, 명시적 phase factor의 추가 band가 s라면 product support는 |k|<=pK+s다. Cyclic length N에서 retained |k|<=K에 alias가 들어오지 않는 충분조건은

    N > (p+1)K+s.

증명: false alias는 product index m와 retained k가 m=k+jN, j!=0일 때 생긴다. 이때 N<=|m|+|k|<=(p+1)K+s여야 하므로 역으로 위 조건이면 불가능하다. Full product의 모든 계수를 저장하려면 더 강한 N>2(pK+s)가 충분하다. Nyquist endpoint의 처리와 엄격부등식을 혼동하지 않는다.

정확 negative controls:
* K=2, f=exp(2i theta), f^2=exp(4i theta). N=5에서는 mode4가-1로 alias된다. 정확한 |k|<=2 Galerkin product는0이다.
* cubic에 phase+1을 곱하면 mode7이 생긴다. N=9는-2로 alias시키지만 N=10은 retained band에서 이를 제거한다.

De-aliasing은 finite polynomial의 retained coefficient를 바로잡는 것이지 버린 tail을0으로 만들거나 일반 nonlinear 안정성을 보장하는 것이 아니다. 비다항식 sqrt closure는 일반적으로 무한 모드를 만들며 별도 tail/inverse certificate가 필요하다. 현재 모델은 정확 invariant로 closure를 상수화할 수 있는 경우로 제한한다.

## 5. Fourier–Volterra와 공진에서의 정칙성

Phase lift U(t,theta)에 대해

    partial_t U+Omega partial_theta U=L U+N_lambda(theta,U)

를 생각하면 Fourier mode는

    U_k'=(L-i*k*Omega I)U_k+Nhat_(lambda,k)(U)

이고 finite-time mild equation은

    U_k(t)=exp(t(L-i*k*Omega I))U_k(0)
       +integral_0^t exp((t-s)(L-i*k*Omega I))Nhat_(lambda,k)(s) ds.

Skew shift -ikOmega는 적절한 energy norm의 semigroup 증폭을 바꾸지 않는다. 그러나 좋은 initial phase profile, coefficient-tail regularity, nonlinear closure가 자동으로 주어지는 것은 아니다. Two-scale UA 이론이 사용하는 준비된 initial data와 regularity는 단순 FFT 왕복으로 얻지 못한다.

이번 실행은 위 two-scale PDE의 전체 independent initial phase profile을 푸는 solver가 아니다. 직접 physical characteristic path를

    a_j(t_n+h*tau)=sum_(k,l) c_(j,k,l) tau^l exp(i*k*Omega*h*tau)

로 표현한다. Time primitive는 각 harmonic의 integration constant를 합쳐 실제 tau=0 값을 맞춘다. 이것은 모든 off-characteristic theta에서 같은 initial Fourier profile을 유지하는 것과 다르다. 이 distinction 없이 standard Fourier-Galerkin two-scale solver를 구현했다고 말하지 않는다.

### Entire moment

    I_(k,j)(tau)=integral_0^tau s^j exp(i*k*a*s) ds
       =tau^(j+1) j! exp(i*k*a*tau) phi_(j+1)(-i*k*a*tau).

phi는 entire exponential phi-function이다. ka=0에서 I=tau^(j+1)/(j+1)로 유한하다. 1/(ikOmega)를 단독으로 계산해 divergence라고 해석하면 잘못이다. Nonzero mode에서 exponential-polynomial primitive를 쓰더라도 거의0인 a에서는 큰 항의 cancellation을 피해야 한다.

현재 hybrid representation은 |a|<=1이면 명시적 phase를 degree20 Taylor로 표현하고 remainder |a|^21/21!를 원 residual에 계상한다. |a|>1이면 exact named exponential을 남기고 finite polynomial primitive를 계산한다. Omega=0은 정확한 polynomial primitive로 처리한다. 이 전환은 numerical representation의 변경이며 physical resonance나 root branch를 바꾸는 조작이 아니다.

## 6. Homotopy의 수학적 역할과 한계

lambda∈[0,1]은 비선형 결합의 강도를 연결하는 계산 parameter이며 physical time 또는 frequency가 아니다. 연속 경로의 Volterra map을

    T_lambda(A)=A0+K N_lambda(A)

라고 하자. 같은 complete path ball에서 self-map이고 Lipschitz constant q_h<1이면 unique fixed point가 존재한다. 미분 가능한 경우

    (I-D_A T_lambda) partial_lambda A_lambda = partial_lambda T_lambda,
    ||(I-D_A T_lambda)^-1|| <= 1/(1-q_h).

Semigroup gain1, ||DN_lambda||<=L, ||partial_lambda N_lambda||<=M이면 q_h<=hL 및

    ||partial_lambda A_lambda|| <= hM/(1-hL)

가 충분조건이다. 이 식에는 1/(kOmega)가 없다. Resonant frequency가0이라는 사실과 nonlinear continuation derivative가 singular하다는 것은 다르다.

보다 일반적인 연속 Volterra linearization에서는 반복 kernel의 norm이 (Lh)^n/n!로 감싸지므로 resolvent가 e^(Lh)로 bounded일 수 있다. 따라서 hL>=1은 convenient fixed-point test의 실패이지 physical branch의 fold 또는 해 부재 판정이 아니다.

주의: 본 코드에는 Fourier cap 및 polynomial-degree truncation이 있다. 이 projection이 연속 경로 sup norm에서 contraction이라는 증명은 없다. 따라서 위 연속 fixed-point 정리를 code의 모든 projected Picard sweep 수렴성으로 옮기지 않는다. Bounded sweep은 후보 생성기이고, 최종 lambda=1 원방정식 residual이 수락을 결정한다. lambda<1의 쉬운 문제만 정확히 풀고 target 해라고 반환하면 안 된다.

## 7. 실제 모델: 정확 equivariance를 깨는 cubic modulation

모든 변수·시간은 무차원이다. g=epsilon=1/8, sigma=±1, 정확히 알려진 상수 Omega를 사용한다.

    z1'=i Omega z1+i q [g+lambda epsilon Re(z1)] conj(z1)z2,
    z2'=2i Omega z2+(i q/2)[g+lambda epsilon Re(z1)] z1^2,
    q^2=1+|z1|^2+2|z2|^2, sign(q)=sigma.

Initial z1=1/4,z2=1/2에서 I=|z1|²+2|z2|²=9/16다. Multiplier가 real이므로 I'=0이며 q=sigma5/4가 정확히 일정하다. Root를 임의로 freeze한 것이 아니라 이 initial invariant leaf에서 원방정식과 동일한 polynomial extension을 사용한다. Candidate의 I가 정확히 보존된다는 주장은 하지 않으며 algebraic residual을 진단값으로 남긴다. 일반 closure, damping 또는 다른 initial data에 대한 q freeze는 승인되지 않는다.

Carrier z1=exp(iOmega t)a1,z2=exp(2iOmega t)a2를 쓰면

    a1'=i q c_lambda(t,a1) conj(a1)a2,
    a2'=(i q/2)c_lambda(t,a1) a1^2,
    c_lambda=g+lambda epsilon Re(exp(iOmega t)a1).

이제 explicit residual phase ±Omega가 남는다. Loop9의 exact carrier removal과 다르다. 동시에 비선형 벡터 전체가 같은 real scalar로 곱해지는 구조는 특수하다. 모든 nonequivariant oscillator를 대표하지 않는다.

Max complex-component norm에서 exact initial action은 실제 해를 |a1|,|a2|<1 안에 유지한다. Convex domain |a1|,|a2|<=1에서

    L=|q|(2|g|+3|epsilon|)=25/32

가 F_lambda의 Lipschitz bound다. 예를 들어 첫 성분 derivative에는 q[(g+epsilon)(|a1|+|a2|)+epsilon|a1a2|]가 나오고 이를 위 bound로 감싼다. 두 번째 성분은 더 작은 상계다. Omega는 이 amplitude derivative bound에 들어가지 않지만 Fourier support, phase evaluation precision과 actual work에 들어갈 수 있다.

## 8. 실행 reference와 error contract

Gaussian-rational 계수(C 클래스)를 사용하고 finite EP map에 (k,j)->c를 저장한다. Product는 exact noncyclic coefficient convolution이고 conjugation은 k→-k와 coefficient conjugate를 사용한다. Jacobian/Jv 또는 고차 vector-field derivative는 이 후보 생성에 사용하지 않는다. 이미 알려진 basis를 미분하여 residual을 계산하는 것은 별개다.

각 sweep에서 full nonlinear RHS를 만들고 definite primitive를 계산한다. 그 뒤 |k|<=K, degree<=p로 자르고 coefficient rounding을 한 다음 실제 tau=0 초기값을 정확히 다시 맞춘다. 현재 registry는 저비용(K2,p4,2sweeps)을 먼저, 실패하면(K3,p6,4sweeps)을 시도한다. 실패한 모든 RHS-convolution 평가를 계산량에 포함한다.

현재 global phase exp(iOmega t_n)는 부모의 exact rational trig enclosure에서 중앙값을 잡는다. Local phase의 Taylor remainder와 global phase interval radius를 합쳐 e_phase를 얻는다.

최종 저장 경로 P에서 normalized original-target defect는

    D_theta=P_tau-h F_(lambda=1)(t_n+h tau,P).

Explicit phase를 근사했으므로 full coefficient residual bound에

    h |q epsilon| B^3 e_phase, B>=max_j sup|P_j|, B<=1

를 추가한다. 여기서 polynomial nonlinear RHS는 retained mode 밖까지 전부 재계산한다. 한 harmonic의 polynomial amplitude는 exact complex Bernstein hull로 감싸고 frequency들 사이는 삼각부등식을 사용한다. Aliased grid output이나 sample maximum을 certificate로 사용하지 않는다.

그 전체 bound를 D라고 하면

    E_new <= up[(E_n+D)/(1-hL)+rho_endpoint], hL<1.

증명: 같은 convex domain의 exact solution과 후보에 대해 Gronwall에서 E(t)<=exp(Lh)(E_n+D)이고 exp(Lh)<=1/(1-Lh)다. Exact invariant는 true solution의 domain을 제공하고 candidate B<=1은 선분의 domain을 제공한다. e.g. initial action과 branch를 검사하지 않고 이 정리를 사용하면 안 된다.

Global TL<1이면 ∏(1-Lh_i)^-1 <=(1-LT)^-1이다. Local output increment를 epsilon*h/[8T*Gglobal] 이하로 제한하고 E_new<=epsilon/4를 재확인한다. Physical carrier는 unitary H=diag(1,2) complex norm이므로 H error는 sqrt(3)E와 각 trig/endpoint rounding으로 감싼다. 구현은 최종 physical bound<=epsilon도 직접 검사한다.

고정 precision과 자원 cap에서 불가능한 후보는 거절/중단한다. 모든 허용오차에서 반드시 종료한다는 주장이 아니다. State/model/epoch/generation과 정확한 path, endpoint/error의 binding을 검사한다. Hash는 trusted process의 accidental mixing 방지이며 malicious certificate 검증이 아니다.

## 9. 결과

전체 T=1/2, physical epsilon=1e-8, standard sigma+에서 Omega=0,1e-8,1,40,1e4를 실행했고 Omega=-40,sigma-를 추가했다. 여섯 case 모두4acceptedsteps,8candidatebuilds,24RHSconvolutions였다. 이 표는 다른 초기자료/g/epsilon을 쓴 Loop9와 직접적인 비용비교가 아니다. Step cap 및 약한 coupling의 영향도 있으므로 generic frequency-independent cost를 주장하지 않는다.

    Omega     max envelope error
    0         1.06352e-12
    1e-8      1.06352e-12
    1         2.07619e-12
    40        2.21752e-13
    1e4       1.81633e-13
    -40,-     2.21752e-13

같은 T=1/8,Omega40,epsilon1e-8의 direct와 continuation(0,1/2,1)은 각각1step을 사용했다. Direct는2builds/6RHSconvolutions, continuation은2builds/18RHSconvolutions다. Max error는 각각2.3339e-14와1.6508e-15다. 같은 attained error에서의 비교는 아니지만, 둘 다 같은 예산을 닫으므로 homotopy를 기본값으로 채택할 근거가 없다.

T=1/8,epsilon1e-12의 tight slab은3steps/10builds/30RHSconvolutions로 완료됐다. Full T=1/2의 homotopy와 tight 두 command는45초 실행 한도에 걸려 completed output이 없었다. 해당 전체 campaign을 성공으로 처리하지 않고 동일한 짧은 horizon으로 비교범위를 좁혔다. Runtime 실패는 evidence log에 남겼다.

총 저장된 numerical trajectory는9run/29acceptedsteps/87interioraudits이다. 오차 oracle는 원래 sqrt closure를 다시 계산하는 DOP853의 두 tolerance다. 서로 다른 두 알고리즘이나 rigorously validated oracle라고 부르지 않는다. Main implementation 최초 interior audit에는1e-16 allowance가 있었으며 최종 별도 재검사에서 이를0으로 놓고 endpoint/interior/physical reconstruction violation이 모두0임을 확인했다. 두 검사 기록을 구분했다.

K/p resolution의 동일 slab(Omega40,h1/8,4sweeps):

    K,p   terms    certified endpoint max-complex error
    0,6   14       6.830692749e-4
    1,6   42       1.691048078e-7
    2,4   50       5.692734829e-11
    3,6   98       6.104501492e-13
    4,8   162      5.959788984e-13

K,p가 함께 바뀌므로 pure spectral convergence study가 아니다. 마지막 plateau는 fixed4Picard sweep에 따른 오차일 가능성이 있으나 이를 독립적으로 분리해 증명하지는 않았다.

별도 Omega1e6,h1/16,K3,p6,4sweeps의 single slab은 error<=1.260712092e-14를 인증했다. 이 case에는 독립 numerical trajectory oracle를 돌리지 않았으므로 numerical campaign과 별도다.

## 10. 실패와 검증 지위

처음 두 negative tests는 circular product의 alias와 filtered-roundtrip을 원래 함수identity로 취급하는 잘못된 baseline에서2FAIL이었다. Noncyclic coefficient product 및 retained projection으로 해석을 고친 뒤GREEN이다. 최종 tests29passed, exact algebra16passed. 연결 Wolfram은 DFT/parity/doubledJ/action/primitive/resonance closure를 한 번의 clean call로 확인했다.

저장된29개exact path를 최종 코드로 재인증하여 residual,error,endpoint,physical bound가 모두 정확히 일치했다. 이는 candidate generation 전체의 exact replay와 다른 검증이다. 과거 모든 parent campaign을 재실행하지 않았다. Parent943files와 harnessZIP hashes는 보존했다.

FFT arithmetic은 보조 negative/unit tests에만 사용한다. Main integrator는 sparse rational coefficient convolution이다. 따라서 FFT 병렬화, nativeRust, AD/Krylov, wall-clock speedup 또는 generic fifth-order/UA theorem은 미검증이다. 본 모델은 conservative invariant leaf로 q를 제거한 특수한 경우다. Damping/일반 implicit closure/unknownfrequency/multicarrier small divisors/time-dependent operator는 다음 범위다.

## 11. 통합 판단

가장 유망한 결합은 `invertible representation ↔ nonlinear coefficient convolution → causal entire moment → original residual acceptance`다. Fourier 왕복의 identity는 첫 화살표의 일관성만 검사한다. Involution graph projector를 적용한다고 physical tail이 복구되지 않는다. Homotopy는 어려운 후보를 얻는 선택적 경로이고 최종target검사를 대체하지 않는다.

다음은 (1) FFT de-aliased 저비용 predictor를 현재 exact convolution certificate와 대조하고, (2) invariant로 제거할 수 없는 closure 또는 damping을 넣고, (3) action moment/current operator error와 Fourier tail을 같은 물리budget에 넣는 것이다. 실제 kernel work와 correction/certification/rejected work를 측정하기 전에는 speedup으로 승격하지 않는다.
