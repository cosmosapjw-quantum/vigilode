# RVJ 독립 연구 루프 8: convolution, involution, interpolation/extrapolation

## 0. 결론, 출처, 적용 범위

2026-10-03. Vigilode 저장소와 PR 및 local Rust 검증과 분리된 연구다. 실제 source는 inputs/loop7와 그 안의 원본 curved-mirror v12다. 이 루프는 원방정식의 양방향 coupling을 유지한 채, fast 경로 전체의 다항식 근사를 nonlinear root-forcing의 보간과 정확한 exponential convolution으로 바꾸었다. 후보는 이전 full RVJ5 map과 다르므로 `EXP_CONV_INTERPOLANT`라고 구별한다. RVJ 연구의 확대이지 기존 RVJ의 generic stiff-uniform 5차 반례를 철회하는 것이 아니다.

세 구조는 서로 대체하는 동급 알고리즘이 아니다. Convolution은 forcing을 동역학의 기억으로 전달한다. Involution은 적용 두 번이 항등인 대수·기하 구조다. Interpolation/extrapolation은 제한된 정보를 다른 시점 또는 매개변수로 재구성한다. 이 구분을 명제와 반례, 실제 후보 및 동일한 physical-error certificate에 연결했다.

모든 실행은 exploratory. 정확 대수·직접 증명, connected Wolfram 검산, exact/outward reference, floating audit oracle, 실제 비용과 성능을 분리한다. 독립 최종 reviewer가 없으므로 PROMOTE는 HOLD다. 고차 AD, 큰 행렬 Krylov, native Rust, 실제 병렬 speedup은 실행하지 않았다. 원 source의 누락 입력에 따른 full replay blocker도 유지한다.

## 1. 첨부 계산기하 원문의 정확한 역할

원문 sections/07_algebraic_track_c.tex 203–209행의 iota(m,d)=(m,-d)는 outer endpoint를 교환한다. Quotient는 unordered normal-midpoint scheme이고, oriented scheme은 두 ordered partial-diagonal collision witnesses를 남긴다. 같은 절 264–285행의 (u,s)->(2s-u,s)는 residual scheme를 보존하는 다른 표현이다.

sections/08_boundary_audit.tex 90–118행은 선형 rank-one P_a^2=P_a에서 rho_a=2P_a-I, rho_a^2=I를 얻는다. 이것은 아래 보간 projector와 involution의 연결에 직접 관련된다. 그러나 원문의 boundary involution 자체가 ODE의 damping이나 error control이라는 뜻은 아니다.

sections/10_novelty_audit.tex 161–175행은 generically finite correspondence R에 대해 R^op composed with R의 off-diagonal 부분을 involution-defect multicycle로 포장한다. 다중값 correspondence의 왕복 경로는 single-valued involution J^2=I와 다르다. 본 루프는 이 구분을 보존한다. 원문은 ODE의 convolution이나 아래 adaptive integrator의 정확성을 증명하지 않는다.

원문 전체 suite를 재실행하지 않았다. 누락된 pr11_inputs.py 등은 복원하거나 추측 생성하지 않았다. 필요한 source sections의 실제 텍스트와 source SHA는 SOURCE_MAP_KO.md/SOURCE_BINDING.json에 보존했다.

## 2. Convolution: 무엇을 전달하며 무엇을 근사하는가

### 2.1 Retarded Volterra operator

정해진 norm을 가진 유한차원 상태공간, 상수 A, 고정 입력 연산자 B에 대해

    (K_{A,B} f)(t)=integral_0^t exp((t-s)A) B f(s) ds

를 정의한다. y'=Ay+Bf, y(0)=y0이면

    y(t)=exp(tA)y0+K_{A,B}f(t).

첫 항은 초기 fast amplitude를 보존하고 두 번째 항은 forcing이 남기는 기억이다. f만 작은 값으로 근사하거나 endpoint에서 f가 0인 것을 확인했다고 이 적분이 작아지지는 않는다. 물리 단위에서는 A가 1/time, Bf가 state/time, Kf가 state다.

노드 theta_i에 대한 degree-m 보간 Pi_m과 cardinal basis ell_i를 쓰면

    f_m(theta)=sum_i f_i ell_i(theta),
    W_i(h)=integral_0^h exp((h-s)A) B ell_i(s/h)ds,
    K f_m(h)=sum_i W_i(h) f_i.

Power basis f_m(theta)=sum_j c_j theta^j로 표현하면 정확히

    K f_m(h)=h sum_{j=0}^m j! phi_{j+1}(hA) B c_j,
    phi_k(z)=integral_0^1 exp((1-theta)z) theta^(k-1)/(k-1)! dtheta.

이는 정확한 exponential phi이다. 앞선 rational phi^R와 동일하지 않다. Dallerit–Tokman의 공식 본문 Eq.(2)–(4)도 variation-of-constants와 nonlinear integral 근사라는 접근을 사용한다. 우리는 그 논문의 차수 정리를 그대로 상속하지 않는다.

### 2.2 Interpolation defect는 kernel을 거쳐 전파된다

정확한 forcing f에 대해

    Kf-KPi_m f=K(I-Pi_m)f.

또 샘플의 오차 |delta f_i|<=epsilon_i라면

    ||delta y(h)|| <= sum_i ||W_i(h)|| epsilon_i.

보다 거친 상계로, ||exp(tA)||<=M exp(omega t), Lebesgue function Lambda_m(theta)=sum|ell_i(theta)|이면

    ||delta y(h)|| <= M ||B|| epsilon_max
                        * integral_0^h exp(omega(h-s)) Lambda_m(s/h) ds.

따라서 겉보기 endpoint polynomial error와 물리 forcing error는 다르다. Kernel-weighted gain은 고전적 sup Lebesgue gain보다 작을 수 있으나, cancellation을 실제로 증명하지 않고 임의로 이용해서는 안 된다. 본 패키지는 scalar exp kernel의 정확한 가중치와 세 high-precision 보조 비교를 별도로 기록한다.

m+1차 forcing 미분이 유계라는 추가 가정이 있으면 보간 나머지를 위 식에 넣어 local O(h^(m+2))를 얻을 수 있다. 그러나 stiff initial layer에서 그 미분 상수가 kappa에 독립적이라는 보장은 없다. 따라서 degree4 forcing이라는 이유만으로 본 후보를 generic stiff-uniform5로 승격하지 않는다.

### 2.3 진정한 Volterra 구조는 power에서 드러난다

B=I일 때 Fubini와 semigroup 성질로

    K_A^n f(t)=1/(n-1)! integral_0^t (t-s)^(n-1) exp((t-s)A) f(s) ds.

따라서 ||exp(tA)||<=M exp(omega t) 아래 고정된 h에서

    ||K_A^n|| <= M exp(max(omega,0)h) h^n/n!.

Spectral radius는 0이다. 그러므로 비영 공간에서 이 retarded integral operator 자체가 K_A^2=I인 involution일 수 없다. 이 factorial 구조가 연속 Picard/waveform iteration의 수렴 분석에 사용될 수 있다. 다만 interpolation을 전체 slab의 nodes에서 적용하면 해당 이산 연산자는 더 이상 strict Volterra가 아닐 수 있다.

Nonconstant A(t)의 정확한 해는 U(t,s)를 사용하는 two-time Volterra integral이다. U(t,s)=exp((t-s)A)라는 translation-invariant convolution을 임의로 사용하면 안 되며, time ordering과 commutator/connection 오차가 추가된다.

## 3. Involution: 반사, 역함수, 시간대칭을 구분한다

### 3.1 순수 involution은 비자명한 strict contraction이 아니다

거리공간에서 J^2=I이고 모든 x,y에 d(Jx,Jy)<=q d(x,y), q<1라면

    d(x,y)=d(J^2x,J^2y)<=q^2 d(x,y)

이므로 서로 다른 점이 존재할 수 없다. 또한 smooth one-step map Psi_h=I+hF+O(h^2)에 각 h마다 Psi_h^2=I를 요구하면 2hF=0에서 F=0이다. 실제 time step과 고정된 geometric reversal map을 동일시하면 안 된다.

두 orthogonal reflections R1,R2의 곱은 isometry일 수 있다. 반면 T=(I+R2 R1)/2는 두 직선의 각 theta에서 T* T=cos^2(theta)I이므로 횡단적 경우에 수축한다. 이번 정확 예제 cos(theta)=3/5에서 T*T=9I/25다. theta->0이면 개선은 사라진다. 이 averaging은 involution 자체가 아니라 별도 fixed-point map이고, 실제 ODE나 closure의 해를 보존하는지 추가 검증이 필요하다.

### 3.2 선형 projection만으로는 가능한 연결, 비선형에서는 주의

선형 Pi^2=Pi이면

    J_Pi=2Pi-I,   J_Pi^2=I,
    Pi=(I+J_Pi)/2,  I-Pi=(I-J_Pi)/2.

보간 projector에 적용하면

    K(f-Pi f)=1/2 K(I-J_Pi)f.

즉 involution의 -1 eigenspace 성분이 보간에서 제거되는 잔차이고 convolution이 이를 물리 오차로 운반한다. 이것이 세 개념의 정확한 대수적 연결이다. Pi는 보통 oblique projection이므로 J_Pi가 chosen physical norm에서 isometry라는 뜻은 아니다.

중요 반례: 비선형 P(x,y)=(x+y^2,0)는 P(P(x,y))=P(x,y)이지만

    J=2P-I=(x+2y^2,-y),  J^2(x,y)=(x+4y^2,y).

따라서 nonlinear root projection의 idempotence만으로 involutive reflection을 주장하면 틀린다. 원문 boundary P_a는 선형 rank-one 연산자이므로 원문의 추론에는 이 문제가 없다. Curved projection reflection에는 동일 foot 보존 등 별도 조건이 필요하다.

### 3.3 Time reversal은 retarded를 advanced로 바꾼다

(Tf)(t)=f(h-t)라 하면 T^2=I. B=I에서 변수변환으로

    T K_A T f(t)=integral_t^h exp((s-t)A)f(s)ds.

이는 advanced integral이지 K_A의 inverse가 아니다. 적절한 범위 y(0)=0에서 K_A의 inverse는 differential operator d/dt-A다. 미분은 작은 고주파 오차를 크게 만들 수 있다.

표준 L2 inner product에서는

    K_A^*=T K_{A^*} T.

실수선 convolution algebra에서 k^star(t)=k(-t)^*를 정의하면

    (k1*k2)^star=k2^star*k1^star.

따라서 convolution과 involution은 반대말이 아니라 한 대수 안에 공존할 수도 있다. 다만 causal support [0,infinity)는 star 아래 anticausal support로 바뀌므로 causal subalgebra가 보통 star에 대해 닫히지 않는다. Backward adjoint는 별도의 terminal-data 문제이지 미래 exact trajectory를 online predictor에 넣어도 된다는 뜻은 아니다.

### 3.4 Rational time symmetry와 L-stability의 명확한 장벽

실수 coprime polynomials P,Q에 대한 one-step R=P/Q가

    R(z)R(-z)=1

을 만족한다고 하자. Polynomial identity P(z)P(-z)=Q(z)Q(-z)에서 degP=degQ이고 leading-coefficient ratio가 ±1이다. 따라서 R(-infinity)는 0이 될 수 없다. 즉 이 rational one-step 클래스에서 symmetry와 L-stability는 양립하지 않는다.

이는 모든 역가능 flow가 감쇠할 수 없다는 정리가 아니다. Exact exp(z)는 exp(z)exp(-z)=1이면서 forward 음의 실축에서 감쇠하며, backward inverse가 크게 팽창한다. Multistep/extended-state/smoothing 방법까지 위 한-variable rational proof로 금지하지 않는다.

구체적 반례:

    R_T(z)=(1+z/2)/(1-z/2),
    R_ext(z)=[4 R_T(z/2)^2-R_T(z)]/3.

R_ext=e^z+O(z^5)이지만 lim_{z->-infinity}R_ext=5/3이다. Richardson으로 classical order를 올려도 stiff damping을 얻는 것은 아니며, 이 예에서는 A-stability조차 잃는다. 자명한 algebra를 Wolfram/SymPy로 각각 확인했다.

### 3.5 Algebraic sheet exchange는 동역학 symmetry가 아니다

q^2=1+x는 q->-q라는 involution을 가진다. 그러나 x'=q-x+alpha u는 그 변환 아래 RHS가 -2q만큼 바뀐다. 선택한 witness를 확인 없이 교환하면 다른 해를 푼다. RHS와 모든 관심 관측량이 quotient invariants에만 의존한다는 별도 descent certificate가 있으면 quotient dynamics를 고려할 수 있지만, 이번 모델은 그 경우가 아니다.

## 4. Interpolation, extrapolation, causality

### 4.1 같은 다항식이지만 conditioning domain은 다르다

Current nodes 0,1/4,1/2,3/4,1의 degree4 basis는 [0,1]에서 Lebesgue constant<9/4이다. Node 간 각 구간에서 basis의 부호를 고정하고, 128개의 rational subinterval에서 exact Bernstein upper coefficients를 검사했다. 9/4와의 최소 증명 여유는 263389/6291456이다. 이는 sampling 최대값이 아니다.

반면 equispaced history nodes 0,-1,-2,-3,-4에서 다음 endpoint 1의 weights는

    (5,-10,10,-5,1), sum absolute weights=31.

일반 degree m에서는 (-1)^j binomial(m+1,j+1), 합은 2^(m+1)-1이다. Nodewise independent errors의 signs가 weights와 정렬되면 이 증폭이 실제로 달성되므로 단순 상계만이 아니다.

직전 slab의 0,1/4,1/2,3/4,1 다항식을 다음 equal-length slab 끝 theta=2까지 연장하면

    (35,-160,280,-224,70), absolute sum=769.

31과769는 서로 다른 history sampling geometry이므로 비교 대상의 domain을 적어야 한다. Barycentric 평가의 numerical stability와 data problem의 conditioning은 다르다. Higham의 공식 저자 저장소 abstract는 작은 Lebesgue constant에서의 안정성을, Webb–Trefethen–Gonnet의 공식 abstract는 보간 구간 밖 barycentric formula의 별도 위험을 다룬다. 좋은 evaluation formula가 intrinsic extrapolation gain을 제거하지는 않는다.

시간 extrapolation, h->0 Richardson extrapolation, matrix-function spectral interpolation은 별개다. 같은 이름으로 하나의 차수 또는 안정성 정리를 공유하지 않는다.

정확 collocation fixed point에서는 r=Pi q(Y_r)이지만 finite sweeps와 dyadic coefficient rounding 뒤에는 그 등식에 잔차가 남는다. 본 구현의 원방정식 certificate는 이 fixed-point 미수렴과 rounding을 포함한 최종 r 자체를 검사한다. Pi의 항등식만으로 수락하지 않는다.

### 4.2 Current-node interpolation은 macroscopically causal하되 strict substep Volterra는 아니다

Step 전체의 nodal interpolation Pi를 K 앞에 놓으면 앞선 시각의 결과가 뒤쪽 trial node에 의존할 수 있다. 두 endpoint 보간의 예:

    K Pi f(t)=t f(0)+t^2/[2h] (f(h)-f(0)).

t<h이어도 f(h)의 coefficient가 0이 아니다. 따라서 KPi는 trace 전체에 대한 strict retarded functional이 아니다. 실제 구현은 미래의 exact f(h)를 읽는 것이 아니라 현재 accepted snapshot에서 trial stage를 동시에 생성하고 correction으로 일관성을 맞춘다. 이 의미에서는 macro-step algorithm이 causal하다. 대신 same-step dependency가 제거된 것이 아니라 bounded coupled iteration으로 바뀌었다.

Past extrapolation은 macro predictor를 iteration 없이 만들 수 있지만 conditioning과 model/step-ratio/branch change에 취약하다. 최종 수락은 원 residual certificate가 담당해야 한다. 이번 code는 EXTRAPOLATE_FIRST와 INTERPOLATE_ONLY를 모두 보존한다.

### 4.3 Bounded parallelizable corrector의 조건부 수렴

Exact linear semigroup가 chosen norm에서 비팽창이고 q(x)의 Lipschitz bound가3/4라면, current nodes의 fixed-point map은 nodal infinity norm에서

    q_iter <= (3/4) Lambda_4 h <= 27/128  (h<=1/8)

의 Lipschitz constant를 가진다. 단, 후보 trajectory가 정칙 convex domain 안에 있고 그 map이 해당 집합을 자신에게 보낸다는 조건이 필요하다. 작은 Lipschitz 상수만으로 존재나 branch를 보장하지 않는다.

한 sweep의 다섯 node 평가는 병렬화 가능하지만 sweep들은 순차다. 이번 code는 최대18회 sweep, 85자리 mpmath predictor를 사용하고, 종료 increment1e-28은 predictor 기준일 뿐 정확성 인증이 아니다. 결과를112bit dyadic forcing으로 고정한 뒤 별도의 exact/outward 검증기를 사용한다. Over-solving 및 certificate frequency의 최적화는 아직 수행하지 않았다.

## 5. 같은 양방향 모델의 exponential-convolution 후보

원 모델:

    Y=(x,u,v), Y'=L Y+e1 q(x), q^2=1+x, sign(q)=sigma,
    L=[[-1,alpha,0],[0,-kappa,kappa beta],[kappa eta,0,-kappa rho]].

기본 alpha=eta=1/16,beta=4,rho=1, kappa>=1. 출력은 x,u+x^2/kappa,v+x^3/kappa. D=(-1/2,1), 초기x=0,(u,v)=(0,1), T=1/4, epsilon=1e-6이다.

고정 상태 단위 D_w=diag(1,d/4,1/4), d=max(1,2|beta|)로 바꾸면 L_s=D_w^-1 L D_w는 dissipative이고 root feedback까지 포함한 원 vector field의 infinity log norm은 -nu 이하, 기본nu=1/8이다. 일반 parameter는 이를 실제로 검사한다. Unsupported comparison을 물리적 불안정성으로 분류하지 않는다.

Frozen rational polynomial r(theta)에서 경로를

    Y_r(theta)=exp(theta h L_s)Y_n
          +h integral_0^theta exp((theta-s)h L_s)e1 r(s)ds

로 정의한다. Fast homogeneous layer와 linear slow-fast return coupling이 모두 kernel에 남는다. Fast state 전체를 degree6 polynomial로 근사하지 않는다.

실행 표현은

    Y_r(theta)=V(theta)+exp(theta h L_s)c,
    c=Y_n-V(0),
    (h L_s)V_j=(j+1)V_(j+1)-h e1 r_j

다. 마지막 coefficient부터 풀면 finite polynomial particular solution을 얻는다. detL=kappa^2(alpha beta eta-rho)는 사용한 parameter에서0이 아니다. Mathematical convolution 자체는 L이 singular여도 잘 정의된다. 현재 작은 inverse-based 표현의 domain 제한이지 convolution의 본질적 제한이 아니다. 일반 구현에서는 augmented exponential/phi action으로 inverse를 피할 수 있지만 아직 구현하지 않았다. 작은 h에서 particular/homogeneous cancellation이 커질 수 있어224bit outward arithmetic을 썼다.

이 exact descriptor는

    h^-1 Y_r'=L_s Y_r+e1 r

를 항등적으로 만족한다. 따라서 원 nonlinear residual은 단 한 성분 r-q_sigma(X_r)에 모인다. 이것이 convolution으로 선형 part를 정확히 보존하는 주요 이득이다. 물론 r에는 ODE와 closure를 동시에 맞추는 근사 문제가 남는다.

## 6. Whole-path 사후오차 인증

rmin=inf sigma*r>=2/3, G>=sup|r^2-1-X_r|이면

    delta <= G/(rmin+2/3).

따라서 chosen norm에서 E'=오차의 upper Dini derivative라 할 때

    D+E <= -nu E+delta.

전체step에서

    Z=max(E0, G/[nu(rmin+2/3)])

는 constant supersolution이다. 실제 X_r range±Z가D의 내부이면 first-exit proof로 exact solution의 whole path를 닫는다. Root error는 (G+Z)/(rmin+2/3) 이하다. Endpoint rounding을 같은 norm에서 더한 Enew를 물리 출력에 운반한다.

### 지수항 범위의 실제 계산

각 local slab [a,b]에서 exp(a hL_s)c의 outward interval을 계산한 뒤 degree12 Taylor-Bernstein 표현을 사용한다. Remainder는

    (b-a)^13/13! * ||(hL_s)^13 exp(a hL_s)c||inf

로 감싼다. Forward semigroup의 비팽창성을 적용한 integral Taylor remainder이므로 eigenvalues만으로 추정하지 않는다. Polynomial forcing와 X_r particular의 조합은 degree<=8이며 Bernstein 변환에 정확히 포함된다. 적응적인 이분화는 실제 지수항의 빠른 구간에서 더 많은 slab을 사용한다. 전체 지수 경로를 하나의 고정 degree polynomial로 근사한 것이 아니다.

Exp interval은 exact rational uniformization 후 outward dyadic scaling/squaring으로 계산한다. c=max(-L_ii), B=I+L/c는 norm<=1이고 작은lambda<=1/4에서 exp(-lambda) sum lambda^j B^j/j!의 tail을 geometric bound로 감싼다. 저장된 exponential function을 정확하다고 가정하지 않는다. 각 matrix product의 entry를 outward 계산하고 semigroup norm이 준 [-1,1]과 교차한다.

Domain proof의 모든 subslab은 공통 Z_guard=max(E0,target)를 사용한다. 더 앞선 slab에서 생긴 더 큰 오차를 뒤쪽 slab의 작은 local residual로 reset해서는 안 된다. 최초 구현의 per-slab guard를 이 공통 guard로 강화했고 final cases 전체를 다시 비교했다. Returned Z는 실제 global G에 기반한다. Point evaluations는 예산 위반을 빠르게 기각하는 데만 사용하며 성공 인증은 continuum enclosure로 수행한다.

### Physical bound와 commit

단위 weights를 (1,U,V)라 쓰면

    Bx=E+rho_x,
    By1=U E+(2|xhat|E+E^2)/kappa+rho_y1,
    By2=V E+(3 xhat^2 E+3|xhat|E^2+E^3)/kappa+rho_y2.

모든 rho는 exact central value와 stored96bit dyadic value의 차이다. E0를 버리지 않고 Enew=up(Z+rounding)를 사용한다. 같은 immutable snapshot/model/generation에 대해서만 commit한다. Arbitrary external forged certificate를 검증하는 보안 도구는 아니다.

## 7. 실제 결과와 의미

Main INTERPOLATE_ONLY, epsilon=1e-6,T=1/4:

| kappa | accepted | rejected candidates | correction sweeps | certificates | certification nodes/leaves |
|---:|---:|---:|---:|---:|---:|
|1|3|0|36|3|3/3|
|40|14|3|164|17|164/53|
|400|16|6|196|22|326/99|
|10000|17|9|209|26|512/153|
|1000000|22|14|234|36|855/269|

Parent Loop7 INVARIANT의 역사적 controls는 kappa1/40/400/10000에서8/108/133/165 steps다. 이번에 parent campaign을 다시 돌리지는 않았다. 같은 모델과 허용오차이지만 attained error, 연산 종류, 정밀도와 certificate 비용이 다르므로 matched-accuracy 또는 wall-clock speedup 비교가 아니다.

EXTRAPOLATE_FIRST at kappa40:14steps,30candidate builds,164correction sweeps,13extrapolation attempts중0accepted. kappa10000:19steps,42builds,197sweeps,18attempt중4accepted. 후자는 correction sweeps는209에서197로 줄었지만 steps17->19, certificates26->42로 늘었다. 순이익을 주장하지 않는다. Preserved previous polynomial의 endpoint conditioning769라는 구조와 일치하는 위험이 있지만, 이 수치만으로 observed rejects의 원인을 모두 conditioning으로 귀속하지도 않는다.

추가 조건: negative branch kappa40는14steps; rho2,kappa10000는16steps; 교대 step-cap1/32,1/64의 kappa10000는 실제 비균일23steps다. 전체10run은158accepted steps,790interior comparisons이며 policy/control 반복을 독립된10physical problems로 세지 않는다.

두 tolerance의 SciPy Radau는 original3state ODE와 analytic Jacobian을 사용한다. 모두 endpoint, interior, root의 raw enclosure violations=0. 최대physical error/bound ratio는약1.77e-4다. 이 oracle는 서로 다른 두 알고리즘이 아니라 같은 Radau의 tolerance refinement이며 formal validated oracle는 아니다. Candidate generator의 mpmath exp와 certificate의 exact interval exp는 별도 구현이다. Numeric oracle를 acceptance에서 읽지 않는다.

Final code로 모든10case의 forcing,accepted state,bounds,rejections,counts를 정확 재생성해 기존non-timing JSON과 일치시켰다. Batch B는4case 완료 후 마지막case에서tool timeout이 났으며 완료별log를보존했다. 프로세스가남지않음을확인하고 마지막case만독립실행exit0으로복구했다. Interrupted batch 전체에 exit0를 부여하지 않았다.

## 8. 실패·구현 상태·연구 결정

초기 semantic negative tests2개를RED로관찰했고정확convolution과외삽weights로고쳤다. 새API hardening tests에서는negative inherited error,nonpositivebudget/resources,wrongdimension의3개fail을관찰하고수정했다. 구간별domain guard가전체오차의최댓값을반영해야한다는proof-audit도수정했다. 이는우리reference의문제이지Vigilode버그가아니다.

첫Wolfram호출의Product/If평가에서1/0경고가발생했다. 결과를cleanPASS로쓰지않고유한indexTable로재작성해경고없는두번째계산과별도추가계산을보존했다.

Final29unit tests통과. Algebra28항목중25개는정확항등식/유리수부등식이고3개는convolutionnoiseweights의high-precision보조비교다. 이를모두exactproof라고부르지않는다. 원source/harness의실제hash를확인했고부모source변경없이별도코드만추가했다. 이source의read-check와독립CAS는독립최종reviewer의승인과다르다.

다음의중심은같은convolution후보를largecurrent-operatoraction과연결하는것이다. Forcing extrapolation을무조건먼저시도하거나반사를시간적분기로쓰는방향은채택하지않는다. Current-nodecorrector의과도한정밀도와보간차수/step-ratio를실제physicaldefectbudget에맞추는작업,rootforcing자체에남은initial-layer성분의enrichment,continuumactionerror와nativecost가남는다. 아직독립심사없으므로methodpromotionHOLD다.


최종 candidate 결속 보완: 동일 snapshot에서 만들어진 두 유효한 후보의 certificate를 바꾸어 전달하는 경우와, 다른 inherited radius로 계산된 certificate를 commit하는 경우를 각각 RED로 재현했다. 현재 exact Path(model,h,y0,r,V,c) digest와 initial error를 certificate에 넣고 commit에서 검증한다. 이는 trusted process의 accidental mixing을 막는 계약이지 악의적인 dictionary 위조의 보안 인증은 아니다. 수정 후29tests가 통과했고 모든10case를 세 개의 정상 종료 batch에서 다시 정확 재생성했다. 과거 중간 batch timeout 로그는 삭제하지 않았다.
