# RVJ 독립 연구 루프 5: 미지 closure 경로와 비정규 fast mode의 오차 인증

## 0. 범위와 근거 상태

2026-10-03. Vigilode 저장소와 PR을 읽거나 변경하지 않은 독립 수학·reference-code 연구다. 질문은 ‘정확한 slow flow가 주어지지 않고, algebraic closure 경로가 ODE 해의 일부이며, fast block이 비정규일 때도 causal/adaptive/hybrid RVJ의 물리적 오차 계약을 만들 수 있는가?’이다.

이번 결과는 (i) 미지 slow/closure 경로를 연속 다항식의 differential/algebraic defect로 함께 감싸는 조건부 정리, (ii) 두 개의 명시적 비정규 fast 행렬 family에 대한 Padé action 오차상계, (iii) 두 증명서를 arbitrary accepted mesh에서 합성하는 adaptive reference다. 원래 좌표 RVJ의 generic stiff-uniform 5차, approximate-Jacobian 안정성, embedded-only estimator의 일반적 신뢰성은 여전히 주장하지 않는다. 이번에 고친 것은 그러한 기존 이론적 반례가 아니라 별도 제한 클래스의 인증 경로다.

결과 지위는 DERIVED / CONNECTED_CAS_CHECKED / EXACT_RATIONAL_REFERENCE_VERIFIED / HIGH_PRECISION_ORACLE_CHECKED이다. ‘인증’은 아래 명시된 입력·영역·산술 계약 아래의 수학적 포함관계라는 의미다. Code는 trusted reference execution을 가정하며 untrusted caller가 임의로 만든 certificate dictionary를 보안 토큰으로 인증하지 않는다. 독립 최종 심사자와 formal proof assistant는 없었으므로 최종 승격은 HOLD / INDEPENDENT_REVIEW_UNAVAILABLE이다.

모든 계산은 exploratory다. 최초 계약과 이후 추가 실험·실패·수정을 evidence/EVIDENCE_LOG.jsonl에 분리했다. Sources, 문헌, 직접 유도, 수치 비교를 같은 근거로 취급하지 않는다.

## 1. 원문과 문헌으로부터 가져온 것

### 1.1 직전 루프와 계산기하 원문

Loop4의 물리 오차 공급원은 x'=x²의 정확한 국소 flow identity에 의존했다. Witness tracker는 주어진 parameter path를 인증했으며, 아직 미지 ODE 경로의 tube를 생성하지 않았다. Scalar Padé gap을 비정규 행렬에 대입하지 않는다는 제한도 있었다. 이번은 그 세 경계의 제한적 확장이다.

첨부 curved-mirror v12의 유한 covering, witnessed correspondence, support collision과 projection singularity의 구별은 유지한다. 해당 원문의 diagram/connection을 ODE 상태공간과 동일시하지 않는다. 이번 모델의 algebraic covering은 q²=1+x이며 discriminant는 4(1+x)다. x∈[-1/2,1]에서는 두 sheet가 분리되고 q의 부호가 witness label을 제공한다. 이는 trivialized real two-sheet chart이며 loop4의 복소 cubic monodromy를 일반화해 구현한 것은 아니다.

원문 전체 PR11 suite의 누락된 pr11_inputs.py 등과 당시 flint 실패는 보존된 원본의 blocker다. 이번에 full source suite를 재실행하거나 누락 입력을 재구성하지 않았다. 원문 ZIP과 확보된 source members의 identity만 다시 확인했다.

### 1.2 SciSpace 및 원전 대조

SciSpace에서 defect-based validated integration과 nonnormal matrix-action error 문헌을 검색했다. Jawecki–Auzinger–Koch, BIT 60 (2020), DOI 10.1007/s10543-019-00771-6의 공식 HTML에서 logarithmic-norm/nonexpansivity 가정, defect의 variation-of-constants 식, 적분 추정과 상계의 차이, Hermite/confluent divided differences를 읽었다. 이 문헌의 μ₂≤0 가정을 고유값의 부호로 대체하지 않는다. 그 Krylov 정리를 이번 rational RVJ에 그대로 상속하지도 않는다.

Akrivis–Makridakis–Nochetto, Numerische Mathematik, DOI 10.1007/s00211-009-0254-2는 공식 출판사 abstract에서 higher-degree continuous reconstruction에 기반한 RK/Galerkin 사후오차 접근을 확인했다. 이번 degree-6 reconstruction에 대한 아래 정리는 직접 증명하며 그 논문의 일반 정리를 빌려 ‘RVJ도 성립’한다고 하지 않는다. SciSpace 추가 column 조회는 not_found로 실패해 새 근거로 사용하지 않았다. 문헌이 이 아이디어의 독창성을 증명하지는 않는다.

## 2. 전체 연구 모델과 단위

이 절과 구현의 모든 변수·시간은 무차원 benchmark convention이다. κ는 역시간에 해당하는 fast rate이며 a=κh는 무차원이다. 일반 물리 문제에 옮길 때에는 각 상태 scale과 norm, chart 계수의 단위를 별도로 정해야 한다.

\[
 x'=q-x,\qquad q^2=1+x,\qquad q=\sigma\sqrt{1+x},\quad \sigma\in\{-1,+1\},
\]
\[
 w'=A w,\qquad
 A=\kappa\begin{pmatrix}-1&\beta\\0&-\rho\end{pmatrix},
 \quad \rho\in\{1,2\},\quad \kappa\ge1,
\]
\[
 x(0)=0,\quad w(0)=w_0,\quad 0<T\le1/4.
\]

출력에 해당하는 좌표(아래에서는 ‘물리 좌표’라고 부른다)는
\[
 y_1=w_1+x^2/\kappa,\qquad y_2=w_2+x^3/\kappa.
\]
이 chart의 Jacobian determinant는 1이다. 특히 x=0에서 ratio chart의 singularity가 없다. 단, determinant≠0만으로 임의 영역의 좋은 conditioning까지 주장하지 않는다.

물리 좌표에서 전체 ODE는 Φ(x)=(x²/κ,x³/κ)에 대해
\[
 x'=q-x,\qquad y'=A[y-\Phi(x)]+\Phi'(x)(q-x),\qquad q^2=1+x
\]
다. Fast dynamics는 chart에서 정확히 선형·상수계수로 분리된다. Fast-to-slow feedback 또는 일반 비선형 fast 항을 구현한 것이 아니다. Scalar reduced slow 문제는 separable일 수 있지만 구현/수락에 정확한 slow flow나 closed-form trajectory를 요구하지 않는다는 점이 새롭다.

## 3. 연속 defect로 미지 ODE/closure tube를 함께 닫는 정리

### 3.1 가정과 계산 가능한 양

D=[-1/2,1], q_min=2/3으로 고정한다. 정확한 branch q_σ(x)=σ√(1+x)는 D에서 |q_σ|≥√(1/2)>q_min이고
\[
 F_\sigma'(x)=-1+\frac{\sigma}{2\sqrt{1+x}}\le-1/4.
\]
현재 시각의 exact x에 대한 근사 중심 p(0)=xhat_n과 inherited error E_n이 주어진다. θ=s/h∈[0,1]에서 candidate polynomial p(θ), r(θ)를 생성한다. 다음 양들을 exact Bernstein hull로 감싼다.
\[
 d(\theta)=h^{-1}\partial_\theta p+p-r,
 \qquad g(\theta)=r^2-1-p,
\]
\[
 D_f\ge\sup|d|,\quad D_g\ge\sup|g|,\quad
 r_{\min}\le\inf_{\theta}\sigma r(\theta),\quad r_{\min}\ge2/3.
\]

실제 base가 p인 정확한 root와 r 사이에서는
\[
 |r-q_\sigma(p)|
 =\frac{|r^2-1-p|}{|r+q_\sigma(p)|}
 \le\frac{D_g}{r_{\min}+q_{\min}}.
\]
따라서 reduced defect 상계는
\[
 \Delta=D_f+\frac{D_g}{r_{\min}+q_{\min}}.
\]

### 3.2 First-exit/bootstrap 정리

Bernstein hull p_min≤p≤p_max가 다음 strict inequality를 만족한다고 하자.
\[
 [p_{\min}-E_n-h\Delta,\ p_{\max}+E_n+h\Delta]
 \Subset(-1/2,1).
\tag{TUBE}
\]
그러면 시간 구간 전체에서 같은 branch의 ODE/closure 해가 D 안에 존재하며
\[
 |x(t_n+s)-p(s/h)|
 \le e^{-s/4}E_n+4(1-e^{-s/4})\Delta
 \le E_n+s\Delta.
\tag{SLOW}
\]

증명: Exact solution이 D 안에 있는 최대 구간에서 scalar one-sided Lipschitz bound와 Dini derivative에 의해 e'=비선형차이−defect로부터 D⁺|e|≤−|e|/4+Δ다. Gronwall 비교가 (SLOW)를 준다. 이 상계와 (TUBE)는 exact solution이 첫 exit 시각에서 경계에 닿을 수 없다는 모순을 만든다. Bounded smooth vector field는 해당 compact tube에서 continuation할 수 있으므로 전체 step이 닫힌다. 따라서 ‘true trajectory가 이미 tube 안’이라는 순환 가정을 쓰지 않는다.

동시에 q의 whole-path error는 직접 factorization으로
\[
 |q_\sigma(x(t_n+s))-r(s/h)|
 \le\frac{D_g+E_n+h\Delta}{r_{\min}+q_{\min}}
\tag{ROOT}
\]
다. 이를 위해 별도의 미래 root sorting이나 endpoint Newton 수렴 주장을 사용하지 않는다.

명제는 이 scalar regular closure에 한정된다. 일반 G(y,q)의 inverse bounds, high-index DAE, positive-dimensional fiber, nontrivial monodromy chart atlas를 모두 구현한 것은 아니다. Domain guard가 실패하면 더 작은 step 또는 명시적 unsupported로 남고, 다른 sheet로 이동하지 않는다.

### 3.3 Bernstein bounds는 sampling maxima가 아니다

Power polynomial P(θ)=Σ_{j=0}^n c_jθ^j의 degree-n Bernstein coefficients는
\[
 b_i=\sum_{j=0}^i c_j\binom{i}{j}/\binom{n}{j}.
\]
Basis가 [0,1]에서 nonnegative이고 합이 1이므로 min b_i≤P(θ)≤max b_i. 모든 coefficients를 Fraction으로 계산한다. Oracle의 interior sampling은 이 증명을 대체하지 않고 코드 검산만 한다.

음성 대조: x'=0에서 p(θ)=3θ²−2θ³은 양 끝의 defect p'가 0이지만 p(1)−p(0)=1이다. Endpoint-only residual 검사는 이를 놓치며 Bernstein whole-path bound는 0이 될 수 없다.

### 3.4 실제 RVJ endpoint를 갖는 candidate

현재 signed sqrt interval의 midpoint q0를 얻는다. Future trajectory는 사용하지 않는다. 오차가 0이 아닌 q0도 허용하되 seed inconsistency는 g에 남겨 검사한다. Formal Taylor coefficients를
\[
 x_{j+1}=(q_j-x_j)/(j+1),\qquad
 q_j=\frac{x_j-\sum_{i=1}^{j-1}q_iq_{j-i}}{2q_0}
\]
로 j=1,...,5까지 계산한다. 이는 고차 AD backend가 아니라 이번 scalar closure에 대한 exact coefficient recursion이다. G_q에 해당하는 2q0의 나눗셈을 피한 것이 아니며 정칙 하한을 검사한다.

W=-1+1/(2q0), T5(θ)=Σ x_j(hθ)^j를 놓고
\[
 c=120h^5x_5[\varphi_5^R(hW)-1/120],\qquad
 p(\theta)=T_5(\theta)+c\theta^6,
\]
\[
 r(\theta)=\sum_{j=0}^5q_j(h\theta)^j,
\quad
 \varphi_5^R(z)=\frac{z^2-5z+12}{1440Q(z)}
\]
로 정한다. p(1)은 RVJ endpoint이고 θ=0의 jets through order5를 보존한다. 이것은 generic dense-output tableau의 존재 주장이 아닌, 이번 사후검증을 위한 endpoint-matching reconstruction이다.

일관된 exact seed와 작은 h에서 d=O(h^5), g=O(h^6), 따라서 local hΔ=O(h^6)이다. 연결 CAS는 symbolic q0에 대해 이 차수 상쇄를 확인했다. 실제 approximate sqrt seed의 오차, 저장 endpoint rounding, 위쪽 radius rounding은 별도 포함된다. Finite precision 아래 무한 h-refinement의 형식적 차수를 보장하지 않는다.

## 4. 비정규 2-mode fast action의 직접 상계

### 4.1 Scalar gap을 미분까지 운반한다

Loop4의
\[
 R(z)=\frac{1+2z/5+z^2/20}{1-3z/5+3z^2/20-z^3/60}
\]
와 a≥0에서 δ(a)=R(−a)−e^{−a}∈[0,η(a)]를 사용한다.
\[
 \eta(a)=\min\{R(-a),\ a^6/[7200Q(-a)],\ a^2/[20Q(-a)]\}.
\]
직접 미분하면
\[
 \frac{d}{da}R(-a)+R(-a)=\zeta(a),\qquad
 \zeta(a)=\frac{3a^5}{(a^3+9a^2+36a+60)^2}.
\]
따라서
\[
 R'(-a)-e^{-a}=\delta(a)-\zeta(a),
\]
\[
 |R'(-a)-e^{-a}|
 \le\chi_0(a)=\max\{\zeta(a),|\eta(a)-\zeta(a)|\}.
\]
큰 a에서 너무 느슨해지는 것을 막기 위해
\[
 e^{-a}\le E_6(a)=\left(\sum_{j=0}^6a^j/j!\right)^{-1}
\]
과
\[
 \chi(a)=\min\{\chi_0(a),\ |R(-a)-\zeta(a)|+E_6(a)\}
\tag{CHI}
\]
를 사용한다. 모두 rational arithmetic이다. Small-a leading order는 χ=O(a^5); large-a direct bound leading은 3/a²다. 각 상계가 독립적으로 유효하므로 min도 유효하다.

### 4.2 Jordan과 서로 다른 두 rate

ρ=1이면
\[
 R(hA)=\begin{pmatrix}
 R(-a)&\beta aR'(-a)\\0&R(-a)
 \end{pmatrix}.
\]
따라서 w=(u,v)에 대한 exact exponential-action과의 componentwise 차이는
\[
 b_1=\eta(a)|u|+|\beta|a\chi(a)|v|,\quad
 b_2=\eta(a)|v|
\tag{JORDAN}
\]
로 감싸진다.

ρ=2이면 off-diagonal은 β[R(−a)−R(−2a)]이고, exact exponential의 대응항은 β[e^{−a}−e^{−2a}]다. 두 scalar gaps가 nonnegative이므로
\[
 b_1=\eta(a)|u|+|\beta|\max\{\eta(a),\eta(2a)\}|v|,
 \quad b_2=\eta(2a)|v|.
\tag{PAIR}
\]
연결 Wolfram과 독립 symbolic rational-matrix 계산이 두 identity를 확인했다. Distinct-eigenvalue divided difference가 rate merge에서 R'로 가는 confluent limit도 확인했지만, 임의의 ρ나 ill-conditioned eigenvector transformation을 구현하지는 않았다.

계산기하적 분류에서도 두 종류의 singularity를 구분해야 한다. q²=1+x에서 x=−1은 선택한 root projection의 실제 critical locus다. 반면 위 fast family의 ρ→1에서 나타나는 diagonalization denominator ρ−1은 matrix function 자체의 singularity가 아니다. 일반 ρ≠1의 off-diagonal은 β[R(−a)−R(−ρa)]/(ρ−1)이고, ρ→1에서 βaR'(−a)로 유한하게 간다. Spectrum이 R의 poles를 피하면 R(hA)는 이 spectral collision에서 regular하다. 따라서 eigenvalue collision을 physical branch-loss event로 취급하는 routing은 잘못이며, confluent representation으로 바꾸는 것이 올바른 후보 경로다. 현재 reference는 ρ=1,2를 따로 정확히 처리하며 그 사이의 일반 ρ certificate는 남은 작업이다.


음성 대조 a=1, β=20, w=(0,1): scalar-only component bound는 첫 성분을 0이라고 하지만 실제 오류는 0.004438236...이다. 아래 weighted norm에서도 실제 error는 scalar η보다 2.822718...배 크다. 따라서 ‘eigenvalues가 모두 음수이고 scalar η가 작다’는 인증이 아니다.

### 4.3 고정 weighted norm과 inherited error

\[
 d=\max(1,|\beta|),\qquad
 \|w\|_d=\max(|u|/d,|v|).
\]
S=diag(1/d,1)에 대해 SAS^{-1}의 infinity logarithmic norm은
\[
 \max\{-\kappa+|\beta|\kappa/d,-\rho\kappa\}\le0.
\]
따라서 exact semigroup은 이 고정 norm에서 nonexpansive하다. 물리 좌표로 되돌아갈 때 d를 명시적으로 곱하며 conditioning을 숨기지 않는다.

근사 fast map M_h가 정확한 현재 중앙값 wh에서
\[
 \|M_h(\widehat w)-e^{hA}\widehat w\|_d\le\ell
\]
을 제공하면 inherited error E에 대해
\[
 E^+\le E+\ell.
\tag{FASTPROP}
\]
이는 exact semigroup과 actual center-action gap을 분리해서 증명한 것이다. Numerical R(hA) 자체의 contractivity를 가정하지 않는다. 작은 accepted perturbation을 통째로 numerical amplification으로 전파하는 다른 알고리즘과 혼동하면 안 된다.

### 4.4 Hybrid 후보

첫 후보는 (JORDAN)/(PAIR), exact output-rounding 및 certificate inflation을 합친 local bound다. 예산을 넘을 때에만 verified exponential intervals를 계산한다. Jordan은 e^{−a}(u+βav,v), distinct rate는 (e^{−a}(u+βv)−βe^{−2a}v,e^{−2a}v)를 interval로 감싼다. Exponential interval은 inherited alternating Taylor/outward dyadic squaring 구현을 사용한다. libm 또는 mpmath 결과를 certificate로 쓰지 않는다.

Fast slope와 진폭 모두 선택에 영향을 준다. Candidate 실패 비용도 work record에 남는다. Scalar closed-form small-block action이며 generic AD, Krylov solve, matrix-free large-matrix exponential을 실행한 것이 아니다.

## 5. Causal adaptive 합성 및 물리 출력 정리

Snapshot은 (t,x,w,E_x,E_w,branch,model-binding,generation)을 가진 immutable 값이다. 같은 accepted snapshot에서 candidate를 만들고 rejection은 이 값과 branch를 변경하지 않는다. Commit은 snapshot digest, branch, model epoch 및 generation을 확인한다. 이 hash는 증거 결속용이며 악의적인 외부 certificate의 진위를 보장하는 서명이 아니다.

T≤1/4, κ≥1, positive accepted h_n, Σh_n=T라고 하자. 현재 사용한 slow와 exact fast semigroup의 gain bound는 1이다. ε_x=ε/16, ε_w=ε/(16d)를 두고 각 local bound가
\[
 \ell_{x,n}\le\varepsilon_x h_n/T,\quad
 \ell_{w,n}\le\varepsilon_w h_n/T
\]
를 만족하며 initial errors가 0이면 induction으로
\[
 E_{x,n}\le\varepsilon_x,\qquad E_{w,n}\le\varepsilon_w.
\]
Adaptive choice, step ratio, fast mode sequence가 달라도 동일하다. Certificate radius를 upward rounding한 증가분도 local ℓ에 먼저 더해 예산에 포함한다. Overflow/정밀도 부족은 PrecisionBlocked이며 무조건적인 종료성을 주장하지 않는다.

물리 출력은 다음 직접 bound를 사용한다.
\[
 B_1=dE_w+(2|\widehat x|E_x+E_x^2)/\kappa+\rho_{y1},
\]
\[
 B_2=E_w+(3|\widehat x|^2E_x+3|\widehat x|E_x^2+E_x^3)/\kappa+\rho_{y2}.
\]
각 ρ는 exact central reconstruction과 stored dyadic value의 실제 차이다. B1,B2≤ε를 마지막으로 검사한다. Mean-value theorem으로 x와 xhat이 D에 있는 경우의 더 간단한 |δy1|≤dEw+2Ex/κ+ρ1, |δy2|≤Ew+3Ex/κ+ρ2도 얻을 수 있다.

결론: 이 structured class에서 whole-tube/precision guard를 통과한 모든 accepted endpoint는 ε의 물리 절대오차 계약을 만족한다. κ에 의존하는 prefactor를 오차전파 bound에 숨기지 않는다. 하지만 step count와 비용의 κ-uniform bound, arbitrary generic stiff order5, 빠른 초기층의 continuum relative resolution까지 증명한 것은 아니다.

비영 fast modes를 임의로 0으로 projection하지 않는다. 단, tail이 목표 absolute tolerance보다 훨씬 작을 때 relative error가 크더라도 허용될 수 있다. Slow/closure polynomial tube는 continuum 인증이지만 fast/physical dense-output 및 event-time error 계약은 아직 미구현이다.

## 6. 실제 실행 결과

명령·exit·원시 로그는 evidence에 있다. 최종 code tests는 28개 통과, exact symbolic check는 13개 통과다. 연결 Wolfram은 matrix/defect identity를 재검산했다. Infinity로 직접 보낸 Limit 호출의 경고는 별도 보존했고 reciprocal-variable regular chart로 clean 재검산했다.

Adaptive exploratory matrix 14개: κ={1,40,10000}, β={4,20,−4}, ρ={1,2}, branch ±, nonzero/zero/mixed-sign 초기 fast 상태를 선택했다. ε=1e−8, T=1/4이다. Main 14 cases는 각 8 accepted steps였고, 100-digit mpmath.odefun oracle와 모든 endpoint 및 다섯 interior slow/closure points에서 enclosure가 일치했다. Oracle는 candidate 모듈에 import되지 않는다. Positive slow branch endpoint는 150-digit oracle에서도 다시 계산해 차이 1.2323e−95를 확인했다. 이는 oracle의 numerical convergence check이며 independent rigorous oracle theorem은 아니다.

Representative branch+, w0=(0,1), β=4:

| κ | ρ | accepted | RVJ | EXP enclosure | max physical error y1 | max physical error y2 |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 1 | 8 | 8 | 0 | 4.1898e−11 | 7.4558e−12 |
| 1 | 2 | 8 | 8 | 0 | 1.7926e−10 | 3.1491e−11 |
| 40 | 1 | 8 | 0 | 8 | 5.8693e−13 | 2.0643e−13 |
| 10000 | 1 | 8 | 7 | 1 | 2.3477e−15 | 8.2574e−16 |

β=20, κ=1, ρ=2에서는 EXP enclosure를 8회 선택한다. 이는 eigenvalues만이 아니라 nonnormal coupling의 physical scale도 admission에 들어가는 예다. 같은 κ=10000에서 w0=0이면 RVJ8회, EXP0회다. 이를 성능 향상으로 해석하지 않는다.

κ=10000, β=4, ρ=1의 ε refinement 1e−6/1e−8/1e−10에서 accepted steps는 4/8/32, EXP enclosure는 각1회였다. Default controller의 accepted mesh가 우연히 uniform했으므로 exploratory E07을 추가했다. h=1/64와1/32를 교대로 쓰고 마지막을 T에 맞춘 8 case에서 11 accepted steps씩, 전체 enclosure를 확인했다. κ=40은 EXP11회, κ=10000은 EXP1회 뒤 RVJ10회다.

별도 fast-action sweep 96 case는 100-digit mpmath matrix exponential을 사용했다. a=1e−4,...,1e6, β=−20,0,4,20, 두 rate, 두 initial vector에서 모든 component bound를 만족했다. Scalar-only 잘못된 bound의 weighted underestimate는 2.822718...배다.

숫자는 서로 다른 검사 단위이고 통합 성공률로 합치지 않는다. Main/auxiliary oracle는 고정밀 numerical check이며 exact arithmetic inequalities와 직접 증명을 대체하지 않는다.

## 7. 실패·수정·한계

1. Scalar-only Jordan bound는 red regression에서 실패했다. 추가 derivative gap bound로 수정하고 green을 얻었다. 과학적 반례와 reference repair다.
2. Negative branch의 q_start diagnostic interval endpoint ordering 오류를 수정했다. 원래 acceptance 계산에는 쓰이지 않던 필드다.
3. Outward radius inflation이 reported local budget에 명시적으로 들어가지 않던 회계 오류를 red/green으로 수정했다. 이전 global recheck가 false acceptance를 막았지만 새 recurrence contract에 맞춰 inflation을 local에 먼저 포함했다.
4. 마지막 rounded slow endpoint와 그 radius가 D 안에 있는지 추가 검사했다.
5. Combined final-run tool timeout은 main E03/E04/E06 exit0 뒤 E07 시작 중 발생했다. 프로세스가 남아 있지 않음을 확인하고 E07 단독 재실행 exit0을 기록했다. 수학적 실패나 ‘전체 실행 PASS’로 뭉뚱그리지 않는다.
6. SciSpace add-column not_found, source full replay inherited blocker, CAS infinity 경고를 개별 기록했다.

Loop3/4의 raw-RVJ 반례는 inputs/loop4에 원본으로 보존했다. 그 원래 4개 raw-RVJ numerical run을 이번에 다시 실행했다고 주장하지 않는다. 이번에는 별도의 nonnormal scalar-only negative control과 endpoint residual negative control을 새로 실행했다.

## 8. 하네스와 다음 경로

이번에는 사용자별 GPT6 Astra v4.0.0 research/coding ZIP을 Library에서 실제 취득하고 예상 SHA-256과 일치함을 확인했다. 하네스 원문과 읽은 파일, 적용한 scientific contract, 선행 루프에서의 미확보 상태와의 구분을 HARNESS_BINDING.json에 남겼다. 이는 모델 성능이나 theorem correctness의 증명이 아니다.

남은 작업만 NEXT_DEVELOPMENT_DAG.json에 둔다. 가장 중요한 것은 (a) general vector slow/closure defect provider, (b) 더 많은/가까이 합쳐지는 fast modes와 inexact current-J Krylov certificate, (c) state-dependent fast frame과 fast-to-slow feedback, (d) physical dense/event/branch transition, (e) native roundoff와 실제 총 비용이다. Already-scoped implementation을 ‘전혀 미구현’으로 다시 제안하지 않는다. Independent reviewer가 없으므로 final promotion HOLD를 유지한다.
