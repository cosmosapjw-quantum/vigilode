# RVJ 독립 연구 루프 9
## 연구 이력의 통합 비평과 phase-aware highly oscillatory 확장

날짜: 2026-10-03. 이 문서는 독립 수학·reference-code 연구다. Vigilode의 현재 브랜치, PR, 로컬 native 검증을 읽거나 변경하지 않았다. source-derived 역사, 이번 직접 유도, 연결 CAS, exact/outward reference, floating numerical oracle를 분리한다. 원래 generic RVJ의 반례는 유지한다. 새 모델의 조건부 정확성은 다른 문제에서의 성능, 장시간 symplecticity 또는 독립 최종 심사 승인을 뜻하지 않는다.

## 0. 결론과 범위 고정

지금까지의 성과는 하나의 만능 RVJ tableau보다 `candidate + continuous reconstruction + original-equation certificate + causal selector`라는 polyalgorithm 구조에 가깝다. 이것은 의미 있는 진전이지만, 원래 동기였던 Jacobian/Jv pathology와 직렬 비용을 동시에 줄이는 production 방법은 아직 입증하지 못했다. 많은 성공 사례가 알려진 정칙 chart, 작은 정확 행렬, 주어진 comparison metric, 고차 jet, arbitrary precision에 의존한다.

이번의 새 결론은 다음과 같다.

1. R23은 허수축에서도 안정하지만 큰 위상증분의 진폭을 소거한다. Unit-modulus R33은 그 문제를 바꾸지만 phase accuracy를 보장하지 않는다.
2. 기존 stationary damping box `delta/nu`를 neutral oscillation에 옮길 수 없다. Residual의 시간적분과 physical phase reconstruction을 별도로 계상해야 한다.
3. Exact linear convolution만으로 forcing aliasing은 해결되지 않는다. 알려진 carrier와 진짜 resonance/detuning을 분리하고, 보간할 것은 가능하면 느린 amplitude여야 한다.
4. 알려진 U(1) carrier에 equivariant인 두 복소 모드와 signed algebraic closure에서, carrier를 정확하게 제거한 뒤 RVJ/Taylor amplitude 후보를 exact residual로 검증했다. Envelope mesh는 carrier frequency에 독립이다. Physical carrier의 평가 비용과 주파수 불확실성은 별도이며 독립이라고 주장하지 않는다.

모든 실행은 exploratory다. 최초 RESEARCH_CONTRACT.json의 가설은 유지했다. 구현 단계에서 초기 a1을 1에서 1/2로 제한해 전 구간 unit-ball 증명을 가능하게 하고, invariant signed sqrt closure를 추가했다. 이 범위 확정을 최초 계약에 소급해 반영하지 않았다. 따라서 unrestricted 초기자료에 대한 확인실험이라고 표시하지 않는다.

## 1. 전체 연구 이력의 비평

역사적 정본 파일과 hashes는 evidence/HISTORY_SOURCE_INDEX.json에 있다. 각 단계의 primary note와 claim ceiling을 대조했지만, 과거 모든 numerical campaign을 이번에 다시 돌리지 않았다.

| 연구 가족 | 이미 얻은 것 | 남은 약점 / 이번 판정 |
|---|---|---|
| Ordinary Rosenbrock-W, common/variable gamma | 모든 bounded W에 대한 엄격한 W-order p이면 F-evaluation depth >=p. Common gamma depth5 scalar L-stable 후보를 하나로 좁힘 | Full nonlinear W5 tableau 존재와 비용은 별개. Variable gamma만으로 depth<5를 얻는 경로는 되살리지 않는다. |
| JVP, block/multi-shift/recycled Krylov | 행렬을 조립하지 않고 current operator에 대한 action, RHS/basis 재사용 가능 | 미분 없는 방법은 아니다. 임의 preconditioning 뒤 shift invariance, stale-W 사용, Jv pathology 해소는 자동이 아니다. ROK/low-rank stiff subspace는 여전히 차원·관측 가능성 가설을 요구한다. |
| RJ5 rational-jet | 일반 차원의 고전적5차와 exact-J 선형 R23 안정성 | PR stiff order3 및 approximate-W 반례. Generic stiff-uniform 후보로는 기각하되 제한된 candidate로 보존. |
| RVJ5 rational VoC-jet | scalar/constant-matrix PR군의 uniform5와 nonlinear defect 표현 | Bounded-g semilinear two-step 내부 증폭 반례, embedded blindness가 남음. Exact exponential core 교체만으로도 반례가 남았음. |
| Darboux/cofactor chart, primitive lift | 일부 모델의 fast 분리, 초기층 impulse 보존, physical error transport | 새로운 discrete map이다. 모든 모델에 chart가 있지 않으며 denominator, inverse norm, connection, residual forcing이 필요. |
| Witness/Hensel/homotopy | 정칙 root의 causal path identity, formal jet, 실제 contraction certificate, fold/infinity 분류 | Formal lift와 실제 finite-step root certificate는 다르다. 물리 reset law 없는 fold 통과나 support equality에 의한 branch merge는 금지. |
| Loop4–7 adaptive certificates | unknown closure, 2-mode nonnormality, one/two-way feedback, invariant error box 구현 | 정확한 small-block/metric에 의존. 감쇠 없으면 stationary box를 잃는다. Total computational cost와 method accuracy는 다르다. |
| Loop8 EXP_CONV_INTERPOLANT | homogeneous layer와 linear return coupling을 kernel에 보존. Same-model steps 감소 | 원 RVJ와 다른 map. 209 correction sweeps/153 certified slabs 등 비용; nonlinear forcing alias·과도한 nodal solve·small dense exp/inverse가 남음. |
| Involution/reflection | 선형 projector와 symmetry decomposition, witness swap의 역할을 분리 | 감쇠나 nonlinear convergence를 대신하지 않음. Rational time-symmetry와 L-stability no-go는 해당 one-step 클래스에 한정. |
| Interpolation/extrapolation | forcing 재구성, Lebesgue 및 extrapolation gain31/769, bounded coupled iteration | 정확 kernel도 정보 손실은 복구하지 못함. 외삽 우선이 총 비용에서 불리했던 결과를 보존. |
| 이번 carrier-aware lane | 공진 모드 교환과 damped/neutral 혼합, 원방정식 residual의 물리오차 전달 | 알려진 정확한 carrier/equivariance가 전제. 일반 unknown frequency, nonlinear slow–fast resonance graph, large Krylov 및 장시간 구조 보존은 미완료. |

### 과거 주장 중 반드시 정정된 형태로만 사용하는 것

단일 stage inverse bound만으로 inexact stage의 stiff-uniform order를 증명할 수 없다. 전체 내부 오차 전달과 one-step 안정성이 필요하다. 정확한 Newton의 제곱 수렴을 frozen chord iteration에 옮길 수 없다. `Jacobian-free`는 matrix-free와 derivative-free로 구별한다. 근사 W를 integrator에 대입하는 것과 current J의 solve를 inexact하게 푸는 것, 또는 preconditioner/basis만 재사용하는 것은 별개다.

역사적 step 수를 다른 문제·다른 map·다른 정밀도와 묶어 speedup으로 만들지 않는다. 현재까지 causal protocol의 명료화와 반례 분류는 강점이지만, prototype들의 작은 차원과 알려진 analytic bounds는 가장 큰 외적 타당성 제한이다. 도구·하네스·원본 hash의 정확성은 물리 정리의 타당성과 다른 축이다.

## 2. 감쇠와 진동은 같은 fast 현상이 아니다

복소 scalar z'=(-kappa+i*omega)z에서 kappa는 진폭의 소멸률, omega는 위상의 회전률이다. 둘 다 inverse-time 차원을 갖지만 물리적 오류는 다르다. 초기 진폭이 작아진 dissipative mode에는 절대오차 아래에서 coarse update가 허용될 수 있다. Neutral mode는 진폭이 남으므로 위상 누적오차를 계속 지불한다.

상수 positive Hermitian H에서 A=D+K, D*H+HD<=0, K*H+HK=0이면 A의 log norm도 비양수다. D와 K가 commute하지 않아도 이 에너지 부등식은 성립한다. 그러나 exp(hD)exp(hK)를 exact exp(hA)로 바꾸는 것은 별개이며 leading defect h²[D,K]/2가 있다. Omega가 commutator에 들어가면 주파수독립 정확성을 잃을 수 있다.

비정규 예제 A=[[i*omega,M],[0,i*omega]]는 spectrum이 순허수여도 exp(tA)=exp(i*omega*t)[[1,Mt],[0,1]]이다. (0,1)의 norm은 sqrt(1+M²t²). Eigenvalues만으로 unitary로 분류할 수 없다.

### 물리 norm과 관심량

진폭, unwrapped phase, full state, 에너지/action, slow observable, event time은 별개의 목표다. 에너지 보존만으로 trajectory의 위상 정확성을 보장하지 않는다. 2차 진동계 M q''+K q=f에서 (sqrt(K)q,sqrt(M)q') 같은 energy coordinate를 쓰려면 zero modes와 물리 단위, condition number를 명시해야 한다. 커다란 omega scale을 norm 속에 숨겨 position/velocity 오차를 같은 수치로 간주해서는 안 된다.

## 3. R23과 R33의 정확한 진폭·위상 분석

P=1+2z/5+z²/20, Q=1-3z/5+3z²/20-z³/60, R23=P/Q라 하자.

|R23(i theta)|²=(3600+216theta²+9theta⁴)/(3600+216theta²+9theta⁴+theta⁶).

따라서 theta!=0이면 진폭을 감쇠시키고 |theta|->infinity에서 0으로 간다. 작은 z에서

log R23(z)=z+z⁶/7200+z⁷/42000+O(z⁸).

z=i theta이면 real log=-theta⁶/7200+O(theta⁸), phase=theta-theta⁷/42000+O(theta⁹). N=T/h번 적용하면 leading artificial damping은 T omega⁶h⁵/7200, phase lag는 -T omega⁷h⁶/42000이다. 이 전개는 |omega h|<<1에서만 사용한다.

R33=(1+z/2+z²/10+z³/120)/(1-z/2+z²/10-z³/120)이면 R33(z)R33(-z)=1이라 |R33(i theta)|=1이다. 하지만 logR33=z+z⁷/100800+...이고 큰 theta에서 정확한 phase theta를 추적하지 못한다. Unitarity와 phase accuracy는 독립 조건이다.

고정 차수 rational 함수가 imaginary ray 전체에서 exp(i theta)를 임의의 작은 오차로 근사할 수 없다. 분자차수가 작으면 limit0, 같으면 고정된 유한limit, 크면 발산한다. exp(i theta)의 서로 반대되는 두 subsequence 때문에 유한limit과의 uniform error를1미만으로 줄일 수 없다. 이는 adaptive degree, explicit phase, 제한된 spectral domain을 금지하는 정리가 아니다.

실행: h=.1,N=100,omega=1/10/100/1000. omega100에서 R23 최종진폭5.07e-50, stateerror약1; R33진폭1이지만 stateerror약.82697. Unwrapped phase branch를 사용했으며 principal argument만 보고 여러 회전을 잃지 않았다. evidence/oscillator_filters.json 참조.

## 4. Oscillatory convolution은 반드시 공진을 구분한다

z'=(-kappa+i omega)z+exp(i nu t)b, z(0)=0이면

z(h)=exp(i nu h) h phi1((-kappa+i(omega-nu))h)b,
phi1(z)=(exp(z)-1)/z, phi1(0)=1.

kappa=0, nu=omega에서는 magnitude h|b|다. 커다란 omega라는 이유만으로 이를 O(1/omega)로 버릴 수 없다. 실제로 L-infinity forcing을 endpoint로 전달하는 unitary convolution의 norm은 정확히 h다. 상계<=h는 삼각부등식이고 resonant forcing을 선택하면 equality다.

반대로 실제 envelope b(s)가 미분 가능하고 detuning Delta!=0인 경우 부분적분으로

|integral_0^h exp(i Delta s)b(s) ds|
 <= (|b(0)|+|b(h)|+integral|b'|)/|Delta|

를 얻을 수 있다. 이 경계는 regular envelope 및 nonresonance를 요구한다. Delta~0에서는 entire phi함수나 confluent expansion으로 계산하고 singular division으로 바꾸지 않는다.

### 샘플 aliasing의 exact counterexample

h=1, omega=8pi, nodes0,1/4,1/2,3/4,1을 사용한다. f(s)=exp(8pi i s)는 모든 node에서1이다. Degree4 forcing interpolant는 상수1인데, kernel exp(8pi i(1-s))로 convolution하면 endpoint0이다. Exact resonant forcing의 endpoint는1이다. Homogeneous exponential이 정확해도 forcing의 alias를 되돌릴 수 없다.

### 고정차수 다항식의 oscillatory 경로 하한

complex polynomial p, degree m에 대해 sup_[0,1]|p(theta)-exp(i a theta)|<1이라 하자. theta_j=j*pi/a, j=0,...,floor(a/pi)에서 Re p의 부호는 (-1)^j와 같다. 인접한 점 사이에 실근이 있어야 하므로

m>=floor(a/pi).

따라서 phase를 포함한 O(1)-진폭 oscillation 전체를 고정차수 다항식으로 재구성하는 비용은 선형으로 frequency*step과 함께 커질 수밖에 없다. 이는 Loop7의 decaying layer에 대한 Markov bound와 다른 구조적 장애물이다. Carrier-enriched/Fourier/Filon 경로나 일부 관심량만 계산하는 방식에는 이 전제가 적용되지 않는다.

## 5. Involution에서 phase-equivariance로: 정확히 제거할 수 있는 항

U_theta(z1,z2)=(exp(i theta)z1,exp(2i theta)z2)라 하자. 임의 다항식 monomial z^alpha conjugate(z)^beta가 j성분에 나타날 때 residual phase는

Delta=(alpha-beta)·omega-omega_j

다. Delta=0인 monomial은 resonant이고 평균화로 삭제해서는 안 된다. 작은 Delta는 느린 beat로 유지하며 큰 nonzero Delta만 별도 oscillatory moment로 취급할 후보가 된다.

이번 H1=conj(z1)z2, H2=z1²/2는 각각 charge1,2이므로 위 circle action에 정확히 equivariant다. I=|z1|²+2|z2|²는 invariant라 q²=1+I도 carrier와 commute한다. 이 polynomial identity는 원계수로 exact check가 가능하다.

이는 단순히 관측값 I가 같으니 state를 quotient한다는 뜻이 아니다. 물리 복소상태를 요구하면 phase를 반드시 저장·재구성한다. 원문의 witness/support 구분과 마찬가지로 invariant observable equality는 full-state equality가 아니다. Undamped equation에서 conjugation은 reversing involution이지만 damping이 있으면 같은 reversal symmetry가 사라진다. 이번 adaptive map의 symplecticity는 증명하지 않았다.

## 6. 새 기준 모델과 오차 정리

### 6.1 원방정식과 정확한 carrier 제거

모든 변수·시간은 무차원 benchmark convention이다. 차원복원 시 omega,delta,gamma는 inverse time, g는 nonlinear amplitude와 closure scale에 맞는 단위를 갖는다.

z1'=(i Omega-gamma1)z1+i g q conj(z1)z2,
z2'=(2i Omega+i delta-gamma2)z2+i(g/2)q z1²,
q²=1+|z1|²+2|z2|², sign(q)=sigma.

가정: g,delta는 실수; gamma1,gamma2>=0; Omega는 정확히 알려진 상수; sigma=±1은 고정; a1(0)=1/2, a2(0)=1/4+i/8, T<=1. Actual main T=1/2. 주파수는 데이터로부터 추측하지 않는다.

z1=exp(i Omega t)a1, z2=exp(2i Omega t)a2로 두면

a1'=-gamma1 a1+i g q conj(a1)a2,
a2'=(-gamma2+i delta)a2+i(g/2)q a1².

이것은 근사가 아니라 exact transformed equation이다. 실제 두 frequency는 Omega와2Omega+delta이고 detuning delta는 제거하지 않았다.

H=diag(1,1,2,2), a=(x,y,u,v)의 weighted action I=||a||_H²는

I'=-2gamma1|a1|²-4gamma2|a2|²<=0.

I0=13/32<1이므로 정확한 해는 항상 unit H-ball에 있다. 이 invariant가 exact domain과 closure |q|>=1을 제공한다. Undamped I conservation을 근거로 canonical Hamiltonian이나 symplectic integrator라고 부르지 않는다.

### 6.2 오차 성장 상수는 carrier와 무관하다

비선형 vector Hn=(yu-xv,xu+yv,-xy,(x²-y²)/2)를 두자. Exact identity는

||Hn(a)||_H²=|a1|² I/2.

Unit ball에서 ||Hn||<=1, |q|<=sqrt2<3/2, ||Dq||<=1이다. 또한 complex directional expression

D Hn[a]v = (i[conj(v1)a2+conj(a1)v2], i a1 v1)

와 weighted Cauchy에서 ||DHn||²<=(5/2)||a||_H²<=5/2<4를 얻어 ||DHn||<=2를 쓸 수 있다. 따라서 ||D(qHn)||<=4이다.

Detuning의 linear part는 H-skew다. Exact vector field의 logarithmic norm은4|g|-min(gamma1,gamma2) 이하이다. 구현은 안전한 nonnegative

lambda=max(0,4|g|-min(gamma1,gamma2))

를 사용한다. 큰 delta는 이 성장상수에 들어가지 않지만, 후보 polynomial 정확성과 비용에는 들어간다. 음의 log norm을 이용해 error를 잊어버리는 개선은 이번에 하지 않았다.

### 6.3 differential/algebraic defect

현재 amplitude snapshot에서 degree5 Taylor jet, degree6 endpoint-matching RVJ curve p(theta), degree5 closure curve r(theta)를 만든다. r0는 exact sqrt interval의 signed midpoint다. 모든 계수는 Fraction이다. High-order AD backend가 아니다.

RVJ 후보는 p=T5+theta^6 h^5(120phi5R(hJ)-I)a5,
phi5R(Z)=Q(Z)^-1(Z²-5Z+12I)/1440,

이며 current4x4real Jacobian과 exact Gaussian solve를 사용한다. Taylor 후보는 보정항을 생략한다. 이 J에는 closure derivative a^T H/q가 포함된다. Approximate root seed가 정확하다고 가정하지 않고 그 불일치를 아래 residual에 남긴다.

Bernstein hull로 다음을 감싼다.

I(p)<=1, m=inf sigma*r>=1/2,
Df>=sup||p'/h-[L p+g r Hn(p)]||_H,
Dg>=sup|r²-1-I(p)|.

Exact same-sign closure에 대해 |r-q(p)|<=Dg/(m+1). 따라서 실제 reduced defect는

delta_cert=Df+|g|Dg/(m+1)

로 감싸진다. 두 trajectory 사이 segment도 convex unit ball 안에 있으므로

E(s)<=exp(lambda*s)(E0+s delta_cert)

가 전체 step에 성립한다. 이 모델은 exact invariant domain을 이미 증명했으므로 여기서는 별도의 circular tube assumption이 없다. Candidate unit-ball/domain 검사는 여전히 필요하다.

저장 endpoint는 dyadic112bit로 반올림하고 H-norm rounding을 더한다. Root error는 Dg/(m+1)+E 이하이다. Continuous physical curve exp(i Omega t)p와 원방정식의 defect는 amplitude defect의 unitary rotation이므로 같은 norm경계가 성립한다.

### 6.4 causal adaptive error budget

G>=exp(lambda*T)를 exact interval arithmetic으로 계산한다. Accepted local output perturbation ell_n은 기존 E0에 곱해지는 exact represented gain을 뺀 나머지로 정의하며 모든 upward radius inflation과 저장 rounding을 포함한다.

ell_n<=tol*h_n/(4*T*G), Enew<=tol/4.

임의 positive accepted mesh에서 sum h=T라면 global E<=tol/4가 따른다. 미래 exact solution은 사용하지 않는다. 실패한 후보는 accepted state/branch/epoch를 바꾸지 않는다. Hash는 accidental candidate mixing을 막는 trusted-process binding이지 malicious certificate의 보안 인증이 아니다. 실제 commit에서 path뿐 아니라 stored endpoint/error도 결속한다.

### 6.5 physical carrier의 평가와 불확실성

정확 carrier 아래 ||z-z_hat||_H<=E이다. 구현에서 sin/cos interval을 Taylor series와 repeated doubling으로 평가하고 real/imag 재구성오차를 H norm으로 더한다. 큰 rational angle을 먼저 |angle|<=1/8로 줄이며, doubling수와 증가 precision을 계상한다. Libm trig나 mpmath는 certificate에 들어가지 않는다.

공통 carrier가 Omega±DeltaOmega로만 알려졌고 detuning과 초기 envelope는 같다면

||U_Omega(t)-U_(Omega+DeltaOmega)(t)||_H
 <=min(2,2t|DeltaOmega|).

따라서 이 값에 ||a_hat||_H를 곱한 phase uncertainty를 따로 더한다. 이는 correlated common-carrier uncertainty에 대한 식이며 unknown detuning, unknown amplitudes, arbitrary independently uncertain frequencies에는 별도 sensitivity가 필요하다.

결론: 이 정확히 equivariant인 모델의 정해진 finite horizon에서, carrier frequency와 무관한 envelope mesh와 수학적 full-state absolute error bound를 얻는다. Carrier 평가비용·필요 bits·unknown frequency estimation·long-time geometric structure가 frequency-independent라는 주장은 아니다. Phase 자체의 상대오차는 amplitude가0에 가까우면 정의가 나빠진다. |stateerror|<=e<A이면 phase error<=arcsin(e/A)라는 별도 변환이 가능하다.

## 7. 실행 결과와 근거 상태

Main8조건: resonant, detuned, damped, negative branch, large detuning, strong damping, Taylor-first, tight tolerance. 이들은 총214acceptedsteps이며 각 step의 amplitude와3interior points를 검사했다. 각 envelope trajectory를 Omega=0,1,10³,10⁶,10¹²로 재구성했다. 40개의 별도 적분을 했다는 뜻이 아니다.

기본 T=.5,tol1e-6에서:

| 조건 | Accepted | 선택 | 최대 amplitude H-error |
|---|---:|---|---:|
| resonant |4|RVJ4|3.28e-11|
| delta=.75 |4|RVJ4|6.91e-10|
| gamma=(.5,2), delta=.75 |13|RVJ13|2.17e-9|
| sigma=-1, delta=-.5 |4|RVJ4|3.24e-10|
| delta=20 |128|RVJ128|1.62e-9|
| gamma=(10,20) |53|RVJ53|1.05e-9|
| Taylor-first |4|Taylor4|5.18e-11|

이 결과는 detuning과 damping이 여전히 비용을 만든다는 사실을 보인다. 이번 main에서 동일 trajectory 내 RVJ/Taylor 전환의 순이익은 관측하지 않았다. 두 candidate의 수락을 각각 시험했을 뿐이다.

Oracle는 별도SciPy DOP853/Radau 두 알고리즘이며tol3e-13,atol2e-15다. 모든 raw endpoint/interior/physical reconstructions에서 bound위반0이다. Observed max ratio는약.167미만. Oracle도근사이므로 formal proof는 residual/interval계산에 있다.

추가 mpmath60자리,degree24,Taylor oracle를 resonant envelope에 사용했다. DOP853 endpoint와Hnorm차이는1.48e-16. Omega40에서는 원래physicalequation을직접DOP853로다시적분해 reconstructedvalues와대조했고bound위반0이었다.

Tol1e-6/1e-8/1e-10/1e-12의추가실행은4/4/8/32steps. 앞두결과는stepcap때문에동일상태다. Tol1e-10에서 finalerror1.02e-12,tol1e-12에서9.95e-16이다. 고정step차수연구로relabelling하지않는다.

Nonuniformcase는7steps, h=1/16,3/32,1/32를사용했고finalerror4.76e-12이bound안에있었다. Omega1e12에서absoluteDeltaOmega1e-4의reconstruction차이를별도계상했다. 상대주파수오차가작더라도phaseerror는주파수오차*time에의존한다.

## 8. 문헌과 비교해야 할 대안들

[L1] Chartier–Lemou–Méhats–Zhao, IMA42(2022),1623–1644, online2021-05-03, DOI10.1093/imanum/drab014: 공식abstract에서 RHS만으로 고차uniformaccuracy를보존하는two-scale/micro–macro방법을확인. 원래derivative-free목표에직접적인baseline이다. 아직코드를가져와비교하지않았다.

[L2] Cohen–Gauckler–Hairer–Lubich, authorpreprint2014-08-25: AssumptionsA/B와Theorem3.1을parsed본문에서읽었다. 고정highfrequencies,Hamiltonianpotential의미분경계,유계energy,정해진filter및numerical h*omega nonresonance조건에서장시간energynearconservation을준다. Physicalfrequency끼리의nonresonance와step-frequencyalias를구분한다. 이정리를현재variableadaptiveRVJ에상속하지않는다. WebPDFscreenshot은시도했으나도구오류로실패했고,그림에서새결론을끌어내지않았다.

[L3] Khanamiryan, BIT DOI10.1007/s10543-008-0201-0: 공식abstract의Filon-type+waveformrelaxation은Loop8와이번oscillatoryforcing의직접적인선행맥락이다. Boundedphysicalnodes의forcing이빠르게진동하면amplitude/phase분리또는oscillatoryquadrature가필요하다.

[L4] Wang–Zhao, arXiv2110.15265: abstract의geometrictwo-scale,finite-timeuniform2및long-timenearconservation을구분하여확인. 특정Hamiltonian클래스의결과다.

[L5] LinaWang–BinWang–JiyongLi, DOI10.1137/25M1750986, online2026-01-02, MMS24(1)1–31: 공식abstract에서NLDEnonrelativisticregime의uniform4와MFEnearconservation을확인. 최신선행비교대상이지우리generalODE결과의증명은아니다.

새로움·우선권은주장하지않는다. 단순knowncarrier변환은이미잘알려진구조다. 우리의추가산출물은기존RVJ연구의후보/반례/오차계약과이변환을동일한testedreference로결속한것이다.

## 9. 통합 architecture에 대한 결정

계속할중심은일반분리 y'=A_d y+A_o y+N(y,q)에서각부분의증명가능한동작을구분하는것이다. A_d의감쇠에는잔여진폭과historyimpulse, A_o의진동에는carrier·phase·resonance, N에는nonlinearforcing과closuredefect를사용한다. Noncommuting/time-dependent경우는connection/commutator를원residual에포함해야한다.

Routing은eigenvalue한개가아니라다음을입력으로한다: physicalobservable, fixedmetric/semigroupbound, crediblecarrier/frequencyuncertainty, detuninginterval과resonancegraph, actualforcingderivativeorresidualbound, comparisonmargin, predictedtotalwork. Unknown혹은증명없는후보는abstain할수있다.

R23은dissipativeaction후보로유지한다. R33은oscillatory보조baseline이지만phasecertificate없는기본경로로승격하지않는다. Carrier가주어지고equivariance가증명되면amplitudecertificate경로를허용한다. Genericoscillatorynonlinearity에는Filon/Levin,modulatedFourier,two-scale/micro–macro또는phasefittedtrigonometric경로가더적합할수있다. 실제선정에는독립benchmark가필요하다.

## 10. 실패·미완료·다음실험

REDpolicy는neutraldefect와주파수uncertainty를0으로처리하고샘플만으로forcing을인증하던baseline3개실패다. 기존Vigilode버그가아니다. Newmodalcode의radius회계에서gain*E0의upwardrounding을localcharge에서누락한문제를test로잡아수정했다. Endpoint/오차를path와다른값으로바꿔도commit하던2개test도RED/GREEN으로수정했다. 이것은보안공격인증문제가아닌trustedprocess의accidentaldata-mixing검사다.

Symbolicchecker의4x1/4x4zero shape혼동,unsimplifiedmatrixequality실패는정리반례가아니라검사코드오류로분리했다. Wolfram추가호출의undefinedsymbol/infinity경고는성공에포함하지않고ClearAll과regularseries로cleanreplay했다.

최종externalreview는UNAVAILABLE/HOLD. Fulloriginalgeometrysuite는authenticmissinginput상태를유지하고재실행하지않았다. NativeRust/AD/JVP/Krylov,largePDE,state-dependentcarrier,noncommutingframe,generichighindexDAE,energy-preservingadaptiveimplementation는수행하지않았다. 과거전체suite를이번통과수에합하지않는다.

다음bounded연구는두carrier가정확히맞지않는non-equivariantmonomial을추가해finite/nearresonance를보존하고,entirephi/Filonmoments를currentactionresidual에연결하는것이다. 동시에[L1]derivative-freeUA와[L3]waveformFilon을baseline으로구현비용과달성오차를동시에비교해야한다. Fixedknowncarrier문제에서의작은step수만으로그비교를대신할수없다.
