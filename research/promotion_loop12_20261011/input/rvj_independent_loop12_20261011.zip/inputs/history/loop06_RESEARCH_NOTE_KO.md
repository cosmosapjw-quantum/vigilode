# RVJ 독립 연구 루프 6: 초기 fast 효과를 보존하는 causal feedback 인증

## 0. 결론과 적용 범위

2026-10-03. Vigilode 원격 저장소와 PR을 읽거나 수정하지 않은 독립 연구다. Loop5의 가장 작은 미완료 확장인 fast-to-slow feedback을 구현했다. 정확한 선형 primitive lift, whole-path residual과 integrated fast-path error의 결합, 두 slow candidate 및 두 fast action의 hybrid 선택을 사용한다. 추가 탐색에서는 시간밀도 오차예산과 유한 transient 오차예산을 분리했다.

지위: DERIVED / CONNECTED_CAS_CHECKED / EXACT_RATIONAL_REFERENCE_VERIFIED / NUMERICALLY_CHECKED. 독립 최종 심사자는 없으며 HOLD / INDEPENDENT_REVIEW_UNAVAILABLE을 유지한다. Generic raw-coordinate RVJ5의 이전 반례, approximate-W 불안정성, embedded-only 추정기의 한계를 철회하지 않는다. 이번 구현은 full-system RVJ tableau가 아니라 scalar RVJ filter를 사용하는 새로운 partitioned lifted reference map이다.

모든 실행은 exploratory다. 초기 계약은 RESEARCH_CONTRACT.md에, reserve 정책의 추가 사전 기록은 evidence/EVIDENCE_LOG.jsonl에 있다. 기존 time-density 결과를 reserve 결과로 덮어쓰지 않았다. 관련 unit tests는 회귀 증거이지 독립 과학심사나 속도 측정이 아니다.

## 1. 선행 루프 및 계산기하 원문과의 연결

Loop5에서는 x'=sigma sqrt(1+x)-x와 두 fast modes가 chart에서 분리되어 있었다. 따라서 fast endpoint certificate가 slow dynamics에 영향을 주지 않았다. 이번에는 x'에 alpha*w1을 넣는다. General vector closure, time-dependent fast frame, fast-to-slow와 slow-to-fast 양방향 결합 전체를 구현했다고 말하지 않는다.

첨부 curved-mirror v12의 witnessed correspondence, finite covering, support collision과 projection singularity 구별을 유지한다. 이번 q^2=1+x의 witness는 고정 부호 sigma이고, x=-1의 실제 branch singularity를 넘지 않는다. 새 lift의 분모 det(A)=kappa^2*rho는 fast split의 정칙성 조건이며, 이를 물리 root가 소멸하는 event와 동일시하지 않는다. rho=1의 fast eigenvalue collision에서도 block representation과 lift는 정칙하다. 원문이 이번 적분기나 오차정리를 증명하는 것은 아니다.

원본 PR11 전체 재현은 missing input으로 인해 선행 루프에서 BLOCKED였다. 이번에는 새로운 원본이 제공되지 않았으므로 누락 자료를 추측 생성하거나 전체 source suite를 재시도하지 않았다. 보존된 inputs/loop5 및 원 source identity는 별도로 확인했다.

SciSpace에서 logarithmic-norm DAE stability, partitioned linearly implicit integration, waveform relaxation, defect a posteriori estimation을 검색했다. Higueras–Söderlind의 2002년 논문은 Lund University의 저자 소속기관 기록/abstract에서 Dini derivative와 perturbation bound의 맥락을 확인했다. Springer 본문 요청은 robots/cache 오류로 실패했다. QDeC 자료의 'asymptotically correct estimator'를 rigorous enclosure의 증명으로 사용하지 않았다. 아래 정리는 직접 유도하며 novelty를 주장하지 않는다. 상세 조회 범위는 LITERATURE.json에 있다.

## 2. 모델, 단위, 초기조건

이 구현의 시간과 모든 변수는 무차원 benchmark convention이다. 원래 물리 단위에서는 kappa가 역시간, C가 x/(w*time), L=C A^{-1}가 x/w의 단위를 갖는다. 일반화 시 각 norm의 상태 scale과 출력 단위를 다시 정의해야 한다.

    x' = F_sigma(x) + alpha*w1,
    F_sigma(x) = sigma*sqrt(1+x) - x,
    q^2 = 1+x, q의 부호=sigma in {-1,+1},
    w' = A w,
    A = kappa [[-1,beta],[0,-rho]], rho in {1,2}, kappa>=1.

x(0)=0, w(0)=w0, 0<T<=1/4이다. alpha와 beta는 고정된 실수다. 물리 출력은

    y1 = w1 + x^2/kappa,
    y2 = w2 + x^3/kappa.

D=[-1/2,1]에서 F'_sigma<=-1/4, |F'_sigma|<=7/4이다. 두 불등식은 실제 root 크기>=sqrt(1/2)>2/3로부터 따른다. 이하 L_F=7/4, q_min=2/3을 사용한다. Fast block이 slow에 영향을 주지만 fast 방정식은 x에 의존하지 않는다. 일반 양방향 결합은 절 10의 조건부 정리까지만 진행했다.

## 3. Endpoint error가 feedback error를 제어하지 못한다

후보 fast 경로의 시작/끝이 정확해도 시간적분 오차는 0일 필요가 없다. w_exact=0, w_candidate=6s(1-s), s in [0,1]이면 양 끝 차이는 0이고 적분 차이는 1이다. x'=alpha*w의 slow forcing 오차는 |alpha|이다. 후보가 fast ODE를 만족하지 않는다는 사실이 바로 whole-path defect 검사를 필요로 한다. 이는 기존 Loop5 fast operator의 결함으로 보고하는 것이 아니라 endpoint-only 일반화의 반례다.

실제 강직 초기층에서도 동일한 문제가 발생한다.

    x'=alpha*w, w'=-kappa*w, x0=0, w0=1
    x(h)=alpha(1-exp(-kappa*h))/kappa.

Fast endpoint가 극도로 작아도 slow displacement는 O(kappa^-1)로 남는다. w를 작다는 이유로 없애면서 x0를 그대로 사용하는 근사는 이 효과를 버린다. 실제 nonlinear benchmark의 kappa=10^6에서도 alpha*w1를 처음부터 삭제한 control과의 T=1/4 차이가 약 8.7659321e-7로 남았으며 이는 eps=1e-8을 넘는다. 이 값은 독립 고정밀 numerical oracle 결과이고, 위 선형 식은 정확 반례다.

## 4. 정확한 primitive lift

C=(alpha,0), ell=C A^{-1}로 두면

    ell=(-alpha/kappa,-alpha*beta/(kappa*rho)),
    ell A=C.

따라서

    z=x-ell*w,  x=z+ell*w,
    z'=F_sigma(z+ell*w),  w'=A w.

변환의 Jacobian determinant는 1이다. 초기값은 z0=x0-ell*w0이어야 한다. 이는 물리 초기조건을 바꾸는 reset이 아니라 정확한 좌표변환이다. z0를 0으로 재설정하면 초기 fast 효과를 다시 잃는다. Generic state-dependent A나 ell(t)에는 -ell'(t)w가 추가되므로 이 식을 그대로 쓰면 안 된다.

고정 weighted infinity norm을

    d=max(1,|beta|), ||w||_d=max(|w1|/d,|w2|)

로 두고 dual row norm을

    Lambda=||ell||_{d,*}=|ell1|d+|ell2|

로 둔다. d와 Lambda를 물리 오차 환산에 명시적으로 유지한다. determinant가 1이라는 사실만으로 좋은 conditioning을 주장하지 않는다.

두 fast family에서

    ||exp(sA)||_d <= g_k(s)=(1+kappa*s)exp(-kappa*s) <=1,
    J_k(h):=integral_0^h g_k(s) ds
       =[2-(2+kappa*h)exp(-kappa*h)]/kappa
       <= min(h,2/kappa).

rho=1에서는 exp(sA)=exp(-kappa*s)[[1,beta*kappa*s],[0,1]]이다. rho=2의 off-diagonal은 beta(exp(-kappa*s)-exp(-2kappa*s))이고 1-exp(-a)<=a를 쓰면 동일한 상계가 나온다.

### 중앙 transient의 직접 경계

정확한 현재 중앙 fast 값 w=(u,v)에 대해

    S0=|alpha|/kappa (|u|+|beta||v|)

는 sup_s |ell exp(sA)w|의 상계다. 또한

    I0 <= min(h*S0, |alpha|/kappa^2 (|u|+c_rho |beta||v|)),
    c_1=2, c_2=1.

rho=1에서 ell exp(sA)w=-alpha/kappa exp(-kappa*s)[u+beta(1+kappa*s)v]를 적분하면 된다. rho=2에서는 beta(exp(-a)-exp(-2a)/2)를 이용한다. O(kappa^-1) physical impulse를 좌표에 보존하고 나면, slow vector field에서 생략하는 잔여 transient는 적분상 O(kappa^-2)로 제어된다.

## 5. 임의 fast path 후보와 slow/closure의 동시 인증

현재 accepted state가 (zhat,what,Ez,Ew,sigma)라고 하자. Exact initial fast state는 ||w_n-what||_d<=Ew를 만족한다. p(theta)는 z 후보, v(theta)는 fast 경로 후보, r(theta)는 closure 후보이고 theta=s/h이다. 정의한다.

    xi=p+ell*v,
    differential defect d_f=p'/h+xi-r,
    algebraic defect d_g=r^2-1-xi.

Bernstein hull로 Df>=sup|d_f|, Dg>=sup|d_g| 및 m<=inf sigma*r를 계산한다. m>=q_min이면

    |r-q_sigma(xi)| <= Dg/(m+q_min),
    Delta=Df+Dg/(m+q_min).

중앙 fast path의 projected discrepancy를

    S_v >= sup_s |ell(exp(sA)what-v(s/h))|,
    I_v >= integral_0^h |ell(exp(sA)what-v(s/h))| ds

로 감싼다. Inherited fast error의 해당 상계는 각각 Lambda*Ew, Lambda*Ew*J_k(h)다.

다음 양을 만든다.

    B_z=Ez+h*Delta+L_F[I_v+Lambda*Ew*J_k(h)],
    B_x=B_z+S_v+Lambda*Ew.

xi의 Bernstein range가 [xi_min,xi_max]일 때

    [xi_min-B_x,xi_max+B_x] strictly inside (-1/2,1)

이면 전체 step의 실제 x,z,q 경로가 인증된다.

### 증명

p+ell*w_exact는 xi로부터 최대 S_v+Lambda*Ew만큼 떨어져 있으므로 guard 안에서 D에 있다. Exact x가 D 안에 있는 최대 구간에서

    z'-p'=F_sigma(z+ell*w)-F_sigma(p+ell*w)
             +F_sigma(p+ell*w)-p'

로 분해한다. 첫 항은 z-p에 대해 one-sided derivative<=-1/4이고, 둘째 항은 Delta+L_F|ell(w-v)|로 감싸진다. Dini/Gronwall 비교에서 감쇠를 버리는 안전한 상계를 사용하면 |z-p|<=B_z다. 따라서 |x-xi|<=B_x이다. Strict guard는 exact x가 첫 exit 시각에서 D 경계에 도달한다는 가정과 모순된다. Fast linear solution은 전 시간 존재하고, compact regular closure에서 slow solution의 continuation이 가능하므로 전체 step을 닫는다. 정확한 해가 이미 tube 안이라고 가정하는 순환 논증이 아니다.

같은 부호의 root에 대해

    |q_sigma(x)-r| <= (Dg+B_x)/(m+q_min).

이는 endpoint Newton residual이나 root sorting으로 witness를 승인하는 방식이 아니다.

Endpoint roundoff를 포함한 recurrence는

    Ez+ <= Ez+L_F Lambda Ew J_k(h) + ell_z,
    ell_z=h*Delta+L_F I_v+rho_z,
    Ew+ <= G_k(h) Ew+ell_w,

이다. 여기서 G_k(h)>=||exp(hA)||_d이고 <=1이다. Reference는 G<=min(1,(1+a)/sum_{j=0}^6 a^j/j!)를 사용한다. Fast numerical R(hA)의 contractivity가 아니라 exact semigroup과 중앙 action error를 분리한다.

## 6. 실제 두 slow 후보

### RESOLVED_JET

v_m(s)=sum_{j=0}^m s^j A^j what/j!, m=5를 사용한다. Variation-of-constants의 Taylor remainder와 exact semigroup의 비팽창성에서

    S_v <= Lambda ||A^(m+1)what||_d h^(m+1)/(m+1)!,
    I_v <= Lambda ||A^(m+1)what||_d h^(m+2)/(m+2)!

가 따른다. 이를 scalar endpoint filter bound로 대체하지 않는다.

v의 현재 jets와 q^2=1+x를 사용해

    x_j=z_j+ell*w_j,
    z_(j+1)=(q_j-x_j)/(j+1),
    q_j=(x_j-sum_{i=1}^{j-1}q_i q_(j-i))/(2q0)

를 계산한다. Seed q0는 sqrt interval의 signed midpoint이며, seed 불일치도 algebraic defect에 남는다.

p(theta)=sum_{j=0}^5 z_j(h theta)^j + c theta^6으로 두고

    c=120 h^5 z5 [phi5^R(hW)-1/120],
    W=-1+1/(2q0)

를 사용한다. 이것은 scalar frozen-W RVJ filter를 붙인 partitioned candidate다. Full autonomous (z,w) 시스템에 대한 원래 RVJ 공식과 같다고 주장하지 않는다. 고정된 kappa에서 작은 h의 classical consistency는 유지되지만, 본 결과의 중심은 사후오차 certificate이지 generic uniform-order 주장도 아니다.

### LIFTED_OUTER

v=0으로 두고 같은 scalar RVJ 후보를 z'=F_sigma(z)에 대해 만든다. 생략된 ell*w의 nonlinear 효과를 4절의 S0,I0로 완전히 계상한다. z0는 정확한 lift 초기값을 보존한다. Candidate의 shifted base가 정칙 root domain 밖이면 root를 평가하지 않고 이 후보를 거절하며 RESOLVED_JET을 시도한다. p가 아니라 xi 및 exact shifted reference의 whole-tube guard를 확인한다.

두 후보는 과거 accepted snapshot에서만 생성된다. Slow 후보는 fast endpoint solve를 기다릴 필요가 없다. 다만 이 dependency 사실을 parallel speedup으로 보고하지 않는다. RESOLVED_JET에는 6회의 2-mode A action과 implicit jet의 차수 의존성이 남는다.

## 7. Fast action, 물리 오차 및 causal 합성

Fast endpoint에는 Loop5의 검증된 two-mode rational gap bound와 EXP_ENCLOSURE fallback을 그대로 재사용한다. Current A의 정확한 계수에 관한 결과이며 arbitrary stale W를 대체하는 것이 아니다. Endpoint choose_fast와 slow path v는 다른 객체다. Fast endpoint가 정확해도 slow path error I_v가 자동으로 작아지지 않는다.

현재 numerical x의 중앙값은 zhat+ell*what이다. Stored x와의 rounding을 rho_x라 하면

    Ex=Ez+Lambda*Ew+rho_x.

물리 출력의 상계는

    B1=d*Ew+(2|xhat|Ex+Ex^2)/kappa+rho_y1,
    B2=Ew+(3|xhat|^2 Ex+3|xhat|Ex^2+Ex^3)/kappa+rho_y2.

여기서 각 rho는 정확한 중앙 재구성과 저장값의 차이다. Reference는 Ex,B1,B2<=eps를 모두 요구한다.

Time-density 정책은 ez_budget=eps/16과

    ew_budget=eps/[64 d (1+(1+L_F*T)Lambda)]

를 사용한다. ell_z<=ez_budget*h/T, ell_w<=ew_budget*h/T를 요구하면 Ez<=Ez0+ez_budget+L_F Lambda T ew_budget, Ew<=ew_budget다. Initial lift rounding과 physical reconstruction은 별도 guard에 남는다. 조건부 accepted-error 보장이며 고정 precision에서의 종료나 kappa와 무관한 step count를 증명하지 않는다.

Immutable snapshot에는 시간, z,w,누적 radius,branch,model/epoch,generation이 들어간다. Commit은 같은 input digest와 generation을 요구한다. 실패한 trial은 snapshot을 수정하지 않으며 계산한 후보/인증/실패 비용은 counts에 남는다. 이는 trusted execution의 provenance 계약이며 위조된 외부 certificate의 보안 인증은 아니다.

## 8. 추가 탐색: 유한 transient 예산과 시간밀도 예산을 분리

큰 kappa의 전체 transient 잔여오차는 O(kappa^-2)인데, 매번 ell_z<=const*h를 강제하면 h를 줄일수록 허용 예산도 줄어 불필요한 초기 microstep을 만들 수 있다. 기존 physical tolerance를 완화하지 않고 error budget의 사용 방식을 바꾸었다.

    ell_z = ell_density + ell_transient,
    ell_density=h*Delta+stored/upper-rounding,
    ell_transient=L_F I_v.

총 ez_budget의 1/4는 시간에 비례해 배분하고 3/4는 누적 transient reserve로 둔다.

    ell_density,n <= (ez_budget/4) h_n/T,
    spent_n + ell_transient,n <= 3 ez_budget/4.

spent는 accepted commit 때만 증가하고, rejected trial에서는 보존된다. 따라서 임의 accepted mesh에 대해 sum ell_z<=ez_budget다. Inherited fast error가 slow로 들어오는 L_F Lambda Ew J 항은 이 reserve에 숨기지 않고 recurrence에 그대로 남긴다.

이 추가 실험은 초기 결과를 본 뒤 별도로 exploratory 등록했다. reserve 정책은 선택 가능한 옵션이며 기본 time-density 결과를 교체하지 않는다. 느슨한 epsilon에서는 smooth budget을 줄인 탓에 오히려 steps가 증가했다. Online split 최적화나 speed advantage를 증명하지 않았다.

## 9. 실제 결과와 oracle 구분

Certificate arithmetic: exact Fraction + outward dyadic arithmetic. 핵심 source는 code/feedback.py이고 그 안에는 mpmath/scipy import가 없다. sqrt/current-model jets, Bernstein bounds와 scalar analytic fast-block formulas는 명시적으로 사용한다. AD/Krylov/native parallel runtime는 구현하지 않았다.

Audit oracle: physical x ODE를 fast time tau=kappa*t에서 mpmath 65자리로 적분한다. tau=96 뒤에는 forcing tail을 생략하지만 그 누락량을

    |alpha|/kappa exp(-96) [|u0|+|beta*v0|(96+1)]

로 별도 상계한다. Scalar slow log norm이 음수이므로 이 bound를 이후에도 사용할 수 있다. 이 tail은 certificate가 아니라 별도 oracle의 오차 계정이다. 대표 kappa=10^6를 80자리, tau=112까지 다시 계산해 x(T) 차이 1.7271e-46을 얻었으며 65자리 tail bound 1.9702e-46 안이다. Numerical oracle 자체에 대한 formal validated-ODE theorem은 아니다. Interior diagnostic 비교에서 1e-58 numerical allowance를 사용하고 endpoint 물리 비교에는 analytical oracle tail을 더한다. Continuum certificate는 sampling이 아니라 5절 proof와 exact Bernstein 계산에 근거한다.

Main exploratory matrix 12 cases: kappa=1,40,10^4,10^6; rate1/2; beta=4,-4,20; alpha=1/4,-1/4,0,1/20; branch +/-; zero/nonzero/mixed-sign fast states. T=1/4, eps=1e-8. 총 392 accepted steps와 1960 interior diagnostic points를 계산했다. 모두 물리 및 path bounds 안에 들어갔다. 숫자는 물리모델 성공률이나 독립검사 수로 합치지 않는다.

Representative beta4,alpha1/4,rate1,branch+,w0=(0,1):

| kappa | accepted | resolved slow | outer slow | RVJ fast | EXP fast | max x error |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 8 | 8 | 0 | 8 | 0 | 6.8610e-11 |
| 40 | 63 | 63 | 0 | 0 | 63 | 1.5728e-11 |
| 10000 | 48 | 29 | 19 | 14 | 34 | 1.8691e-11 |
| 1000000 | 8 | 0 | 8 | 7 | 1 | 5.0939e-11 |

kappa=10^6, eps=1e-10에서는 time-density 정책은 73 steps, 최소 h=1/4194304와 28 resolved candidates를 사용했다. split reserve는 32 outer steps, 최소 h=1/128을 사용하고 transient charge 3.5e-12를 누적 지불했다. 실제 max x errors는 각각 4.4631e-14,9.9870e-13으로 모두 같은 tolerance 안이다. eps=1e-6에서는 steps가 4->8, eps=1e-8에서는 8->16으로 증가한다. 더 적은 steps가 wall-clock 개선을 뜻하지 않는다.

Nonuniform cap study 4 cases 중 3개는 실제 비균일 mesh를 사용했고 1개(split reserve,kappa=10^6)는 guard/controller 때문에 균일 1/64가 선택됐다. 이 한 case를 비균일 mesh 검증으로 집계하지 않는다. 총 6개의 tolerance/policy 결과와 4개의 cap study 결과를 별도로 보존했다.

새 tests 33개, symbolic checks 15개, inherited Loop5 code tests 28개를 실행했다. Parent의 과거 14개 adaptive campaign이나 원래 RVJ 반례 전체를 이번에 재실행했다고 주장하지 않는다. Endpoint-feedback negative, omitted-memory negative, reserve double-spending negative, stale epoch/commit, whole-path tampering이 이번의 직접 검사 대상이다.

## 10. 제한적인 추가 정리: 양방향 feedback의 작은 이득 조건

실제 bidirectional solver는 아직 없지만 다음 sufficient error-tube algebra를 유도하고 helper로 구현했다. 어떤 regular tube에서

    D+ ex <= -a ex + c ew + df,
    D+ ew <= d ex - b ew + dg,

a,b>0, c,d>=0를 증명할 수 있다고 하자. pa>=psi_a(h), pb>=psi_b(h), psi_a=(1-exp(-ah))/a이고 reference는 pa=min(h,1/a),pb=min(h,1/b)를 쓴다. Bx=ex0+pa*df, Bw=ew0+pb*dg라고 두면

    X<=Bx+c pa W,  W<=Bw+d pb X.

Gamma=c*d*pa*pb<1이면

    X_bound=(Bx+c pa Bw)/(1-Gamma),
    W_bound=(Bw+d pb Bx)/(1-Gamma)

가 양의 해다. 이 radius가 실제 모델의 strict tube 안에 들어가는지 별도 검증하면 first-exit argument에 사용할 수 있다. Gamma>=1은 이 sufficient test가 실패했다는 뜻이지 곧 실제 해의 불안정성이나 해 부재의 증명은 아니다. 부호를 버려 느슨해진 comparison일 수 있다. 현재 helper는 이 2x2 algebra만 검사하며 actual two-way trajectory를 생성하지 않는다.

## 11. Inexact lift와 moving frame의 정확한 잔차

어떤 근사 row ell_hat을 사용해도 z=x-ell_hat*w는 정칙 shear다. 그러나

    r_ell=C-ell_hat*A,
    z'=F_sigma(z+ell_hat*w)+r_ell*w

가 되므로 r_ell*w를 반드시 포함하거나 그 integral을 charge해야 한다. Current A에서 계산한 residual norm으로

    extra <= ||r_ell||_{d,*}(||what||_d+Ew) J_k(h)

라는 sufficient term을 얻는다. 이 helper를 exact lift와 1% 잘못된 row에 대해 검사했으며, full approximate-lift client에는 통합하지 않았다. 이는 stale W로 적분공식을 조용히 바꾸는 것과 다르다.

ell이 시간에 의존하면 -ell'(t)w, w'=Aw+g(x)이면 -ell*g(x)가 transformed slow 식에 추가된다. 두 항 모두 연결 Wolfram으로 검산했다. State-dependent frame이나 generic inexact current-J action의 구현은 남은 과제다.

## 12. 실패, 재현 및 종료 판정

- Endpoint-only feedback negative baseline의 두 test는 의도대로 RED였고 integrated-path charge로 수정 후 GREEN이다. 이를 기존 Vigilode의 버그로 보고하지 않는다.
- Case2+3의 고정 45초 도구 호출이 case2 완료 후 case3 oracle에서 timeout됐다. 남은 프로세스가 없음을 확인하고 case3을 따로 실행했다. 이후 3+4 job은 exit0이다.
- Background shell 접수의 transport timeout에서는 이미 시작한 동일 프로세스를 관찰하여 exit0까지 확인했고 중복 dispatch하지 않았다.
- Springer primary-page fetch robots/cache 실패를 문헌 미확보로 기록했다. 관련 institution abstract만 근거로 사용했다.
- Split reserve는 eps가 느슨한 두 case에서 steps가 늘었다. 이를 개선으로 숨기지 않고 정책 tradeoff로 남겼다.

모든 장기 job은 이번 응답 안에서 종료 상태를 확인했다. Source/harness hashes와 code/proof/evidence manifest를 보존한다. 독립 decision reviewer가 없으므로 전체 방법의 PROMOTE는 하지 않는다. 다음 우선순위는 actual bidirectional feedback에서 tube-comparison 계수를 계산하고, 이번 inexact lift residual을 current-operator action에 연결하는 것이다. 충분한 조건을 쓸 수 없는 모델은 unsupported로 남겨야 한다.
