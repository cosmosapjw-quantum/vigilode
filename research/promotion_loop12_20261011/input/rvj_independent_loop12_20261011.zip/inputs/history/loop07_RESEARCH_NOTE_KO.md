# RVJ 독립 연구 루프 7: 실제 양방향 feedback과 불변 오차 box

## 0. 결과와 경계

2026-10-03. Vigilode의 로컬 native 검증과 분리된 연구다. 이번에는 실제 slow-to-fast 강제항을 포함하는 양방향 모델을 적분하고, 원래 differential/algebraic residual에서 물리 오차를 인증했다. 시간적분한 residual을 누적하는 기준 정책과, feedback을 포함한 감쇠를 이용하는 불변 오차-box 정책을 모두 보존했다. 후자는 큰 강직도에서 step 수를 줄였지만 작은 강직도에서는 증가시켰다. Taylor 우선 정책도 실제로 두 모드를 사용했으나 더 비쌌다.

지위는 DERIVED / CONNECTED_CAS_CHECKED / EXACT_RATIONAL_REFERENCE_VERIFIED / NUMERICALLY_CHECKED다. 독립 최종 reviewer와 formal proof assistant는 없으므로 방법 승격은 HOLD다. 모든 실행은 exploratory이며 E06 불변-box 확장은 초기 비용 결과를 본 뒤 별도로 기록했다. 초기 RESEARCH_CONTRACT.md를 소급 변경하지 않았다.

범용 raw-coordinate RVJ5의 선행 반례, approximate-W의 불안정성, embedded-only의 한계는 철회하지 않는다. 새로운 것은 기존 raw RVJ의 보편성 회복이 아니라, 원래 방정식에 대한 별도의 검증 조건 아래 실제 양방향 모델을 수락하는 경로다. 고정 차수의 연속 다항식 검증 때문에 강직 초기층을 해상해야 하는 비용 제한도 증명한다. 실행 가능한 큰 행렬 AD/Krylov, Rust, 병렬 speedup은 수행하지 않았다. Vigilode의 원격/로컬 저장소나 PR을 읽거나 변경하지 않았다.

## 1. 선행 연구, 계산기하 원문 및 외부 문헌

Loop6는 x'=F(x)+Cw, w'=Aw의 단방향 forcing을 구현하고, 양방향 오차의 2x2 작은-이득 helper만 제공했다. 이번에는 helper만 재실행한 것이 아니라 실제 양방향 trajectory, 두 후보, whole-path certificate와 adaptive commit까지 구현했다.

보존된 curved-mirror v12의 01_diagram_transport.tex, 03_fold_surgery.tex, 05_compact_source.tex를 다시 읽었다. Witness covering과 target support의 구별, 정칙 chamber 안의 path lifting, 실제 projection fold와 표현상의 singularity 구별을 유지한다. 본 모델의 closure는 q^2=1+x이며 x=-1에서 discriminant가 0이다. q의 부호와 전체 x-tube를 검사하며 root sorting이나 branch jump는 하지 않는다. rho=1은 fast eigenvalue collision이지만 block matrix나 primitive shear의 singularity가 아니다. 원문의 diagram 또는 connection이 ODE norm과 같다는 주장은 하지 않는다. 원문 전체 PR11 suite는 authentic missing input 문제를 그대로 보존했고 재실행하지 않았다.

SciSpace로 multirate Exponential Rosenbrock, rational Krylov와 stiffness-resilient exponential 방법을 발견했다. 별도 웹으로 다음 원전을 확인했다.
* Higueras–Söderlind (2002), logarithmic norms and nonlinear DAE stability: 저자 소속기관 abstract. Dini derivative/perturbation inequality라는 맥락만 사용한다.
* Jawecki–Auzinger–Koch (2020): 공식 HTML에서 nonexpansivity의 logarithmic-norm 가정과 defect의 variation-of-constants 표현을 확인했다. 특히 shift-and-invert에는 기존 경계를 곧바로 상속할 수 없다는 원문 제한을 유지한다.
* Aptekarev 등 (2014), arXiv:1405.0167: 원 논문 abstract에 명시된 고전적 Markov inequality를 8절의 직접 유도에 사용한다. 원 논문의 L2/Jacobi asymptotic 결과를 사용하지 않는다.
* Luan–Chinomona–Reynolds, arXiv:2106.05385v2: abstract의 modified fast IVP/phi-action 구성을 다음 exponential-path 후보의 문헌상 선행 맥락으로 둔다. 본문 차수 정리는 이번 RVJ에 적용하지 않는다.
* Göckler–Grimm (2014), DOI 10.1137/140964655: 공식 abstract의 field-of-values 가정 및 simple-pole parallel rational Krylov를 후속 후보로 기록한다. 실제 구현/효율성은 미검증이다.

문헌 조회는 novelty 또는 이번 reference correctness의 증명이 아니다. 식별자와 읽은 범위는 LITERATURE.json에 있다.

## 2. 실제 양방향 모델

시간과 상태는 무차원 benchmark convention이다. 차원을 복원할 때 kappa는 역시간, alpha와 eta는 상태 scale의 변환을 포함하고, below weighted norm은 정해진 상태 단위에서 해석해야 한다.

    x' = q - x + alpha u,
    q^2 = 1+x, sign(q)=sigma in {-1,+1},
    u' = kappa(-u+beta v),
    v' = kappa(eta x-rho v).

kappa>=1, rho in {1,2}, 0<T<=1/4, x0=0이다. u0,v0는 유한한 값이며 zero/nonzero/mixed-sign을 검사했다. 기본값은 alpha=eta=1/16, beta=4다. Return forcing kappa*eta*x가 강직도와 함께 커지므로 kappa가 증가할 때 사라지는 weak feedback만을 조사한 것이 아니다.

물리 출력은 x, y1=u+x^2/kappa, y2=v+x^3/kappa다. 이 출력 map의 Jacobian determinant는 1이다. 단, determinant만으로 global conditioning을 주장하지 않는다.

정칙 x 영역 D=(-1/2,1), q_min=2/3을 사용한다. 정확한 signed branch F_sigma(x)=sigma sqrt(1+x)-x는 D에서 F'_sigma<=-a, a=1/4를 만족한다.

### 단방향 primitive lift를 그대로 옮기면 틀린다

A=kappa[[-1,beta],[0,-rho]], C=(alpha,0), ell=C A^-1이면

    ell=(-alpha/kappa,-alpha beta/(kappa rho)), ell A=C.

하지만 지금은 w'=Aw+(0,kappa eta x)므로 z=x-ell w에 대해

    z'=F_sigma(x)+(alpha beta eta/rho)x.

추가항은 kappa에 따라 사라지지 않는다. 실제 fast equilibrium은 v*=eta x/rho, u*=beta eta x/rho이므로 같은 feedback이 남는다. 기본 rho=1에서는 x/64다. 이 identity를 Wolfram과 SymPy에서 검산했다. Main reference는 이전 one-way solver를 사용하지 않고 원래 3변수 방정식을 직접 적분한다.

## 3. 실제 feedback의 비교행렬과 고정 norm

    d=max(1,2|beta|), ||w||_d=max(|u|/d,|v|),
    b=min(1-|beta|/d,rho), c=|alpha|d.

Fast block의 해당 logarithmic norm은 -kappa*b 이하이고 b>=1/2다. 두 trajectory 또는 trajectory와 연속 후보의 차이는 정칙 tube 안에서

    D+ e_x <= -a e_x+c e_w+Delta_x,
    D+ e_w <= kappa|eta| e_x-kappa b e_w+Delta_w

를 만족한다. 따라서 M=[[-a,c],[kappa|eta|,-kappa b]]는 Metzler comparison matrix다.

고정 s>0가 a-cs>0, b-|eta|/s>0를 만족하면

    ||(x,u,v)||_* = max(|x|,|u|/(d s),|v|/s)

에서 exact reduced flow는 적어도

    nu=min(a-cs,kappa(b-|eta|/s))

의 수축률을 갖는다. 기본 s=1/4,d=8에서는 M(1,s)^T=(-1/8,-kappa/16)^T이고 nu=1/8로 모든 kappa>=1에서 유계다. 실제 physical norm 변환에 d와 s를 다시 포함한다.

General parameter admission은 c|eta|<ab일 때 가능한 s의 구간 |eta|/b<s<a/c를 제공한다(0 coupling은 별도 해석). 현재 구현은 caller-supplied 고정 s를 검증하며 이를 online 최적화하지 않는다. 안정성 parameter 조건, 정칙 root 조건, 예산 조건은 별개의 계약이다.

작은-이득 radius도 실제 모델에서 계산한다. p_a=min(h,1/a), p_b=min(h,1/(kappa b)), Gamma=c kappa|eta| p_a p_b<1이면

    Bx=e_x0+p_a Delta_x, Bw=e_w0+p_b Delta_w,
    X=(Bx+c p_a Bw)/(1-Gamma),
    W=(Bw+kappa|eta|p_b Bx)/(1-Gamma).

기본계수에서는 Gamma<=1/4가 모든 h에 대해 성립한다. Reference는 이를 보조 진단으로 계산하지만 주 certificate는 다음 고정 norm/tube를 사용한다.

이 충분조건이 실패했다고 물리적 불안정성을 결론내리지 않는다. 실제 행렬 [[-1,2],[-2,-1]]는 eigenvalues -1±2i로 안정하지만 절댓값 비교행렬 [[-1,2],[2,-1]]에는 eigenvalue +1이 있다. Cancellation을 버리는 비교는 보수적일 수 있다.

## 4. Full RVJ와 Taylor 후보의 동일한 원방정식 residual

현재 x에 대해 certified signed sqrt interval의 midpoint q0를 만들고 5차까지 formal coefficient를 계산한다.

    x_(j+1)=(q_j-x_j+alpha u_j)/(j+1),
    u_(j+1)=kappa(-u_j+beta v_j)/(j+1),
    v_(j+1)=kappa(eta x_j-rho v_j)/(j+1),
    q_j=(x_j-sum_{i=1}^{j-1}q_i q_(j-i))/(2q0).

이는 exact-rational reference의 차수별 recursion이다. High-order AD backend가 아니고, 2q0 inverse 또는 5개 차수의 sequential dependency를 없애지도 않는다. Approximate q0의 seed inconsistency는 algebraic residual에 남긴다.

Current seed Jacobian은

    J=[[-1+1/(2q0), alpha, 0],
       [0,-kappa,kappa beta],
       [kappa eta,0,-kappa rho]].

이전의 scalar partitioned lift와 달리 이번 RVJ candidate는 full 3x3 rational action을 사용한다. Q(Z)=I-3Z/5+3Z^2/20-Z^3/60, phi5^R(Z)=Q(Z)^-1(Z^2-5Z+12I)/1440라 하면

    p(theta)=sum_{j=0}^5 a_j(h theta)^j
             + h^5(120 phi5^R(hJ)-I)a5 theta^6.

따라서 p(1)은 compact RVJ endpoint, 시작점의 5차 jet은 유지한다. Small exact 3x3 solve 하나를 사용하며 explicit Jacobian/storage-free라고 주장하지 않는다. Taylor candidate는 같은 jet에서 마지막 theta^6 correction만 빼고, solve 없이 만든다. 두 후보는 동일한 certificate를 통과해야 한다.

q 경로를 r(theta)라 하고

    d1=p_x'/h+p_x-r-alpha p_u,
    d2=p_u'/h+kappa p_u-kappa beta p_v,
    d3=p_v'/h+kappa rho p_v-kappa eta p_x,
    g=r^2-1-p_x

를 계산한다. Exact Bernstein coefficients로 전체 theta∈[0,1]에서 각 다항식의 supremum, range와 signed root margin m=inf sigma*r>=q_min을 감싼다. Sampling maximum을 certificate로 사용하지 않는다.

    Delta_x=sup|d1|+sup|g|/(m+q_min),
    Delta_w=max(sup|d2|/d,sup|d3|),
    delta=max(Delta_x,Delta_w/s).

같은 branch에서 |r-q_sigma(p_x)|=|g|/|r+q_sigma(p_x)|이므로 이 Delta는 실제 원방정식 reduced residual을 감싼다. Return forcing을 누락하는 잘못된 d3는 새 regression에서 실패했으며 최소한의 올바른 residual 식으로 수정했다. 이것은 연구용 음성 대조이지 Vigilode의 결함을 새로 보고한 것이 아니다.

## 5. 두 오차 공급원: 누적 시간밀도와 불변 box

### 5.1 기본 DENSITY 정책

현재 exact solution과 저장 상태 사이의 fixed-norm bound가 E0라고 하자. 정칙 영역 안에서는 D+E<=-nu E+delta이므로 E(s)<=E0+s delta다. p_x의 Bernstein range에 대해

    [p_min-E0-h delta, p_max+E0+h delta] strictly inside D

를 검사하면 first-exit contradiction으로 전체 exact path가 D에 남는다. 즉 정확한 해가 미리 tube에 있다는 순환 가정을 사용하지 않는다.

Stored endpoint rounding r_store를 같은 norm으로 계산하고 upward dyadic inflation까지 local charge에 포함한다.

    local=up(h delta+r_store), Enew=E0+local.

R=eps/[4 max(1,d s+2,s+3)]로 두고 local<=R h/T를 요구한다. Initial E0=0이면 arbitrary accepted positive mesh, sum h=T에서 E_n<=R가 따른다.

### 5.2 새 INVARIANT 정책의 정리

고정 방향 v=(1,s)^T에서 a-cs>0, kappa(bs-|eta|)>0라고 하자. 정의한다.

    Zstar=max(Delta_x/(a-cs),
              Delta_w/[kappa(bs-|eta|)]),
    Z=max(E0,Zstar).

그러면

    M (Z,sZ)^T+(Delta_x,Delta_w)^T <= 0.

이는 비교계의 constant supersolution이다. Metzler positivity 또는 최초 접촉 논증에 의해 초기 오차가 (Z,sZ) box에 들어 있으면 전체 step에서도 그 box를 벗어날 수 없다. 각 경계면에서 증가방향 derivative가 양수가 될 수 없기 때문이다. p_x range±Z가 D의 내부라는 strict guard를 함께 검사하면 실제 nonlinear/closure 경로의 first-exit가 불가능하다.

따라서

    sup_step ||Y_exact-p||_* <= Z,
    Enew=up(Z+r_store).

Root whole-path error는 (sup|g|+Z)/(m+q_min) 이하이다. Implementation은 Zstar<=R/2, Enew<=R와 물리 재구성 검사를 요구한다. R/2는 residual과 누적 rounding을 분리하기 위한 사전에 정한 여유이며, 수행 결과에 맞추어 바꾸지 않았다.

중요한 구별: E0를 버리거나 0으로 reset하지 않는다. Z>=E0이며 저장 rounding은 매 step 뒤에 더한다. 그래서 arbitrary accepted mesh와 candidate switching에서도 bound가 유지된다. Fixed precision에서 계속된 rounding이 cap을 소진할 수 있고 그 경우 중단한다. 시간에 따라 변화하는 norm을 비용 없이 바꾸지도 않는다.

일반적인 확장 원리: 어떤 Metzler M과 양의 방향 v가 -Mv>0를 만족하면 Zstar=max_i delta_i/(-Mv)_i는 불변 오차 box Zv를 제공한다. 이 직접 증명은 차원과 무관하다. 이번 코드가 임의 차원의 M, root inverse, domain을 자동 생성한다는 뜻은 아니다. 고정 방향을 offline에서 검증해 두면 online certificate는 행별 residual과 나눗셈으로 구성되며 새 nonlinear root iteration이 필요하지 않다.

### 5.3 정확성 보장과 차수/효율성은 다르다

이 두 정책은 original RVJ의 임의 시스템에서의 안정성을 복구하는 theorem이 아니다. 원래 방정식의 연속 residual과 perturbation flow를 검증하는 additional acceptance 조건이다. 고전적 차수가 좋아도 candidate가 이 조건을 통과하지 않으면 거절한다. 오차 전파는 kappa-uniform하게 감싸지만 step count, termination, precision 비용이 kappa-independent라고 주장하지 않는다.

## 6. 물리 출력과 causal transaction

위 norm에서 |dx|<=E, |du|<=d s E, |dv|<=s E다. Exact central reconstruction과 실제 저장값 사이 차이를 rho1,rho2라 하면

    B1=d s E+(2|xhat|E+E^2)/kappa+rho1,
    B2=s E+(3 xhat^2 E+3|xhat|E^2+E^3)/kappa+rho2.

Physical output x의 bound E도 포함하고 전부 eps 이하인지 최종 검사한다. Smooth reconstruction inequality와 모든 outward rounding을 동일 상태에서 계산한다. Fast modes를 0으로 projection하지 않고, zero initial fast modes도 return forcing에 의해 실제 비영이 되는 시험을 넣었다.

Immutable snapshot은 t,Y,E,generation을 가진다. Model epoch, branch, 전체 parameter identity를 certificate에 결속한다. Commit은 같은 snapshot과 generation을 요구한다. Rejected candidate는 state, witness, error budget을 바꾸지 않는다. 이 hash는 trusted-process consistency이며 외부 위조 certificate의 보안 인증이 아니다.

RVJ_FIRST와 TAYLOR_FIRST는 같은 jet과 certification policy를 사용한다. 전자는 처음 RVJ가 통과하면 Taylor를 계산하지 않고, 후자는 반대로 한다. 양쪽 실패 시 h를 줄인다. 시간 간격은 입력 당시의 state와 model 및 trial 결과만으로 정하며 미래의 정확해나 audit oracle을 보지 않는다. 독립 후보의 동시 실행 가능성은 있지만 본 코드는 순차 reference다.

## 7. 실제 결과

모든 main case는 T=1/4, eps=1e-6, dyadic state/radius 96 bits다. Main 15개 실행조건은 11개 물리 parameter/initial-state 조합에 두 certification policy를 부분 교차한 것이다. 서로 독립된 15개의 물리모델이라고 세지 않는다.

기본 positive branch, alpha=eta=1/16,beta=4,rho=1,w0=(0,1):

| kappa | DENSITY steps | INVARIANT steps | invariant max y1 error |
|---:|---:|---:|---:|
| 1 | 4 | 8 | 2.2836e-11 |
| 40 | 113 | 108 | 7.3512e-10 |
| 400 | 218 | 133 | 6.1977e-10 |
| 10000 | 423 | 165 | 6.6632e-10 |

모두 같은 물리 eps를 만족하지만 실제 오차와 budget 사용 정도는 같지 않다. 따라서 이것은 matched-accuracy speed 비교가 아니다. 10000에서 counted small 3x3 solves는 451->180, certificate evaluations는 479->195다. Reject와 fallback 작업을 포함한 logical counts다. Full Fraction arithmetic, Bernstein 비용, 할당, wall-clock, synchronization을 모두 대표하는 FLOP count가 아니다.

RVJ_FIRST의 main에서는 모든 accepted candidate가 RVJ였다. 실제 hybrid switching을 위해 별도 TAYLOR_FIRST 네 조건을 실행했다. INVARIANT 아래 kappa=1,40,400,10000에서 각각 8,153,193,693 steps, accepted Taylor/RVJ는 8/0,149/4,170/23,493/200이었다. kappa=10000에서 candidate solves 215, certificate evaluations 923으로 RVJ_FIRST의 180과195보다 불리하다. Taylor 한 번이 싸다는 것만으로 전체 경로가 싸지지는 않았다. 정책을 기본값으로 승격하지 않았다.

kappa=400의 eps=1e-4/1e-6/1e-8에서는 INVARIANT steps=58/133/343이었다. 별도 alternating cap 1/512,1/256의 kappa40 실행은 실제 세 step 길이를 사용한 비균일 mesh로 126 steps를 완료했다.

Main 15조건: 1979 accepted steps, 9895 interior comparisons. Hybrid 4조건:1047 steps,5235 comparisons. Auxiliary4조건:660 steps,3300 comparisons이며 eps1e-6 조건 하나는 main의 반복이다. Preview는 별도 evidence로 보존하고 본 수치의 독립 반복으로 더하지 않는다.

Audit는 원래 3변수 ODE를 SciPy Radau(exact Jacobian)와 DOP853로 각각 rtol=5e-14,atol=1e-15로 적분했다. Enclosure theorem이 아니라 독립적인 floating numerical check다. Comparison script는 cross-solver difference 기반 numerical allowance를 별도 기록하지만, 실제 실행된 모든 조건에서 allowance를 더하기 전 raw endpoint/interior/root violations도 0이었다. Main의 최대 물리 error/bound ratio는 약0.16485, hybrid는0.11676이다.

kappa1 기본계는 mpmath55자리, degree25 Taylor oracle(tol1e-43)로 추가 대조했다. Endpoint에서 Radau와의 최대 차이는1.252e-15, DOP853과는3.024e-16이다. 이 고정밀 oracle도 독립적인 rigorous validated-solution theorem은 아니다. Candidate/certificate 모듈은 scipy/mpmath를 import하지 않는다.

## 8. 왜 여전히 initial-layer 비용이 남는가: 다항식 경로의 제한

고전적 Markov inequality는 [-1,1]에서 degree-m 실수 다항식에 대해 ||p'||_inf<=m^2||p||_inf다. [0,1]으로 옮기면 계수가2m^2가 된다. 이 고전적 사실은 원 논문 arXiv1405.0167의 abstract에서도 명시되어 있다.

정리. a>=1, 0<epsilon<(1-e^-1)/2이고 실수 degree-m 다항식 p가

    sup_[0,1] |p(theta)-exp(-a theta)| <= epsilon

를 만족한다면

    a <= 2m^2(1+epsilon)/(1-e^-1-2epsilon).

증명. 두 점0과1/a에서 |p(0)-p(1/a)|>=1-e^-1-2epsilon이다. 평균값정리에 의해 ||p'||>=a(1-e^-1-2epsilon). 반면 ||p||<=1+epsilon이므로 Markov inequality와 합하면 결론이다.

m=6,epsilon=1e-6이면 a=kappa h<=113.902797180058...가 필요하다. 이는 날카로운 practical step bound가 아니지만, 고정 차수만으로 unit-amplitude 강직 초기층 전체를 arbitrarily coarse step에서 균일하게 좁게 재구성할 수 없음을 보인다. 더 정확한 approximation theory가 더 강한 제약을 줄 수 있다.

이 제한은 endpoint-only L-stable integrator, exponential/rational enriched path, 적분된 forcing의 오차만 필요한 scheme까지 금지하지 않는다. 작은 fast 진폭에 같은 absolute tolerance를 적용하면 상대적으로 완화된다. 또한 본 실험의 구체적인 423 또는165라는 step count를 이 약한 하한이 정량적으로 설명한다는 주장도 아니다.

결론: 원래 목표인 적은 serial work를 위해서는 scalar filter의 poles만 재조정할 것이 아니라, fast exp/phi waveform을 유지한 reconstruction이나 integrated-path error certificate가 필요하다. MERB나 simple-pole rational Krylov는 관련 선행 후보지만 이번 코드에 통합하지 않았다.

## 9. 검증·실패·종료

최종 테스트30개, symbolic checks16개가 통과했다. 초기 누락-return 회귀는 실제 RED를 관찰했고 원방정식 residual로 수정했다. Invariant-box RED는 기존 h*residual 정책이 새 damping-aware tightness 계약을 만족하지 못함을 재현한 것이다. 기존 bound가 틀렸다는 의미는 아니다.

Wolfram 최초 호출에 잘못된 Sum iterator의 Protected/localization 경고가 있었다. 같은 호출 안에서 식을 재대입한 출력이 있어도 clean pass로 사용하지 않았다. 이후 stateless clean 호출을 새로 실행해 lift,comparison inverse,linear RVJ,negative control,discriminant를 확인했다. Wolfram 결과와 local exact SymPy checks는 algorithmic cross-check이며 independent final reviewer는 아니다.

E06은 비용 preview 후 별도 탐색으로 기록했다. 작은 kappa에서 INVARIANT steps 증가, 큰 kappa에서 Taylor-first 악화는 그대로 남겼다. 전체 부모 numerical campaign, 원래 generic RVJ counterexample campaign, native Rust/AD/Krylov, source full suite를 이번에 반복하지 않았다. 부모 원본 파일들의 byte identity는 별도 확인한다.

현재 scoped research outputs는 닫되 외부 reviewer 없이 PROMOTE하지 않는다. 다음의 미수행 작업만 NEXT_DEVELOPMENT_DAG.json에 둔다.
