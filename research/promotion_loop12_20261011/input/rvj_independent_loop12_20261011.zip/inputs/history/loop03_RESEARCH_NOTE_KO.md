# 연구 루프 3: RVJ5의 비정규 행렬 경계, semilinear 반례, Darboux 좌표 수정

Date: 2026-10-02
Status: 연구용 증명·검산 패키지. Production 적분기 또는 성능 우위 판정이 아니다.

## 0. 이번 루프의 결정

직전 루프의 scalar constant-rate PR uniform5 결과를 출발점으로 삼아, 다음 네 가지를 실제 산출했다.

1. 고정 시간간격과 고정 H-dissipative fast matrix 아래에서 여러 fast mode와 비정규·defective matrix를 허용하는 vector PR uniform5 정리.
2. 비선형 항의 미분과 정확한 해의 미분이 강직도와 무관하게 유계인 진짜 2D semilinear 문제에서도, 원 좌표의 RVJ5가 uniform5를 갖지 않는다는 두-step 반례.
3. 해당 반례의 Darboux cofactor를 맞추어 stiffness-independent regular rational chart를 구성하고, 그 chart에서 fast mode를 버리지 않는 수정 알고리즘과 well-prepared uniform5를 증명.
4. RVJ5/RVJ4의 embedded difference가 이미 증명된 PR군에서도 실제 local error를 임의로 작게 보고할 수 있다는 반례.

결정: 원 좌표의 RVJ5를 범용 stiff-uniform5 적분기로 승격하지 않는다. 기존 classical5와 제한된 PR 정리는 유지한다. 정칙 cofactor chart 및 오차 안정성이 인증된 경로는 계속 개발한다. 더 높은 차수의 scalar rational filter나 exact exponential 대체만으로 이번 내부 오차 증폭을 고쳤다고 주장하지 않는다.

## 1. 입력, 근거, 문헌 위치

직전 인계서의 우선 작업은 vector stiff order, 두 개 이상의 fast mode, nonnormal coupling, approximate-W/true-J 구분, embedded estimator effectivity였다. 실제 입력은 `results/input_identity.json`에 hash와 크기로 고정했다. `source_snapshot/rosenbrock_ag_loop2_20261002`는 원 zip에서 복원한 변경하지 않은 source snapshot이다.

사용한 외부 원전:

- [S1] Koskela–Ostermann, *Exponential Taylor methods: Analysis and implementation*, Computers & Mathematics with Applications 65(3), 487–499 (2013), DOI 10.1016/j.camwa.2012.06.004. SciSpace 검색 및 publisher-indexed abstract/metadata 확인. 고차 AD와 VoC 결합, 잠재적 instability라는 연구 배경만 사용했다. 전체 본문의 수렴 정리를 읽었다고 주장하지 않는다.
- [S2] Roberts–Shirokoff–Biswas–Seibold, *A Stiff Order Condition Theory for Runge–Kutta Methods Applied to Semilinear ODEs*, arXiv:2505.15099v4, 2026-05-02. HTML의 문제 가정, matrix rational von Neumann 정리, semilinear order 분석 구조를 확인했다. 이 논문의 RK 정리가 RVJ에 자동으로 적용되는 것은 아니다.
- [S3] Ferragut–Gasull, *Seeking Darboux Polynomials*, Acta Applicandae Mathematicae 139, 167–186 (2015), DOI 10.1007/s10440-014-9974-0. Publisher abstract/metadata 확인. Cofactor를 단순화하고 bounded-degree polynomial을 찾는 관점에 참조했다. 아래 quotient와 반례 수정은 직접 계산했다.

문헌 우선권이나 새로운 방법군의 역사적 최초성을 주장하지 않는다. 식에 [T3.x]가 붙은 결과는 본 루프에서 직접 유도한 결과다. Exact algebra, numerical probe, 외부 문헌 결과를 분리한다. 원 URL와 조회 범위는 `sources/source_registry.json`에 있다.

## 2. 정의와 컨벤션

자율 ODE Y'=F(Y), 양의 step h, 정확한 순간 flow derivative v_j=L_F^(j-1)F를 사용한다. v_j의 단위는 [Y]/[time]^j, J=F'의 단위는 [time]^-1이다. 수치 반례와 kappa=h^-6 scaling은 고정 시간·상태 scale로 무차원화한 식이다. 이를 물리 단위가 있는 kappa와 h에 그대로 대입하지 않는다.

기존 rational core:

P(z)=1+2z/5+z^2/20,
Q(z)=1-3z/5+3z^2/20-z^3/60,
R(z)=P(z)/Q(z).

phi_j^R(z)=[R(z)-sum_(ell=0)^(j-1) z^ell/ell!]/z^j.

특히

phi_5^R(z)=(z^2-5z+12)/(1440 Q(z)).

RVJ5의 nonlinear-defect 표현은

Psi_h(Y)=Y+h phi_1^R(hJ)F
 +sum_(j=1)^4 h^(j+1) phi_(j+1)^R(hJ)[v_(j+1)-Jv_j].

증명용 compact form:

Psi_h(Y)=Y+sum_(j=1)^4 h^j v_j/j!+h^5 phi_5^R(hJ)v5.

이 두 식은 정확한 arithmetic에서 동일하다. Reference 코드는 F 및 nonlinear-defect source를 기호적으로 먼저 단순화한 뒤 dense Q(hJ) solve를 사용한다. 고차원 생산 구현, AD backend 또는 실제 Krylov를 구현한 것은 아니다.

H norm은 ||v||_H^2=v*Hv이며 H는 양의정부호다. 강직도와 차원에 독립적인 정리를 주장할 때에는 H와 물리 norm 사이의 동치상수를 별도로 균일하게 제어해야 한다. 나쁜 norm 변환 안에 nonnormal amplification을 숨기지 않는다.

## 3. [T3.1] Vector PR uniform5: 고정·비정규 dissipative fast matrix

### 전제와 정리

x'=1,
y'=A[y-phi(x)]+phi'(x), y in R^m,

에서 A는 한 적분 전체에 걸쳐 고정한 행렬이고 A*H+HA<=0라고 하자. phi는 [x0,x0+T]에서 C6이며 M_j=sup||phi^(j)||_H, j=5,6는 A의 stiffness와 무관하게 유계다. 정확한 augmented Jacobian과 flow jets, 고정 step h>0, Nh<=T를 사용한다.

e_n=y_n-phi(x_n)라고 하면

||e_N||_H <= ||e0||_H
 +h^5[(2M5+T M6)/60+T M6/720].

따라서 e0=0인 well-prepared graph data에서 uniform global5다. Diagonalizability는 요구하지 않는다. Defective matrix, complex mode, nonnormal mixing이 허용된다. 다만 단순히 Re spectrum(A)<=0인 것만으로 이 정리를 적용하지 않는다.

### 증명 1: scalar rational factor

B(z)=phi_5^R(z)-1/120,
K(z)=-(z^2-4z+11)/[120(z^2-6z+60)].

직접 통분하면

B(z)=[1-R(z)]K(z).

K의 극점은 3 +/- i sqrt(51)로 우반평면에 있다. z=i omega에서

4|z^2-6z+60|^2-|z^2-4z+11|^2
=3(omega^2-55)^2+5204>0.

따라서 imaginary axis에서 |K|<=1/60이다. K는 닫힌 좌반평면에서 pole-free이고 infinity의 극한은 -1/120이므로 최대모듈 원리로 전체 좌반평면에서도 |K|<=1/60이다. 이는 exact polynomial SOS certificate다. 이전 scalar 음의 실수축 경계 1/120을 complex half-plane으로 아무 증명 없이 옮기지 않았다.

### 증명 2: 행렬 functional calculus

H-dissipative A에 대한 rational half-plane von Neumann inequality를 사용하면

||R(hA)||_H<=1,
||K(hA)||_H<=1/60.

이 형태의 inequality는 [S2, Theorem 1]에서 명시되어 있다. H^(1/2) similarity 후 Cayley transform으로 contraction operator의 disk functional calculus에 환원할 수 있다. 예를 들어 Z=h H^(1/2)A H^(-1/2), T=(I+Z)(I-Z)^(-1)라 놓으면 ||T||_2<=1이다. 좌반평면에서 유계인 rational function을 disk에 옮겨 von Neumann inequality를 적용한다. 우리는 R의 기존 A-stability와 위 K bound만 사용한다.

### 증명 3: 정확한 recurrence와 Abel summation

Exact instantaneous jets는

v_j=(delta_(j1), phi^(j)(x)+A^j e).

Compact map에 대입하면 S=R(hA)에 대해

e_(n+1)=S e_n+h^5(I-S)K(hA)phi^(5)(x_n)-r_(6,n),
||r_(6,n)||_H<=h^6M6/720.

u_j=K(hA)phi^(5)(x_j)라 놓는다. Abel identity는

sum_(j=0)^(N-1) S^(N-1-j)(I-S)u_j
=u_(N-1)-S^N u_0-sum_(j=1)^(N-1)S^(N-j)(u_j-u_(j-1)).

Contractivity와 ||u_j-u_(j-1)||_H<=hM6/60를 대입하면 이 합의 norm은 (2M5+T M6)/60 이하다. Taylor remainder 합은 N h^6 M6/720<=T h^5 M6/720이다. 따라서 정리가 따른다.

### Variable h와 초기층에 대한 제한

Variable h에서는 같은 Abel 구조를 u_n=h_n^5 K(h_nA)phi^(5)(x_n)에 적용할 수 있다. 그러나 sum||u_n-u_(n-1)||의 uniform O(hmax^5) bound가 별도로 필요하다. 이번 vector 정리는 arbitrary variable h를 무조건 포함하지 않는다. 이전 scalar PR 정리는 그 별도 증명과 함께 유지된다.

e0!=0일 때 위 식은 graph까지의 거리 경계다. Exact solution은 graph에 exp(tA)e0를 더한 것이므로, 임의의 미해상 초기층까지 uniform5로 계산했다는 뜻이 아니다.

### 실제 검증

A01=[[-1,1,0],[0,-1,1/2],[0,0,-2]],
A02=[[-1,6,0],[-6,-2,1],[0,-1,-3]].

두 행렬의 symmetric part 음의정부호성과 nonnormality를 정확히 검증했다. A01은 eigenvalue -1의 algebraic multiplicity2, geometric multiplicity1이므로 defective다.

A=kappa A0, phi=(x^5,x^6,sin x), T=1, N=8,16,32,64, kappa=1,1000,h^-2를 검사했다. 모든 계산에서 위 bound가 유지되었고 kappa=h^-2 lane에서 5차에 접근했다. Full augmented 4D VoC reference의 한 step과 recurrence의 일치도 독립 검사했다.

## 4. [T3.2] Uniform5의 진짜 semilinear 반례

### 문제와 정확한 해

x'=x^2,
y'=(-kappa+2x)y+x^2,
x(0)=1, y(0)=1/kappa, kappa>=1.

정확한 해는

x(t)=1/(1-t),
y(t)=1/[kappa(1-t)^2], 0<=t<=1/4.

A_kappa=diag(0,-kappa),
g(x,y)=(x^2,2xy+x^2)

로 분해된다. A_kappa는 dissipative이고 g는 kappa와 무관한 2차 polynomial이다. 정확한 궤도와 첫 두 numerical states를 포함하는 고정 compact tube에서 모든 필요한 g derivatives가 균일하게 유계다. 전역 Lipschitz 가정을 쓰고 싶으면 그 tube에서 1인 smooth compact cutoff를 g에 곱할 수 있다. 해당 exact trajectory와 두-step 계산은 바뀌지 않는다. 전체 g는 그때 polynomial은 아니지만 매끄러운 semilinear 반례로는 충분하다.

정확한 해의 시간 미분은 x^(j)=j!/(1-t)^(j+1), y^(j)=(j+1)!/[kappa(1-t)^(j+2)]이므로 0<=t<=1/4에서 kappa와 무관한 경계를 갖는다. 이것은 거대한 초기층의 미분을 숨긴 반례가 아니다.

### Full current J와 flow jets

J=[[2x,0],[2y+2x,-kappa+2x]].

e=y-x^2/kappa, a=-kappa+2x라고 두면 연속식은 e'=a e다. c1=a,
c_(j+1)=x^2 (d c_j/dx)+a c_j

로 정의하면

v_(j,y)=(j+1)! x^(j+2)/kappa+c_j e.

j=1,...,5에서 직접 Lie derivative로 만든 jet과 이 표현이 동일함을 exact arithmetic으로 검사했다.

### Discrete triangular-map 공식

p_s=phi_5^R(2hx), p_f=phi_5^R(h a),

U_h(x)=x+sum_(j=1)^4 h^j x^(j+1)+120h^5 p_s x^6,

A_h=1+sum_(j=1)^4 h^j c_j/j!+h^5 p_f c5
 +240h^5 x^6/kappa (p_s-p_f).

Well-prepared input y=x^2/kappa에서 출력 y를 y_on이라 하면

y_on=[x^2+sum_(j=1)^4 (j+1)h^j x^(j+2)+720h^5 p_f x^7]/kappa
 +240h^5 x^6(x+x^2/kappa)/kappa (p_s-p_f).

D_h=y_on-U_h(x)^2/kappa.

그러면 정확히

x_+=U_h(x),
e_+=A_h(x,kappa)e+D_h(x,kappa).

근거는 lower triangular J에 대한 divided-difference formula다. phi(hJ)의 lower-left entry는 J21[phi(2hx)-phi(h a)]/kappa다. 이를 compact map에 대입하면 위 식이 나온다. 임의의 근사 J를 사용한 것이 아니다. Exact rational point에서 full matrix map과도 독립 대조했다.

### Weighted algebraic boundary와 증명

kappa=h^-6를 선택한다. 직접 전체 two-step rational expression을 전개하면 expression swell이 크다. 대신 다음 정규화된 두 함수를 먼저 만든다.

Atilde(h,x)=cancel[h^8 A_h(x,h^-6)],
Dtilde(h,x)=cancel[h^-11 D_h(x,h^-6)].

정확하게 소거한 후 둘 다 h=0에서 분모가 0이 아닌 regular rational function이며,

Atilde(0,x)=-x^2/3,
Dtilde(0,x)=-4x^7.

이는 weighted scaling chart에서의 valuation 계산이다. CAS의 수치 fit이 아니라 exact rational boundary evaluation이다. 분모가 0이 아님을 함께 검사하여 잘못된 0/0 대입을 피했다.

e0=0, x0=1, U_h(x)->x이므로

e1=h^11[-4+o(1)],
e2=h^-8[-1/3+o(1)] e1+h^11[-4+o(1)]
  =4h^3/3+o(h^3).

또한 x2와 exact x(2h)의 차이는 O(h^6)이고 1/kappa=h^6이므로 graph reconstruction difference [x2^2-x(2h)^2]/kappa는 O(h^12)다. 따라서 실제 물리 성분의 오차도

lim_(h->0+,kappa=h^-6) [y2-y(2h)]/h^3=4/3.

### 정확한 결론

이 결과는 fixed T에서 max_(nh<=T)||error_n||<=C h^5를 kappa와 무관하게 보장하는 주장을 반증한다. t=2h 자체가 그 grid에 들어 있기 때문이다. 반대로 fixed-final-time error가 반드시 3차라는 주장은 하지 않는다. 더 오래 적분하면 더 나빠질 수 있다.

발생한 실패는 classical consistency의 부재가 아니라, tiny transverse local defect가 numerical map의 h^-8 sensitivity로 증폭되는 내부 오차 안정성 실패다. Exact J, exact jets, 고정밀 arithmetic에서도 성립한다. Finite-difference step, Krylov convergence, AD graph 오류로 분류하면 안 된다.

### 수치 reference

100자리 dense VoC reference에서 h=1/N, kappa=N^6를 사용했다.

N=16: y_error/h^3=1.64294674397401498328
N=32: 1.47792668095070595659
N=64: 1.40327519247485296153
N=128: 1.36773855352016928282
N=256: 1.35039727960428234306

이는 4/3에 접근한다. N=128 계산은 140자리로 재실행해 agreement를 확인했다. kappa=8 고정, T=1/4의 별도 refinement는 마지막 observed order 4.98449477116으로 classical5를 재확인했다.

### Exponential core control과 별도 variable-rate 반례

같은 compact-jet 구조에서 rational R를 exact exp로만 바꾸는 control 계산도 수행했다. h=1/128에서 error/h^3=1.36773713922440507519였다. 따라서 이 예제에서 단순히 poles를 늘리거나 exact exponential로 교체하는 것은 문제를 제거하지 않았다. 이것은 역사적 exponential Taylor 방법 전체에 대한 동일성·불가능성 주장이 아니다.

별도 예제로 x'=1, y'=-kappa(1+x)[y-x^5]+5x^4도 분석했다. a=-kappa(1+x), c_(j+1)=c_j'+a c_j로 구한 transverse amplification은 고정 h,x에서 A_h/kappa^3 -> h^4(1+x)^2/6이다. kappa=h^-2의 두-step 오차는 -h^3/6에 접근한다. 이 예제는 stiffness가 nonlinear/time-dependent coefficient에도 들어가므로, 위 bounded-g semilinear 반례보다 약한 보조 결과로 보존했다.

## 5. [T3.3] Darboux quotient로 해당 반례를 실제 수정

### Cofactor 일치 정리

다항식 vector field F에 대해

L_F C=(-kappa+a)C,
L_F D=aD

라는 exact certificate가 있다고 하자. D!=0인 chart에서 w=C/D는

w'=[(L_F C)D-C(L_F D)]/D^2=-kappa w

를 만족한다. 이 결과는 직접 quotient rule로 증명된다. 검색 가능한 대상은 coefficient equality, cofactor ansatz, normalization, denominator 및 chart rank다. Darboux polynomial/cofactor 계산의 배경에는 [S3]를 참조했으며, 아래 해는 직접 계산했다.

### 실제 cofactor search와 정칙성

위 반례에서 C=kappa y-x^2, D=kappa x^2가 성립한다.

L_F C=(-kappa+2x)C,
L_F D=2xD.

차수<=2 ansatz a0+a1 x+a2 y+a3 x^2를 사용해 첫 cofactor에서는 a2=kappa, 두 번째 cofactor에서는 a3=kappa로 normalization했다. 정확한 coefficient solve가 각각 C와 D를 유일하게 돌려주었다. 이는 선택한 ansatz와 cofactor에서의 유일성이지, 모든 차수의 Darboux polynomial exhaustion이 아니다.

w=y/x^2-1/kappa,
y=x^2(w+1/kappa).

(x,w)->(x,y)의 Jacobian determinant는 x^2다. 따라서 kappa>=1, 1<=x<=2, bounded w에서 chart와 inverse의 derivative bounds는 kappa와 무관하게 선택 가능하다. 단순히 kappa y로 변수 스케일을 바꾸어 큰 condition number를 숨기는 방법과 다르다. x=0은 제외한 chart이며, 그 locus는 별도로 남겨야 한다.

### 수정된 적분 알고리즘

x'=x^2,
w'=-kappa w

를 계산한다. 각 step에서는

x_+=U_h(x),
w_+=R(-kappa h)w,
y_+=x_+^2(w_++1/kappa).

이것은 원 좌표의 RVJ를 같은 방식으로 실행한 결과와 같지 않다. Nonlinear chart를 적용한 뒤 새 discrete map을 정의한 것이다. 즉 preconditioner 개선만이 아니라 integrator의 coordinate-dependent 재설계다.

w0=0이면 w_n=0을 exact arithmetic에서 보존한다. Reduced slow method의 classical5 상수는 kappa에 의존하지 않는다. Compact slow domain 안에서

|y_n-y(t_n)|=|x_n^2-x(t_n)^2|/kappa
 <=(|x_n|+|x(t_n)|)|x_n-x(t_n)|/kappa.

따라서 well-prepared data에서 uniform5다. 비영인 w0를 0으로 projection하지 않는다. 그 경우 rational fast update를 남기지만, 미해상 initial layer의 uniform accuracy는 별도 과제다.

### 수치 결과

T=1/4, N=8,16,32,64, kappa=h^-6에서 slow error observed order는

4.91331775629, 4.95689121673, 4.97850808806.

모든 step이 1<=x<=2 chart 안에 있고 w=0 보존 및 물리 y error reconstruction bound를 확인했다. w0=0.1,kappa=40,h=0.1에서 w1=0.00291262135922330097로 빠른 성분을 소거하지 않고 감쇠시킴도 검사했다.

### 여러 fast mode로의 일반화 경계

C_i,D_i의 cofactor 차이를 각각 constant target eigenvalue로 맞출 수 있으면 mode별 quotient를 만들 수 있다. 일반 matrix cofactor B와 moving frame S에서는 w=S^-1 C의 방정식에 -S^-1 L_F S가 반드시 들어간다. 이것은 일반적으로 B와 교환하지 않는다. 회전 frame의 정확한 connection [[0,-1],[1,0]]를 검사해 단순 similarity만 사용하는 잘못을 방지했다.

모든 시스템이 작은 차수의 rational chart를 가진다는 보장은 없다. Degree bound 안에서 실패했다고 고차·비대수적 chart까지 불가능하다고 판단하지 않는다. Conversely, chart를 찾았어도 denominator lower bound, inverse conditioning, initial branch, chart transition을 인증하기 전에는 사용하지 않는다.

## 6. [T3.4] Embedded 5(4) estimator의 강직 blindness

constant-rate PR 문제

x'=1,
y'=lambda(y-x^5)+5x^4,
(x0,y0)=(0,0), z=h lambda<0

를 고려한다. 첫 step에서 exact y(h)=h^5다. RVJ5와 RVJ4 출력은 각각

y5=120h^5 phi_5^R(z),
y4=0.

따라서 eta=|y5-y4|, LTE=|y5-h^5|의 비는

eta/LTE = -5(z^2-5z+12)/[z(z^2-4z+11)]
         ~5/|z| ->0.

이것은 서로 다른 Q5와 Q4를 사용해도 생긴다. Parent에서 해결한 문제는 linear homogeneous test 전체에서 estimator가 항등적으로 0인 현상이었고, 지금의 nonlinear/forcing stiff blindness는 별개의 문제다.

h=0.1,z=-10^6에서

true local error = 9.9999500001999994e-6,
embedded estimate = 4.99998000006e-11,
effectivity = 5.000004999985e-6.

즉 실제 local error의 약 1/200000만 보고한다. 해당 PR군에서 main method의 uniform global5 정리와 모순되지 않는다. 그 정리는 damped accumulation을 이용하며, embedded estimator의 effectivity를 보장한 것이 아니다.

### 제한적인 local defect certificate

Exact flow derivatives가 입력되고, 실제 step 궤도의 ||Y^(6)||<=M6를 인증했다고 하자.

ell_h=h^5[phi_5^R(hJ)-I/120]v5.

Compact form과 Taylor theorem에서

||Psi_h(Y)-exact_flow_h(Y)-ell_h||<=h^6 M6/720.

따라서 ||ell_h||+h^6M6/720가 true local error의 상계다. 위 quintic PR에서는 M6=0이므로 정확한 값이 된다. 이것은 generic solver에 공짜로 추가되는 추정기가 아니다. 임의의 stiff numerical state에서는 v5와 M6가 매우 클 수 있고, source cancellation이나 추가 RHS 비용이 생길 수 있다. Formal closure jet만으로 실제 M6를 인증했다고 해석하지 않는다. 우선 certified chart/slow dynamics에서 이 certificate를 사용하는 경로만 허용한다.

## 7. 실행 검증과 failure 분류

새 exact verifier: `proofs/verify_exact_loop3.py`, 40/40.
새 numerical verifier: `proofs/verify_numeric_loop3.py`, 89/89.
합계 129/129. 이 안에는 no-go와 estimator failure의 정확성을 검증한 항목이 포함된다.

Connected Wolfram final block: 14/14 exact checks, Linux Wolfram 15.0.1. 이 block의 재현 코드는 `proofs/replay_wolfram.wl`. Local container의 Wolfram kernel 실행을 했다는 주장은 아니다.

Parent source의 manifest 38개 파일을 검증하고, scratch copy에서 parent 64/64 및 56/56, grandparent 33/33을 재실행했다. 원 source snapshot은 변경하지 않았다. 로그와 결과는 `results/PARENT_REPLAY.json` 및 `*_replay.log`에 있다.

Numerical tests는 기본 100자리 mpmath, 일부 140자리 repeat다. Nonnormal matrix norm probe는 numpy double SVD를 사용한다. Exact matrix positivity, rational identity와 고정밀 recurrence checks를 별도로 제공하므로 단순 double sampling을 전체 정리의 증명으로 취급하지 않는다.

실행 중 발생한 실패도 보존한다.

- Full nested rational two-step expansion은 expression swell로 시간 제한에 걸렸다. Weighted boundary를 먼저 계산하는 방식으로 해결했다.
- Unsimplified polynomial expression에 .has(kappa)를 검사해 잘못된 실패를 냈다. Canonical expansion 후 dependence check를 하도록 수정했다. 원 실패 기록은 historical_failures에 있다.
- Wolfram protected symbol C 사용으로 gauge certificate가 invalid였다. cnumer/cdenom 이름으로 독립 재실행해 0을 얻었다.
- 일부 초기 Limit는 Infinity 관련 경고를 냈다. 최종 certificate는 cancel 후 regular boundary evaluation으로 대체해 경고 없이 14/14를 재실행했다.

이들은 implementation/CAS-resource 문제이며 수학적 반례와 분리한다. 원 좌표 RVJ의 uniform-order failure와 embedded effectivity failure는 과학적 결과이므로 'fixed'로 덮지 않는다.

## 8. 다음 연구 계약

### 다음 bounded unit

1. 정확한 또는 오차가 인증된 Darboux/cofactor chart를 integrator interface로 만든다. Inputs: chart, inverse, denominator/rank margin, cofactor residual, current full-J action, physical norm. Outputs: chart-validity certificate, translated jet, physical error budget. 먼저 이번 2D 반례와 constant-matrix PR를 회귀시험으로 고정한다.
2. Approximate cofactor matching에서는 numerator residual을 실제 w equation forcing과 error growth로 환산한다. 작은 polynomial residual을 무조건 작은 solution error라고 해석하지 않는다.
3. Chart가 없는 generic lane에는 genuinely error-stable correction 또는 peer/derivative-light 대안을 연구한다. 이번 no-go를 통과하지 못한 RVJ core에 scalar poles만 늘리는 작업은 우선하지 않는다.
4. Embedded pair만으로 step을 수락하지 않는다. Certified slow/graph defect 또는 다른 independently validated stiff estimator를 병합한다.
5. 그 후 analytic reference와 AD jet, current-J Krylov implementation을 동일 입력과 residual budget으로 대조한다. Cost는 F/Jv/고차 directional AD/source preparation/closure solve/orthogonalization/synchronization/accepted-rejected steps로 분해한다.

Stop conditions: original coordinates의 strong semilinear two-step no-go가 회귀시험에서 사라졌다고 주장하려면 exact formula 또는 independent reference로 수정된 map임을 확인할 것. Chart existence/conditioning을 얻지 못하면 scope를 제한하고 다른 lane으로 전환할 것. Generic stiff-uniform5, arbitrary variable-step nonnormal convergence, unresolved initial layers, all physical positivity/constraints, full adaptive reliability, production speedup은 이번 산출물로 주장하지 않는다.
