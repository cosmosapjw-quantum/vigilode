# Rosenbrock / 계산대수기하 연구 노트
## 2026-10-02: 정칙 chart, 깊이 장벽, rational-jet 5(4) 후보

## 0. 범위와 상태

외부 문헌조사는 하지 않았다. 첨부 논문의 LaTeX와 계산 패키지, 현재 대화의 방정식, 직접 유도, 연결 Wolfram 계산, 별도 SymPy/mpmath 검산을 사용했다. 아래 결과의 새로움이나 문헌 우선권은 주장하지 않는다.

이 노트는 production solver가 아니라 알고리즘 설계에 필요한 정리와 계산 증명서다. 고전적 차수, 선형 A/L-안정성, 비선형 stiff-uniform order, 구현 검증, 실제 wall-clock 우열은 서로 다른 주장이다.

가정: 우선 자율 ODE y'=F(y), F는 필요한 차수만큼 매끄럽고 n차원이다. 비자율식은 시간 변수를 추가해 자율화할 수 있다. h>0, W는 한 macro-step 동안 고정한 선형 연산자다. W의 단위는 시간의 역수, hW는 무차원이다. 서로 다른 단위를 가진 상태 성분은 고정 스케일로 정규화한 뒤 norm을 정의한다.

## 1. 먼저 수정하는 기존 주장

### 1.1 Resultant의 정확한 값

이전 대화에 표시한 정수계수 다항식

p3=24g³−36g²+12g−1,

q4=360g⁴−480g³+120g²−1

에 대해 Res_g(p3,q4)=−124416이다. 이전의 −1/4608000은 표시된 다항식의 resultant와 일치하지 않는다. 두 다항식이 공통근을 갖지 않는다는 결론은 유지된다. 이번 `exact_verification.json`에는 u p3+v q4=1의 정확한 Bézout 계수도 들어 있다.

두 번째 쌍

p4=120g⁴−240g³+120g²−20g+1,

q4L=24g⁴−96g³+72g²−16g+1

의 resultant는 31850496이며, 이것도 단원 ideal이다.

### 1.2 Inexact residual과 stiff-uniform order

한 stage의 ||(I−γhJ)^−1|| 유계성만으로 모든 비선형 stage 오차 전파가 균일하게 제어된다고 할 수 없다. 전체 stage residual map의 역함수 안정성, h A_i^−1 F'(Y_j) 및 off-diagonal coupling, one-step propagation을 함께 제어해야 한다. 따라서 r=O(h^(p+1))에 대한 이전 주장은 이러한 내부 안정성과 one-step 안정성 가정 아래의 충분조건으로 제한한다.

### 1.3 Newton과 chord correction

O(h³) predictor 뒤 한 번의 *현재 점에서의 정확한 Newton correction*은, inverse-Jacobian과 2차 미분이 균일하게 유계인 regular chart에서 O(h⁶) 오차를 준다. 이전 점의 Jacobian을 고정한 chord correction은 일반적으로 O(h⁴)까지만 보장되므로 같은 주장을 할 수 없다.

### 1.4 Fold continuation

Pseudo-arclength의 bordered matrix가 가역이라는 사실은 algebraic solution curve의 continuation을 정당화한다. 지정된 물리 시간 방향으로 원래 reduced ODE가 계속 존재한다거나 물리적 branch 선택이 유일하다는 뜻은 아니다.

## 2. 엄격한 W-order의 깊이 장벽

### 정리 1

다음 형태의 보통 Rosenbrock-W stage를 고려한다.

(I−γ_i hW)k_i = h F(y+Σ_(j<i) a_ij k_j)+hW Σ_(j<i)c_ij k_j.

계수는 h에 무관하고, 같은 step의 DAG만 사용하며, 고차 미분 oracle나 이전 step의 multivalue 정보를 쓰지 않는다. '엄격한 W-order p'는 모든 고정된 bounded W에 대해 고전적 차수 p를 갖는다는 뜻이다. 이때 F-evaluation DAG의 깊이 D는 D≥p이다.

**증명.** W=0을 선택하고 F(y)=λy를 적용한다. stage는 explicit RK가 된다. 첫 level은 z=hλ에 대한 1차 다항식이고, 한 dependency level은 차수를 최대 1 증가시킨다. 따라서 안정성 다항식의 차수는 D 이하이다. p차 정합성은 z^p/p! 항을 요구하므로 D≥p. □

따라서 variable γ_i만으로 depth<5인 엄격한 W5를 만들 수 없다. 이 결론은 W=J를 정확히 쓰는 Rosenbrock, W−J=O(h^r) 등으로 허용 W를 제한하는 방법, multivalue/peer 방법, 고차 derivative method에는 그대로 적용되지 않는다.

## 3. Common-γ, depth=5의 선형 안정성 chart가 닫힘

이전 necessary-condition 유도에 따라

R(z)=N_g(z)/(1−gz)^5,

N_g(z)=1+(1−5g)z+(1/2−5g+10g²)z²
 +(1/6−5g/2+10g²−10g³)z³
 +(1/24−5g/6+5g²−10g³+5g⁴)z⁴.

5차 정합성과 R(∞)=0은

P_g(g)=120g⁵−600g⁴+600g³−200g²+25g−1=0

을 준다. 이 polynomial은 서로 다른 양의 실근을 다섯 개 가진다.

허수축에서

|(1−giω)^5|²−|N_g(iω)|² = ω⁶[A(g)+B(g)ω²+g¹⁰ω⁴],

A(g)=(1−30g+330g²−1680g³+3960g⁴−3600g⁵+720g⁶)/72,

B(g)=(−1+40g−640g²+5280g³−24240g⁴+62400g⁵−86400g⁶+57600g⁷−11520g⁸)/576.

g>0이면 극점은 우반평면에 있다. 양의 leading coefficient를 갖는 quadratic A+Bs+Cs²가 모든 s≥0에서 nonnegative일 필요충분조건은

A≥0 그리고 [B≥0 또는 B²≤4AC].

Wolfram `Reduce`와 별도 유리수 isolating interval + interval polynomial sign 검증이 모두 세 번째 근만 허용했다.

**결론:** g*=0.27805384113645232493158618511929991618… 하나가 선형 L-stability를 만족한다. 나머지 네 근은 A-stability에서 탈락한다. A와 B가 이 근에서 둘 다 양수임도 정확한 부호 검사로 확인했다.

이것은 scalar stability function에 대한 완결된 판정이지, full nonlinear Rosenbrock-W tableau의 존재 증명이 아니다.

## 4. 깊이 장벽의 전제를 바꾸는 일반 rational-jet 정리

Taylor jet을

d_k(y)=L_F^(k−1)F(y)/k!,   T_p(y;h)=y+Σ_(k=1)^p h^k d_k(y)

로 정의한다. 재귀식은 d_1=F, d_(k+1)=D d_k[F]/(k+1)이다.

Q(z)=1+q_1 z+…+q_r z^r, r≤p라고 하자. Π_≤p는 h에 대한 p차 이하 절단이다. 다음 수치 map을 정의한다.

S_p=Π_≤p{Q(hW)[T_p−y]},

Φ_p^Q(y;h)=y+Q(hW)^−1 S_p.

### 정리 2: 고전적 p차

F의 필요한 derivatives와 W가 bounded이고 Q(hW)의 역이 작은 h에서 유계이며 통상적인 one-step 안정성이 성립하면, 위 방법은 global classical order p이다.

**증명.** 정확한 flow를 φ_h라 하면 φ_h=T_p+O(h^(p+1))이다. 또한

Q(hW)Φ_p^Q = Π_≤p[Q(hW)T_p].

따라서 Q(hW)(Φ_p^Q−φ_h)=O(h^(p+1)), 즉 local error O(h^(p+1))이다. 안정성과 합하면 global p차이다. W가 F'와 같을 필요는 없고, W와 F'의 교환도 가정하지 않았다. 다만 이 O 기호의 상수가 stiffness parameter와 독립이라는 주장은 아니다. □

이 방법은 F-evaluation만 쓰는 보통 Rosenbrock-W가 아니다. 고차 flow jet이라는 더 강한 oracle를 사용하므로 정리 1과 모순되지 않는다. AD로 jet을 만든다는 것은 고차 미분 비용이 사라진다는 뜻이 아니다.

### 정리 3: 선형 안정성 설계의 전달

P(z)/Q(z)=exp(z)+O(z^(p+1)), deg P≤p라고 하자. 선형 문제 F(y)=Jy, W=J에서는

Φ_p^Q(y;h)=P(hJ)Q(hJ)^−1 y.

**증명.** d_k=J^k y/k!를 대입하면 QΦ=Π_≤p[Q exp(hJ)]y=P(hJ)y이다. □

이는 임의 차원에 성립하며 F가 cubic일 필요도 없다.

## 5. 구체적인 L-stable 5(4) pair

### 5.1 주 방법

분자 2차, 분모 3차로 Q exp−P의 0~5차 계수를 0으로 두었다. 정확한 coefficient ideal의 Gröbner basis는

{1+60q3, −3+20q2, 3+5q1, −1+20p2, −2+5p1, −1+p0}.

따라서 유일한 해는

P5=1+2z/5+z²/20,

Q5=1−3z/5+3z²/20−z³/60.

R5=P5/Q5는 exp(z)+z⁶/7200+O(z⁷)이다.

### 5.2 L-stability의 직접 인증

Q5(−s)=1+(3/5)s+(3/20)s²+s³/60이다. cubic Hurwitz 부호 조건에서 모든 coefficient가 양수이고

(3/20)(3/5)−1/60=11/150>0.

따라서 Q5는 닫힌 좌반평면에 영점이 없다. 또한

|Q5(iω)|²−|P5(iω)|²=ω⁶/3600≥0.

무한대에서 R5→0이므로 최대모듈 원리에 의해 좌반평면에서 |R5|≤1이고, R5는 L-stable이다. 이것은 모든 비정규 matrix에 대해 임의 norm의 ||R5(hJ)||≤1이라는 주장이 아니다.

### 5.3 저차 방법과 estimator

동일한 구성에서 p=4,

P4=1+z/4,

Q4=1−3z/4+z²/4−z³/24

를 사용한다. R4=exp(z)+z⁵/480+O(z⁶)이다.

Hurwitz margin은 (3/4)(1/4)−1/24=7/48>0이고,

|Q4(iω)|²−|P4(iω)|²=ω⁶/576.

따라서 저차 partner도 선형 L-stable이다. 두 nonlinear map은 같은 F, W 및 d1…d5를 공유할 수 있고 차이는 고전적으로 O(h⁵)이다. 선형 정확-W 문제에서는

R5−R4=−z⁵/(480 Q5 Q4).

따라서 estimator가 선형 문제 전체에서 항등적으로 0이 되지 않으며 두 방법 모두 stiff limit에서 0으로 간다. 추정오차의 신뢰성, dense output, rejected-step 전략은 추가 검증이 필요하다.

**중요한 실패 사례:** Q5를 그대로 둔 채 절단 차수만 5에서 4로 낮추면, 선형 W=J 문제에서 두 안정성 함수가 같아져 estimator가 0이 된다. 별도 Q4는 이 blocker를 해소한다.

## 6. Shift 병렬화와 안정적인 jet 분해

Q5(z)=Π_(i=1)^3(1−γ_i z)에서 γ_i는

60γ³−36γ²+9γ−1=0

의 근이다. 판별식은 −3888이므로 서로 다른 세 근이며, 한 실근과 한 켤레쌍이다.

γ1≈0.27488882959567736775,

γ2,3≈0.16255558520216131613 ±0.18494932440714078428 i.

Q4도 세 simple poles를 가지며 shift polynomial은 24γ³−18γ²+6γ−1, 판별식 −1296이다. 이 scalar algebraic roots는 offline coefficient 데이터다. ODE step마다 root finder로 다시 풀 필요가 없다.

분자 N의 차수가 3 미만이면

N(z)/Q(z)=Σ_i β_i/(1−γ_i z),

β_i=−γ_i N(1/γ_i)/Q'(1/γ_i).

따라서 각 proper rational action은 독립된 shifted system으로 분해된다. 둘 다 계산하는 adaptive pair는 분모가 서로 다르므로 일반적으로 여섯 논리적 shifts가 필요하다. 실수 문제에서는 켤레 대칭을 활용할 수 있다.

모든 RHS가 미리 알려졌을 때

K_m(I−γ_i hW,B)=K_m(W,B)

이므로 한 block Krylov basis를 공유한다. 임의의 preconditioner, nested closure elimination, step 중 달라지는 W에 이 등식을 무조건 적용하지 않는다. Krylov 재귀·orthogonalization·global reduction도 여전히 serial-depth 비용이다.

### 큰 상쇄를 피하는 affine-linear defect split

단순히 y+h d1+h²d2와 커다란 rational correction을 더하면, stiff linear limit에서 큰 항의 상쇄로 floating-point 문제가 생길 수 있다.

δ_k=d_k−W^(k−1)F/k!, k≥2,

A_(p,k)(z)=Q_≤(p−k)(z)/Q(z)

라 하자. p5에 대해서

Ψ5(z)=(R5−1)/z=(1−z/10+z²/60)/Q5(z).

정확한 항등식은

Φ5=y+h Ψ5(hW)F+Σ_(k=2)^5 h^k A_(5,k)(hW)δ_k.

W=J=F'(y)이면 δ2=0이다. F가 affine이고 W가 정확하면 모든 δ_k=0이므로 큰 pure-linear Taylor 항을 따로 만들 이유가 없다.

J=F', H=F'', T=F''', U=F''''라고 쓰면

δ3=H(F,F)/6,

δ4=[JH(F,F)+3H(F,JF)+T(F,F,F)]/24,

δ5=[J²H(F,F)+3JH(F,JF)+JT(F,F,F)
 +4H(F,J²F)+4H(F,H(F,F))+3H(JF,JF)
 +6T(F,F,JF)+U(F,F,F,F)]/120.

이렇게 pure-linear rooted-tree 항을 기호적으로 제거한 뒤 AD 방향미분으로 계산하면 '두 큰 jet을 계산한 다음 빼기'를 피할 수 있다. 그럼에도 고차 directional derivative와 그 dependency DAG는 실제 비용이며, 구현·benchmark 전에는 빠르다고 판정하지 않는다.

## 7. 논문의 quotient를 closure branch에 실제 적용

예제 G(u,q)=q³−q+u=0을 사용한다. 여기서는 f 대신 G의 branch 구조를 다룬다.

동일 u에서 서로 다른 두 roots를 q±=m±d로 놓고 H=d²로 quotient하면

(G(u,m+d)+G(u,m−d))/2 = m³+3mH−m+u,

(G(u,m+d)−G(u,m−d))/(2d) = 3m²+H−1.

따라서 H≠0인 off-diagonal chart의 shape representation은

8m³−2m−u=0,   H=1−3m².

원 closure의 판별식은 Δ(u)=4−27u²이고, unordered-pair cubic의 판별식은 64Δ(u)이다. 같은 branch collision locus를 정확히 복구한다.

이것은 논문의 witness-swap quotient 방법을 root branch collision에 적용한 계산이다. 실근 여부, 어떤 branch를 초기조건이 선택했는지, continuation 방향은 별도 데이터다.

### Saturation은 fold 근방 수치 admissibility를 대체하지 않는다

정칙 chart는 Gq=3q²−1≠0이다. Rabinowitsch 표현

<G,1−η(3q²−1)>

을 쓸 수 있다. 하지만 η를 제거하면 ideal <G>가 다시 나오며, 그 affine closure에는 fold도 들어 있다. 이것이 원문 Artinian 조건의 필요성과 동일한 현상이다. 계산에서는 localization 조건과 수치적 lower bound를 계속 유지해야 한다.

G_u=1이므로 전체 algebraic curve는 매끄러워도 q=q(u) chart는 fold에서 깨진다. q를 parameter로 쓰면 u=q−q³로 매끄럽게 기술되지만, 지정된 시간 방향의 physical branch가 계속 존재한다는 뜻은 아니다.

일반 polynomial closure에서는 Jacobian minors, discriminant/critical-value ideal, quotient shape chart를 offline으로 구하고, online에서는 regularity와 실제 inverse action 크기를 검사하는 구조가 가능하다. 상태 차원이 커지면 global elimination은 폭증할 수 있으므로 작은 closure block 또는 parameter slice부터 시작한다.

## 8. Normal reflection은 root contraction을 자동으로 주지 않음

실수 양의정부호 계산 metric을 택하고, regular constraint manifold에 대한 국소 metric projection을 Π_M라 하자. R_M=2Π_M−I의 해에서의 미분은 2P_T−I이며 등거리 reflection이다. 두 reflection의 합성도 선형화 수준에서 등거리이므로 그 자체로 contraction theorem을 얻지 못한다.

G(u,q)=q³−q+u와 고정 u 평면의 교점을 고려한다. a=Gq이고 normal=(1,a)이다. 두 reflection을 평균한 map T=(I+R_N R_M)/2의 미분은

DT=1/(1+a²) [[1,a],[-a,1]],

(DT)^T DT=I/(1+a²).

따라서 a≠0에서 국소 수축률은 1/sqrt(1+a²)이지만 fold a→0에서는 1로 간다. '반사 두 번'이 Jacobian pathology를 해결했다는 주장은 성립하지 않는다.

국소 좌표 w=q+K(u−u0)를 쓰면 transformed normal은 (1−aK,a)이다. K=1/a이면 접공간을 평탄화할 수 있지만, 이것은 inverse derivative 정보를 이미 사용한 것이다. 정확한 inverse 대신 recycled tangent approximation을 amortize하는 방향이 현실적인 연구 대상이다.

## 9. 2D/cubic을 넘어서는 범위

### 9.1 arbitrary degree even/odd quotient

F가 d차 polynomial이고 n(x)는 고정된 x에서 평가한 normal direction이라고 하자. H=λ², λ≠0에서 F(x±λn)=0과 F(x)=0은

E(x,H)=Σ_(j=1)^floor(d/2) H^(j−1) D^(2j)F[n^(2j)]/(2j)!=0,

O(x,H)=Σ_(j=0)^floor((d−1)/2) H^j D^(2j+1)F[n^(2j+1)]/(2j+1)!=0

로 정확히 표현된다. 이는 Taylor의 even/odd 분리만으로 증명되며 ambient dimension과 무관하다. Cubic에서는 E=F''[n,n]/2, O=F'[n]+H F'''[n,n,n]/6로 원문을 복구한다.

그러나 n차원 hypersurface에서 미지수 x와 H는 n+1개, 방정식은 세 개이므로 expected dimension은 n−2이다. 평면의 유한한 길이를 고차원 유한 root count로 그대로 옮길 수 없다.

### 9.2 two-normal matching의 차원 장벽

ambient N, codimension r의 manifold에서 normal frames를 N1,N2∈R^(N×r)라 하자. 논문의 matching은

[N1 N2](α,β)^T=m1−m2.

모든 chord에 대해 유일한 matching을 보장하는 square invertible 조건은 2r=N이다. 2r<N이면 chord가 column space에 속한다는 추가 incidence가 필요하고, 2r>N이면 일반적으로 uniqueness가 없어 gauge 또는 별도 선택 규칙이 필요하다. 따라서 plane-curve carrier를 n차원에 그대로 복사할 수 없다.

### 9.3 방법 coefficient 공간의 chart 정책

차수조건 ideal, DAG zero pattern, normalization, denominator 및 rank 조건을 분리한다. distinct-shift discriminant를 invert한 chart만 계산하면 repeated/common-γ 방법을 잃으므로 equality chart도 별도로 남긴다. 한 finite scheme의 squarefree eliminant와 graph substitution은 그 component의 존재를 증명할 뿐 다른 chart의 부재를 증명하지 않는다. 이 구분을 모든 solver coefficient 탐색에 그대로 적용한다.

## 10. 검증 상태와 실행 계약

- 연결 Wolfram: resultant/Bézout, exact gamma A-stability classification, fifth/fourth rational coefficient system 및 허수축 항등식, selected source cubic checks, closure quotient, reflection identity를 실제 계산했다.
- 독립 SymPy/mpmath: `proofs/verify_exact.py` 33/33 checks. 유리수 isolating intervals, 2D/3D noncommuting W order coefficients, scalar nonlinear refinement 포함.
- scalar y'=y², y(0)=1, t_final=1/2, N=8,16,32,64에서 exact-J mode의 마지막 observed order 4.95639618415837; W=0 mode 4.93445984302155. 이것은 한 nonstiff toy의 asymptotic check이며 performance benchmark가 아니다.
- 원본 전체 Wolfram core/atlas: 이번 작업에서 실행하지 않았다.
- 전체 `verify_exact.wl` local replay: container에 kernel이 없어 실행하지 않았다. 개별 계산 block은 연결 kernel에서 실행했다.
- matrix-free AD/Krylov production implementation: 미구현.
- full nonlinear Rosenbrock-W depth-five tableau: 존재 판정 미완료.
- nonlinear stiff-uniform order, positivity, event/dense output, repeated rejection, nonnormal sensitivity, inexact AD/closure action: 추가 검증 필요.
- RODAS5P/BDF/Radau 대비 wall-clock 우월성: 미검증.

### 다음 최소 연구 실험

우선 rational-jet 5(4)의 dense reference를 작은 analytic systems에서 구현해 정확한 jet, defect split, scalar L-stability, nonnormal perturbation, closure branch crossing을 분리 검증한다. 이후 identical acceptance/error contract를 가진 AD + shared block Krylov implementation으로 옮긴다. 비용은 N_F, 각 차수 AD directional action, N_Wv, Krylov dimension, synchronization, closure tangent solve, peak memory와 wall-clock으로 분해한다.

후보를 버리는 조건은 전체 workload에서 jet 생성 비용 또는 필요한 Krylov dimension이 기존 stage chain 절감보다 지속적으로 커지는 경우다. 비선형 stiff-order 감소가 발생하면 추가 W correction 또는 problem-specific splitting을 연구하며, 고전적 5차 증명을 stiff-uniform 5차로 확대 해석하지 않는다.
