# 연구 루프 2: 강직 차수의 반례, rational VoC-jet 수정, 정칙 기하의 계산 계약

Date: 2026-10-02

## 0. 결론과 근거 상태

이 루프는 앞선 rational-jet 5(4)를 production solver로 승격하지 않는다. 이전 33개 검산을 실제 재실행했으며 결과는 33/33이다. 이번에는 새로 작성한 두 연구용 검증기에서 64/64와 56/56, 합계 120/120 검사를 실행했다. 이 수에는 반례의 정확성을 검사한 항목이 포함된다. 120/120은 integrator가 모든 문제에 성공한다는 뜻이 아니다.

주요 성과는 다음과 같다.

1. 이전 RJ5는 정확한 Jacobian과 정확한 arithmetic에서도 cubic Prothero–Robinson(PR)형 문제에서 uniform order가 3으로 떨어진다.
2. Variation-of-constants에 맞춰 jet을 재결합한 RVJ5를 구성했다. 같은 Q5와 세 개 shifted operator를 유지한다. 고전적 5차와, 명시적인 PR 문제군에서 lambda에 독립적인 uniform 5차 오차경계를 증명했다.
3. 임의의 작은 고정 상대 오차를 갖는 W 대체는 이전 RJ5와 새로운 RVJ5 모두의 stiff stability를 파괴할 수 있다. Krylov basis/preconditioner 재사용과 실제 미분 연산자 대체를 엄격히 구별해야 한다.
4. 불변 ideal, 유한 epsilon 불변 graph, 정칙 closure의 Newton–Hensel lift, 무한대로 도주하는 branch, 기하적 fast-block resolvent를 실제 계산했다.
5. production AD, Krylov 반복 성능, 일반 비선형 stiff-uniform 5차, positivity, adaptive controller, RODAS5P/BDF/Radau 대비 wall-clock 우열은 미검증이다.

상세 근거는 `results/loop2_verification.json`, `results/rvj_verification.json`, `proofs/*.py`, 연결 Wolfram 계산 요약과 재현용 `.wl`에 있다. 원전과 본 루프의 직접 유도를 섞지 않기 위해 문헌은 [S1]~[S6], 직접 결과는 T2.x로 구분한다. 문헌 우선권이나 방법의 역사적 새로움은 주장하지 않는다.

## 1. 정의, 가정, 단위

기본 문제는 자율 ODE y'=F(y), y in R^n이다. 시간 의존 문제는 시간 좌표를 포함해 자율화한다. F는 필요한 차수만큼 매끄럽다. h>0는 실제 시간 차원을 갖는 step, W는 한 step 동안 고정한 시간 역수 차원의 선형 연산자다. z=h lambda, hW는 무차원이다. 서로 다른 물리 단위의 상태 성분은 명시적인 고정 스케일로 무차원화한 뒤 norm을 정의한다.

v_j = y^(j)(t_n), d_j=v_j/j!, v_1=F, d_(j+1)=D d_j[F]/(j+1).

v_j의 차원은 [y]/[t]^j이다. 수치 toy의 시간과 변수는 고정 기준값으로 무차원화했다. 비교의 성공조건은 같은 물리 오차에서의 비용이며 accepted-step 수만으로 성능을 판정하지 않는다.

고전적 order와 uniform stiff order는 다르다. 전자는 고정된 문제에서 h->0인 극한, 후자는 stiffness parameter와 독립적인 오차상수에 관한 주장이다. [S1]은 semigroup와 비선형 미분의 균일 유계성을 가정하고, [S2]는 단순 Taylor보다 variation-of-constants에 기반한 stiff order 조건을 다룬다. 이 문헌의 정리가 여기의 유리함수 근사에 자동으로 이전되지는 않는다.

앞선 필터는

P5(z)=1+2z/5+z^2/20,
Q5(z)=1-3z/5+3z^2/20-z^3/60,
R5=P5/Q5.

P4(z)=1+z/4,
Q4(z)=1-3z/4+z^2/4-z^3/24,
R4=P4/Q4.

두 R은 scalar L-stable이다. 이 선형 안정성 결과는 원 패키지에서 증명했으며 이번에 원 검증기를 재실행했다. 이는 비정규 matrix의 임의 norm에 대한 contractivity 또는 일반 비선형 stiff order 증명이 아니다.

## 2. T2.1: 이전 RJ5의 정확한 uniform-order 반례

다음 자율 ODE를 사용한다.

x'=1,
y'=lambda (y-x^3)+3x^2,
lambda<0, x(0)=y(0)=0.

정확한 해는 y=x^3이며 이 해의 모든 필요한 미분은 lambda와 무관하다. 정확한 augmented Jacobian은

J=[[0,0],[6x-3lambda x^2,lambda]].

이전 방법은

T5=yvec+sum_(k=1)^5 h^k d_k,
RJ5=yvec+Q5(hJ)^(-1) Pi_(<=5){Q5(hJ)(T5-yvec)}.

### 정확한 recurrence

e_n=y_n-x_n^3, z=h lambda라고 두면

x_(n+1)=x_n+h,
e_(n+1)=R5(z)e_n+h^3 z^3/(60Q5(z)).

이는 실제 flow jet과 2x2 행렬을 대입해 직접 유도했고, Wolfram과 SymPy가 독립적으로 확인했다. 따라서 e0=0, 일정 h에서

e_N=-h^3 z^2/(z^2-6z+60) [1-R5(z)^N].

z=z0<0를 고정하고 h->0, lambda=z0/h, Nh=T로 보내면 R5(z0)^N->0이고 오차는 일반적으로 h^3에 비례한다. 따라서 uniform order5는 반증된다. 반면 고정 lambda에서 h->0이면 기존 classical order5와 모순되지 않는다.

lambda->-infinity, h 고정에서는 one-step defect가 정확히 -h^3으로 간다. 이 실패는 Jacobian assembly, finite difference, Krylov residual, 부동소수점 오차가 원인이 아니다.

### p와 분모 차수 r에 대한 일반화

x'=1, y'=lambda[y-phi(x)]+phi'(x), W=정확한 augmented J를 사용한다. Q의 차수 r<=p-1이고 시작점이 정확한 graph 위에 있다고 하자. 이전 rational-jet map은

y_(n+1)=phi(x)+h phi'(x)
 +sum_(k=2)^p h^k/k! [Q_(<=p-k)(z)/Q(z)] phi^(k)(x).

증명: 첫 jet은 (1,phi')이고 이후 jet은 (0,phi^(k)/k!)이다. augmented J의 삼각 구조를 사용하면 첫 jet에서 생긴 off-diagonal 항은 해를 구할 때 정확히 상쇄되고, 나머지 수직 jet에는 위 truncated Q 비율만 남는다.

k<=p-r에서는 비율이 1이다. 첫 누락 차수 k0=p-r+1에서는 비율이 z->-infinity에서 0으로 간다. phi=x^k0를 고르면 정확한 h^k0 forcing defect가 남는다. 따라서 이 클래스와 이러한 필터 가정에서 PR uniform order는 p-r+1을 넘을 수 없다. p=5,r=3이면 3이다. 일반적인 모든 stiff ODE에서 3차가 보장된다는 주장은 아니다.

## 3. T2.2: W의 작은 고정 상대 오차는 stiff stability를 보존하지 않음

F(y)=lambda y, 정확한 flow jet을 사용하되 W=alpha lambda, alpha>0라고 하자. 이전 RJ5의 증폭함수는

R_alpha(z)=1+[sum_(k=1)^5 z^k/k! sum_(j=0)^min(3,5-k) q_j(alpha z)^j]/Q5(alpha z).

Q5+분자의 최고차 z^5 계수는 (1-alpha)^3/120이다. 따라서

lim_(z->-infinity) R_alpha(z)/z^2=(alpha-1)^3/(2alpha^3).

alpha!=1인 모든 고정 상대 오차에 대해 무한 강직 극한에서 증폭이 발산한다. alpha=1.01,z=-10000에서는 R_alpha=49.959960191602811311...이다.

이것은 'classical order가 모든 bounded W에 대해 5'라는 이전 정리와 모순되지 않는다. bounded W를 가정한 h->0 정리는 W가 stiffness와 함께 무한히 커지는 극한에 관한 것이 아니다.

운영적으로 아래를 구별한다.

- 이전 Krylov basis와 preconditioner를 재사용하지만 현재의 정확한 target operator Jv에 대해 residual을 제어한다.
- integrator의 operator 자체를 이전 W나 low-rank W로 대체한다.

첫 번째는 linear solve approximation, 두 번째는 방법 자체의 변경이다. 이 루프가 robust하게 허용하는 것은 첫 번째이지 두 번째의 무조건 허용이 아니다.

## 4. T2.3: rational variation-of-constants jet (RVJ5) 구성

[S1,S2]의 variation-of-constants 관점을 가져오되, 아래 유리함수 구성과 증명은 본 루프에서 직접 수행했다. exact exponential phi_j와 rational phi_j^R는 다른 함수임에 주의한다.

### 유리 phi 계수

phi_j^R(z)=[R5(z)-sum_(ell=0)^(j-1) z^ell/ell!]/z^j, j=1,...,5.

z=0의 singularity는 removable이다. 정확한 표현은 phi_j^R=N_j/Q5이며

N1=(z^2-6z+60)/60,
N2=(z^2-8z+30)/60,
N3=(z^2-7z+20)/120,
N4=(z^2-6z+15)/360,
N5=(z^2-5z+12)/1440.

모든 분자는 2차이고 동일한 세 simple poles를 공유한다. 따라서 수정식은 main method에 필요한 논리적 shifted operator 수를 증가시키지 않는다.

핵심은 z=0의 차수 일치뿐 아니라 모든 z에서의 함수 항등식이다.

z N1=P5-Q5,
N_j-z N_(j+1)=Q5/j!, j=1,...,4.

N_j의 15개 계수를 미지수로 두면 위 polynomial coefficient ideal은 유일한 유리수 해를 갖는다. 이 부분은 선형 coefficient system이므로 무거운 Groebner 계산이 필요하지 않다. 정확한 해와 항등식을 검증기에 저장했다.

### 알고리즘 식

nu_k=v_(k+1)-W v_k, k=1,...,4.

RVJ5(y)=y+h phi_1^R(hW)F
 +sum_(k=1)^4 h^(k+1) phi_(k+1)^R(hW)nu_k.

F와 W와 v_j는 모두 같은 step 기준점에서 평가한다. W는 그 step 내에서 고정한다. 각 nu_k의 단위는 [y]/[t]^(k+1)이므로 모든 합의 단위는 [y]이다.

W=J일 때 nu1=0이다. H=F'', T=F''', U4=F''''라고 쓰면

nu2=H(F,F),
nu3=3H(F,JF)+T(F,F,F),
nu4=4H(F,J^2F)+4H(F,H(F,F))+3H(JF,JF)
     +6T(F,F,JF)+U4(F,F,F,F).

이를 먼저 기호적으로 단순화하면 pure-linear Taylor tower를 계산한 뒤 빼는 불필요한 cancellation을 줄일 수 있다. 그러나 고차 directional AD와 J(JF)의 실제 순차 의존성은 남는다.

### 동치 compact form과 고전적 차수 증명

phi_j^R-z phi_(j+1)^R=1/j!를 각 v_j에 적용하면 telescoping으로

RVJ5=y+sum_(j=1)^4 h^j v_j/j! + h^5 phi_5^R(hW)v5.

phi_5^R(0)=1/120이므로 bounded W와 충분한 regularity에서 T5+O(h^6)이다. 통상적인 one-step 안정성과 합하면 classical global order5이다. W와 J의 교환은 필요하지 않다.

compact form은 증명에 유용하지만 stiff linear 항의 큰 cancellation 때문에 구현 기본형으로 권하지 않는다. 실제 reference도 nonlinear-defect/VoC 형태를 계산했다.

F(y)=Jy, W=J이면 모든 nu_k=0이고 RVJ5=R5(hJ)y이다. 따라서 scalar L-stability는 기존 R5와 동일하다.

### 4차 partner

R4=P4/Q4로 같은 정의를 적용해 j=1,...,4를 사용한다. 분자는

N1,4=(z^2-6z+24)/24,
N2,4=(z^2-5z+12)/24,
N3,4=(z^2-4z+8)/48,
N4,4=(z^2-3z+6)/144.

고전적 4차이며 선형 함수는 R4이다. 두 방법의 선형 차이는 여전히

R5-R4=-z^5/(480 Q5 Q4)

로, 전체 선형 문제군에서 항등적으로 0인 estimator를 피한다. full pair는 최대 여섯 논리적 shifts를 사용한다. adaptive estimator의 일반적인 effectivity나 stiff controller의 신뢰성을 증명한 것은 아니다.

## 5. T2.4: RVJ5의 PR 문제군 uniform 5차 정리

### 전제

x'=1,
y'=lambda[y-phi(x)]+phi'(x), lambda<=0는 상수,
phi는 [x0,x0+T]에서 C6이고 M_j=sup|phi^(j)|, j=5,6이 lambda와 무관하게 유계이다.

각 step에서 정확한 augmented J와 flow jets를 사용한다. h_n>0은 일정할 필요가 없다. hmax=max h_n, sum h_n<=T. e_n=y_n-phi(x_n).

### 정리

|e_N| <= |e0| + hmax^5 [M5/120 + T M6/720].

따라서 정확한 초기조건 e0=0에서 lambda<=0 전체에 대해 uniform global 5차다.

### 증명

정확한 순간 flow derivative는

v_j=(delta_(j,1), phi^(j)(x)+lambda^j e), j>=1.

compact form에 대입하면 정확히

e_(n+1)=R5(z_n)e_n
 +h_n^5[phi_5^R(z_n)-1/120]phi^(5)(x_n)-r_(6,n),

|r_(6,n)|<=h_n^6 M6/720, z_n=h_n lambda<=0.

음의 실수축에서 0<R5(z)<=1이다. P5=((z+4)^2+4)/20>0,
Q5(-s)=1+3s/5+3s^2/20+s^3/60>0,
Q5(-s)-P5(-s)=s+s^2/10+s^3/60>=0으로 확인된다.

또한 정확한 핵심 항등식은

[phi_5^R(z)-1/120]/[1-R5(z)]
 =-(z^2-4z+11)/[120(z^2-6z+60)].

z<=0에서 우변의 절댓값은 1/120 이하이다. 따라서 한 step에서

|e_(n+1)|<=R_n|e_n|+(1-R_n)hmax^5 M5/120+h_n^6 M6/720.

전개하면 damping weight 합은

sum_j (1-R_j) product_(k>j) R_k=1-product_j R_j<=1.

또한 sum h_n^6<=T hmax^5이다. 이를 합하면 정리가 성립한다. lambda=0의 경우는 연속 극한으로 포함된다. □

이 정리는 단일 cubic 예제가 아니라 C6 함수 phi, 임의 양의 step sequence를 포함한다. 그러나 일반 vector stiff nonlinear system의 uniform5 정리로 확대하지 않는다. 특히 time-dependent lambda, nonnormal coupling, 여러 fast modes, off-manifold initial layers에는 별도 증명이 필요하다.

### 검증

z=-40, T=1, N=8,16,32,64에서

- phi=x^3: 기존 RJ5의 observed order는 3, RVJ5의 오차는 80자리 reference에서 0.
- phi=x^5: RVJ5 observed order 4.99999999995, 5, 5.
- phi=x^6: RVJ5 observed order 4.91527, 4.95943, 4.98014.
- phi=sin(x), lambda=-10000, 교대 variable h=(1/32,3/32)를 사용해 위 정리의 경계 안에 들어감을 확인했다.
- y'=y^2의 별도 nonstiff refinement에서 마지막 observed order는 4.94004.

값 전체는 `results/rvj_verification.json`에 있다.

### 해결되지 않은 W 대체 문제

새 방법에서도 F=lambda y, W=alpha lambda이면

RVJ_R_alpha(z)=T4(z)+alpha^(-5)[R5(alpha z)-T4(alpha z)],

lim RVJ_R_alpha(z)/z^4=(alpha-1)/(24alpha).

따라서 fixed relative W error의 stiff 불안정성은 남으며, 성장 차수는 오히려 더 높을 수 있다. '수정된 RVJ5가 approximate-J pathology까지 해결했다'는 주장은 금지한다.

## 6. T2.5: 불변 ideal과 좌표변환에 의한 강직 기하 분리

Polynomial vector field F와 constraint vector C에 대해 정확한 ideal membership certificate

D C(y)F(y)=B(y)C(y)

를 얻었다고 하자. 이는 다항식 계수 비교 또는 Groebner normal form과 syzygy로 검증할 수 있다. trajectory를 따라 C'=B(y(t))C이므로 C(y0)=0이면 C(y(t))=0이다. 이것은 단순 residual fitting이 아니라 정확한 불변성 증명이다.

정칙 graph chart에서 좌표 (x,w=C(x,q))를 사용하면

x'=a(x,w), w'=Btilde(x,w)w.

w=0에서 모든 transverse flow jet은 0이다. W의 lower-left block도 0인 compatible 구조를 사용하면, rational numerator와 denominator가 block upper triangular이므로 이전 RJ5 및 RVJ5 모두 w=0을 정확히 보존한다. reduced x dynamics의 미분, 재구성 chart와 one-step 안정성 상수가 stiffness와 무관하게 유계이면, well-prepared manifold 위에서는 reduced classical order가 곧 uniform order가 된다.

cubic PR에서는 C=y-x^3, C'=lambda C이므로 x'=1,w'=lambda w이다. y=(x+h)^3 복원이 정확하다. 추가 검증으로 x'=x^2,w'=lambda w,y=x^3,e0=0인 nonlinear slow problem에서 reconstruction error가 lambda와 정확히 독립이고 5차에 접근함을 확인했다.

이것은 arbitrary initial state를 manifold에 projection해도 된다는 허가가 아니다. w0!=0이면 그 빠른 이완을 유지해야 한다.

### Critical equilibrium graph와 유한 epsilon 불변 graph의 구별

x'=1, y'=-(y-x^3)/epsilon에서 C0=y-x^3는

C0'=-C0/epsilon-3x^2

이므로 불변이 아니다. 실제 invariant graph q_epsilon은

q_epsilon+epsilon q_epsilon'=x^3

를 만족해야 한다. cubic ansatz의 계수를 정확히 풀면

q_epsilon=x^3-3epsilon x^2+6epsilon^2 x-6epsilon^3.

그때 C_epsilon=y-q_epsilon은 정확히 C_epsilon'=-C_epsilon/epsilon이다. 일반 polynomial phi의 차수가 d라면

q_epsilon=sum_(j=0)^d (-epsilon)^j phi^(j)

가 같은 항등식을 만족한다.

일반 slow-fast system x'=f(x,q), epsilon q'=-G(x,q)의 graph invariance 식은

G(x,q_epsilon)+epsilon Dq_epsilon f(x,q_epsilon)=0.

G_q(x,q0)가 가역이면 epsilon 계수 전개에서 각 새 q_j는 같은 G_q(x,q0)에 선형으로 들어간다. 이는 formal asymptotic construction이며 수렴을 보장하지 않는다. 수치 오차 예산에는 단순 G residual이 아니라 이 invariance residual도 필요하다.

근사 graph qhat의 residual B_m=G(x,qhat)+epsilon Dqhat f(x,qhat)라 하자. transverse vector field가 영역 내에서 one-sided Lipschitz constant <=-sigma/(2epsilon)를 가지면

|e(t)|<=exp[-sigma t/(2epsilon)]|e0|+(2/sigma)sup|B_m|.

증명: error equation의 forcing은 -B_m/epsilon이고 contraction inequality에 적분인자를 적용한다. graph geometry와 chart bounds는 이 가정에 포함되어야 한다. 단지 det Gq!=0인 것만으로 transverse attraction을 주장할 수 없다.

## 7. T2.6: 정칙 closure의 formal etale lift와 Newton–Hensel 계산

[S3,S4]의 Jacobian 기준과 formal etale의 unique infinitesimal lifting 성질을 다음 계산 문제에 적용한다. square polynomial G(x,q)=0, known point (x0,q0), Gq0 가역, 입력 path x(theta)가 주어졌다고 하자. theta는 무차원 formal parameter다.

A_p=k[theta]/(theta^(p+1))에서 q(0)=q0을 유지하는 q(theta)는 유일하다. 이는 계수 차수마다 미지의 새 계수가 동일한 Gq0와 곱해지는 사실로도 직접 증명된다.

q^(r)가 G residual O(theta^r)를 만족하면

q^+=q^(r)-[Gq(x(theta),q^(r))]^(-1)G(x(theta),q^(r))
   mod theta^min(2r,p+1)

는 residual O(theta^min(2r,p+1))를 갖는다. 보정량 O(theta^r)의 제곱부터 비선형 Taylor remainder가 시작하기 때문이다. 역은 truncated power-series algebra 안에서 계산한다. base Jacobian만 고정한 chord와 다르다.

p=5에서는 modulo theta^2, theta^4, theta^6의 세 formal Newton round가 충분하다. 이것은 실제 유한 h에서 root solver가 반드시 세 번 만에 끝난다는 뜻이 아니다. 특정 구조에서는 더 적은 round도 가능하다.

A(theta)=sum A_j theta^j, A0 가역일 때 formal correction c(theta)의 계수는

A0 c_k=g_k-sum_(j=1)^k A_j c_(k-j)

로 계산한다. 같은 base operator를 재사용하지만 내부 convolution과 선형 solve의 비용 및 순차 의존성은 남는다. 큰 차수에서는 matrix-series Newton inversion 또는 relaxed convolution이 별도 최적화 대상이다.

### 실제 계산

scalar G=q^3-q+u, u=theta, q0=0:

q(theta)=theta+theta^3+3theta^5 mod theta^6.

vector closure

G1=q1^2+q2-u1,
G2=q2^2+q1-u2,
q0=(1,1), u0=(2,2), Gq0=[[2,1],[1,2]], det=3,
u1=2+theta, u2=2-2theta+theta^2.

5차 lift를 계산하고 residual modulo theta^6=0, 별도의 coefficient-by-coefficient solve와 동일함을 확인했다. 전체 계수는 JSON에 있다.

### 실제 root에 대한 별도 certificate

formal equality는 실제 h의 수렴 반경이나 root identity를 보장하지 않는다. [S6]의 certified root 접근 역시 approximation과 certification을 구분한다. 이번에는 alphaCertified를 실행하지 않고 다음 간단한 contraction certificate를 직접 사용했다.

B는 고정 approximate inverse, beta=||BG(qpred)||,
ball radius rho에서 sup||I-BGq||<=kappa<1,
beta+kappa rho<=rho.

그러면 T(q)=q-BG(q)는 ball을 자신으로 보내는 contraction이고, 유일한 root q*가 그 안에 있으며

||qpred-q*||<=beta/(1-kappa).

G=q^3-q+u, u=1/10, qpred=10103/100000,
rho=1/1000, |q|<=1/5, B=-1,
kappa=3/25,
beta=1219362727/10^15.

위 inequalities를 정확한 유리수로 검증했다. 인증된 root distance bound는 110851157/80000000000000이다. 이는 그 ball 안의 uniqueness이며 모든 algebraic roots의 전체 분류는 아니다.

## 8. T2.7: discriminant만으로는 branch atlas가 충분하지 않음

정칙 Jacobian은 local projection chart를 보장하지만 global finite/proper mapping을 보장하지 않는다. [S3]에서도 etale와 finite를 동치로 정의하지 않는다.

예제 G(u,q)=u q-1에서 finite critical ideal은

<G,Gq>=<u q-1,u>=<1>.

즉 finite critical point가 없다. 그럼에도 q=1/u는 u->0에서 무한대로 도주한다. q=Qh/Wh로 projective homogenization하면

u Qh-Wh=0.

Wh=0,Qh!=0인 chart를 조사하면 예외는 정확히 u=0이다. 이를 saturation variable과 elimination으로 독립 계산했다.

따라서 실용적인 atlas에는 rank-critical locus 외에도 leading coefficient/infinity locus, 좌표 크기, 물리 admissibility, 현재 branch identity가 필요하다.

fold 예제 q^2-u=0의 branch q=sqrt(u)는

q^(5)=105/(32 u^(9/2)).

고차 jet의 오차상수는 fold에 접근할수록 폭주한다. formal degree를 높이거나 AD를 정확하게 해도 이 기하를 없애지 못한다. chart 변경 또는 arclength continuation은 곡선 자체를 추적할 수 있지만 지정된 시간 방향으로 physical root가 존재한다는 보장은 아니다.

## 9. T2.8: critical-manifold 기하에서 fast-block preconditioner를 직접 도출

[S5]는 fast field f0=P mu의 분해, A=Dmu P의 가역성과 안정성 아래의 projector

Pi=I-P A^(-1)Dmu

를 제시한다. 이는 orthogonal projection일 필요가 없다. 여기서는 O(epsilon^0) reduced dynamics로 full system을 대체하지 않고, 이 분해를 frozen linear solve에 사용한다.

정칙 critical manifold mu=0에서

Jfast=P V/epsilon, V=Dmu, A=V P.

eta=gamma h/epsilon이면 다음은 정확한 항등식이다.

(I-eta P V)^(-1)=I+eta P(I-eta A)^(-1)V
 =Pi+P(I-eta A)^(-1)A^(-1)V.

증명: 첫 식에 I-etaPV를 곱해 I가 됨을 확인한다. 둘째 식은 (I-etaA)^(-1)-I=eta(I-etaA)^(-1)A를 쓴다. A가 안정하고 eta가 적절한 오른쪽 반직선을 따라 무한대로 가면 inverse는 Pi로 간다.

이는 finite stiffness에서 fast dynamics를 보존하면서 선형 inverse를 r x r fast block으로 줄이는 구조다. r이 충분히 작거나 block sparse일 때만 computational saving이 기대된다.

3차원/rank1 예제 P=(1,2,0)^T,V=(1,-1,1),A=-1에서 projector, inverse, stiff limit를 정확하게 검증했다. Pi는 비대칭이다.

manifold 밖에서는 D(Pmu)=(DP)mu+P Dmu이다. (DP)mu를 버리면 다른 operator가 되므로 이 inverse는 기본적으로 preconditioner로 사용한다. 실제 outer Krylov residual은 현재 full J에 대해 계산한다. A invertibility와 negative-real-part spectrum 조건도 유지해야 한다.

## 10. T2.9: shifted solve의 출력 오차 계약

고정 양의정부호 metric H에서

W*H+HW<=0

라고 가정한다. gamma의 실수부가 양수, h>=0이면

||(I-gamma hW)^(-1)||_H<=|gamma|/Re(gamma).

증명: C=1/gamma I-hW에 대해 Re< v,Cv >_H >= Re(1/gamma)||v||_H^2이다. Cauchy–Schwarz로 ||C^(-1)||_H<=1/Re(1/gamma). I-gamma hW=gamma C이므로 원하는 경계가 따른다.

N_j/Q5=sum_i beta_(ij)/(1-gamma_i z)로 두면 RVJ의 모든 matrix functions는 동일한 shifted solves로 구현된다. 합쳐진 RHS

b_i=sum_(j=1)^5 beta_(ij) h^j s_(j-1),
s0=F, s_(j-1)=nu_(j-1) for j>=2

를 먼저 만들면, main update는 y+sum_i (I-gamma_i hW)^(-1)b_i다. 정확한 연산자에 대한 각 residual r_i가 있을 때

||delta y||_H <= sum_i |gamma_i|/Re(gamma_i) ||r_i||_H.

각 matrix-function action을 별도로 계산하는 형태에는 residue |beta_ij|도 포함된다. 또한 source jet error delta s_j에는

sum_(j=1)^5 h^j C_j ||delta s_(j-1)||_H,
C_j=sum_i |beta_ij| |gamma_i|/Re(gamma_i)

를 더한다. 이 경계가 직접 state-error budget으로 들어가야 한다. global order 보존에는 numerical flow의 내부/step 안정성이 추가로 필요하다.

예를 들어 W=[[-1,M],[0,-1]]는 모든 고유값이 -1이지만 h=gamma=1에서 inverse의 off-diagonal entry가 M/4이다. Euclidean norm에서 eigenvalues만으로 uniform bound를 만들 수 없다. H=diag(1,M^2),M>=1을 택하면 transformed W=[[-1,1],[0,-1]]로 dissipative하지만 metric condition number가 M^2다. 물리 norm으로 돌아올 때 큰 상수를 숨기면 안 된다.

실수 dissipative 3x3 예제의 complex shifts에 대해 위 bound를 dense SVD로 검사했다. 동일한 shifts의 partial-fraction 합과 직접 Q5 inverse의 일치도 double precision에서 확인했다. 이것은 실제 Krylov의 iteration count나 병렬 speedup 시험은 아니다.

## 11. 다음 알고리즘 계약과 미완료 사항

현재 구현 가능한 연구 skeleton은 다음과 같다.

1. G의 regularity, chart compactness/infinity boundary, physical branch 및 invariance residual을 확인한다. 필요 시 안정한 algebraic root certificate를 생성한다.
2. known state path가 주어진 regular closure에서는 Hensel lift로 jet을 구한다. coupled ODE/closure path 자체가 미지인 경우에는 별도의 coupled jet construction이 필요하다.
3. 현재 full derivative operator를 기준으로 F와 nu2,nu3,nu4를 준비한다. AD는 이를 정확한 방향미분으로 표현하는 수단이지 complexity를 없애는 수단은 아니다.
4. 세 known RHS를 만들고 shared block Krylov 또는 independent shifted solves를 수행한다. preconditioner와 basis는 재활용할 수 있으나 target operator 변경과 혼동하지 않는다.
5. fourth partner와 error budget을 평가한다. failed root/jet/linear residual gate는 truncation-error reject와 별도로 분류한다.

다음 bounded 연구 단위는 RVJ5의 vector nonlinear stiff order 분석이다. 최소한 semilinear split F=Ay+g(y), 여러 fast eigenmodes, 비정규 off-diagonal coupling, 유한 초기층, variable h, approximate closure jet을 포함하고 exact-J/approximate-W/preconditioned true-J를 분리한다. 일반 theorem이 없다고 전체 solver 개발을 멈추는 것이 아니라, 이미 증명한 PR 및 정칙 기하 영역과 아직 검증되지 않은 영역을 구분해 비교한다.

full nonlinear Rosenbrock-W depth-five tableau 경로와 peer/multivalue 경로는 삭제하지 않았다. 이번 루프는 rational-jet 경로에 반례와 보완식을 추가한 것이다.

## 12. 원전 및 실행 기록

[S1] Hochbruck, Ostermann, Schweitzer, Exponential Rosenbrock-type methods, SIAM J. Numer. Anal. 47(1), 786–803 (2009). KIT author copy의 Assumptions C.1/C.2, defect와 VoC 부분을 확인했다.
[S2] Luan, Ostermann, Exponential B-Series: The Stiff Case, SIAM J. Numer. Anal. 51(6), 3431–3445 (2013), DOI 10.1137/130920204. 출판사 초록/메타데이터를 확인했으며 paywalled 전체 본문을 읽었다고 주장하지 않는다.
[S3] The Stacks Project, Section 10.143, tag 00U0, Etale ring maps.
[S4] The Stacks Project, Section 10.150, tag 00UP, Formally etale maps.
[S5] Feliu, Kruff, Walcher, Tikhonov–Fenichel Reduction for Parameterized Critical Manifolds with Applications to Chemical Reaction Networks, J. Nonlinear Sci. 30, 1355–1380 (2020), DOI 10.1007/s00332-020-09610-3. 공개 본문의 Proposition 1, projection 및 parameterization 부분을 읽었다.
[S6] Hauenstein, Sottile, Algorithm 921: alphaCertified: Certifying Solutions to Polynomial Systems, ACM TOMS 38(4), Article 28 (2012), DOI 10.1145/2331130.2331136; arXiv:1011.1091. 프로그램은 이 루프에서 실행하지 않았다.

원 URL, 실제 조회 범위, 본 루프 적용 범위는 `sources/source_registry.json`에 있다. 외부 원전은 본 루프의 새 theorem을 증명해준다는 의미로 인용하지 않는다.

실행 중 CAS script의 잘못된 symbolic MatrixPower 사용과 Python symbol 생성 실수가 있었으며, `results/FAILURE_REGISTRY.json`에 분류해 남겼다. 이들을 수학적 반례나 환경 단절로 잘못 분류하지 않았다. 최종 검증 스크립트는 모두 실제 재실행했다. 연결 Wolfram의 일부 Limit 호출은 경고를 냈으며 결과는 별도 정확한 항등식 및 SymPy 검산과 대조했다. 연결된 계산 block 실행과 전체 로컬 Wolfram script 실행을 구별한다.
