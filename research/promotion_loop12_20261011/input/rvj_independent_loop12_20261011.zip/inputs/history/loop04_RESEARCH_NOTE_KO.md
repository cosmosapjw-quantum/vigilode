# RVJ 독립 연구 루프 4: witness를 보존하는 causal·adaptive·hybrid 적분

## 0. 범위와 결론

이 루프는 Vigilode PR #70 및 로컬 native 검증과 분리된 수학·reference-code 연구다. 저장소를 읽거나 변경하지 않았고 GitHub mutation을 수행하지 않았다. 이전 raw-coordinate RVJ5의 일반 semilinear 반례, approximate-W의 강직 불안정성, embedded-only estimator의 한계를 유지한다.

이번 결과는 네 가지다. (1) parameter endpoint가 아니라 연속 witness lift를 cache/branch identity의 기준으로 삼는 정칙 tube 계약, (2) prescribed physical-time fold 통과와 단순 chart 변경을 구분하는 event 규칙, (3) Padé fast-mode error의 양의 적분 나머지에서 유도한 진폭 가중 오차상계, (4) 그 상계와 정확 유리수 계산으로 동작하는 모델별 adaptive hybrid RVJ reference 및 물리 오차 공급원이다. 일반 stiff ODE solver 또는 성능 개선의 증명은 아니다.

모든 실행은 exploratory다. `RESEARCH_CONTRACT.md`는 실행 전 고정했고, 원본·반례와 실패를 별도로 보존했다. 지위는 `DERIVED / CAS_CHECKED / EXACT_RATIONAL_REFERENCE_VERIFIED`이며 독립 reviewer에 의한 최종 승격은 `PENDING`이다.

## 1. 첨부 계산기하 보고서에서 실제로 가져온 것

첨부 `curved_mirror_integrated_research_report_v12_source(1).zip`는 2026-06-19 표기의 LaTeX 통합 보고서다. Diagram=decreasing neighborhood tower, connection=Euclidean realizability, mirror transform=witnessed correspondence라는 구별을 보존한다. RVJ state나 ODE를 원문의 diagram/connection과 동일시하지 않는다.

* `01_diagram_transport.tex`: finite covering의 pullback과 path lifting, chamber-preserving homotopy의 불변성. Support topology로 내려가려면 별도의 embedding 조건이 필요하다.
* `02_connection_rank.tex`: nontrivial finite cover에서는 전역적인 scalar branch separation이 막힐 수 있다. 이것은 한 번 선택한 root의 시간경로 lift를 금지한다는 뜻이 아니다.
* `03_fold_surgery.tex`: 정규형 t=v², real witness의 2개 생성/소멸, sqrt(t) separation, complex transposition. Witness cobordism은 매끄러워도 base-time projection은 singular할 수 있다.
* `05_compact_source.tex`: u³-3u-lambda=0, discriminant=27(4-lambda²). 0 주변 loop는 identity, 2 주변 meridian은 두 root를 바꾼다.
* `08_boundary_audit.tex`, `09_exceptional_cone.tex`, `PR12_STATUS.md`: finite critical locus, support collision, projective infinity/positive-dimensional boundary를 구분한다. 7128과 3300은 철회된 숫자이므로 본 연구의 count나 certificate로 사용하지 않는다.

이 원문으로부터 직접 얻는 것은 covering/fold/collision의 구조다. ODE의 adaptive accuracy, Padé remainder, physical error controller는 아래에서 별도로 유도한다.

### 원본 패키지의 재현 한계

제공된 전체 PR11 runner는 현재 환경에서 `ModuleNotFoundError: flint`로 종료했다. 또한 checksum 목록에 있는 `pr11_inputs.py`와 `run_pr11.sh`가 ZIP에 없으며, README의 `run_all.sh`도 없다. Manifest 15개 항목 중 선언된 상대 경로에 존재하는 것은 6개이며, 2개 결과 파일은 data/ 아래에 이동되어 동일 hash로 존재한다. 모든 위치에서 없는 것은 7개다. 실제 존재한 파일들에서는 checksum 불일치가 발견되지 않았다.

따라서 원문의 전체 28-check suite를 재현했다고 하지 않는다. 필요한 discriminant/fold/low-r 식은 SymPy/Fraction으로, source에 동봉된 `modgb.py`는 실제로 import하여 세 좋은 소수에서 degree-3 quotient와 derivative unit ideal을 다시 계산했다. 이들은 총 11개 선택적 check이며 full suite와 별개다.

## 2. 정칙 witness의 causal 계약

G(lambda,q)=0의 정칙 finite covering을 생각하자. ODE의 상태 y가 closure의 base lambda를 결정할 수도 있지만, 아래 명제는 우선 인증된 base path 또는 그 tube가 주어진 경우에 적용한다. 미지인 coupled ODE 경로까지 이미 검증했다고 가정하지 않는다.

### 명제 1: endpoint-only root identity는 일반적으로 불가능하다

닫힌 base loop의 monodromy가 선택한 root를 다른 root로 보낸다면, 현재 base point만을 key로 갖는 single-root cache는 continuous path lift를 보존할 수 없다.

증명: 시작과 끝의 base point는 같지만 유일한 path lift의 endpoints는 다르다. Endpoint key는 두 값을 동일하게 돌려주어야 하므로 둘 중 하나의 lift와 불일치한다. 따라서 cache에는 현재 witness/branch state 또는 그것과 동등한 continuation token이 필요하다. 전체 과거 경로를 매번 저장해야 한다는 명제는 아니다.

원문 cubic의 complexification은 두 실수 변수로 표현된 base와 witness로 이해할 수 있다. 단일 실수 parameter의 정칙 실근들이 fold 없이 서로 교환한다는 주장이 아니다.

### 명제 2: parametric contraction slab

완비 norm 공간의 닫힌 convex ball B(qc,rho), 시간 slab의 base path lambda(s), 고정 가역행렬 B를 생각하자. 다음을 보인다.

    beta >= sup_s || B G(lambda(s),qc) ||
    theta >= sup_{s,q in ball} || I - B G_q(lambda(s),q) ||
    theta < 1, beta + theta*rho <= rho.

각 s에서 T_s(q)=q-BG(lambda(s),q)는 ball을 자신으로 보내는 contraction이다. Banach 정리에 의해 유일한 zero q(s)가 존재한다. G와 lambda의 연속성 및 uniform theta<1로 q(s)도 연속이다. Slab 시작의 inherited root enclosure가 ball 안에 있으면 이 root는 해당 witness의 유일한 연속 lift다.

Endpoint corrector의 작은 residual만으로는 slab을 인증하지 않는다. 새 endpoint root ball이 이전 slab ball 안에 들어가는지도 확인한다. 이것이 branch jumping을 막는 연결 조건이다.

### source cubic에 대한 계산식

q와 lambda를 복소수 두 유리수 성분으로 저장하고 norm을 |Re|+|Im|로 둔다. d=3qc²-3, c=||1/d||_1, Delta>=sup_s||lambda(s)-lambda0||_1이면

    beta = c (||qc³-3qc-lambda0||_1 + Delta),
    theta = c (6||qc||_1 rho + 3rho²).

이는 (qc+e)²-qc²=2qc e+e²와 submultiplicativity에서 따른다. Code는 beta/theta/margin을 Fraction으로 계산한다. Newton 8회는 candidate 생성의 상한일 뿐 정확성의 근거가 아니며, 최종적으로 위 부등식을 통과해야 한다.

실험은 반지름 1/4의 counterclockwise square path를 사용한다. 원문의 원형 meridian과 같은 puncture를 감싸며 임의 endpoint sorting을 하지 않는다. 0 주변에서는 permutation [0,1,2], 2 주변에서는 [0,2,1]을 얻었다. 고정된 root label 순서는 초기 생성기에 따른 것이고 invariant는 cycle type이다. 전체 157개 adaptive slab이 인증되었다. Monic cubic은 compact parameter path 위에서 roots가 유계이므로 이 예제에서는 infinity escape가 없다.

### support 충돌과 witness 소멸의 구분

G(q)=q²-1=0의 두 witness -1,+1은 output q²에서 같은 값 1로 보이지만, closure가 다른 equation에 q 자체로 들어가면 두 dynamics는 다르다. 따라서 observable equality는 witness merge의 충분조건이 아니다. 원문의 support collision과 discriminant의 구별을 이 의미로 사용한다.

## 3. Fold에서는 더 좋은 root finder만으로 충분하지 않다

### 명제 3: real fold와 physical-time obstruction

q²=tau(t), tau'= -nu<0, tau(0)>0이면 t*=tau(0)/nu 이전의 두 real branches는 존재하지만 t>t*에는 real root가 없다. dq/dt=-nu/(2q)는 fold에서 발산한다.

Regular-step 규칙 h_n=theta*tau_n/nu, 0<theta<1을 끝없이 사용하면 tau_n=(1-theta)^n tau_0, sum h_n=t*. 즉 finite physical time에 무한 regular steps가 쌓이는 numerical Zeno가 생긴다.

Pseudo-arclength로 매끄러운 total curve를 추적하는 것은 가능하지만, 이를 t>t*의 real physical solution으로 오인하면 안 된다. 필요한 동작은 (i) event bracket, (ii) 명시적으로 주어진 물리적 reset/branch law, 또는 (iii) 모델 적합성 중단이다. 자동으로 다른 root에 점프하지 않는다.

Reference는 theta=1/2, tau0=nu=1, event tolerance=2^-20에서 20회 후 [1-2^-20,1] bracket과 `FOLD_EVENT_MODEL_DECISION_REQUIRED`를 반환한다. 이는 이 normal form에서 정확히 계산한 event bracket이며 범용 event solver가 아니다.

## 4. Fast-mode 전환 기준을 만드는 Padé 나머지

아래 R은 기존 RVJ5의 [2/3] 유리함수다. 이 유리함수 자체나 certified homotopy라는 발상을 새 발견으로 주장하지 않는다.

    P(z)=1+2z/5+z²/20,
    Q(z)=1-3z/5+3z²/20-z³/60,
    R(z)=P(z)/Q(z).

kappa>0, a=kappa*h>=0이면 a는 무차원이다.

### 명제 4: 양의 적분 나머지와 저비용 상계

정확히

    R(-a)-exp(-a)
      = a^6 / [120 Q(-a)] * integral_0^1 exp(-a s) s³(1-s)² ds.

반복 부분적분으로 우변을 평가하면 P(-a)-Q(-a)exp(-a)가 나온다. a=0은 연속 극한으로 포함한다. Wolfram과 SymPy가 항등식 차이 0을 각각 확인했다.

적분은 음수가 아니며,

    integral_0^1 s³(1-s)² ds = 1/60,
    integral_0^infinity exp(-a s)s³ ds = 6/a^4 (a>0)

이므로

    0 <= R(-a)-exp(-a) <= eta(a),
    eta(a)=min{R(-a), a^6/[7200Q(-a)], a²/[20Q(-a)]}.

Q(-a)>0이고 P(-a)=(a-4)²/20+1/5>0, Q(-a)-P(-a)=a+a²/10+a³/60>=0이므로 0<R(-a)<=1. Large-a에서는 R(-a)~3/a다.

### Algorithmic 의미

현재 fast 중심 wh, inherited radius Ew에 대해 rational candidate의 새 오차는

    Ew+ <= R(-a)Ew + eta(a)|wh| + rho_round.

따라서 허용 local fast budget bw를 만족하는지의 기본 판정은

    eta(a)|wh| + rho_round <= bw.

이 판정에는 exp evaluation이 없다. 강직도만 threshold로 삼지 않고 실제 남은 fast amplitude를 사용한다. 판정 실패 시 exp(-a)의 검증된 interval [ell,u]를 만들고 m=(ell+u)/2를 사용하면

    Ew+ <= u Ew + (u-ell)|wh|/2 + rho_round.

Reference의 exp enclosure는 alternating Taylor, dyadic outward squaring, 그리고 큰 a에서 exp(-a)<=2^-floor(a)를 사용한다. libm의 반올림 정확성을 가정하지 않는다. 작은 fast component를 무조건 0으로 project하지 않으며, 양/음 부호와 비영 진폭을 유효한 dyadic 중심으로 보존한다.

이 scalar eta bound를 arbitrary nonnormal matrix에 직접 적용하지 않는다. 그러한 확대에는 resolvent/semigroup bound가 필요하다.

## 5. 임의 causal hybrid 선택에 대한 enclosure 합성

### 명제 5: 후보의 선택과 certificate는 분리할 수 있다

모든 candidate m이 동일한 accepted-state enclosure와 동일한 witness에 대해

    e_{n+1} <= A_{m,n} e_n + delta_{m,n}

라는 유효한 componentwise nonnegative 오차 전파를 제공한다고 하자. Candidate와 검증 비용을 모두 계상하고, 통과한 후보 중 하나만 commit한다면 어떤 선택 순서라도 그 recurrence의 귀납적 합성은 유효하다. 실패한 trial은 accepted state, witness, physical budget을 변경하지 않는다.

증명은 각 단계의 containment와 componentwise monotonicity를 귀납적으로 합성하면 된다. 비정상적으로 큰 A를 scalar L-stability만으로 숨길 수는 없다. 필요하다면 A 자체의 크기를 acceptance에서 제한해야 한다.

Causal이라는 말은 미래 reference solution을 이용하지 않는다는 뜻이다. 알려진 모델을 prospective stage/time에 평가하는 것까지 금지하는 뜻이 아니다. 같은 snapshot에서 만든 독립 candidates는 병렬 계산할 수 있으나, 이 reference는 실제 병렬 speedup을 측정하지 않는다.

## 6. Scoped theorem: 임의 초기 fast amplitude를 갖는 adaptive chart-RVJ

이 절과 실행 예제의 모든 변수·시간은 무차원 benchmark convention이다.

    x'=x²,
    y'=(-kappa+2x)y+x²,
    x(0)=1,
    y(0)=w0+1/kappa,
    0<T<=1/4, kappa>0.

정칙 chart w=y/x²-1/kappa에서

    x'=x², w'=-kappa*w.

정확한 해는 audit에서만 x=1/(1-t), w=w0 exp(-kappa*t)로 사용한다. Integrator의 candidate/acceptance 함수는 이 미래 trajectory oracle을 인자로 받지 않는다. 다만 모델의 국소 flow identity를 사용하므로 결과는 이 integrable class에 한정된다.

### Slow RVJ의 local defect

b=h*x라고 쓰면 slow RVJ step은

    U_h(x)=x(1+b+b²+b³+b⁴+120b⁵ phi5^R(2b)),
    phi5^R(z)=(z²-5z+12)/(1440Q(z)).

직접 정리하면

    U_h(x)-x/(1-b)
      = -x*b^6*(19-17b+6b²) / [30(1-b)Q(2b)].

0<=b<=1/4에서 Q(2b)>=7/10, 1-b>=3/4, 0<19-17b+6b²<=19이므로

    |local defect| <= 2*x^7*h^6.

Stored x의 rounding을 여기에 더한다. 같은 상계는 모든 partial length 0<=s<=h에 대해 성립한다.

### Uniform propagated coordinate bounds

Accepted x-box와 그 whole-step exact-flow enclosure가 [1/2,2]에 있고 h<=1/8이라고 하자. Exact slow-flow Lipschitz gain은

    L_n <= (1-h_n*x_upper,n)^-2.

h*x_upper<=1/4이므로

    log L_n <= (16/3)h_n,
    product L_n <= exp((16/3)T) < 9.

마지막의 상계는 T<=1/4 및 e<3으로 충분하다. Fast coordinate는 명제 4에 의해 R(-a)<=1 또는 verified exponential gain<=1로 전파된다.

목표 physical absolute tolerance eps>0와 다음 budget을 선택한다.

    eps_x = eps/[16(|w0|+1/kappa+1)],
    eps_w = eps/16,
    local_x,n <= eps_x*h_n/(9T),
    local_w,n <= eps_w*h_n/T.

그러면 임의의 accepted variable mesh에서 initial coordinate error=0일 때

    |xhat_n-x(t_n)| <= eps_x,
    |what_n-w(t_n)| <= eps_w.

증명: slow 쪽은 각 local error에 남은 propagation product를 곱해 합하고 product<9 및 sum h<=T를 적용한다. Fast 쪽은 gain<=1이므로 local budgets를 합한다. Mode가 바뀌어도 같은 bounds이므로 동일한 귀납이 성립한다. 충분한 working precision이 필요하며, 고정 정밀도에서 budget이 지나치게 작으면 reference는 `PrecisionBlocked`를 반환한다. 무조건 종료한다는 주장은 하지 않는다.

### Physical error와 재구성

xhat와 exact x가 모두 [1/2,2]이면, |w(t)|<=|w0|을 사용하여

    |yhat-y(t)|
       <= 4 eps_x (|w0|+1/kappa) + 4 eps_w + rho_y.

재구성 rounding rho_y<=eps/4이면 이 값은 3eps/4 이하이다. Code는 이보다 직접적인 box bound

    B_y=(2|xhat|rx+rx²)|what+1/kappa|
         +(|xhat|+rx)² rw
         +|xhat²(what+1/kappa)-stored_y|

도 다시 검사하여 eps를 넘는 candidate는 commit하지 않는다. 한 번의 endpoint bound를 global bound로 오인하지 않고 rx,rw를 누적 전파한다.

결론: whole-step chart guard와 위 budget이 유지된 이 모델에서는 kappa에 독립적으로 physical max-grid absolute error를 제어한다. 특히 w0=0만을 가정하지 않는다. 이는 error-tolerance theorem이며 generic RVJ5의 stiff order 5 정리나 모든 stiffness에서 동일 step count라는 정리가 아니다.

비영 초기층을 허용한다는 것은 step 내부의 빠른 파형을 충분히 해상했다는 뜻이 아니다. 위 정리는 physical max-grid absolute error에 관한 것으로, fast component 자체의 상대오차 또는 정확한 exponential tail의 상대 재현을 보장하지 않는다. 아래의 dense-window enclosure도 유효한 포함관계이지 좁은 uniform dense-error bound가 아니다.

## 7. Dense/window 및 approximate cofactor의 제한된 확장

`dense_box`는 이 integrable chart의 이미 accepted된 initial box에서, 임의 local window [s0,s1] 전체의 X,W,Y enclosure를 계산한다. Monotone x flow 및 exp interval의 곱으로 얻는다. 이것은 generic polynomial dense interpolant가 아니다. Event의 부재를 interval로 제외할 수 있으나 event의 유일성·시각 오차 또는 범용 event handler는 아직 구현하지 않았다.

Approximate cofactor가

    L_F C=(-kappa+a)C+r_C, L_F D=aD+r_D

이면 w'= -kappa*w + (r_C-w r_D)/D다. Tube에서 |D|>=Dmin, |w|<=W, |r_C|<=epsC, |r_D|<=epsD이면 forcing bound는

    G <= (epsC+W epsD)/Dmin.

한 step에 누락한 forcing이 만드는 fast error는 Duhamel로

    <= [(1-exp(-kappa*h))/kappa] G <= min(h,1/kappa)G.

이 식을 구현·단위시험했지만, approximate chart client 전체를 이번 integrator에 연결하지는 않았다. Residual가 작아도 Dmin이 작으면 무효라는 점을 유지한다.

## 8. 실행 결과

* Unit/contract tests: 31 passed, 0 failed.
* Source-bound selected checks: 11. Whole PR11 suite와 다르다.
* New exact algebra checks: 3, 별도의 연결 Wolfram clean replay 포함.
* Adaptive model cases: kappa={1,40,10000}, w0={0,+1,-1}, eps=1e-8, T=1/4의 9개.
* Oracle comparison: audit만 140 decimal digits. 모든 accepted endpoint의 x,w,y 오차가 exact-rational certificate 안에 들어갔다.
* Cubic path tracking: 2개의 loop, 157 certified slabs.
* Inherited raw-coordinate counterexample: N={32,64,128,256}의 4개, error/h³가 4/3에 접근하는 기존 실패를 다시 보존했다.

대표 w0=1 결과:

| kappa | accepted steps | rational RVJ | EXP enclosure | rejected | max physical y error |
|---:|---:|---:|---:|---:|---:|
| 1 | 55 | 55 | 0 | 5 | 1.49990148297e-11 |
| 40 | 49 | 30 | 19 | 5 | 3.20148721758e-11 |
| 10000 | 49 | 48 | 1 | 5 | 1.47651750083e-15 |

w0=-1에서도 같은 mode counts를 얻었고, fast amplitude를 0으로 투영하지 않았다. 모든 9개 case의 error/bound 최대는 약 0.904 미만이었다. 보정 횟수는 비용·speedup이 아니다. Fraction arithmetic과 interval exponentials, derivative/jet를 명시적으로 쓰는 reference이며 production AD/JVP/Krylov 실행은 하지 않았다.

Tolerance를 1e-6,1e-8,1e-10으로 강화한 kappa=10000,w0=1 실행의 accepted steps는 각각 16,49,128이었다. 이는 adaptive response의 확인이지 보편적인 최적 step law가 아니다.

## 9. 검산, 실패, 승격 경계

Red run에서는 scalar L-stability만 보고 fast candidate를 수용하던 baseline이 unresolved initial-layer test에서 실패했다. 진폭 가중 gap bound 및 EXP enclosure fallback을 넣은 후 해당 regression과 다른 30개 계약이 통과했다.

Wolfram의 첫 탐색 호출에서 infinity substitution 경고가 발생했다. 이후 reciprocal-variable expansion과 clean integral-identity call로 검산했다. 경고 호출을 clean PASS로 집계하지 않는다.

원본 source runner의 flint 부재와 누락 inputs는 본 연구 reference의 실패와 별도다. 원문 modular/FLINT 전체 결과, Singular/Macaulay2, full residual primary decomposition/Segre class는 여기서 승격하지 않았다.

`research-systematically`, TDD, verification skill과 현재 모델의 수학 유도를 묶은 실행 기록을 사용했다. 과거 사용자별 GPT6 Astra v4 ZIP의 정확한 원문/해시는 이번 세션에서 확보하지 못했으므로 그 배포본을 byte-verified로 재실행했다고 하지 않는다. 독립 subagent/human reviewer는 없었다. Wolfram과 다른 산술 표현의 검산은 독립 구현 검산이지 독립 최종 심사자의 승인과 같지 않다.

## 10. 남은 연구

NEXT_DEVELOPMENT_DAG.json은 아직 하지 않은 작업만 담는다. 우선 (A) 원본 missing input 복구, (B) model-specific certified coordinate provider를 일반화한 interface, (C) 두 fast modes와 off-diagonal coupling, (D) ODE와 coupled closure path tube의 동시 생성, (E) dense/event와 chart transition, (F) exact-reference를 native implementation으로 옮기며 총 비용·rounding을 검증하는 순서다. 범용 raw-coordinate RVJ5를 되살렸다는 주장은 하지 않는다.

## 외부 문헌의 역할

Duff–Lee, arXiv:2402.07053: parametric Krawczyk certified homotopy의 선행 맥락(이번에는 초록 확인; 본문 HTML fetch 실패). Beltrán–Leykin, arXiv:1105.5992v2: rational certified path-tracking의 선행 맥락(초록·버전 확인). Telen–Van Barel–Verschelde, DOI 10.1137/19M1288036: adaptive Padé predictor/path-jump 방지의 선행 맥락(공식 출판사 초록 확인). 이 논문들의 일반 정리를 본 reference의 convergence theorem으로 대체 인용하지 않았다. 위 명제들은 표시된 가정 아래 직접 유도했다.
