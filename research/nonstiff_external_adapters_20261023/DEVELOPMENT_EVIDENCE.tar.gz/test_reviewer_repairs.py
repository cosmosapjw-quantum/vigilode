"""Narrow synthetic regressions for strict eligibility and max-step refusal."""
import copy
import json
from pathlib import Path
import sys
import tempfile

source = Path('/home/cosmosapjw/vigilode-nonstiff-adapters-source-7htbCC')
sys.path.insert(0, str(source / 'research/nonstiff_external_adapters_20261023'))
import analyze_external as a
import verify_adapters as v
from run_external import SOURCE, sha256, write_json

base = Path('/home/cosmosapjw/vigilode-nonstiff-run-Ioh017/full-comparison')
receipts = json.loads((base / 'RECEIPTS.json').read_text())
native = next(x for x in receipts if x['case'] == 'decay' and x['mode'] == 'dopri5'
              and x['rtol'] == 1e-9 and x['phase'] == 'warmup')
vode = next(x for x in receipts if x['case'] == 'decay' and x['mode'] == 'vode'
            and x['rtol'] == 1e-9 and x['phase'] == 'warmup')
native_record = json.loads((base / native['stdout']).read_text())
external_record = json.loads((base / vode['stdout']).read_text())
external_record.update(mode='diffsol', adapter_source_commit='a' * 40)
external_record['adapter'].update(solver='diffsol', method='Tsit45',
                                  version='0.16.1', adapter_source_commit='a' * 40)
assert v.check_record(external_record,
    {k: external_record[k] for k in ('case','dimension','rtol','atol','mode')},
    'a' * 40, v.frozen_analyzer())['valid']

with tempfile.TemporaryDirectory(dir='/home/cosmosapjw/vigilode-nonstiff-adapters-run-tTYnLc') as temp:
    folder = Path(temp)
    configs = [dict(id=0, case='decay', dimension=8, rtol=1e-9, atol=1e-12, mode='dopri5'),
               dict(id=1, case='decay', dimension=8, rtol=1e-9, atol=1e-12, mode='diffsol')]
    # The exact atol is the stored f64 product, rather than a decimal rewrite.
    for cfg in configs:
        cfg['atol'] = native_record['atol']
    write_json(folder/'PLAN.json', dict(source_commit=SOURCE, timed_repeats=3,
                                       warmups_per_configuration=1, configurations=configs))
    saved = []
    strict = []
    for cfg, record in zip(configs, (native_record, external_record)):
        for phase, repeat in [('warmup',-1),('timed',0),('timed',1),('timed',2)]:
            name = f'{cfg["id"]:03d}_{phase}_{repeat}.stdout.json'
            err = f'{cfg["id"]:03d}_{phase}_{repeat}.stderr.log'
            (folder/name).write_text(json.dumps(record)+'\n')
            (folder/err).write_text('')
            saved.append({**cfg,'phase':phase,'repeat':repeat,'stdout':name,'stderr':err,
                          'status':'COMPLETED','exit_code':0,'stdout_sha256':sha256(folder/name),
                          'stderr_sha256':sha256(folder/err)})
            if cfg['mode']=='diffsol':
                strict.append({'id':cfg['id'],'phase':phase,'repeat':repeat,'valid':repeat!=0,
                               'record_success':True,'status':'COMPLETED',
                               'reasons':['synthetic strict method mismatch'] if repeat==0 else []})
    write_json(folder/'RECEIPTS.json', saved)
    original_receipts_sha = sha256(folder/'RECEIPTS.json')
    code,_ = a.run_strict_analysis(folder, a.frozen_script(), strict, 0)
    assert code==0
    assert sha256(folder/'RECEIPTS.json')==original_receipts_sha
    summary=json.loads((folder/'SUMMARY.json').read_text())
    rows={x['mode']:x for x in summary['rows']}
    assert rows['dopri5']['all_runs_successful'] is True
    assert rows['diffsol']['all_runs_successful'] is False
    assert summary['common_error_comparisons'][0]['comparator_over_explicit_time'] is None
    assert summary['strict_replay_gate']['strict_invalid_completed_receipts']==1
    assert (folder/'WORK_PRECISION.png').is_file() and (folder/'RAW_OUTPUTS.tar.gz').is_file()
print('strict-invalid external excluded from row, ratio and plot input; originals unchanged PASS')

failure = copy.deepcopy(external_record)
failure.update(success=False, max_steps=1, message='max steps',
               times=[0.0], states=[external_record['states'][0]],
               reference=[external_record['reference'][0]],
               max_abs_error=0.0, max_normalized_error=0.0,
               last_accepted_time=0.0,
               last_accepted_state=external_record['states'][0],
               work={'rhs_attempted':1,'rhs_completed':1})
request={k:failure[k] for k in ('case','dimension','rtol','atol','mode','source_commit',
                               'adapter_source_commit','max_steps')}
analyzer=v.frozen_analyzer()
assert v.check_negative_control('max-step-exhaustion','COMPLETED',failure,request,'a'*40,analyzer)==[]
julia_failure=copy.deepcopy(failure)
julia_failure['mode']='julia'
julia_failure['adapter'].update(solver='OrdinaryDiffEq',method='Tsit5',
                                julia_version='1.12.7',preparation_success=False)
julia_request={k:julia_failure[k] for k in request}
assert v.check_negative_control('max-step-exhaustion','COMPLETED',julia_failure,
                                julia_request,'a'*40,analyzer)==[]
assert v.check_negative_control('max-step-exhaustion','PROCESS_FAILED',None,request,'a'*40,analyzer)
assert v.check_negative_control('max-step-exhaustion','COMPLETED',{},request,'a'*40,analyzer)
bad=copy.deepcopy(failure);bad['work']={}
assert v.check_negative_control('max-step-exhaustion','COMPLETED',bad,request,'a'*40,analyzer)
bad=copy.deepcopy(failure);bad['last_accepted_state']=[]
assert v.check_negative_control('max-step-exhaustion','COMPLETED',bad,request,'a'*40,analyzer)
bad=copy.deepcopy(failure);bad['max_steps']=100000
assert v.check_negative_control('max-step-exhaustion','COMPLETED',bad,request,'a'*40,analyzer)
assert v.check_negative_control('invalid-tolerance','PROCESS_FAILED',None,request,'a'*40,analyzer)==[]
assert v.check_negative_control('invalid-tolerance','COMPLETED',None,request,'a'*40,analyzer)
print('max-step parse/identity/partial/cost and invalid-input refusal controls PASS')
