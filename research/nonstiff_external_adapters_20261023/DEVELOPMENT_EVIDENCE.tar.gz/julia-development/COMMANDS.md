# Julia development commands and first observations

Executor requested gpt-6.1-sol/medium; observed model runtime NOT_INDEPENDENTLY_OBSERVED.

Read-only preflight observed Julia version 1.12.7 and executable `/home/cosmosapjw/.julia/juliaup/julia-1.12.7+0.x64.linux.gnu/bin/julia`. Adapter checkout was clean at 8c80985e30778df4ba44b2b7085753fa345cf0e2 on branch research/nonstiff-external-adapters-20261023, origin https://github.com/cosmosapjw-quantum/vigilode.git.

After receiving the frozen parent contract, created the owned Julia directory and dedicated run-root depot. Copied the existing component_julia Manifest, wrote a minimal exact-pinned Project, and executed:

```sh
JULIA_DEPOT_PATH=/home/cosmosapjw/vigilode-nonstiff-adapters-run-tTYnLc/julia-development/julia-depot JULIA_PKG_PRECOMPILE_AUTO=0 JULIA_NUM_PRECOMPILE_TASKS=4 /home/cosmosapjw/.juliaup/bin/julia --startup-file=no --project=/home/cosmosapjw/vigilode-nonstiff-adapters-source-7htbCC/research/nonstiff_external_adapters_20261023/adapters/julia -e 'using Pkg; Pkg.instantiate(); Pkg.resolve(); Pkg.precompile()' > install-first.log 2>&1
```

Pkg.resolve pruned the copied Manifest from172 to134 entries; a Python TOML comparison confirmed no retained package version/git-tree changes. External packages and MKL artifacts were installed only to the new depot. Global Julia environments were untouched.

The first draft's Meta.parseall call returned without throwing; an explicit check of returned Expr(:error) detected ambiguous Julia dot syntax in scalar literals (`10.^`, `1.-`) and macro comparison spacing at the entry point. These were corrected before executing the adapter. parse.log preserves the subsequent successful explicit parse check. Initial tool-call output retains the parse errors; no solver measurement was represented by that parse check.
