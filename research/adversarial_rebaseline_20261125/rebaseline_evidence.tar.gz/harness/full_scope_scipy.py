#!/usr/bin/env python3
"""Extended Full-Scope Adversarial Benchmark: Python SciPy Comparators."""
import json
import math
import sys
import time
import numpy as np
from scipy.integrate import solve_ivp


def calc_max_wrms(states, ref_states, atol_scale, error_rtol=1.0):
    n_pts = len(ref_states)
    n = len(atol_scale)
    sqrt_n = math.sqrt(n)
    worst = 0.0
    for k in range(n_pts):
        y = states[k]
        r = ref_states[k]
        norm = 0.0
        for i in range(n):
            sc = error_rtol * (atol_scale[i] + abs(r[i]))
            e = (y[i] - r[i]) / sc
            norm = math.hypot(norm, e / sqrt_n)
        worst = max(worst, norm)
    return worst


def run_timed(fn):
    for _ in range(1):
        res = fn()
        if not res["ok"]:
            return {**res, "wall_ms_median": None}
    times = []
    last = res
    for _ in range(3):
        t0 = time.perf_counter_ns()
        last = fn()
        times.append((time.perf_counter_ns() - t0) / 1e6)
        if not last["ok"]:
            return {**last, "wall_ms_median": None}
    times.sort()
    return {**last, "wall_ms_median": times[len(times) // 2]}


def kepler_exact(t, ecc=0.5):
    M = t % (2.0 * math.pi)
    E = M
    for _ in range(30):
        E -= (E - ecc * math.sin(E) - M) / (1.0 - ecc * math.cos(E))
    cE, sE = math.cos(E), math.sin(E)
    fac = math.sqrt(1.0 - ecc * ecc)
    r = 1.0 - ecc * cE
    return [cE - ecc, fac * sE, -sE / r, fac * cE / r]


def main():
    out_file = sys.argv[1]
    ref_file = sys.argv[2] if len(sys.argv) > 2 else None
    refs = {}
    if ref_file:
        with open(ref_file) as f:
            refs = json.load(f).get("references", {})

    rows = []
    rtols = [1e-4, 1e-6, 1e-8]

    # 1. Kepler e=0.5
    grid_kep = np.linspace(0.0, 20.0 * math.pi, 101)
    ref_kep = [kepler_exact(float(t)) for t in grid_kep]
    def f_kep(t, y):
        r2 = y[0] * y[0] + y[1] * y[1]
        inv_r3 = -1.0 / (r2 * math.sqrt(r2))
        return [y[2], y[3], inv_r3 * y[0], inv_r3 * y[1]]

    for rtol in rtols:
        atol = rtol * 1e-2
        for aid, meth in [("scipy-rk45", "RK45"), ("scipy-dop853", "DOP853"), ("scipy-radau", "Radau")]:
            def run_k(meth=meth, rtol=rtol, atol=atol):
                sol = solve_ivp(f_kep, (0.0, 20.0 * math.pi), [0.5, 0.0, 0.0, math.sqrt(3.0)],
                                method=meth, t_eval=grid_kep, rtol=rtol, atol=atol)
                if not sol.success or sol.y.shape[1] != len(grid_kep):
                    return {"ok": False, "err_msg": sol.message, "states": [], "nf": int(sol.nfev)}
                states = sol.y.T.tolist()
                u = states[-1]
                e0 = 0.5 * 3.0 - 1.0 / 0.5
                ef = 0.5 * (u[2]**2 + u[3]**2) - 1.0 / math.hypot(u[0], u[1])
                return {"ok": True, "err_msg": "", "states": states, "nf": int(sol.nfev),
                        "njac": int(sol.njev) if sol.njev is not None else None,
                        "nlu": int(sol.nlu) if sol.nlu is not None else None,
                        "extra": {"energy_drift": abs(ef - e0)}}
            res = run_timed(run_k)
            err = calc_max_wrms(res["states"], ref_kep, [1.0]*4) if res["ok"] else None
            rows.append({"problem": "kepler-ecc05", "arm": aid, "rtol": rtol, "ok": res["ok"],
                         "err_msg": res["err_msg"], "error_common": err, "wall_ms_median": res["wall_ms_median"],
                         "nf": res.get("nf"), "njac": res.get("njac"), "nlu": res.get("nlu"), "extra": res.get("extra", {})})

    # 2. Prothero-Robinson lambda=-1e4
    grid_pr = np.linspace(0.0, 10.0, 101)
    ref_pr = [[math.sin(float(t))] for t in grid_pr]
    f_pr = lambda t, y: [-10000.0 * (y[0] - math.sin(t)) + math.cos(t)]
    j_pr = lambda t, y: [[-10000.0]]
    for rtol in rtols:
        atol = rtol * 1e-2
        for aid, meth in [("scipy-radau", "Radau"), ("scipy-bdf", "BDF"), ("scipy-lsoda", "LSODA")]:
            def run_pr(meth=meth, rtol=rtol, atol=atol):
                kw = {"jac": j_pr} if meth in ("Radau", "BDF") else {}
                sol = solve_ivp(f_pr, (0.0, 10.0), [0.0], method=meth, t_eval=grid_pr, rtol=rtol, atol=atol, **kw)
                if not sol.success or sol.y.shape[1] != len(grid_pr):
                    return {"ok": False, "err_msg": sol.message, "states": [], "nf": int(sol.nfev)}
                return {"ok": True, "err_msg": "", "states": sol.y.T.tolist(), "nf": int(sol.nfev),
                        "njac": int(sol.njev) if sol.njev is not None else None,
                        "nlu": int(sol.nlu) if sol.nlu is not None else None}
            res = run_timed(run_pr)
            err = calc_max_wrms(res["states"], ref_pr, [1.0]) if res["ok"] else None
            rows.append({"problem": "prothero-robinson-1e4", "arm": aid, "rtol": rtol, "ok": res["ok"],
                         "err_msg": res["err_msg"], "error_common": err, "wall_ms_median": res["wall_ms_median"],
                         "nf": res.get("nf"), "njac": res.get("njac"), "nlu": res.get("nlu"), "extra": {}})

    # 3. Stiff burst switching
    grid_b = np.linspace(0.0, 6.0, 101)
    ref_b = refs.get("stiff-burst-switching")
    def f_b(t, y):
        lam = 5000.0 * math.exp(-40.0 * (t - 3.0)**2)
        return [y[1], -y[0] - lam * (y[1] + math.sin(t)) - math.cos(t)]
    def j_b(t, y):
        lam = 5000.0 * math.exp(-40.0 * (t - 3.0)**2)
        return [[0.0, 1.0], [-1.0, -lam]]
    for rtol in rtols:
        atol = rtol * 1e-2
        for aid, meth in [("scipy-lsoda", "LSODA"), ("scipy-radau", "Radau"), ("scipy-bdf", "BDF"), ("scipy-dop853", "DOP853")]:
            def run_b(meth=meth, rtol=rtol, atol=atol):
                kw = {"jac": j_b} if meth in ("Radau", "BDF") else {}
                sol = solve_ivp(f_b, (0.0, 6.0), [1.0, 0.0], method=meth, t_eval=grid_b, rtol=rtol, atol=atol, **kw)
                if not sol.success or sol.y.shape[1] != len(grid_b):
                    return {"ok": False, "err_msg": sol.message, "states": [], "nf": int(sol.nfev)}
                return {"ok": True, "err_msg": "", "states": sol.y.T.tolist(), "nf": int(sol.nfev),
                        "njac": int(sol.njev) if sol.njev is not None else None,
                        "nlu": int(sol.nlu) if sol.nlu is not None else None}
            res = run_timed(run_b)
            err = calc_max_wrms(res["states"], ref_b, [1.0, 1.0]) if (res["ok"] and ref_b) else None
            rows.append({"problem": "stiff-burst-switching", "arm": aid, "rtol": rtol, "ok": res["ok"],
                         "err_msg": res["err_msg"], "error_common": err, "wall_ms_median": res["wall_ms_median"],
                         "nf": res.get("nf"), "njac": res.get("njac"), "nlu": res.get("nlu"), "extra": {}})

    with open(out_file, "w") as f:
        json.dump({"schema": "vigilode-full-scope-scipy-v1", "timing_authority": "diagnostic_only", "rows": rows}, f, indent=2)
    print(f"Wrote {len(rows)} SciPy rows to {out_file}")


if __name__ == "__main__":
    main()
