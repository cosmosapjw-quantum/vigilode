#!/usr/bin/env python3
"""Aggregate all live HEAD=933922495 adversarial benchmark receipts into a unified report."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

SCRATCH = Path("/home/cosmosapjw/.gemini/antigravity/brain/980552fb-33e9-431b-b87d-0b62ddeb4cb4/scratch/live_runs")
OUT_MD = Path("/home/cosmosapjw/vigilode/bench/out/ADVERSARIAL_FULL_SCOPE_20261125_REPORT.md")
OUT_JSON = Path("/home/cosmosapjw/vigilode/bench/out/adversarial_full_scope_20261125_summary.json")


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def fmt_e(v) -> str:
    if v is None:
        return "—"
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return "NaN/Inf"
    return f"{v:.2e}"


def fmt_ms(v) -> str:
    if v is None:
        return "—"
    return f"{v:.3f}"


def fmt_int(v) -> str:
    if v is None:
        return "—"
    return str(int(v))


def gmean(vals: list[float]) -> float | None:
    pos = [v for v in vals if v is not None and v > 0 and math.isfinite(v)]
    if not pos:
        return None
    return math.exp(sum(math.log(v) for v in pos) / len(pos))


def parse_rust_status(st) -> tuple[bool, str]:
    if isinstance(st, dict):
        kind = st.get("kind", "")
        if kind == "success":
            return True, "PASS"
        msg = st.get("message") or kind
        return False, f"FAIL({msg})"
    if st == "Success":
        return True, "PASS"
    return False, f"FAIL({st})"


def main():
    files = {
        "cross_rust": SCRATCH / "cross_solver_v1_rust.json",
        "cross_julia": SCRATCH / "cross_solver_v1_julia.json",
        "spatial_v3": SCRATCH / "spatial_battery_v3_rust.json",
        "opt_battery": SCRATCH / "opt_battery_head.json",
        "full_rust": SCRATCH / "full_scope_rust.json",
        "full_ens": SCRATCH / "full_scope_ensemble_unpinned.json",
        "full_julia": SCRATCH / "full_scope_julia.json",
        "full_scipy": SCRATCH / "full_scope_scipy.json",
    }
    data = {}
    hashes = {}
    for k, p in files.items():
        hashes[k] = {"path": str(p), "sha256": sha256(p)}
        data[k] = json.loads(p.read_text())

    # Index canonical cross_solver_v1
    cross_idx = {}
    for r in data["cross_rust"]["rows"]:
        cross_idx[(r["problem"], r["arm"], float(r["rtol"]))] = r
    for r in data["cross_julia"]["results"]:
        cross_idx[(r["problem"], r["algorithm"], float(r["rtol"]))] = r

    # Index spatial_battery_v3
    spatial_idx = {}
    for r in data["spatial_v3"]["rows"]:
        spatial_idx[(r["problem"], r["arm"], float(r["rtol"]))] = r

    # Index extended full scope
    ext_idx = {}
    for src_key in ("full_rust", "full_julia", "full_scipy"):
        for r in data[src_key]["rows"]:
            ext_idx[(r["problem"], r["arm"], float(r["rtol"]))] = r
    ens_unpinned = {r["arm"]: r for r in data["full_ens"]["rows"]}

    # Validate zero silent NaN/Inf passes
    silent_nan_passes = []
    for label, idx in [("cross", cross_idx), ("spatial", spatial_idx), ("ext", ext_idx)]:
        for k, r in idx.items():
            if "work" in r:
                ok, _ = parse_rust_status(r.get("status"))
                err = r.get("error_common")
            elif "algorithm" in r:
                ok = r.get("status") == "Success"
                err = r.get("error_common", r.get("error"))
            else:
                ok = r.get("ok") is True
                err = r.get("error_common")
            if ok and err is not None and (not isinstance(err, (int, float)) or not math.isfinite(err)):
                silent_nan_passes.append((label, k))
    assert not silent_nan_passes, f"Silent NaN passes detected: {silent_nan_passes}"

    # Build Markdown report
    md = []
    md.append("# VigilODE Full-Scope Adversarial Cross-Solver Benchmark Report (HEAD `933922495`)\n")
    md.append("> **Timing Authority**: `diagnostic_only` (AMD Ryzen 9 5900X 12-Core / 24 Logical CPUs, single-thread pinned `taskset -c 0`, `OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1`; 8-thread `Dopri5Ensemble` also measured unpinned separately).")
    md.append("> **Production Status Notice**: `HOLD_NOT_RELEASE_QUALIFIED` (per repository qualification notice; see adversarial limitations below).\n")
    md.append("## 1. Provenance & Datasets\n")
    md.append("| Dataset Key | Schema / Role | Rows | SHA-256 (prefix) |")
    md.append("| :--- | :--- | :---: | :--- |")
    for k, p in files.items():
        d = data[k]
        cnt = len(d.get("rows", d.get("results", d.get("records", []))))
        md.append(f"| `{k}` | `{d.get('schema', 'n/a')}` | {cnt} | `{hashes[k]['sha256'][:16]}...` |")

    # Cross-solver v1 summary at rtol=1e-6
    md.append("\n## 2. Canonical Cross-Solver Stiff / Oscillatory / 1D-PDE Suite (`adversarial_cross_solver_v1`, `rtol=1e-6`)\n")
    cross_arms = [
        "vigilode-dense", "vigilode-banded-dense", "vigilode", "vigilode-banded",
        "diffsol-bdf-dense", "diffsol-bdf-sparse", "cvode-bdf-dense", "cvode-bdf-band",
        "dvode-mf21", "dvode-mf24", "radau5", "radau5-band", "rodas", "rodas-band",
        "julia-rodas5p", "julia-fbdf", "julia-cvode-bdf",
    ]
    for prob in ["robertson", "hires", "van-der-pol-mu1000", "oregonator", "brusselator-1d-n100"]:
        md.append(f"### Problem: `{prob}` (`rtol = 1e-6`)\n")
        md.append("| Solver Arm | Status | Max WRMS Error | Median Time (ms) | RHS Evals | Jac Evals | Steps (Acc/Rej) | Full-Run Heap |")
        md.append("| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |")
        for arm in cross_arms:
            r = cross_idx.get((prob, arm, 1e-6))
            if not r:
                continue
            if "work" in r:
                ok, st = parse_rust_status(r["status"])
                err = r.get("error_common")
                ms = r.get("wall_ms_median")
                nf = r["work"].get("rhs_evaluations") or r.get("callbacks", {}).get("rhs")
                nj = r["work"].get("jacobian_evaluations") or r.get("callbacks", {}).get("jac")
                acc = r["work"].get("accepted_steps")
                rej = r["work"].get("rejected_steps")
                steps = f"{acc}/{rej}" if acc is not None else "—"
                alloc = r.get("allocations", {})
                alloc_s = f"{alloc.get('heap_calls', 0)} calls ({alloc.get('heap_bytes', 0)/1024:.1f} KB)" if alloc else "—"
            else:
                st = "PASS" if r["status"] == "Success" else f"FAIL({r['status']})"
                err = r.get("error_common", r.get("error"))
                ms = r.get("time_median_ms", r.get("wall_ms_median"))
                nf = r.get("nf")
                nj = r.get("njacs", r.get("njac"))
                acc = r.get("naccept", r.get("accepted"))
                rej = r.get("nreject", r.get("rejected"))
                steps = f"{acc}/{rej}" if acc is not None else "—"
                alloc_s = "GC managed"
            md.append(f"| `{arm}` | {st} | {fmt_e(err)} | {fmt_ms(ms)} | {fmt_int(nf)} | {fmt_int(nj)} | {steps} | {alloc_s} |")
        md.append("")

    # Spatial Battery v3 summary at rtol=1e-6
    md.append("## 3. 2D/3D Spatial & Spherical PDE Battery (`adversarial_spatial_battery_v3`, 9 Problems, `rtol=1e-6`)\n")
    sp_probs = [p["id"] for p in data["spatial_v3"]["corpus"]["problems"]]
    sp_arms = [
        "vigilode-banded-dense", "vigilode-dense", "diffsol-bdf-sparse", "diffsol-bdf-dense",
        "cvode-bdf-band", "cvode-bdf-dense", "dvode-mf24", "dvode-mf21", "radau5-band", "rodas-band",
    ]
    md.append("| Problem | " + " | ".join(f"`{a}` (ms / err)" for a in sp_arms) + " |")
    md.append("| :--- | " + " | ".join(":---:" for _ in sp_arms) + " |")
    sp_ratios = {a: [] for a in sp_arms if a != "vigilode-banded-dense"}
    for prob in sp_probs:
        cells = []
        v_base = spatial_idx[(prob, "vigilode-banded-dense", 1e-6)]
        v_ms = v_base.get("wall_ms_median")
        for arm in sp_arms:
            r = spatial_idx[(prob, arm, 1e-6)]
            ms = r.get("wall_ms_median")
            err = r.get("error_common")
            ok, st_lbl = parse_rust_status(r["status"])
            cells.append(f"{fmt_ms(ms)} / {fmt_e(err)}" if ok else st_lbl)
            if arm != "vigilode-banded-dense" and ok and v_ms and ms:
                sp_ratios[arm].append(ms / v_ms)
        md.append(f"| `{prob}` | " + " | ".join(cells) + " |")

    md.append("\n### Spatial Battery v3 Geometric-Mean Speed Ratio (`comparator_ms / vigilode-banded-dense_ms`, >1 = VigilODE faster, `rtol=1e-6`)\n")
    md.append("| Comparator Arm | Geo-Mean Speed Ratio vs `vigilode-banded-dense` | All 9 PDEs Succeeded? |")
    md.append("| :--- | :---: | :---: |")
    sp_gmeans = {}
    for arm in sp_arms:
        if arm == "vigilode-banded-dense":
            continue
        gm = gmean(sp_ratios[arm])
        sp_gmeans[arm] = gm
        ok_all = all(parse_rust_status(spatial_idx[(p, arm, 1e-6)]["status"])[0] for p in sp_probs)
        gm_str = f"{gm:.2f}×" if gm is not None else "— (all failed/missing)"
        md.append(f"| `{arm}` | {gm_str} | {'Yes' if ok_all else 'No'} |")

    # Extended Full-Scope Tables
    md.append("\n## 4. Extended Full-Scope Adversarial Suites (`full_scope_suite` + Julia + SciPy)\n")
    ext_groups = {}
    for (prob, arm, rtol), r in sorted(ext_idx.items()):
        ext_groups.setdefault((prob, rtol), []).append((arm, r))

    for prob in [
        "kepler-ecc05", "nonnormal-kreiss-b100", "dopri5-ensemble-n1024x16",
        "prothero-robinson-1e4", "periodic-advdiff-n256", "brusselator-1d-jvp-n400",
        "dae-robertson-index1", "dae-index1-analytic", "mass-ill-conditioned",
        "dae-index1-inconsistent", "dae-pendulum-index3",
        "stiff-burst-switching", "robertson-rhs-only-fallback",
        "event-root-finding", "event-terminal-first", "event-tangent-adversarial",
    ]:
        md.append(f"### Problem: `{prob}`\n")
        if prob == "dopri5-ensemble-n1024x16":
            md.append("> *Note: The table below was measured under single-core `taskset -c 0` pinning (`6.147 ms` 1T vs `6.310 ms` 8T). See `Unpinned 8-Thread Parallel Ensemble` below for true multi-core scaling (`6.603 ms` 1T -> `1.687 ms` 8T).*\n")
        md.append("| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |")
        md.append("| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |")
        for rtol in [1e-4, 1e-6, 1e-8]:
            for arm, r in ext_groups.get((prob, rtol), []):
                ex = r.get("extra") or {}
                ex_str = ", ".join(f"{k}={fmt_e(v) if isinstance(v, float) else v}" for k, v in ex.items() if v is not None)
                if not r.get("ok"):
                    ex_str = f"ERR: {r.get('err_msg', '')}" + (f" | {ex_str}" if ex_str else "")
                acc_rej = f"{r.get('accepted', '—')}/{r.get('rejected', '—')}"
                md.append(
                    f"| {rtol:.0e} | `{arm}` | {'PASS' if r.get('ok') else 'FAIL'} | "
                    f"{fmt_e(r.get('error_common'))} | {fmt_ms(r.get('wall_ms_median'))} | "
                    f"{fmt_int(r.get('nf'))} | {fmt_int(r.get('njac'))} | {fmt_int(r.get('njvp'))} | "
                    f"{fmt_int(r.get('nlu'))} | {acc_rej} | {ex_str} |"
                )
        md.append("")

    md.append("### Unpinned 8-Thread Parallel Ensemble (`dopri5-ensemble-n1024x16`)\n")
    for aid, r in ens_unpinned.items():
        md.append(f"- `{aid}`: ok={r['ok']}, time={fmt_ms(r['wall_ms_median'])} ms, nf={r['nf']}, extra={r['extra']}")

    md.append("\n### Typed Capability Refusals (`Rodas5p::capabilities`)\n")
    for c in data["full_rust"]["capability_refusals"]:
        md.append(f"- `{c['expected']}`: refused={c['refused']} -> `{c['detail']}`")

    md.append("\n### VG-1 Hot-Loop Allocation Audit\n")
    for k, v in data["full_rust"]["vg1_allocation_audit"].items():
        md.append(f"- `{k}`: rust_calls={v['rust_calls']}, rust_bytes={v['rust_bytes']}, heap_calls={v['heap_calls']}")

    # Opt battery summary
    md.append("\n## 5. Internal Polyalgorithm Route Battery (`opt_baseline_battery`, `rtol=1e-5`)\n")
    md.append("| Problem | Route Policy | f_evals | jac_builds | jvp_calls | lu | acc/rej | switches | Time (ms) | WRMS Err |")
    md.append("| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |")
    for r in data["opt_battery"]["records"]:
        if abs(r["rtol"] - 1e-5) < 1e-12:
            md.append(
                f"| `{r['problem_id']} ({r['problem_name']})` | `{r['route_policy']}` | "
                f"{r['f_evals']} | {r['jac_builds']} | {r['jvp_calls']} | {r['lu_factorizations']} | "
                f"{r['accepted']}/{r['rejected']} | {r['route_switches']} | {r['wall_ns_median_of_5']/1e6:.3f} | {fmt_e(r['err_wrms_at_T'])} |"
            )

    OUT_MD.write_text("\n".join(md) + "\n")

    summary = {
        "provenance": hashes,
        "timing_authority": "diagnostic_only",
        "spatial_v3_geomean_speed_ratio_vs_vigilode_banded_dense_at_1e6": sp_gmeans,
        "vg1_allocation_audit": data["full_rust"]["vg1_allocation_audit"],
        "capability_refusals": data["full_rust"]["capability_refusals"],
        "unpinned_ensemble": ens_unpinned,
    }
    OUT_JSON.write_text(json.dumps(summary, indent=2) + "\n")

    print(f"Wrote {OUT_MD} ({OUT_MD.stat().st_size} bytes) and {OUT_JSON}")
    print("Spatial v3 GeoMean Speed Ratios vs vigilode-banded-dense (rtol=1e-6):")
    for a, g in sp_gmeans.items():
        print(f"  {a:25s}: {g:.3f}x" if g else f"  {a:25s}: None")
    print("VG-1 Audit:", json.dumps(data["full_rust"]["vg1_allocation_audit"], indent=2))
    print("Unpinned Ensemble:", json.dumps({k: {"ms": v["wall_ms_median"], "ok": v["ok"], "extra": v["extra"]} for k, v in ens_unpinned.items()}))


if __name__ == "__main__":
    main()
