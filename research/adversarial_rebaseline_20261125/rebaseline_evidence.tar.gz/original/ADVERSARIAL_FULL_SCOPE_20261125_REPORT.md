# VigilODE Full-Scope Adversarial Cross-Solver Benchmark Report (HEAD `933922495`)

> **Timing Authority**: `diagnostic_only` (AMD Ryzen 9 5900X 12-Core / 24 Logical CPUs, single-thread pinned `taskset -c 0`, `OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1`; 8-thread `Dopri5Ensemble` also measured unpinned separately).
> **Production Status Notice**: `HOLD_NOT_RELEASE_QUALIFIED` (per repository qualification notice; see adversarial limitations below).

## 1. Provenance & Datasets

| Dataset Key | Schema / Role | Rows | SHA-256 (prefix) |
| :--- | :--- | :---: | :--- |
| `cross_rust` | `vigilode-bench.wp.v1` | 126 | `24da9ea79e3c7f8a...` |
| `cross_julia` | `vigilode.cross_solver_run.v2` | 45 | `a50b5c5812fd26f9...` |
| `spatial_v3` | `vigilode-bench.wp.v1` | 378 | `44ef441cc3ac09fe...` |
| `opt_battery` | `vigilode.opt_baseline.v1` | 96 | `a0cb9d96a7e7dae4...` |
| `full_rust` | `vigilode-full-scope-rust-v1` | 242 | `2aab4a5bccb2bf0e...` |
| `full_ens` | `vigilode-full-scope-rust-ensemble-v1` | 3 | `d31c3404989bc4f8...` |
| `full_julia` | `vigilode-full-scope-julia-v1` | 112 | `d06b0bda92d6b91c...` |
| `full_scipy` | `vigilode-full-scope-scipy-v1` | 30 | `81b2baf2b6f583c5...` |

## 2. Canonical Cross-Solver Stiff / Oscillatory / 1D-PDE Suite (`adversarial_cross_solver_v1`, `rtol=1e-6`)

### Problem: `robertson` (`rtol = 1e-6`)

| Solver Arm | Status | Max WRMS Error | Median Time (ms) | RHS Evals | Jac Evals | Steps (Acc/Rej) | Full-Run Heap |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `vigilode-dense` | PASS | 5.02e-07 | 0.055 | 383 | 41 | 41/2 | 301 calls (44.7 KB) |
| `vigilode` | PASS | 5.19e-08 | 0.090 | 1004 | 122 | 122/4 | 276 calls (23.2 KB) |
| `diffsol-bdf-dense` | PASS | 1.50e-06 | 0.095 | 260 | 0 | 168/0 | 871 calls (84.0 KB) |
| `cvode-bdf-dense` | PASS | 2.03e-06 | 0.229 | 304 | 4 | 231/7 | 200 calls (19.5 KB) |
| `dvode-mf21` | PASS | 3.37e-06 | 0.078 | 337 | 5 | 237/19 | 108 calls (7.9 KB) |
| `radau5` | PASS | 8.01e-07 | 0.028 | 338 | 40 | 47/2 | 109 calls (8.1 KB) |
| `rodas` | PASS | 3.98e-07 | 0.037 | 485 | 80 | 80/1 | 108 calls (7.9 KB) |
| `julia-rodas5p` | PASS | 5.41e-08 | 0.074 | 612 | 66 | 66/2 | GC managed |
| `julia-fbdf` | PASS | 8.67e-07 | 0.283 | 436 | 2 | 189/18 | GC managed |
| `julia-cvode-bdf` | PASS | 1.98e-06 | 0.146 | 304 | 5 | 224/7 | GC managed |

### Problem: `hires` (`rtol = 1e-6`)

| Solver Arm | Status | Max WRMS Error | Median Time (ms) | RHS Evals | Jac Evals | Steps (Acc/Rej) | Full-Run Heap |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `vigilode-dense` | PASS | 6.29e-07 | 0.361 | 1902 | 209 | 209/3 | 476 calls (347.8 KB) |
| `vigilode` | PASS | 1.43e-07 | 0.349 | 2141 | 265 | 265/3 | 419 calls (152.7 KB) |
| `diffsol-bdf-dense` | PASS | 5.55e-06 | 0.388 | 884 | 0 | 363/15 | 2071 calls (251.1 KB) |
| `cvode-bdf-dense` | PASS | 8.50e-06 | 0.906 | 825 | 12 | 513/46 | 200 calls (29.1 KB) |
| `dvode-mf21` | PASS | 8.98e-06 | 0.280 | 827 | 11 | 496/45 | 108 calls (17.1 KB) |
| `radau5` | PASS | 6.86e-06 | 0.168 | 1140 | 73 | 117/2 | 109 calls (18.3 KB) |
| `rodas` | PASS | 7.63e-07 | 0.327 | 2219 | 369 | 369/1 | 108 calls (17.3 KB) |
| `julia-rodas5p` | PASS | 2.33e-06 | 0.496 | 2524 | 258 | 258/25 | GC managed |
| `julia-fbdf` | PASS | 3.61e-05 | 0.841 | 1440 | 6 | 395/20 | GC managed |
| `julia-cvode-bdf` | PASS | 8.50e-06 | 0.400 | 826 | 12 | 467/46 | GC managed |

### Problem: `van-der-pol-mu1000` (`rtol = 1e-6`)

| Solver Arm | Status | Max WRMS Error | Median Time (ms) | RHS Evals | Jac Evals | Steps (Acc/Rej) | Full-Run Heap |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `vigilode-dense` | PASS | 2.04e-06 | 0.336 | 4028 | 350 | 350/124 | 619 calls (178.7 KB) |
| `vigilode` | PASS | 4.60e-07 | 0.277 | 3904 | 411 | 411/88 | 565 calls (26.5 KB) |
| `diffsol-bdf-dense` | PASS | 3.98e-05 | 0.510 | 1777 | 0 | 817/115 | 4803 calls (425.3 KB) |
| `cvode-bdf-dense` | PASS | 2.54e-04 | 0.837 | 1354 | 23 | 925/90 | 200 calls (17.7 KB) |
| `dvode-mf21` | PASS | 2.55e-04 | 0.242 | 1352 | 22 | 925/89 | 108 calls (6.1 KB) |
| `radau5` | PASS | 2.47e-06 | 0.149 | 3008 | 247 | 350/11 | 109 calls (6.2 KB) |
| `rodas` | PASS | 6.61e-06 | 0.190 | 3708 | 608 | 608/12 | 108 calls (6.1 KB) |
| `julia-rodas5p` | PASS | 1.75e-06 | 0.455 | 4759 | 381 | 381/166 | GC managed |
| `julia-fbdf` | PASS | 6.10e-05 | 1.501 | 3342 | 13 | 936/153 | GC managed |
| `julia-cvode-bdf` | PASS | 2.54e-04 | 0.450 | 1354 | 23 | 835/90 | GC managed |

### Problem: `oregonator` (`rtol = 1e-6`)

| Solver Arm | Status | Max WRMS Error | Median Time (ms) | RHS Evals | Jac Evals | Steps (Acc/Rej) | Full-Run Heap |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `vigilode-dense` | PASS | 2.01e-06 | 0.977 | 8309 | 903 | 903/26 | 1176 calls (536.6 KB) |
| `vigilode` | PASS | 2.08e-06 | 0.676 | 7683 | 935 | 935/29 | 1089 calls (80.4 KB) |
| `diffsol-bdf-dense` | PASS | 2.08e-04 | 1.029 | 3974 | 0 | 1469/138 | 8549 calls (803.8 KB) |
| `cvode-bdf-dense` | PASS | 4.28e-04 | 2.466 | 3679 | 59 | 2357/194 | 200 calls (19.5 KB) |
| `dvode-mf21` | FAIL(DVODE ISTATE -1) | — | 0.313 | 1465 | 20 | 982/77 | 14 calls (3.5 KB) |
| `radau5` | PASS | 3.51e-06 | 0.354 | 5397 | 486 | 579/8 | 109 calls (8.1 KB) |
| `rodas` | PASS | 8.35e-06 | 0.636 | 9056 | 1501 | 1501/10 | 108 calls (7.9 KB) |
| `julia-rodas5p` | PASS | 2.06e-06 | 1.232 | 11146 | 1072 | 1072/187 | GC managed |
| `julia-fbdf` | PASS | 1.49e-05 | 2.899 | 6880 | 32 | 1653/165 | GC managed |
| `julia-cvode-bdf` | PASS | 5.48e-04 | 1.088 | 3424 | 57 | 2036/183 | GC managed |

### Problem: `brusselator-1d-n100` (`rtol = 1e-6`)

| Solver Arm | Status | Max WRMS Error | Median Time (ms) | RHS Evals | Jac Evals | Steps (Acc/Rej) | Full-Run Heap |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `vigilode-dense` | PASS | 9.00e-06 | 2.974 | 765 | 78 | 78/9 | 341 calls (2067.1 KB) |
| `vigilode-banded-dense` | PASS | 9.00e-06 | 1.847 | 765 | 78 | 78/9 | 342 calls (1921.0 KB) |
| `vigilode` | PASS | 4.54e-07 | 3.427 | 1053 | 129 | 129/3 | 283 calls (10339.1 KB) |
| `vigilode-banded` | PASS | 4.54e-07 | 2.094 | 1053 | 129 | 129/3 | 155 calls (114.3 KB) |
| `diffsol-bdf-dense` | PASS | 4.31e-05 | 3.722 | 292 | 0 | 203/8 | 900 calls (4888.4 KB) |
| `diffsol-bdf-sparse` | PASS | 4.31e-05 | 1.094 | 292 | 0 | 203/8 | 1849 calls (1721.3 KB) |
| `cvode-bdf-dense` | PASS | 1.18e-05 | 7.899 | 236 | 4 | 196/6 | 200 calls (345.4 KB) |
| `cvode-bdf-band` | PASS | 1.18e-05 | 2.102 | 236 | 4 | 196/6 | 200 calls (200.1 KB) |
| `dvode-mf21` | PASS | 1.18e-05 | 1.339 | 236 | 4 | 196/6 | 108 calls (325.8 KB) |
| `dvode-mf24` | PASS | 1.18e-05 | 0.725 | 236 | 4 | 196/6 | 108 calls (178.9 KB) |
| `radau5` | PASS | 1.68e-06 | 3.975 | 506 | 65 | 71/2 | 109 calls (485.9 KB) |
| `radau5-band` | PASS | 1.68e-06 | 1.032 | 506 | 65 | 71/2 | 109 calls (193.7 KB) |
| `rodas` | PASS | 1.00e-06 | 4.082 | 789 | 129 | 129/3 | 108 calls (329.6 KB) |
| `rodas-band` | PASS | 1.00e-06 | 1.440 | 789 | 129 | 129/3 | 108 calls (182.7 KB) |
| `julia-rodas5p` | PASS | 5.63e-06 | 5.385 | 974 | 100 | 100/9 | GC managed |
| `julia-fbdf` | PASS | 1.78e-05 | 2.876 | 491 | 1 | 215/8 | GC managed |
| `julia-cvode-bdf` | PASS | 1.18e-05 | 1.334 | 236 | 4 | 190/6 | GC managed |

## 3. 2D/3D Spatial & Spherical PDE Battery (`adversarial_spatial_battery_v3`, 9 Problems, `rtol=1e-6`)

| Problem | `vigilode-banded-dense` (ms / err) | `vigilode-dense` (ms / err) | `diffsol-bdf-sparse` (ms / err) | `diffsol-bdf-dense` (ms / err) | `cvode-bdf-band` (ms / err) | `cvode-bdf-dense` (ms / err) | `dvode-mf24` (ms / err) | `dvode-mf21` (ms / err) | `radau5-band` (ms / err) | `rodas-band` (ms / err) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `sphere-photon-2d` | 0.363 / 9.70e-08 | 0.401 / 9.70e-08 | 0.612 / 7.97e-07 | 1.167 / 7.97e-07 | 0.610 / 1.41e-06 | 1.537 / 1.41e-06 | 0.188 / 1.41e-06 | 0.349 / 1.41e-06 | 0.220 / 8.81e-07 | 0.299 / 1.97e-07 |
| `semilinear-advection-diffusion-2d` | 0.761 / 1.21e-07 | 0.841 / 1.21e-07 | 0.711 / 5.05e-06 | 1.442 / 5.05e-06 | 1.220 / 3.48e-06 | 2.983 / 3.48e-06 | 0.322 / 3.48e-06 | 0.544 / 3.48e-06 | 0.521 / 1.12e-06 | 0.526 / 4.85e-07 |
| `semilinear-advection-diffusion-3d` | 2.803 / 6.95e-08 | 2.401 / 6.95e-08 | 4.887 / 4.49e-07 | 9.862 / 4.49e-07 | 7.550 / 2.99e-06 | 17.198 / 2.99e-06 | 1.214 / 3.08e-06 | 2.625 / 3.08e-06 | 2.916 / 1.00e-06 | 1.750 / 2.64e-07 |
| `sphere-photon-3d` | 2.428 / 5.69e-08 | 2.842 / 5.69e-08 | 11.904 / 3.78e-07 | 29.044 / 3.78e-07 | 7.204 / 1.73e-06 | 28.586 / 1.73e-06 | 1.257 / 1.70e-06 | 4.296 / 1.70e-06 | 3.034 / 7.08e-07 | 2.386 / 1.74e-07 |
| `spherical-diffusion-2d` | 0.254 / 7.70e-08 | 0.259 / 7.70e-08 | 0.487 / 7.27e-07 | 0.578 / 7.27e-07 | 0.442 / 3.13e-06 | 0.899 / 3.13e-06 | 0.140 / 2.83e-06 | 0.209 / 2.83e-06 | 0.166 / 8.67e-07 | 0.188 / 1.60e-07 |
| `allen-cahn-2d` | 0.223 / 4.34e-07 | 0.229 / 4.34e-07 | 0.366 / 1.67e-07 | 0.449 / 1.67e-07 | 0.406 / 1.22e-06 | 0.816 / 1.22e-06 | 0.109 / 1.09e-06 | 0.178 / 1.09e-06 | 0.149 / 1.00e-06 | 0.159 / 4.24e-07 |
| `gray-scott-2d` | 0.775 / 1.79e-07 | 0.778 / 1.79e-07 | 1.211 / 9.85e-07 | 2.343 / 9.85e-07 | 1.420 / 1.25e-05 | 3.244 / 1.25e-05 | 0.300 / 8.12e-06 | 0.623 / 8.12e-06 | 0.506 / 1.27e-06 | 0.423 / 4.39e-07 |
| `burgers-2d` | 1.173 / 1.89e-06 | 1.001 / 1.89e-06 | 1.056 / 3.30e-06 | 1.361 / 3.30e-06 | 1.514 / 2.46e-06 | 2.618 / 2.46e-06 | 0.433 / 3.76e-06 | 0.600 / 3.76e-06 | 0.521 / 8.24e-06 | 0.663 / 4.67e-07 |
| `sine-gordon-2d` | 0.523 / 1.79e-07 | 0.432 / 1.79e-07 | 0.386 / 2.66e-06 | 0.677 / 2.66e-06 | 0.735 / 8.62e-06 | 1.292 / 8.62e-06 | 0.199 / 8.68e-06 | 0.275 / 8.68e-06 | 0.286 / 2.32e-06 | 0.390 / 4.51e-07 |

### Spatial Battery v3 Geometric-Mean Speed Ratio (`comparator_ms / vigilode-banded-dense_ms`, >1 = VigilODE faster, `rtol=1e-6`)

| Comparator Arm | Geo-Mean Speed Ratio vs `vigilode-banded-dense` | All 9 PDEs Succeeded? |
| :--- | :---: | :---: |
| `vigilode-dense` | 0.99× | Yes |
| `diffsol-bdf-sparse` | 1.52× | Yes |
| `diffsol-bdf-dense` | 2.59× | Yes |
| `cvode-bdf-band` | 1.83× | Yes |
| `cvode-bdf-dense` | 4.14× | Yes |
| `dvode-mf24` | 0.45× | Yes |
| `dvode-mf21` | 0.82× | Yes |
| `radau5-band` | 0.69× | Yes |
| `rodas-band` | 0.70× | Yes |

## 4. Extended Full-Scope Adversarial Suites (`full_scope_suite` + Julia + SciPy)

### Problem: `kepler-ecc05`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-adams` | PASS | 3.60e-01 | 0.625 | 989 | 0 | — | 0 | 607/48 | energy_drift=1.90e-03, ncfn=0, nfeLS=0, nni=986 |
| 1e-04 | `cvode-bdf-dense` | PASS | 7.90e-01 | 0.810 | 970 | 13 | — | 118 | 701/53 | ncfn=0, nfeLS=0, nni=967 |
| 1e-04 | `diffsol-bdf-dense` | PASS | 1.54e-02 | 0.458 | — | — | — | 160 | 674/97 | ncfn=3, nni=1248 |
| 1e-04 | `diffsol-tsit45` | PASS | 1.63e-01 | 0.109 | — | — | — | 0 | 173/73 | ang_mom_drift=4.36e-04, energy_drift=1.20e-03, ncfn=0, nni=0 |
| 1e-04 | `dvode-mf10-adams` | PASS | 1.27e-01 | 0.155 | 990 | 0 | — | 0 | 617/48 | energy_drift=1.69e-03, ncfn=0, nni=0 |
| 1e-04 | `julia-cvode-adams` | PASS | 3.60e-01 | 0.348 | 988 | 0 | — | — | 559/48 | ang_mom_drift=2.30e-03, energy_drift=1.89e-03 |
| 1e-04 | `julia-rodas5p` | PASS | 8.92e-02 | 0.537 | 5089 | 347 | — | — | 347/72 | ang_mom_drift=5.01e-04, energy_drift=4.43e-04 |
| 1e-04 | `julia-tsit5` | PASS | 5.62e-01 | 0.053 | 1407 | 0 | — | — | 195/39 | ang_mom_drift=1.05e-03, energy_drift=3.84e-03 |
| 1e-04 | `julia-vern9` | PASS | 2.57e-02 | 0.098 | 2034 | 0 | — | — | 106/21 | ang_mom_drift=2.46e-05, energy_drift=1.41e-04 |
| 1e-04 | `radau5` | PASS | 4.40e-02 | 0.214 | 2487 | 306 | — | 359 | 318/42 | nstep=360 |
| 1e-04 | `scipy-dop853` | PASS | 2.80e-02 | 10.217 | 1739 | 0 | — | 0 | —/— | energy_drift=1.63e-04 |
| 1e-04 | `scipy-radau` | PASS | 8.11e-03 | 84.770 | 3154 | 71 | — | 378 | —/— | energy_drift=3.81e-05 |
| 1e-04 | `scipy-rk45` | PASS | 7.76e-01 | 8.711 | 1190 | 0 | — | 0 | —/— | energy_drift=9.38e-03 |
| 1e-04 | `vigilode-auto-endpoint` | PASS | — | 0.063 | 1237 | 0 | 0 | 0 | 152/54 | ang_mom_drift=1.52e-04, endpoint_only=True, endpoint_wrms=7.45e-01, energy_drift=8.13e-03, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier1ExplicitDopri5'] |
| 1e-04 | `vigilode-dopri5-dense` | PASS | 7.45e-01 | 0.077 | 1237 | 0 | 0 | 0 | 152/54 | ang_mom_drift=1.52e-04, energy_drift=8.13e-03, fsal_reuses=205, mode=quartic-dense-observations |
| 1e-04 | `vigilode-dopri5-obs` | PASS | 7.24e-01 | 0.077 | 1315 | 0 | 0 | 0 | 185/34 | ang_mom_drift=5.87e-04, energy_drift=7.26e-03, fsal_reuses=218, mode=step-landing |
| 1e-04 | `vigilode-rodas5p-dense` | PASS | 1.23e-01 | 0.355 | 3147 | 282 | 0 | 369 | 282/87 | ang_mom_drift=5.06e-04, energy_drift=5.85e-04, ft_calls=0, output_clipped_steps=0 |
| 1e-06 | `cvode-adams` | PASS | 4.72e-03 | 1.247 | 1761 | 0 | — | 0 | 1093/70 | energy_drift=2.87e-05, ncfn=0, nfeLS=0, nni=1758 |
| 1e-06 | `cvode-bdf-dense` | PASS | 3.35e-02 | 1.431 | 1691 | 24 | — | 139 | 1380/66 | ncfn=0, nfeLS=0, nni=1688 |
| 1e-06 | `diffsol-bdf-dense` | PASS | 2.87e-02 | 0.706 | — | — | — | 174 | 1403/111 | ncfn=4, nni=2120 |
| 1e-06 | `diffsol-tsit45` | PASS | 7.05e-04 | 0.227 | — | — | — | 0 | 413/146 | ang_mom_drift=3.86e-06, energy_drift=1.74e-06, ncfn=0, nni=0 |
| 1e-06 | `dvode-mf10-adams` | PASS | 5.22e-03 | 0.291 | 1782 | 0 | — | 0 | 1112/65 | energy_drift=3.72e-05, ncfn=1, nni=0 |
| 1e-06 | `julia-cvode-adams` | PASS | 4.72e-03 | 0.604 | 1760 | 0 | — | — | 1023/70 | ang_mom_drift=5.36e-05, energy_drift=2.88e-05 |
| 1e-06 | `julia-rodas5p` | PASS | 8.55e-04 | 1.221 | 11837 | 847 | — | — | 847/103 | ang_mom_drift=2.63e-06, energy_drift=4.45e-06 |
| 1e-06 | `julia-tsit5` | PASS | 1.59e-03 | 0.111 | 3171 | 0 | — | — | 478/50 | ang_mom_drift=3.57e-06, energy_drift=8.84e-06 |
| 1e-06 | `julia-vern9` | PASS | 7.87e-05 | 0.140 | 3122 | 0 | — | — | 162/33 | ang_mom_drift=2.30e-08, energy_drift=4.24e-07 |
| 1e-06 | `radau5` | PASS | 7.77e-04 | 0.424 | 4984 | 613 | — | 732 | 667/66 | nstep=733 |
| 1e-06 | `scipy-dop853` | PASS | 1.47e-03 | 14.882 | 2636 | 0 | — | 0 | —/— | energy_drift=7.00e-06 |
| 1e-06 | `scipy-radau` | PASS | 2.38e-05 | 218.924 | 9111 | 21 | — | 442 | —/— | energy_drift=1.20e-07 |
| 1e-06 | `scipy-rk45` | PASS | 2.39e-03 | 17.324 | 2774 | 0 | — | 0 | —/— | energy_drift=1.81e-05 |
| 1e-06 | `vigilode-auto-endpoint` | PASS | — | 0.142 | 2785 | 0 | 0 | 0 | 358/106 | ang_mom_drift=2.47e-06, endpoint_only=True, endpoint_wrms=2.35e-03, energy_drift=1.87e-05, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier1ExplicitDopri5'] |
| 1e-06 | `vigilode-dopri5-dense` | PASS | 2.35e-03 | 0.159 | 2785 | 0 | 0 | 0 | 358/106 | ang_mom_drift=2.47e-06, energy_drift=1.87e-05, fsal_reuses=463, mode=quartic-dense-observations |
| 1e-06 | `vigilode-dopri5-obs` | PASS | 2.45e-03 | 0.156 | 2899 | 0 | 0 | 0 | 393/90 | ang_mom_drift=2.18e-06, energy_drift=1.84e-05, fsal_reuses=482, mode=step-landing |
| 1e-06 | `vigilode-rodas5p-dense` | PASS | 1.49e-03 | 0.761 | 6941 | 702 | 0 | 791 | 702/89 | ang_mom_drift=3.56e-06, energy_drift=7.19e-06, ft_calls=0, output_clipped_steps=0 |
| 1e-08 | `cvode-adams` | PASS | 6.12e-05 | 2.278 | 2999 | 0 | — | 0 | 1858/89 | energy_drift=1.89e-07, ncfn=0, nfeLS=0, nni=2996 |
| 1e-08 | `cvode-bdf-dense` | PASS | 9.30e-04 | 2.830 | 3256 | 50 | — | 207 | 2930/59 | ncfn=0, nfeLS=0, nni=3253 |
| 1e-08 | `diffsol-bdf-dense` | PASS | 4.80e-04 | 1.193 | — | — | — | 154 | 3017/84 | ncfn=0, nni=3814 |
| 1e-08 | `diffsol-tsit45` | PASS | 1.40e-05 | 0.423 | — | — | — | 0 | 972/129 | ang_mom_drift=4.40e-08, energy_drift=6.06e-08, ncfn=0, nni=0 |
| 1e-08 | `dvode-mf10-adams` | PASS | 3.80e-05 | 0.504 | 2856 | 0 | — | 0 | 1779/93 | energy_drift=9.30e-10, ncfn=0, nni=0 |
| 1e-08 | `julia-cvode-adams` | PASS | 6.12e-05 | 1.040 | 2995 | 0 | — | — | 1769/88 | ang_mom_drift=6.23e-07, energy_drift=1.90e-07 |
| 1e-08 | `julia-rodas5p` | PASS | 7.39e-06 | 2.981 | 28999 | 2145 | — | — | 2145/139 | ang_mom_drift=1.70e-08, energy_drift=3.82e-08 |
| 1e-08 | `julia-tsit5` | PASS | 2.59e-06 | 0.245 | 7275 | 0 | — | — | 1194/18 | ang_mom_drift=6.22e-09, energy_drift=1.15e-08 |
| 1e-08 | `julia-vern9` | PASS | 9.76e-07 | 0.195 | 4818 | 0 | — | — | 251/50 | ang_mom_drift=1.46e-10, energy_drift=5.30e-09 |
| 1e-08 | `radau5` | PASS | 9.58e-06 | 0.815 | 10024 | 660 | — | 1063 | 1405/39 | nstep=1444 |
| 1e-08 | `scipy-dop853` | PASS | 2.48e-05 | 21.779 | 3884 | 0 | — | 0 | —/— | energy_drift=1.29e-07 |
| 1e-08 | `scipy-radau` | PASS | 7.19e-08 | 690.419 | 31414 | 21 | — | 584 | —/— | energy_drift=3.62e-10 |
| 1e-08 | `scipy-rk45` | PASS | 5.96e-06 | 34.373 | 5858 | 0 | — | 0 | —/— | energy_drift=5.24e-09 |
| 1e-08 | `vigilode-auto-endpoint` | PASS | — | 0.290 | 5887 | 0 | 0 | 0 | 891/90 | ang_mom_drift=3.55e-08, endpoint_only=True, endpoint_wrms=6.14e-06, energy_drift=4.78e-09, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier1ExplicitDopri5'] |
| 1e-08 | `vigilode-dopri5-dense` | PASS | 6.14e-06 | 0.312 | 5887 | 0 | 0 | 0 | 891/90 | ang_mom_drift=3.55e-08, energy_drift=4.78e-09, fsal_reuses=980, mode=quartic-dense-observations |
| 1e-08 | `vigilode-dopri5-obs` | PASS | 6.26e-06 | 0.302 | 5953 | 0 | 0 | 0 | 922/70 | ang_mom_drift=3.32e-08, energy_drift=2.90e-09, fsal_reuses=991, mode=step-landing |
| 1e-08 | `vigilode-rodas5p-dense` | PASS | 1.39e-05 | 1.780 | 16561 | 1795 | 0 | 1853 | 1795/58 | ang_mom_drift=3.08e-08, energy_drift=6.77e-08, ft_calls=0, output_clipped_steps=0 |

### Problem: `nonnormal-kreiss-b100`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-adams` | PASS | 5.23e-05 | 0.057 | 76 | 0 | — | 0 | 46/0 | ncfn=0, nfeLS=0, nni=73 |
| 1e-04 | `diffsol-tsit45` | PASS | 1.57e-05 | 0.039 | — | — | — | 0 | 24/0 | ncfn=0, nni=0 |
| 1e-04 | `dvode-mf10-adams` | PASS | 5.17e-05 | 0.015 | 76 | 0 | — | 0 | 46/0 | ncfn=0, nni=0 |
| 1e-04 | `julia-cvode-bdf` | PASS | 1.37e-04 | 0.074 | 79 | 2 | — | — | 58/2 |  |
| 1e-04 | `julia-rodas5p` | PASS | 3.93e-07 | 0.032 | 244 | 22 | — | — | 22/0 |  |
| 1e-04 | `julia-tsit5` | PASS | 8.31e-07 | 0.014 | 159 | 0 | — | — | 26/0 |  |
| 1e-04 | `vigilode-auto-endpoint` | PASS | — | 0.011 | 112 | 14 | 0 | 14 | 14/0 | endpoint_only=True, endpoint_wrms=2.21e-07, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['TierProtectedReference'] |
| 1e-04 | `vigilode-dopri5-dense` | PASS | 1.64e-05 | 0.014 | 115 | 0 | 0 | 0 | 19/0 | fsal_reuses=18, mode=quartic-dense-observations |
| 1e-04 | `vigilode-rodas5p-dense` | PASS | 7.72e-06 | 0.019 | 126 | 14 | 0 | 14 | 14/0 | ft_calls=0, output_clipped_steps=0 |
| 1e-06 | `cvode-adams` | PASS | 8.69e-07 | 0.084 | 108 | 0 | — | 0 | 66/1 | ncfn=0, nfeLS=0, nni=105 |
| 1e-06 | `diffsol-tsit45` | PASS | 1.30e-07 | 0.044 | — | — | — | 0 | 40/0 | ncfn=0, nni=0 |
| 1e-06 | `dvode-mf10-adams` | PASS | 4.22e-07 | 0.020 | 98 | 0 | — | 0 | 60/0 | ncfn=0, nni=0 |
| 1e-06 | `julia-cvode-bdf` | PASS | 4.11e-06 | 0.091 | 134 | 2 | — | — | 106/4 |  |
| 1e-06 | `julia-rodas5p` | PASS | 1.23e-08 | 0.048 | 453 | 41 | — | — | 41/0 |  |
| 1e-06 | `julia-tsit5` | PASS | 1.66e-08 | 0.018 | 297 | 0 | — | — | 49/0 |  |
| 1e-06 | `vigilode-auto-endpoint` | PASS | — | 0.018 | 216 | 27 | 0 | 27 | 27/0 | endpoint_only=True, endpoint_wrms=1.75e-09, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['TierProtectedReference'] |
| 1e-06 | `vigilode-dopri5-dense` | PASS | 1.54e-07 | 0.019 | 229 | 0 | 0 | 0 | 38/0 | fsal_reuses=37, mode=quartic-dense-observations |
| 1e-06 | `vigilode-rodas5p-dense` | PASS | 1.03e-07 | 0.030 | 243 | 27 | 0 | 27 | 27/0 | ft_calls=0, output_clipped_steps=0 |
| 1e-08 | `cvode-adams` | PASS | 1.62e-08 | 0.115 | 172 | 0 | — | 0 | 100/3 | ncfn=0, nfeLS=0, nni=170 |
| 1e-08 | `diffsol-tsit45` | PASS | 9.16e-10 | 0.054 | — | — | — | 0 | 82/0 | ncfn=0, nni=0 |
| 1e-08 | `dvode-mf10-adams` | PASS | 1.59e-08 | 0.032 | 180 | 0 | — | 0 | 109/3 | ncfn=0, nni=0 |
| 1e-08 | `julia-cvode-bdf` | PASS | 2.50e-08 | 0.131 | 239 | 4 | — | — | 228/0 |  |
| 1e-08 | `julia-rodas5p` | PASS | 2.58e-10 | 0.089 | 948 | 86 | — | — | 86/0 |  |
| 1e-08 | `julia-tsit5` | PASS | 3.01e-10 | 0.026 | 639 | 0 | — | — | 106/0 |  |
| 1e-08 | `vigilode-auto-endpoint` | PASS | — | 0.036 | 488 | 61 | 0 | 61 | 61/0 | endpoint_only=True, endpoint_wrms=9.10e-12, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['TierProtectedReference'] |
| 1e-08 | `vigilode-dopri5-dense` | PASS | 1.69e-09 | 0.036 | 523 | 0 | 0 | 0 | 87/0 | fsal_reuses=86, mode=quartic-dense-observations |
| 1e-08 | `vigilode-rodas5p-dense` | PASS | 1.29e-09 | 0.053 | 549 | 61 | 0 | 61 | 61/0 | ft_calls=0, output_clipped_steps=0 |

### Problem: `dopri5-ensemble-n1024x16`

> *Note: The table below was measured under single-core `taskset -c 0` pinning (`6.147 ms` 1T vs `6.310 ms` 8T). See `Unpinned 8-Thread Parallel Ensemble` below for true multi-core scaling (`6.603 ms` 1T -> `1.687 ms` 8T).*

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-06 | `diffsol-tsit45-seq16` | PASS | — | 2.557 | — | — | — | — | None/None | max_abs_err=3.58e-08 |
| 1e-06 | `julia-tsit5-seq16` | PASS | 4.45e-09 | 2.879 | — | — | — | — | None/None | max_abs_err=4.45e-09 |
| 1e-06 | `vigilode-ensemble-1t` | PASS | — | 6.147 | 1738 | — | — | — | None/None | max_abs_err=6.26e-08, workers=1 |
| 1e-06 | `vigilode-ensemble-8t` | PASS | — | 6.310 | 1738 | — | — | — | None/None | max_abs_err=6.26e-08, workers=8 |

### Problem: `prothero-robinson-1e4`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-bdf-dense` | PASS | 4.58e-05 | 0.080 | 115 | 2 | — | 17 | 80/6 | ncfn=0, nfeLS=0, nni=112 |
| 1e-04 | `diffsol-bdf-dense` | PASS | 2.45e-05 | 0.052 | — | — | — | 31 | 87/13 | ncfn=0, nni=121 |
| 1e-04 | `diffsol-esdirk34` | PASS | 5.66e-02 | 0.027 | — | — | — | 16 | 20/0 | ncfn=0, nni=73 |
| 1e-04 | `diffsol-trbdf2` | PASS | 2.27e-02 | 0.033 | — | — | — | 16 | 20/0 | ncfn=0, nni=52 |
| 1e-04 | `dvode-mf21` | PASS | 2.36e-05 | 0.022 | 117 | 2 | — | 23 | 73/9 | ncfn=0, nni=114 |
| 1e-04 | `julia-cvode-bdf` | PASS | 4.58e-05 | 0.085 | 115 | 2 | — | — | 74/6 |  |
| 1e-04 | `julia-fbdf` | PASS | 1.20e-06 | 0.146 | 172 | 1 | — | — | 142/6 |  |
| 1e-04 | `julia-radauiia5` | PASS | 1.34e-01 | 0.018 | 29 | 1 | — | — | 5/0 |  |
| 1e-04 | `julia-rodas5p` | PASS | 6.56e-04 | 0.026 | 155 | 17 | — | — | 17/0 |  |
| 1e-04 | `radau5` | PASS | 7.92e-02 | 0.007 | 65 | 3 | — | 14 | 12/2 | nstep=14 |
| 1e-04 | `rodas-idfx0` | PASS | 6.68e-02 | 0.007 | 90 | 15 | — | 15 | 15/0 | nstep=15 |
| 1e-04 | `rodas-idfx1` | PASS | 6.68e-02 | 0.007 | 90 | 15 | — | 15 | 15/0 | nstep=15 |
| 1e-04 | `scipy-bdf` | PASS | 8.03e-06 | 10.196 | 206 | 9 | — | 26 | —/— |  |
| 1e-04 | `scipy-lsoda` | PASS | 3.76e-05 | 1.941 | 302 | 40 | — | 40 | —/— |  |
| 1e-04 | `scipy-radau` | PASS | 3.17e-01 | 1.388 | 51 | 1 | — | 14 | —/— |  |
| 1e-04 | `vigilode-rodas5p-enforce-ft` | PASS | 3.25e-04 | 0.249 | 279 | 62 | 0 | 62 | 16/15 | ft_calls=31, output_clipped_steps=0 |
| 1e-04 | `vigilode-rodas5p-fd-ft` | PASS | 2.01e-05 | 0.027 | 258 | 22 | 0 | 24 | 22/2 | ft_calls=22, output_clipped_steps=0 |
| 1e-04 | `vigilode-rodas5p-ft` | PASS | 2.01e-05 | 0.027 | 214 | 22 | 0 | 24 | 22/2 | ft_calls=22, output_clipped_steps=0 |
| 1e-06 | `cvode-bdf-dense` | PASS | 1.33e-07 | 0.127 | 183 | 3 | — | 30 | 132/10 | ncfn=0, nfeLS=0, nni=180 |
| 1e-06 | `diffsol-bdf-dense` | PASS | 1.69e-07 | 0.087 | — | — | — | 51 | 161/28 | ncfn=0, nni=237 |
| 1e-06 | `diffsol-esdirk34` | PASS | 2.25e-04 | 0.050 | — | — | — | 17 | 51/1 | ncfn=1, nni=196 |
| 1e-06 | `diffsol-trbdf2` | PASS | 1.67e-04 | 0.115 | — | — | — | 90 | 92/45 | ncfn=0, nni=369 |
| 1e-06 | `dvode-mf21` | PASS | 2.08e-07 | 0.039 | 228 | 3 | — | 37 | 161/14 | ncfn=0, nni=225 |
| 1e-06 | `julia-cvode-bdf` | PASS | 1.33e-07 | 0.102 | 182 | 3 | — | — | 122/10 |  |
| 1e-06 | `julia-fbdf` | PASS | 1.64e-08 | 0.274 | 330 | 1 | — | — | 247/16 |  |
| 1e-06 | `julia-radauiia5` | PASS | 1.04e-01 | 0.015 | 33 | 1 | — | — | 6/0 |  |
| 1e-06 | `julia-rodas5p` | PASS | 7.11e-06 | 0.039 | 326 | 36 | — | — | 36/0 |  |
| 1e-06 | `radau5` | PASS | 3.15e-03 | 0.008 | 84 | 3 | — | 16 | 16/2 | nstep=18 |
| 1e-06 | `rodas-idfx0` | PASS | 8.17e-04 | 0.048 | 955 | 140 | — | 163 | 140/23 | nstep=163 |
| 1e-06 | `rodas-idfx1` | PASS | 8.17e-04 | 0.047 | 955 | 140 | — | 163 | 140/23 | nstep=163 |
| 1e-06 | `scipy-bdf` | PASS | 2.81e-07 | 14.943 | 288 | 11 | — | 35 | —/— |  |
| 1e-06 | `scipy-lsoda` | PASS | 5.15e-07 | 2.044 | 336 | 24 | — | 24 | —/— |  |
| 1e-06 | `scipy-radau` | PASS | 6.38e-04 | 3.876 | 148 | 1 | — | 24 | —/— |  |
| 1e-06 | `vigilode-rodas5p-enforce-ft` | PASS | 2.01e-06 | 0.796 | 936 | 208 | 0 | 208 | 44/60 | ft_calls=104, output_clipped_steps=0 |
| 1e-06 | `vigilode-rodas5p-fd-ft` | PASS | 1.66e-07 | 0.054 | 657 | 59 | 0 | 60 | 59/1 | ft_calls=59, output_clipped_steps=0 |
| 1e-06 | `vigilode-rodas5p-ft` | PASS | 1.66e-07 | 0.053 | 539 | 59 | 0 | 60 | 59/1 | ft_calls=59, output_clipped_steps=0 |
| 1e-08 | `cvode-bdf-dense` | PASS | 8.72e-10 | 0.207 | 293 | 5 | — | 35 | 230/10 | ncfn=0, nfeLS=0, nni=290 |
| 1e-08 | `diffsol-bdf-dense` | PASS | 9.61e-10 | 0.104 | — | — | — | 34 | 269/12 | ncfn=0, nni=330 |
| 1e-08 | `diffsol-esdirk34` | PASS | 1.52e-06 | 0.328 | — | — | — | 119 | 356/56 | ncfn=1, nni=1570 |
| 1e-08 | `diffsol-trbdf2` | PASS | 4.33e-07 | 0.380 | — | — | — | 101 | 572/54 | ncfn=1, nni=1673 |
| 1e-08 | `dvode-mf21` | PASS | 1.81e-09 | 0.056 | 309 | 5 | — | 42 | 243/12 | ncfn=0, nni=306 |
| 1e-08 | `julia-cvode-bdf` | PASS | 8.72e-10 | 0.140 | 293 | 5 | — | — | 220/10 |  |
| 1e-08 | `julia-fbdf` | PASS | 1.25e-10 | 0.575 | 659 | 1 | — | — | 468/29 |  |
| 1e-08 | `julia-radauiia5` | PASS | 3.25e-04 | 0.053 | 384 | 1 | — | — | 30/51 |  |
| 1e-08 | `julia-rodas5p` | PASS | 1.77e-08 | 0.106 | 1064 | 118 | — | — | 118/0 |  |
| 1e-08 | `radau5` | PASS | 7.08e-05 | 0.010 | 132 | 1 | — | 20 | 27/0 | nstep=27 |
| 1e-08 | `rodas-idfx0` | PASS | 2.60e-09 | 1.943 | 41711 | 6931 | — | 6956 | 6931/25 | nstep=6956 |
| 1e-08 | `rodas-idfx1` | PASS | 2.10e-09 | 1.890 | 41632 | 6917 | — | 6943 | 6917/26 | nstep=6943 |
| 1e-08 | `scipy-bdf` | PASS | 1.16e-09 | 22.589 | 462 | 7 | — | 46 | —/— |  |
| 1e-08 | `scipy-lsoda` | PASS | 8.70e-10 | 2.514 | 486 | 17 | — | 17 | —/— |  |
| 1e-08 | `scipy-radau` | PASS | 4.18e-07 | 12.001 | 504 | 2 | — | 28 | —/— |  |
| 1e-08 | `vigilode-rodas5p-enforce-ft` | PASS | 5.64e-09 | 1.989 | 2349 | 522 | 0 | 522 | 133/128 | ft_calls=261, output_clipped_steps=0 |
| 1e-08 | `vigilode-rodas5p-fd-ft` | PASS | 1.76e-09 | 0.145 | 2004 | 180 | 0 | 183 | 180/3 | ft_calls=180, output_clipped_steps=0 |
| 1e-08 | `vigilode-rodas5p-ft` | PASS | 1.76e-09 | 0.141 | 1644 | 180 | 0 | 183 | 180/3 | ft_calls=180, output_clipped_steps=0 |

### Problem: `periodic-advdiff-n256`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-bdf-dense` | PASS | 1.63e-04 | 9.354 | 35 | 1 | — | 4 | 28/0 | ncfn=0, nfeLS=0, nni=32 |
| 1e-04 | `cvode-bdf-spgmr` | PASS | 1.68e-04 | 7.060 | 40 | 0 | — | 0 | 28/0 | ncfn=0, nfeLS=0, nni=37 |
| 1e-04 | `diffsol-bdf-dense` | PASS | 2.52e-04 | 18.490 | — | — | — | 7 | 34/0 | ncfn=0, nni=40 |
| 1e-04 | `diffsol-bdf-sparse` | PASS | 2.52e-04 | 1.147 | — | — | — | 7 | 34/0 | ncfn=0, nni=40 |
| 1e-04 | `dvode-mf21` | PASS | 1.49e-04 | 1.629 | 34 | 1 | — | 4 | 29/0 | ncfn=0, nni=31 |
| 1e-04 | `julia-cvode-bdf` | PASS | 1.63e-04 | 1.327 | 35 | 1 | — | — | 28/0 |  |
| 1e-04 | `julia-cvode-gmres` | PASS | 3.69e-04 | 1.347 | 104 | 0 | — | — | 66/0 |  |
| 1e-04 | `julia-fbdf` | PASS | 8.38e-05 | 0.656 | 56 | 1 | — | — | 32/0 |  |
| 1e-04 | `julia-rodas5p` | PASS | 1.09e-06 | 0.579 | 83 | 9 | — | — | 9/0 |  |
| 1e-04 | `radau5` | PASS | 3.21e-05 | 6.031 | 55 | 1 | — | 9 | 13/0 | nstep=13 |
| 1e-04 | `vigilode-auto-jvp` | PASS | — | 27.401 | 64 | 0 | 2688 | 0 | 8/0 | endpoint_only=True, endpoint_wrms=1.22e-05, fallback_steps=0, invariant_drift=[], linear_iterations=2560, routes=['Tier2MatrixFreeKrylov'] |
| 1e-04 | `vigilode-pexprb54s4` | PASS | 6.98e-14 | 79.949 | 408 | — | 5350 | — | 102/0 | phi_actions=510, phi_krylov_vectors=5044 |
| 1e-04 | `vigilode-rodas5p-dense` | PASS | 1.93e-05 | 3.894 | 72 | 8 | 0 | 8 | 8/0 | ft_calls=0, output_clipped_steps=0 |
| 1e-04 | `vigilode-sparse-jvp` | PASS | — | 27.832 | 64 | 0 | 2688 | 0 | 8/0 | endpoint_only=True, endpoint_wrms=1.22e-05, fallback_steps=0, invariant_drift=[], linear_iterations=2560, routes=['Tier2MatrixFreeKrylov'] |
| 1e-06 | `cvode-bdf-dense` | PASS | 1.06e-05 | 13.613 | 69 | 1 | — | 9 | 57/1 | ncfn=0, nfeLS=0, nni=66 |
| 1e-06 | `cvode-bdf-spgmr` | PASS | 9.77e-06 | 7.879 | 113 | 0 | — | 0 | 58/1 | ncfn=0, nfeLS=0, nni=110 |
| 1e-06 | `diffsol-bdf-dense` | PASS | 9.63e-07 | 16.321 | — | — | — | 9 | 71/0 | ncfn=0, nni=74 |
| 1e-06 | `diffsol-bdf-sparse` | PASS | 9.63e-07 | 0.967 | — | — | — | 9 | 71/0 | ncfn=0, nni=74 |
| 1e-06 | `dvode-mf21` | PASS | 1.07e-05 | 2.327 | 69 | 1 | — | 10 | 57/1 | ncfn=0, nni=66 |
| 1e-06 | `julia-cvode-bdf` | PASS | 1.05e-05 | 2.772 | 69 | 2 | — | — | 56/1 |  |
| 1e-06 | `julia-cvode-gmres` | PASS | 1.34e-05 | 1.587 | 136 | 0 | — | — | 114/1 |  |
| 1e-06 | `julia-fbdf` | PASS | 9.32e-07 | 0.989 | 117 | 1 | — | — | 61/1 |  |
| 1e-06 | `julia-rodas5p` | PASS | 3.88e-08 | 0.912 | 155 | 17 | — | — | 17/0 |  |
| 1e-06 | `radau5` | PASS | 1.55e-06 | 6.363 | 92 | 1 | — | 9 | 20/0 | nstep=20 |
| 1e-06 | `vigilode-auto-jvp` | PASS | — | 53.821 | 104 | 0 | 4368 | 0 | 13/0 | endpoint_only=True, endpoint_wrms=9.55e-08, fallback_steps=0, invariant_drift=[], linear_iterations=4160, routes=['Tier2MatrixFreeKrylov'] |
| 1e-06 | `vigilode-pexprb54s4` | PASS | 6.98e-14 | 56.458 | 408 | — | 5350 | — | 102/0 | phi_actions=510, phi_krylov_vectors=5044 |
| 1e-06 | `vigilode-rodas5p-dense` | PASS | 1.94e-07 | 6.032 | 117 | 13 | 0 | 13 | 13/0 | ft_calls=0, output_clipped_steps=0 |
| 1e-06 | `vigilode-sparse-jvp` | PASS | — | 53.244 | 104 | 0 | 4368 | 0 | 13/0 | endpoint_only=True, endpoint_wrms=9.55e-08, fallback_steps=0, invariant_drift=[], linear_iterations=4160, routes=['Tier2MatrixFreeKrylov'] |
| 1e-08 | `cvode-bdf-dense` | PASS | 5.75e-08 | 22.472 | 118 | 2 | — | 14 | 105/1 | ncfn=0, nfeLS=0, nni=115 |
| 1e-08 | `cvode-bdf-spgmr` | PASS | 4.49e-08 | 13.620 | 182 | 0 | — | 0 | 165/1 | ncfn=0, nfeLS=0, nni=179 |
| 1e-08 | `diffsol-bdf-dense` | PASS | 1.74e-07 | 22.525 | — | — | — | 12 | 121/0 | ncfn=0, nni=127 |
| 1e-08 | `diffsol-bdf-sparse` | PASS | 1.74e-07 | 1.358 | — | — | — | 12 | 121/0 | ncfn=0, nni=127 |
| 1e-08 | `dvode-mf21` | PASS | 5.75e-08 | 3.605 | 118 | 2 | — | 14 | 105/1 | ncfn=0, nni=115 |
| 1e-08 | `julia-cvode-bdf` | PASS | 5.75e-08 | 4.414 | 118 | 2 | — | — | 104/1 |  |
| 1e-08 | `julia-cvode-gmres` | PASS | 7.75e-08 | 2.138 | 181 | 0 | — | — | 163/1 |  |
| 1e-08 | `julia-fbdf` | PASS | 5.99e-08 | 1.822 | 231 | 1 | — | — | 133/4 |  |
| 1e-08 | `julia-rodas5p` | PASS | 5.19e-10 | 1.566 | 317 | 35 | — | — | 35/0 |  |
| 1e-08 | `radau5` | PASS | 7.16e-08 | 7.588 | 172 | 1 | — | 8 | 37/0 | nstep=37 |
| 1e-08 | `vigilode-auto-jvp` | PASS | — | 92.113 | 208 | 0 | 8736 | 0 | 26/0 | endpoint_only=True, endpoint_wrms=5.44e-10, fallback_steps=0, invariant_drift=[], linear_iterations=8320, routes=['Tier2MatrixFreeKrylov'] |
| 1e-08 | `vigilode-pexprb54s4` | PASS | 6.98e-14 | 55.016 | 408 | — | 5350 | — | 102/0 | phi_actions=510, phi_krylov_vectors=5044 |
| 1e-08 | `vigilode-rodas5p-dense` | PASS | 1.99e-09 | 10.164 | 234 | 26 | 0 | 26 | 26/0 | ft_calls=0, output_clipped_steps=0 |
| 1e-08 | `vigilode-sparse-jvp` | PASS | — | 87.862 | 208 | 0 | 8736 | 0 | 26/0 | endpoint_only=True, endpoint_wrms=5.44e-10, fallback_steps=0, invariant_drift=[], linear_iterations=8320, routes=['Tier2MatrixFreeKrylov'] |

### Problem: `brusselator-1d-jvp-n400`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-bdf-band` | PASS | 4.98e-03 | 5.179 | 168 | 3 | — | 20 | 140/3 | ncfn=0, nfeLS=0, nni=165 |
| 1e-04 | `cvode-bdf-spgmr` | PASS | 1.09e-02 | 51.801 | 180 | 0 | — | 0 | 119/5 | ncfn=0, nfeLS=0, nni=177 |
| 1e-04 | `diffsol-bdf-sparse` | PASS | 5.20e-03 | 3.340 | — | — | — | 23 | 110/7 | ncfn=1, nni=219 |
| 1e-04 | `dvode-mf24` | PASS | 6.45e-03 | 2.128 | 183 | 3 | — | 23 | 140/6 | ncfn=0, nni=180 |
| 1e-04 | `julia-cvode-gmres` | PASS | 1.02e-03 | 10.990 | 629 | 0 | — | — | 409/0 |  |
| 1e-04 | `julia-fbdf` | PASS | 7.29e-03 | 3.513 | 380 | 1 | — | — | 123/8 |  |
| 1e-04 | `julia-rodas5p` | PASS | 8.09e-04 | 4.665 | 544 | 54 | — | — | 54/7 |  |
| 1e-04 | `radau5-band` | PASS | 7.43e-05 | 2.641 | 347 | 36 | — | 47 | 44/3 | nstep=47 |
| 1e-04 | `vigilode-auto-jvp` | PASS | — | 1351.839 | 674 | 0 | 85347 | 0 | 65/36 | endpoint_only=True, endpoint_wrms=1.34e-05, fallback_steps=0, invariant_drift=[], linear_iterations=82600, routes=['Tier2MatrixFreeKrylov'] |
| 1e-04 | `vigilode-banded-dense` | PASS | 3.49e-04 | 4.673 | 479 | 43 | 0 | 56 | 43/13 | ft_calls=0, output_clipped_steps=0 |
| 1e-04 | `vigilode-sparse-jvp` | PASS | — | 3.940 | 420 | 42 | 168 | 54 | 42/12 | endpoint_only=True, endpoint_wrms=1.71e-05, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier4StagedRodas5p'] |
| 1e-06 | `cvode-bdf-band` | PASS | 1.65e-04 | 8.921 | 273 | 4 | — | 28 | 228/7 | ncfn=0, nfeLS=0, nni=270 |
| 1e-06 | `cvode-bdf-spgmr` | PASS | 2.94e-04 | 78.833 | 416 | 0 | — | 0 | 284/6 | ncfn=0, nfeLS=0, nni=413 |
| 1e-06 | `diffsol-bdf-sparse` | PASS | 2.04e-04 | 7.564 | — | — | — | 32 | 236/15 | ncfn=0, nni=364 |
| 1e-06 | `dvode-mf24` | PASS | 1.25e-04 | 3.274 | 275 | 4 | — | 28 | 230/7 | ncfn=0, nni=272 |
| 1e-06 | `julia-cvode-gmres` | PASS | 5.00e-05 | 16.785 | 998 | 0 | — | — | 717/1 |  |
| 1e-06 | `julia-fbdf` | PASS | 1.19e-04 | 5.555 | 588 | 1 | — | — | 265/13 |  |
| 1e-06 | `julia-rodas5p` | PASS | 2.42e-05 | 9.656 | 1167 | 117 | — | — | 117/14 |  |
| 1e-06 | `radau5-band` | PASS | 3.28e-06 | 4.416 | 580 | 74 | — | 83 | 82/1 | nstep=83 |
| 1e-06 | `vigilode-auto-jvp` | PASS | — | 1068.114 | 820 | 0 | 67949 | 0 | 92/12 | endpoint_only=True, endpoint_wrms=2.40e-06, fallback_steps=0, invariant_drift=[], linear_iterations=65480, routes=['Tier2MatrixFreeKrylov'] |
| 1e-06 | `vigilode-banded-dense` | PASS | 2.96e-05 | 11.067 | 912 | 92 | 0 | 104 | 92/12 | ft_calls=0, output_clipped_steps=0 |
| 1e-06 | `vigilode-sparse-jvp` | PASS | — | 7.615 | 820 | 92 | 368 | 104 | 92/12 | endpoint_only=True, endpoint_wrms=2.40e-06, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier4StagedRodas5p'] |
| 1e-08 | `cvode-bdf-band` | PASS | 2.93e-06 | 17.791 | 531 | 9 | — | 40 | 482/6 | ncfn=0, nfeLS=0, nni=528 |
| 1e-08 | `cvode-bdf-spgmr` | PASS | 6.87e-06 | 90.026 | 973 | 0 | — | 0 | 668/6 | ncfn=0, nfeLS=0, nni=970 |
| 1e-08 | `diffsol-bdf-sparse` | PASS | 3.63e-06 | 7.806 | — | — | — | 33 | 511/10 | ncfn=0, nni=664 |
| 1e-08 | `dvode-mf24` | PASS | 2.93e-06 | 6.374 | 531 | 9 | — | 40 | 482/6 | ncfn=0, nni=528 |
| 1e-08 | `julia-cvode-gmres` | PASS | 1.60e-06 | 21.755 | 1412 | 0 | — | — | 1062/2 |  |
| 1e-08 | `julia-fbdf` | PASS | 3.28e-06 | 9.463 | 1023 | 1 | — | — | 577/15 |  |
| 1e-08 | `julia-rodas5p` | PASS | 2.51e-07 | 21.716 | 2672 | 278 | — | — | 278/21 |  |
| 1e-08 | `radau5-band` | PASS | 6.98e-08 | 8.534 | 1148 | 144 | — | 157 | 167/0 | nstep=167 |
| 1e-08 | `vigilode-auto-jvp` | PASS | — | 1535.964 | 1812 | 0 | 96813 | 0 | 223/4 | endpoint_only=True, endpoint_wrms=3.19e-08, fallback_steps=0, invariant_drift=[], linear_iterations=92680, routes=['Tier2MatrixFreeKrylov'] |
| 1e-08 | `vigilode-banded-dense` | PASS | 3.77e-07 | 17.987 | 2019 | 222 | 0 | 225 | 222/3 | ft_calls=0, output_clipped_steps=0 |
| 1e-08 | `vigilode-sparse-jvp` | PASS | — | 16.280 | 1812 | 223 | 892 | 227 | 223/4 | endpoint_only=True, endpoint_wrms=3.19e-08, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier4StagedRodas5p'] |

### Problem: `dae-robertson-index1`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `diffsol-bdf-mass` | PASS | 8.69e-05 | 0.104 | — | — | — | 21 | 93/0 | max_constraint_residual=4.44e-16, ncfn=1, nni=145 |
| 1e-04 | `diffsol-esdirk34-mass` | PASS | 2.73e-04 | 0.122 | — | — | — | 24 | 71/2 | max_constraint_residual=2.22e-16, ncfn=3, nni=526 |
| 1e-04 | `julia-dfbdf` | PASS | 1.92e-05 | 0.165 | 223 | 2 | — | — | 107/5 | max_constraint_residual=1.11e-15 |
| 1e-04 | `julia-fbdf` | PASS | 8.38e-05 | 0.156 | 245 | 2 | — | — | 102/6 | max_constraint_residual=3.55e-15 |
| 1e-04 | `julia-ida` | PASS | 3.79e-05 | 0.121 | 137 | 22 | — | — | 102/2 | max_constraint_residual=5.55e-16 |
| 1e-04 | `julia-rodas5p` | PASS | 1.16e-06 | 0.147 | 470 | 39 | — | — | 39/0 | max_constraint_residual=1.11e-15 |
| 1e-04 | `radau5-mass` | PASS | 1.51e-05 | 0.018 | 187 | 24 | — | 28 | 28/1 | max_constraint_residual=2.22e-16, nstep=29 |
| 1e-04 | `rodas-mass` | PASS | 2.19e-05 | 0.017 | 192 | 32 | — | 32 | 32/0 | max_constraint_residual=4.44e-16, nstep=32 |
| 1e-04 | `sundials-ida` | PASS | 3.75e-05 | 0.117 | 136 | 21 | — | 21 | 104/2 | max_constraint_residual=4.44e-16, ncfn=0, nni=136 |
| 1e-04 | `vigilode-rodas5p-mass` | PASS | 1.13e-05 | 0.211 | 214 | 24 | 0 | 24 | 22/2 | ft_calls=24, max_constraint_residual=8.88e-16, output_clipped_steps=0 |
| 1e-06 | `diffsol-bdf-mass` | PASS | 1.89e-06 | 0.090 | — | — | — | 26 | 164/0 | max_constraint_residual=1.78e-15, ncfn=0, nni=247 |
| 1e-06 | `diffsol-esdirk34-mass` | PASS | 2.98e-06 | 0.229 | — | — | — | 29 | 125/3 | max_constraint_residual=2.22e-16, ncfn=4, nni=1159 |
| 1e-06 | `julia-dfbdf` | PASS | 1.82e-07 | 0.324 | 403 | 2 | — | — | 232/8 | max_constraint_residual=7.50e-11 |
| 1e-06 | `julia-fbdf` | PASS | 8.66e-07 | 0.315 | 419 | 2 | — | — | 205/13 | max_constraint_residual=2.71e-14 |
| 1e-06 | `julia-ida` | PASS | 9.92e-07 | 0.155 | 245 | 31 | — | — | 204/1 | max_constraint_residual=1.31e-14 |
| 1e-06 | `julia-rodas5p` | PASS | 5.44e-08 | 0.111 | 830 | 69 | — | — | 69/0 | max_constraint_residual=1.11e-15 |
| 1e-06 | `radau5-mass` | PASS | 8.01e-07 | 0.029 | 338 | 40 | — | 49 | 47/2 | max_constraint_residual=2.22e-16, nstep=49 |
| 1e-06 | `rodas-mass` | PASS | 3.98e-07 | 0.037 | 485 | 80 | — | 81 | 80/1 | max_constraint_residual=8.88e-16, nstep=81 |
| 1e-06 | `sundials-ida` | PASS | 1.06e-06 | 0.217 | 244 | 30 | — | 30 | 205/1 | max_constraint_residual=1.89e-14, ncfn=0, nni=244 |
| 1e-06 | `vigilode-rodas5p-mass` | PASS | 5.02e-07 | 0.362 | 385 | 43 | 0 | 43 | 41/2 | ft_calls=43, max_constraint_residual=1.11e-15, output_clipped_steps=0 |
| 1e-08 | `diffsol-bdf-mass` | PASS | 2.75e-08 | 0.162 | — | — | — | 32 | 300/1 | max_constraint_residual=8.88e-16, ncfn=0, nni=454 |
| 1e-08 | `diffsol-esdirk34-mass` | PASS | 5.00e-08 | 0.986 | — | — | — | 57 | 670/6 | max_constraint_residual=2.22e-16, ncfn=1, nni=5105 |
| 1e-08 | `julia-dfbdf` | PASS | 2.42e-09 | 0.659 | 842 | 2 | — | — | 511/7 | max_constraint_residual=1.05e-11 |
| 1e-08 | `julia-fbdf` | PASS | 7.30e-09 | 0.610 | 758 | 2 | — | — | 380/21 | max_constraint_residual=1.11e-15 |
| 1e-08 | `julia-ida` | PASS | 3.12e-08 | 0.248 | 505 | 43 | — | — | 390/8 | max_constraint_residual=3.08e-09 |
| 1e-08 | `julia-rodas5p` | PASS | 1.18e-09 | 0.233 | 1994 | 166 | — | — | 166/0 | max_constraint_residual=1.11e-15 |
| 1e-08 | `radau5-mass` | PASS | 4.45e-08 | 0.047 | 639 | 68 | — | 82 | 90/2 | max_constraint_residual=2.22e-16, nstep=92 |
| 1e-08 | `rodas-mass` | PASS | 9.23e-09 | 0.098 | 1445 | 240 | — | 241 | 240/1 | max_constraint_residual=8.88e-16, nstep=241 |
| 1e-08 | `sundials-ida` | PASS | 5.62e-08 | 0.421 | 508 | 36 | — | 36 | 411/9 | max_constraint_residual=2.26e-09, ncfn=0, nni=508 |
| 1e-08 | `vigilode-rodas5p-mass` | PASS | 3.48e-09 | 0.875 | 941 | 105 | 0 | 105 | 101/4 | ft_calls=105, max_constraint_residual=7.77e-16, output_clipped_steps=0 |

### Problem: `dae-index1-analytic`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `diffsol-bdf-mass` | PASS | 4.55e-05 | 0.039 | — | — | — | 16 | 59/3 | ncfn=0, nni=70 |
| 1e-04 | `julia-dfbdf` | PASS | 5.62e-06 | 0.103 | 84 | 1 | — | — | 51/3 | max_constraint_residual=2.94e-06 |
| 1e-04 | `julia-fbdf` | PASS | 1.75e-05 | 0.080 | 79 | 1 | — | — | 42/0 | max_constraint_residual=5.76e-06 |
| 1e-04 | `julia-ida` | PASS | 4.74e-05 | 0.091 | 66 | 20 | — | — | 53/1 | max_constraint_residual=1.55e-04 |
| 1e-04 | `julia-rodas5p` | PASS | 9.83e-06 | 0.043 | 233 | 21 | — | — | 21/0 | max_constraint_residual=3.12e-05 |
| 1e-04 | `radau5-mass` | PASS | 3.01e-05 | 0.010 | 95 | 3 | — | 19 | 20/2 | nstep=22 |
| 1e-04 | `rodas-mass` | PASS | 8.27e-05 | 0.016 | 208 | 33 | — | 35 | 33/2 | nstep=35 |
| 1e-04 | `sundials-ida` | PASS | 4.74e-05 | 0.068 | 66 | 20 | — | 20 | 54/1 | ncfn=0, nni=66 |
| 1e-04 | `vigilode-rodas5p-mass` | PASS | 2.88e-05 | 0.113 | 143 | 13 | 0 | 13 | 13/0 | ft_calls=13, output_clipped_steps=0 |
| 1e-06 | `diffsol-bdf-mass` | PASS | 3.47e-07 | 0.056 | — | — | — | 22 | 105/4 | ncfn=1, nni=121 |
| 1e-06 | `julia-dfbdf` | PASS | 5.41e-08 | 0.161 | 136 | 1 | — | — | 101/6 | max_constraint_residual=8.34e-08 |
| 1e-06 | `julia-fbdf` | PASS | 1.46e-07 | 0.147 | 162 | 1 | — | — | 83/8 | max_constraint_residual=3.70e-08 |
| 1e-06 | `julia-ida` | PASS | 2.05e-07 | 0.109 | 116 | 23 | — | — | 101/1 | max_constraint_residual=3.99e-08 |
| 1e-06 | `julia-rodas5p` | PASS | 2.72e-07 | 0.066 | 428 | 38 | — | — | 38/1 | max_constraint_residual=7.64e-07 |
| 1e-06 | `radau5-mass` | PASS | 1.23e-06 | 0.024 | 167 | 4 | — | 24 | 35/3 | nstep=38 |
| 1e-06 | `rodas-mass` | PASS | 2.10e-06 | 0.054 | 549 | 89 | — | 92 | 89/3 | nstep=92 |
| 1e-06 | `sundials-ida` | PASS | 2.05e-07 | 0.100 | 115 | 22 | — | 22 | 102/1 | ncfn=0, nni=115 |
| 1e-06 | `vigilode-rodas5p-mass` | PASS | 2.22e-07 | 0.279 | 363 | 33 | 0 | 33 | 32/1 | ft_calls=33, output_clipped_steps=0 |
| 1e-08 | `diffsol-bdf-mass` | PASS | 2.22e-08 | 0.077 | — | — | — | 31 | 166/8 | ncfn=0, nni=194 |
| 1e-08 | `julia-dfbdf` | PASS | 5.83e-10 | 0.350 | 318 | 1 | — | — | 255/5 | max_constraint_residual=3.97e-10 |
| 1e-08 | `julia-fbdf` | PASS | 1.81e-09 | 0.300 | 211 | 1 | — | — | 185/7 | max_constraint_residual=6.94e-10 |
| 1e-08 | `julia-ida` | PASS | 1.62e-09 | 0.164 | 223 | 27 | — | — | 209/0 | max_constraint_residual=6.06e-11 |
| 1e-08 | `julia-rodas5p` | PASS | 7.04e-09 | 0.121 | 901 | 81 | — | — | 81/1 | max_constraint_residual=2.11e-08 |
| 1e-08 | `radau5-mass` | PASS | 3.99e-08 | 0.023 | 315 | 3 | — | 24 | 66/2 | nstep=68 |
| 1e-08 | `rodas-mass` | PASS | 1.42e-07 | 0.098 | 1618 | 268 | — | 270 | 268/2 | nstep=270 |
| 1e-08 | `sundials-ida` | PASS | 1.62e-09 | 0.204 | 222 | 27 | — | 27 | 209/0 | ncfn=0, nni=222 |
| 1e-08 | `vigilode-rodas5p-mass` | PASS | 2.04e-09 | 0.812 | 1078 | 98 | 0 | 98 | 96/2 | ft_calls=98, output_clipped_steps=0 |

### Problem: `mass-ill-conditioned`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `diffsol-bdf-mass` | PASS | 1.47e-05 | 0.026 | — | — | — | 15 | 32/4 | ncfn=0, nni=47 |
| 1e-04 | `julia-dfbdf` | PASS | 6.02e-07 | 0.061 | 31 | 1 | — | — | 25/0 |  |
| 1e-04 | `julia-fbdf` | PASS | 1.08e-05 | 0.046 | 30 | 1 | — | — | 22/0 |  |
| 1e-04 | `julia-ida` | PASS | 1.17e-04 | 0.127 | 32 | 11 | — | — | 26/0 |  |
| 1e-04 | `julia-rodas5p` | PASS | 5.95e-08 | 0.031 | 101 | 9 | — | — | 9/0 |  |
| 1e-04 | `radau5-mass` | PASS | 1.37e-05 | 0.006 | 39 | 1 | — | 9 | 9/0 | nstep=9 |
| 1e-04 | `sundials-ida` | PASS | 1.17e-04 | 0.038 | 33 | 11 | — | 11 | 26/0 | ncfn=0, nni=33 |
| 1e-04 | `vigilode-rodas5p-mass` | PASS | 2.24e-06 | 0.056 | 54 | 6 | 0 | 6 | 6/0 | ft_calls=6, output_clipped_steps=0 |
| 1e-06 | `diffsol-bdf-mass` | PASS | 4.36e-07 | 0.038 | — | — | — | 24 | 56/7 | ncfn=0, nni=76 |
| 1e-06 | `julia-dfbdf` | PASS | 4.85e-09 | 0.074 | 43 | 1 | — | — | 37/0 |  |
| 1e-06 | `julia-fbdf` | PASS | 1.81e-07 | 0.071 | 42 | 1 | — | — | 33/0 |  |
| 1e-06 | `julia-ida` | PASS | 9.27e-07 | 0.081 | 51 | 18 | — | — | 40/1 |  |
| 1e-06 | `julia-rodas5p` | PASS | 3.68e-09 | 0.034 | 134 | 12 | — | — | 12/0 |  |
| 1e-06 | `radau5-mass` | PASS | 8.60e-07 | 0.007 | 50 | 1 | — | 9 | 11/0 | nstep=11 |
| 1e-06 | `sundials-ida` | PASS | 9.27e-07 | 0.051 | 50 | 17 | — | 17 | 41/1 | ncfn=0, nni=50 |
| 1e-06 | `vigilode-rodas5p-mass` | PASS | 1.04e-07 | 0.064 | 63 | 7 | 0 | 7 | 7/0 | ft_calls=7, output_clipped_steps=0 |
| 1e-08 | `diffsol-bdf-mass` | PASS | 2.15e-09 | 0.053 | — | — | — | 33 | 94/11 | ncfn=0, nni=120 |
| 1e-08 | `julia-dfbdf` | PASS | 4.23e-10 | 0.120 | 92 | 1 | — | — | 75/4 |  |
| 1e-08 | `julia-fbdf` | PASS | 8.41e-10 | 0.112 | 94 | 1 | — | — | 69/5 |  |
| 1e-08 | `julia-ida` | PASS | 2.76e-08 | 0.096 | 81 | 23 | — | — | 62/2 |  |
| 1e-08 | `julia-rodas5p` | PASS | 1.52e-10 | 0.041 | 211 | 19 | — | — | 19/0 |  |
| 1e-08 | `radau5-mass` | PASS | 4.24e-08 | 0.008 | 77 | 1 | — | 9 | 17/0 | nstep=17 |
| 1e-08 | `sundials-ida` | PASS | 2.76e-08 | 0.073 | 81 | 22 | — | 22 | 64/2 | ncfn=0, nni=81 |
| 1e-08 | `vigilode-rodas5p-mass` | PASS | 1.05e-09 | 0.094 | 99 | 11 | 0 | 11 | 11/0 | ft_calls=11, output_clipped_steps=0 |

### Problem: `dae-index1-inconsistent`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-06 | `diffsol-bdf-mass` | PASS | — | — | — | — | — | — | —/— | final_constraint_err=5.93e-08, y_end=[0.8414708531238368, 1.381773481700612] |
| 1e-06 | `julia-ida-default` | FAIL | — | — | — | — | — | — | None/None | ERR: EXCEPTION: DAE initialization failed with CheckInit: Initial conditions do not satisfy the DAE constraints.

The residual norm is 1.0, which exceeds the tolerance 1.0e-8.

Note that the initial conditions include both `du0` (derivatives) and `u0` (states),
and the choice of derivatives must be compatible with the states.

To resolve this issue, you have several options:
1. Fix your initial conditions (both `du0` and `u0`) to satisfy the DAE constraints
2. Use Brown's full basic initialization: initializealg = DiffEqBase.BrownFullBasicInit()
   - Optional: specify tolerance with DiffEqBase.BrownFullBasicInit(abstol=1e-8)
3. Use Shampine's collocation initialization: initializealg = DiffEqBase.ShampineCollocationInit()
   - Optional: specify initial dt with DiffEqBase.ShampineCollocationInit(0.001)
4. If using ModelingToolkit, use: initializealg = SciMLBase.OverrideInit()

Example for automatic initialization:
solve(prob, IDA(); initializealg = DiffEqBase.BrownFullBasicInit())
 | ok=False, retcode=EXCEPTION: DAE initialization failed with CheckInit: Initial conditions do not satisfy the DAE constraints.

The residual norm is 1.0, which exceeds the tolerance 1.0e-8.

Note that the initial conditions include both `du0` (derivatives) and `u0` (states),
and the choice of derivatives must be compatible with the states.

To resolve this issue, you have several options:
1. Fix your initial conditions (both `du0` and `u0`) to satisfy the DAE constraints
2. Use Brown's full basic initialization: initializealg = DiffEqBase.BrownFullBasicInit()
   - Optional: specify tolerance with DiffEqBase.BrownFullBasicInit(abstol=1e-8)
3. Use Shampine's collocation initialization: initializealg = DiffEqBase.ShampineCollocationInit()
   - Optional: specify initial dt with DiffEqBase.ShampineCollocationInit(0.001)
4. If using ModelingToolkit, use: initializealg = SciMLBase.OverrideInit()

Example for automatic initialization:
solve(prob, IDA(); initializealg = DiffEqBase.BrownFullBasicInit())
 |
| 1e-06 | `julia-rodas5p-checkinit` | FAIL | — | — | — | — | — | — | None/None | ERR: EXCEPTION: DAE initialization failed: your u0 did not satisfy the initialization requirements, normresid = 0.7071067811865476 > abstol = 1.0e-8.
If you wish for the system to automatically change the algebraic variables to satisfy the algebraic constraints, please pass `initializealg = BrownFullBasicInit()` to solve (this option will require `using OrdinaryDiffEqNonlinearSolve`). If you wish to perform an initialization on the complete u0, please pass `initializealg = ShampineCollocationInit()` to `solve`. Note that initialization can be a very difficult process for DAEs and in many cases can be numerically intractable without symbolic manipulation of the system. For an automated system that will generate numerically stable initializations, see ModelingToolkit.jl structural simplification for more details.
 | ok=False, retcode=EXCEPTION: DAE initialization failed: your u0 did not satisfy the initialization requirements, normresid = 0.7071067811865476 > abstol = 1.0e-8.
If you wish for the system to automatically change the algebraic variables to satisfy the algebraic constraints, please pass `initializealg = BrownFullBasicInit()` to solve (this option will require `using OrdinaryDiffEqNonlinearSolve`). If you wish to perform an initialization on the complete u0, please pass `initializealg = ShampineCollocationInit()` to `solve`. Note that initialization can be a very difficult process for DAEs and in many cases can be numerically intractable without symbolic manipulation of the system. For an automated system that will generate numerically stable initializations, see ModelingToolkit.jl structural simplification for more details.
 |
| 1e-06 | `julia-rodas5p-defaultinit` | FAIL | — | — | — | — | — | — | None/None | ERR: EXCEPTION: DAE initialization failed: your u0 did not satisfy the initialization requirements, normresid = 0.7071067811865476 > abstol = 1.0e-8.
If you wish for the system to automatically change the algebraic variables to satisfy the algebraic constraints, please pass `initializealg = BrownFullBasicInit()` to solve (this option will require `using OrdinaryDiffEqNonlinearSolve`). If you wish to perform an initialization on the complete u0, please pass `initializealg = ShampineCollocationInit()` to `solve`. Note that initialization can be a very difficult process for DAEs and in many cases can be numerically intractable without symbolic manipulation of the system. For an automated system that will generate numerically stable initializations, see ModelingToolkit.jl structural simplification for more details.
 | ok=False, retcode=EXCEPTION: DAE initialization failed: your u0 did not satisfy the initialization requirements, normresid = 0.7071067811865476 > abstol = 1.0e-8.
If you wish for the system to automatically change the algebraic variables to satisfy the algebraic constraints, please pass `initializealg = BrownFullBasicInit()` to solve (this option will require `using OrdinaryDiffEqNonlinearSolve`). If you wish to perform an initialization on the complete u0, please pass `initializealg = ShampineCollocationInit()` to `solve`. Note that initialization can be a very difficult process for DAEs and in many cases can be numerically intractable without symbolic manipulation of the system. For an automated system that will generate numerically stable initializations, see ModelingToolkit.jl structural simplification for more details.
 |
| 1e-06 | `radau5-mass` | PASS | — | — | — | — | — | — | —/— | final_constraint_err=0.00e+00, y_end=[0.8414710672354812, 1.3817732082484515] |
| 1e-06 | `sundials-ida-calcic` | PASS | — | — | — | — | — | — | —/— | final_constraint_err=1.22e-08, y_end=[0.8414709126173571, 1.3817733506193375] |
| 1e-06 | `sundials-ida-noic` | FAIL | — | — | — | — | — | — | —/— | ERR: IDA flag=-3, completed=1/11 |
| 1e-06 | `vigilode-rodas5p-mass` | FAIL | — | — | — | — | — | — | —/— | ERR: maximum step count or minimum step reached |

### Problem: `dae-pendulum-index3`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-06 | `diffsol-bdf-mass` | FAIL | — | — | — | — | — | — | —/— | ERR: Non-linear solver error: Newton linesearch failed to find a suitable step in max iterations |
| 1e-06 | `radau5-index2-hint` | PASS | — | — | — | — | — | — | —/— | y_end=[0.879548260547785, -0.4758096871361806, -0.4641573229122763, -0.8580075454817512, 1.4277337839099757] |
| 1e-06 | `sundials-ida` | FAIL | — | — | — | — | — | — | —/— | ERR: IDA flag=-3, completed=1/11 |
| 1e-06 | `vigilode-rodas5p-mass` | FAIL | — | — | — | — | — | — | —/— | ERR: maximum step count or minimum step reached |

### Problem: `stiff-burst-switching`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-adams` | PASS | 3.28e-04 | 1.199 | 3751 | 0 | — | 0 | 1936/7 | ncfn=684, nfeLS=0, nni=3748 |
| 1e-04 | `cvode-bdf-dense` | PASS | 9.62e-04 | 0.192 | 322 | 11 | — | 53 | 191/15 | ncfn=9, nfeLS=0, nni=319 |
| 1e-04 | `diffsol-bdf` | PASS | 3.38e-04 | 0.116 | — | — | — | 48 | 140/15 | ncfn=11, nni=355 |
| 1e-04 | `diffsol-tsit45` | PASS | 2.85e-05 | 0.262 | — | — | — | 0 | 433/60 | ncfn=0, nni=0 |
| 1e-04 | `dvode-mf10-adams` | PASS | 2.78e-04 | 0.375 | 3731 | 0 | — | 0 | 1941/8 | ncfn=655, nni=0 |
| 1e-04 | `julia-cvode-bdf` | PASS | 9.62e-04 | 0.147 | 322 | 11 | — | — | 176/15 |  |
| 1e-04 | `julia-fbdf` | PASS | 4.54e-05 | 0.273 | 683 | 12 | — | — | 191/22 |  |
| 1e-04 | `julia-rodas5p` | PASS | 1.23e-05 | 0.094 | 753 | 71 | — | — | 71/14 |  |
| 1e-04 | `julia-tsit5` | PASS | 1.61e-05 | 0.093 | 2715 | 0 | — | — | 443/9 |  |
| 1e-04 | `scipy-bdf` | PASS | 1.84e-04 | 16.491 | 386 | 21 | — | 46 | —/— |  |
| 1e-04 | `scipy-dop853` | PASS | 1.69e-04 | 15.303 | 3236 | 0 | — | 0 | —/— |  |
| 1e-04 | `scipy-lsoda` | PASS | 1.68e-04 | 2.065 | 434 | 25 | — | 25 | —/— |  |
| 1e-04 | `scipy-radau` | PASS | 7.00e-06 | 21.336 | 888 | 32 | — | 154 | —/— |  |
| 1e-04 | `vigilode-dopri5` | PASS | 2.04e-04 | 0.186 | 2983 | 0 | 0 | 0 | 456/41 | fsal_reuses=496, mode=quartic-dense-observations |
| 1e-04 | `vigilode-rodas5p` | PASS | 2.06e-05 | 0.082 | 826 | 61 | 0 | 83 | 61/22 | ft_calls=61, output_clipped_steps=0 |
| 1e-04 | `vigilode-switcher-ev` | FAIL | — | — | — | — | — | — | None/None | ERR: invalid switching request: ProvidedOnly fallback requires autonomy or an explicit time-derivative provider |
| 1e-06 | `cvode-adams` | PASS | 1.14e-05 | 1.559 | 5066 | 0 | — | 0 | 2430/18 | ncfn=1015, nfeLS=0, nni=5063 |
| 1e-06 | `cvode-bdf-dense` | PASS | 3.91e-06 | 0.363 | 590 | 10 | — | 71 | 369/29 | ncfn=5, nfeLS=0, nni=587 |
| 1e-06 | `diffsol-bdf` | PASS | 3.35e-06 | 0.199 | — | — | — | 66 | 288/30 | ncfn=8, nni=663 |
| 1e-06 | `diffsol-tsit45` | PASS | 3.61e-07 | 0.247 | — | — | — | 0 | 493/20 | ncfn=0, nni=0 |
| 1e-06 | `dvode-mf10-adams` | PASS | 9.85e-06 | 0.475 | 5000 | 0 | — | 0 | 2424/14 | ncfn=1005, nni=0 |
| 1e-06 | `julia-cvode-bdf` | PASS | 5.62e-06 | 0.240 | 597 | 10 | — | — | 339/30 |  |
| 1e-06 | `julia-fbdf` | PASS | 8.29e-07 | 0.581 | 1111 | 9 | — | — | 392/34 |  |
| 1e-06 | `julia-rodas5p` | PASS | 4.42e-07 | 0.203 | 1788 | 178 | — | — | 178/23 |  |
| 1e-06 | `julia-tsit5` | PASS | 2.88e-07 | 0.110 | 3249 | 0 | — | — | 533/8 |  |
| 1e-06 | `scipy-bdf` | PASS | 4.10e-06 | 30.242 | 753 | 28 | — | 75 | —/— |  |
| 1e-06 | `scipy-dop853` | PASS | 7.20e-07 | 21.349 | 4460 | 0 | — | 0 | —/— |  |
| 1e-06 | `scipy-lsoda` | PASS | 1.27e-06 | 2.987 | 672 | 12 | — | 12 | —/— |  |
| 1e-06 | `scipy-radau` | PASS | 9.74e-08 | 45.599 | 1936 | 57 | — | 220 | —/— |  |
| 1e-06 | `vigilode-dopri5` | PASS | 1.22e-06 | 0.207 | 3301 | 0 | 0 | 0 | 530/20 | fsal_reuses=549, mode=quartic-dense-observations |
| 1e-06 | `vigilode-rodas5p` | PASS | 2.59e-07 | 0.172 | 1814 | 149 | 0 | 173 | 149/24 | ft_calls=149, output_clipped_steps=0 |
| 1e-06 | `vigilode-switcher-ev` | FAIL | — | — | — | — | — | — | None/None | ERR: invalid switching request: ProvidedOnly fallback requires autonomy or an explicit time-derivative provider |
| 1e-08 | `cvode-adams` | PASS | 7.05e-08 | 2.041 | 4162 | 0 | — | 0 | 2317/59 | ncfn=264, nfeLS=0, nni=4159 |
| 1e-08 | `cvode-bdf-dense` | PASS | 3.69e-07 | 0.639 | 978 | 15 | — | 115 | 664/49 | ncfn=6, nfeLS=0, nni=975 |
| 1e-08 | `diffsol-bdf` | PASS | 1.10e-07 | 0.304 | — | — | — | 91 | 574/49 | ncfn=6, nni=1062 |
| 1e-08 | `diffsol-tsit45` | PASS | 3.83e-09 | 0.394 | — | — | — | 0 | 805/27 | ncfn=0, nni=0 |
| 1e-08 | `dvode-mf10-adams` | PASS | 7.11e-08 | 0.482 | 3721 | 0 | — | 0 | 1984/45 | ncfn=302, nni=0 |
| 1e-08 | `julia-cvode-bdf` | PASS | 2.45e-07 | 0.390 | 1020 | 15 | — | — | 642/52 |  |
| 1e-08 | `julia-fbdf` | PASS | 3.93e-08 | 1.221 | 1953 | 8 | — | — | 829/57 |  |
| 1e-08 | `julia-rodas5p` | PASS | 2.37e-09 | 0.581 | 5313 | 559 | — | — | 559/35 |  |
| 1e-08 | `julia-tsit5` | PASS | 2.77e-09 | 0.197 | 5967 | 0 | — | — | 985/9 |  |
| 1e-08 | `scipy-bdf` | PASS | 1.41e-07 | 61.476 | 1595 | 38 | — | 124 | —/— |  |
| 1e-08 | `scipy-dop853` | PASS | 1.58e-08 | 22.024 | 4526 | 0 | — | 0 | —/— |  |
| 1e-08 | `scipy-lsoda` | PASS | 4.32e-08 | 5.378 | 1436 | 17 | — | 17 | —/— |  |
| 1e-08 | `scipy-radau` | PASS | 1.21e-09 | 114.712 | 4880 | 118 | — | 362 | —/— |  |
| 1e-08 | `vigilode-dopri5` | PASS | 6.12e-09 | 0.354 | 5701 | 0 | 0 | 0 | 926/24 | fsal_reuses=949, mode=quartic-dense-observations |
| 1e-08 | `vigilode-rodas5p` | PASS | 2.61e-09 | 0.462 | 5278 | 463 | 0 | 489 | 463/26 | ft_calls=463, output_clipped_steps=0 |
| 1e-08 | `vigilode-switcher-ev` | FAIL | — | — | — | — | — | — | None/None | ERR: invalid switching request: ProvidedOnly fallback requires autonomy or an explicit time-derivative provider |

### Problem: `robertson-rhs-only-fallback`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-bdf-fd` | PASS | 3.59e-04 | 0.172 | 245 | 4 | — | 39 | 158/8 | ncfn=1, nfeLS=12, nni=230 |
| 1e-04 | `dvode-mf10-adams` | PASS | 4.43e-05 | 22.726 | 275918 | 0 | — | 0 | 145633/1 | ncfn=52494, nni=0 |
| 1e-04 | `dvode-mf22-fd` | PASS | 1.71e-04 | 0.044 | 209 | 3 | — | 26 | 134/3 | ncfn=0, nni=197 |
| 1e-04 | `vigilode-auto-fallback` | PASS | — | 10.269 | 219007 | 0 | 0 | 0 | 34585/1916 | endpoint_only=True, endpoint_wrms=6.07e-05, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier1ExplicitDopri5'] |
| 1e-04 | `vigilode-dopri5-only` | PASS | 9.73e-05 | 10.235 | 219235 | 0 | 0 | 0 | 34618/1921 | fsal_reuses=36538, mode=step-landing |
| 1e-06 | `cvode-bdf-fd` | PASS | 1.98e-06 | 0.249 | 350 | 5 | — | 38 | 250/9 | ncfn=0, nfeLS=15, nni=332 |
| 1e-06 | `dvode-mf10-adams` | PASS | 1.69e-05 | 22.981 | 276288 | 0 | — | 0 | 145995/16 | ncfn=52172, nni=0 |
| 1e-06 | `dvode-mf22-fd` | PASS | 2.60e-06 | 0.075 | 350 | 4 | — | 52 | 236/19 | ncfn=0, nni=335 |
| 1e-06 | `vigilode-auto-fallback` | PASS | — | 9.768 | 214333 | 0 | 0 | 0 | 34559/1163 | endpoint_only=True, endpoint_wrms=2.95e-07, fallback_steps=0, invariant_drift=[], linear_iterations=0, routes=['Tier1ExplicitDopri5'] |
| 1e-06 | `vigilode-dopri5-only` | PASS | 9.81e-07 | 9.850 | 215047 | 0 | 0 | 0 | 34587/1254 | fsal_reuses=35840, mode=step-landing |

### Problem: `event-root-finding`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-bdf-root` | PASS | — | 0.070 | 95 | 2 | — | — | 80/None | max_root_err=5.67e-04, roots_found=[1.5709097308464335, 4.712764861616693, 7.854548517081158] |
| 1e-04 | `diffsol-bdf-root` | PASS | — | 0.035 | — | — | — | 14 | 77/None | max_root_err=2.44e-04, roots_found=[1.5707896390935285, 4.712163991217248, 7.853737613581858] |
| 1e-04 | `julia-rodas5p-callback` | PASS | — | 0.088 | 233 | 21 | — | — | 21/0 | roots_found=[1.570796517738942, 4.712387610722245, 7.853979069184384], max_root_err=2.56e-06 |
| 1e-04 | `vigilode-rodas5p-events` | PASS | — | 0.015 | 135 | 15 | — | — | 15/None | event_evals=51, max_root_err=7.75e-06, roots_found=[1.5707949347134327, 4.712384078510306, 7.853973883632737] |
| 1e-06 | `cvode-bdf-root` | PASS | — | 0.093 | 114 | 2 | — | — | 102/None | max_root_err=3.82e-06, roots_found=[1.5707956760785782, 4.71238674651632, 7.85397781270855] |
| 1e-06 | `diffsol-bdf-root` | PASS | — | 0.050 | — | — | — | 15 | 131/None | max_root_err=2.18e-06, roots_found=[1.5707960422233398, 4.7123877449888045, 7.853979451860134] |
| 1e-06 | `julia-rodas5p-callback` | PASS | — | 0.120 | 453 | 41 | — | — | 41/0 | roots_found=[1.5707963394775923, 4.712389042341517, 7.853981613206662], max_root_err=6.20e-08 |
| 1e-06 | `vigilode-rodas5p-events` | PASS | — | 0.033 | 340 | 33 | — | — | 33/None | event_evals=86, max_root_err=5.38e-08, roots_found=[1.5707963667859677, 4.712388926633043, 7.853981616730822] |
| 1e-08 | `cvode-bdf-root` | PASS | — | 0.186 | 242 | 4 | — | — | 222/None | max_root_err=5.15e-08, roots_found=[1.5707962925729915, 4.712388937544352, 7.853981582500844] |
| 1e-08 | `diffsol-bdf-root` | PASS | — | 0.089 | — | — | — | 16 | 269/None | max_root_err=9.48e-09, roots_found=[1.5707963251542114, 4.712388974824973, 7.853981624489522] |
| 1e-08 | `julia-rodas5p-callback` | PASS | — | 0.231 | 1087 | 95 | — | — | 95/5 | roots_found=[1.5707963267023595, 4.71238898050205, 7.8539816342974484], max_root_err=3.23e-10 |
| 1e-08 | `vigilode-rodas5p-events` | PASS | — | 0.068 | 763 | 78 | — | — | 78/None | event_evals=181, max_root_err=4.08e-10, roots_found=[1.5707963266706904, 4.712388980386698, 7.853981633566894] |

### Problem: `event-terminal-first`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-04 | `cvode-bdf-terminal` | PASS | — | 0.024 | 29 | 1 | — | — | 23/None | root_err=1.13e-04, terminal_t=1.57e+00 |
| 1e-04 | `julia-rodas5p-terminal` | PASS | — | 0.054 | 90 | 8 | — | — | 8/0 | terminal_t=1.57e+00, final_t=1.57e+00, root_err=1.91e-07 |
| 1e-04 | `vigilode-rodas5p-terminal` | PASS | — | 0.013 | 135 | 15 | — | — | 15/None | final_t_truncated=1.57e+00, post_processed_note=integration ran full [0, 8.5] before truncating outputs, root_err=1.39e-06, terminal_t=1.57e+00 |
| 1e-06 | `cvode-bdf-terminal` | PASS | — | 0.036 | 43 | 1 | — | — | 37/None | root_err=6.51e-07, terminal_t=1.57e+00 |
| 1e-06 | `julia-rodas5p-terminal` | PASS | — | 0.060 | 145 | 13 | — | — | 13/0 | terminal_t=1.57e+00, final_t=1.57e+00, root_err=1.27e-08 |
| 1e-06 | `vigilode-rodas5p-terminal` | PASS | — | 0.030 | 340 | 33 | — | — | 33/None | final_t_truncated=1.57e+00, post_processed_note=integration ran full [0, 8.5] before truncating outputs, root_err=4.00e-08, terminal_t=1.57e+00 |
| 1e-08 | `cvode-bdf-terminal` | PASS | — | 0.061 | 82 | 2 | — | — | 66/None | root_err=3.42e-08, terminal_t=1.57e+00 |
| 1e-08 | `julia-rodas5p-terminal` | PASS | — | 0.081 | 274 | 24 | — | — | 24/1 | terminal_t=1.57e+00, final_t=1.57e+00, root_err=9.25e-11 |
| 1e-08 | `vigilode-rodas5p-terminal` | PASS | — | 0.061 | 763 | 78 | — | — | 78/None | final_t_truncated=1.57e+00, post_processed_note=integration ran full [0, 8.5] before truncating outputs, root_err=1.24e-10, terminal_t=1.57e+00 |

### Problem: `event-tangent-adversarial`

| rtol | Solver Arm | Ok | Error (WRMS) | Time (ms) | nf | njac | njvp | nlu | Acc/Rej | Key Extra |
| :---: | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :--- |
| 1e-06 | `vigilode-rodas5p-events` | PASS | — | — | — | — | — | — | —/— | note=documented limitation: tangent touch without sign change is missed, roots_found=0 |

### Unpinned 8-Thread Parallel Ensemble (`dopri5-ensemble-n1024x16`)

- `vigilode-ensemble-1t`: ok=True, time=6.603 ms, nf=1738, extra={'max_abs_err': 6.257362431677516e-08, 'workers': 1}
- `vigilode-ensemble-8t`: ok=True, time=1.687 ms, nf=1738, extra={'max_abs_err': 6.257362431677516e-08, 'workers': 8}
- `diffsol-tsit45-seq16`: ok=True, time=2.595 ms, nf=None, extra={'max_abs_err': 3.5770570679105607e-08}

### Typed Capability Refusals (`Rodas5p::capabilities`)

- `JvpWithMassOrDenseOutput`: refused=True -> `Err(JvpWithMassOrDenseOutput)`
- `VectorAtolOnMatrixFreeRoute`: refused=True -> `Err(VectorAtolOnMatrixFreeRoute)`
- `VectorAtolOnSequentialRoute`: refused=True -> `Err(VectorAtolOnSequentialRoute)`
- `EventsWithoutDenseOutput`: refused=True -> `Err(EventsWithoutDenseOutput)`
- `BandDeclarationOnJvpProblem`: refused=True -> `Err(BandDeclarationOnJvpProblem)`

### VG-1 Hot-Loop Allocation Audit

- `rodas5p_fast_banded_n400`: rust_calls=40, rust_bytes=104119, heap_calls=40
- `rodas5p_fast_dense_n2`: rust_calls=71, rust_bytes=3111, heap_calls=71
- `rodas5p_fast_small_n3`: rust_calls=32, rust_bytes=2471, heap_calls=32
- `rodas5p_mf_ls_workspace_n256`: rust_calls=112, rust_bytes=204863, heap_calls=112
- `vigilode_solve_with_workspace_n256`: rust_calls=130, rust_bytes=214018, heap_calls=130
- `vigilode_workspace_step_into_n256_x10`: rust_calls=0, rust_bytes=0, heap_calls=0

## 5. Internal Polyalgorithm Route Battery (`opt_baseline_battery`, `rtol=1e-5`)

| Problem | Route Policy | f_evals | jac_builds | jvp_calls | lu | acc/rej | switches | Time (ms) | WRMS Err |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| `B01 (nonstiff_mix)` | `explicit` | 187 | 0 | 0 | 0 | 31/0 | 0 | 0.009 | 1.08e+00 |
| `B01 (nonstiff_mix)` | `implicit` | 176 | 22 | 0 | 176 | 22/0 | 0 | 0.015 | 5.50e-02 |
| `B01 (nonstiff_mix)` | `adaptive_switcher` | 199 | 0 | 0 | 0 | 33/0 | 0 | 0.015 | 1.44e+00 |
| `B02 (harmonic_w_50)` | `explicit` | 21733 | 0 | 0 | 0 | 2970/652 | 0 | 0.884 | 1.76e+02 |
| `B02 (harmonic_w_50)` | `implicit` | 19165 | 2071 | 0 | 19536 | 2071/371 | 0 | 1.333 | 1.82e+01 |
| `B02 (harmonic_w_50)` | `adaptive_switcher` | 22238 | 56 | 0 | 510 | 3026/661 | 0 | 1.027 | 1.76e+02 |
| `B03 (van_der_pol_mu100)` | `explicit` | 72661 | 0 | 0 | 0 | 11727/383 | 0 | 2.950 | 1.16e-01 |
| `B03 (van_der_pol_mu100)` | `implicit` | 2590 | 266 | 0 | 2656 | 266/66 | 0 | 0.181 | 1.37e-01 |
| `B03 (van_der_pol_mu100)` | `adaptive_switcher` | 4493 | 280 | 0 | 2728 | 571/74 | 1 | 0.282 | 2.48e-02 |
| `B04 (robertson)` | `explicit` | 600001 | 0 | 0 | 0 | 94450/5550 | 0 | 26.991 | 1.86e+06 |
| `B04 (robertson)` | `implicit` | 534 | 65 | 0 | 536 | 65/2 | 0 | 0.046 | 1.28e-01 |
| `B04 (robertson)` | `adaptive_switcher` | 2400 | 76 | 0 | 624 | 355/19 | 1 | 0.154 | 1.09e-01 |
| `B05 (hires)` | `explicit` | 64219 | 0 | 0 | 0 | 10431/272 | 0 | 3.825 | 5.65e-01 |
| `B05 (hires)` | `implicit` | 778 | 78 | 0 | 800 | 78/22 | 0 | 0.129 | 8.59e-01 |
| `B05 (hires)` | `adaptive_switcher` | 2395 | 66 | 0 | 636 | 356/19 | 1 | 0.237 | 7.77e-01 |
| `B06 (brusselator_1d_100)` | `explicit` | 3931 | 0 | 0 | 0 | 633/22 | 0 | 1.697 | 2.40e-01 |
| `B06 (brusselator_1d_100)` | `implicit` | 635 | 0 | 27667 | 648 | 68/13 | 0 | 116.137 | 1.11e+00 |
| `B06 (brusselator_1d_100)` | `adaptive_switcher` | 4009 | 0 | 451 | 9 | 636/33 | 0 | 3.548 | 6.62e-01 |
| `B07 (stiff_forced)` | `explicit` | 18655 | 0 | 0 | 0 | 3100/9 | 0 | 0.943 | 1.16e-01 |
| `B07 (stiff_forced)` | `implicit` | 360411 | 45033 | 0 | 360432 | 45033/21 | 0 | 35.132 | 2.81e-01 |
| `B07 (stiff_forced)` | `adaptive_switcher` | 19206 | 54 | 0 | 520 | 3153/32 | 0 | 1.691 | 1.14e-01 |
| `B08 (pulse_order_reduction)` | `explicit` | 18799 | 0 | 0 | 0 | 3123/10 | 0 | 0.939 | 1.62e-01 |
| `B08 (pulse_order_reduction)` | `implicit` | 358525 | 44799 | 0 | 358544 | 44799/19 | 0 | 26.883 | 2.61e-01 |
| `B08 (pulse_order_reduction)` | `adaptive_switcher` | 19348 | 55 | 0 | 516 | 3176/32 | 0 | 1.064 | 1.14e-01 |
