# Selected references and implementation documentation

## Formal verification and Lean
- Lean Reference, *Elaboration and Compilation*, trusted kernel and checking pipeline: https://lean-lang.org/doc/reference/latest/Elaboration-and-Compilation/
- Lean Reference, *Validating a Lean Proof*, including `#print axioms` and `sorryAx`: https://lean-lang.org/doc/reference/latest/ValidatingProofs/
- Lean Reference, *Interacting with Lean*, printing axioms: https://lean-lang.org/doc/reference/latest/Interacting-with-Lean/
- Lean 4.35.0 release notes, `lake check`, `lake comparator`, extra checkers: https://lean-lang.org/doc/reference/latest/releases/v4.35.0/
- Elan toolchain manager: https://github.com/leanprover/elan
- Mathlib4 project: https://github.com/leanprover-community/mathlib4

## Wolfram
- WolframScript command-line interface (`-code`, `-file`): https://reference.wolfram.com/language/ref/program/wolframscript.html.en
- `FindEquationalProof`: https://reference.wolfram.com/language/ref/FindEquationalProof.html
- `ProofObject`: https://reference.wolfram.com/language/ref/ProofObject.html
- `Resolve`: https://reference.wolfram.com/language/ref/Resolve.html
- `Reduce`: https://reference.wolfram.com/language/ref/Reduce.html

## Search and optimization
- Coulom (2006), *Efficient Selectivity and Backup Operators in Monte-Carlo Tree Search*: https://link.springer.com/chapter/10.1007/978-3-540-75538-8_7
- Childs, Brodeur & Kocsis (2008), *Transpositions and move groups in Monte Carlo tree search*: https://doi.org/10.1109/cig.2008.5035667
- Kocsis & Szepesvári (2006), *Bandit Based Monte-Carlo Planning*: https://link.springer.com/chapter/10.1007/11871842_29
- Bengio et al. (2021), *Flow Network based Generative Models for Non-Iterative Diverse Candidate Generation*: https://arxiv.org/abs/2106.04399
- Willsey et al. (2021), *egg: Fast and extensible equality saturation*: https://arxiv.org/abs/2004.03082
- Gardner et al. (2014), *Bayesian Optimization with Inequality Constraints*: https://proceedings.mlr.press/v32/gardner14.html
- Daulton, Balandat & Bakshy (2020), *Differentiable Expected Hypervolume Improvement for Parallel Multi-Objective Bayesian Optimization*: https://arxiv.org/abs/2006.05078
- Eriksson et al. (2019), *Scalable Global Optimization via Local Bayesian Optimization (TuRBO)*: https://arxiv.org/abs/1910.01739
- Mouret & Clune (2015), *Illuminating Search Spaces by Mapping Elites*: https://arxiv.org/abs/1504.04909
- Welling & Teh (2011), *Bayesian Learning via Stochastic Gradient Langevin Dynamics*: https://www.stats.ox.ac.uk/~teh/research/compstats/WelTeh2011a.pdf
- Teh, Thiery & Vollmer (2016), *Consistency and Fluctuations For Stochastic Gradient Langevin Dynamics*: https://jmlr.org/papers/v17/teh16a.html
- Kent & Branke (2020), *BOP-Elites, a Bayesian Optimisation algorithm for Quality-Diversity search*: https://arxiv.org/abs/2005.04320

## Interpretation notes
- MCTS graph transpositions are established in game/search literature; their application to proof obligations needs domain-specific state keys and edge semantics.
- GFlowNets sample diverse high-reward objects under learned flow-consistency objectives; this is not a proof calculus or proof-correctness oracle.
- E-graphs represent equivalence classes under the selected rewrite rules; extraction depends on a cost model and saturation bounds. They do not provide a universal canonical form for mathematical equivalence.
- WL graph features are retrieval/similarity features, not a complete graph-isomorphism or theorem-equivalence proof.
- Langevin guarantees require continuous state spaces, a specified target density/potential, regularity and step-size assumptions. No gradient is defined on unparsed theorem text.
- BO's GP/EI quality depends on kernel adequacy, data, noise modelling and stationarity. In CTSH it controls policy allocation only.
