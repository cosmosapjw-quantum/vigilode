# Ablation protocol

The included executable ablation isolates optimizer mechanics on a deterministic deceptive block landscape with a known finite optimum. It compares random search, MCTS-only, GA-only, fixed-ratio MCTS+GA, BO-controlled MCTS+GA, and BO hybrid without discrete tempering.

It uses equal oracle-evaluation budgets and multiple seeds. The output contains per-arm mean best score, sample standard deviation, success rate and unique evaluations. Repeated runs are deterministic for a given package version, seed and settings.

**Interpretation boundary:** this benchmark is not a theorem-proving benchmark. It does not validate natural-language mutation semantics, proof soundness, theorem novelty, or the benefit of the combined harness on research mathematics. It checks that the optimizer modules execute, compare, and record behavior on a deceptive search landscape. The Lean/Wolfram adapters are independently tested on known exact examples.

For research-grade ablations, use the user's real theorem corpus with fixed goal contracts and equal budgets. Arms should include random, MCTS-only, GA-only, MCTS+GA fixed policy, and BO-controlled hybrid; optional feature ablations remove Langevin/tempering, off-pool novelty, or proof-repair. Never disable the strict scope/axiom/proof gate in production arms. A gate-off test may be run only on a synthetic security fixture and is not an admissible theorem result.

Primary measurements: kernel-checked theorem completions; validated counterexamples; unique useful intermediate lemmas; proof cost; repeated-obligation rate; duplicate rate; goal-drift rejection; human review time. Report theorem truth, empirical performance, novelty evidence and cost separately.


## Latest bundled synthetic run (v2.0.2)

The bundled `results/ablation.json` is the 40-seed, 180-evaluation-per-run result for six arms. On the deceptive-block objective, hybrid-fixed averaged 10.500/12 with 8/40 hits; BO-hybrid averaged 10.525/12 with 10/40 hits. The paired BO-minus-fixed mean was +0.025 with a 95% paired-seed bootstrap interval [-0.325, +0.400] (9 wins, 9 losses, 22 ties). Thus BO changed the policy (mean exploration 0.542 vs 0.450; mean discrete-tempering probability 0.270 vs 0.200) but this run does **not** establish a performance improvement over the fixed controller. The no-perturb arm had a -0.150 paired mean difference from fixed, with interval [-0.475, +0.150], also inconclusive.

This discrete benchmark has no continuous parameter vector, so the Langevin probability is held at zero. Continuous ULA is unit-tested separately; a continuous-objective benchmark is still needed before making claims about Langevin's contribution. These numerical observations are descriptive optimizer diagnostics, not evidence about theorem search.


## Continuous ULA ablation

Run `ctsh ablate-continuous --budget 180 --seeds 40`. This is a separate one-dimensional tilted double-well problem, `E(x)=(x^2-1)^2+0.4x`, initialized at `x=+1` in the deceptive local basin. It compares deterministic gradient descent, fixed-probability ULA (p=0.35), and a BO-controlled ULA probability. The continuous objective supplies an exact analytic gradient; ULA is never applied to discrete theorem syntax.

The test measures whether the adaptive controller actually changes the Langevin probability and whether the resulting best energy differs from a fixed probability under paired seeds. It does not show that Langevin is universally useful; its usefulness depends on the energy geometry, step size, temperature, budget and proposal schedule. Treat the bootstrap interval as a toy-optimizer description, not a theorem-search guarantee.

## Bundled continuous result (v2.0.2)

The 40-seed, 180-step continuous run is stored in `results/continuous_langevin_ablation.json`. Gradient-only remained in the deceptive local basin (mean best energy 0.3894; 0/40 successes). Fixed-probability ULA (p=0.35) reached mean best energy -0.3469 and succeeded in 37/40 runs. BO varied the ULA probability substantially (177.3 unique rounded policy values per run on average; mean p=0.274) and reached mean best energy -0.1698 with 28/40 successes. Against fixed ULA, BO's mean paired energy difference was +0.1770 (95% paired bootstrap CI [+0.0782, +0.2796], where lower energy is better). Thus BO adapted the control variable, but on this particular toy problem it underperformed the fixed p=0.35 baseline. This is a useful negative result: adaptive control is not automatically superior and needs calibration, better feedback design, or additional problem families.
