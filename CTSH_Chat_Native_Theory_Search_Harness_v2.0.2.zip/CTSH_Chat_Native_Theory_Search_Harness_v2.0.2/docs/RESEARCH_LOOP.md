# Constructive research loop for theorem discovery

1. **R1 Contract:** freeze the theorem or discovery objective, quantifiers, domain, definitions, hypotheses, conventions and resource budget.
2. **R2 Evidence:** inspect exact sources, prior claims, libraries, proof dependencies and counterexamples. Record versions and identity type.
3. **R3 Formalization:** create the precise natural-language statement and a faithful formal statement when feasible. Note any abstraction gap.
4. **R4 Divergence:** use the exploration hooks to propose off-pool theory perspectives and alternative proof families. Every candidate must map back to the goal.
5. **R5 Construction:** prove open obligations, build examples/counterexamples, derive intermediate inequalities/identities, and maintain AND/OR proof dependencies.
6. **R6 Independent check:** attack boundary cases, degenerate limits, sign/units/domain/regularity assumptions. Use separate proof routes and installed exact tools.
7. **R7 Computation:** invoke Lean/Wolfram only for supported encodings; persist exact commands and outputs. Random tests are diagnostics, not proof.
8. **R8 Verdict:** retain OPEN/CONJECTURAL/DERIVED/SYMBOLIC/KERNEL/REFUTED distinctions. A strong no-go requires complete quantified proof, nontriviality, mechanism, consequence, literature comparison and scope-matched independent review.
9. **R9 Consolidation:** unify only with an equivalence witness; otherwise mark possible duplicates. Save reusable lemmas with hypotheses and provenance.
10. **R10 Handoff:** export state capsule, unresolved obligations, latest BO policy and next concrete action.

A failed proof attempt is not a refutation. A bounded numerical test is not a proof. A Lean kernel pass is not a novelty claim. Keep each evidential statement in its own channel.
