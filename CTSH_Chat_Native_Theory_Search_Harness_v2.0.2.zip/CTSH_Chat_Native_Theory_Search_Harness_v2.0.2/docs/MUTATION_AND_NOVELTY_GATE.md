# Strict mutation gate and forced novelty hooks

## Hard gate order
1. **Goal identity:** exact `goal_id` match. A `direct_target` candidate must preserve the locked statement and the complete fixed-hypothesis set exactly (whitespace-normalized statement comparison). Supporting lemmas may have their own narrower mathematical statement, but must declare a bridge to the locked target. Reformulation requires an explicit goal-contract opt-in and a separate equivalence obligation.
2. **Operator typing:** every mutation uses a registered semantic operator, nonempty `changed_fields`, a specific `expected_gain`, an operator-specific semantic witness, and a valid parent arity. Top-level `parent_ids` must exactly match `mutation.parent_claim_ids`. `DIRECT_DERIVATION` takes no parents; `COMPOSE`, `ANTI_UNIFY` and `TYPE_SAFE_CROSSOVER` take 2–4; unary semantic transformations take one; `NEW_THEORY_BRIDGE` takes 0–1. The exact witness field for each operator is listed in `src/ctsh/gates.py` (`MUTATION_CONTRACTS`).
3. **Bridge:** supporting lemma, bridge result and method idea must identify a target term or unresolved goal obligation.
4. **Hypothesis control:** no silent hypothesis addition. An auxiliary assumption requires explicit authorization and a discharge obligation. Direct-target candidates may not strengthen the goal.
5. **Scope control:** forbidden domain tags reject the candidate.
6. **Nontriviality disclosure:** candidate supplies a nontrivial inference and why it matters. Heuristics can flag obvious restatements; they do not decide mathematical triviality in general.
7. **Novelty gate (exploration only):** a new perspective must not be in the current theory pool, must state a transferable principle, and must include an operational bridge. Proof method or dependency structure must be distinct from the existing pool.
8. **Evidence control:** model-authored candidates must enter with `status: OPEN`; only verifier/human-review commands can change evidential status. `PROOF_STRATEGY_DRIFT` and `NEUTRAL_DRIFT` must preserve the parent's statement and exact hypotheses; neutral drift may change only proof representation. `COUNTEREXAMPLE_SEARCH` requires one live target parent. `COUNTEREXAMPLE_REPAIR` may cite exactly one archived REFUTED parent as negative feedback, never as a true lemma premise. Refuted parents are illegal for every other operator. A counterexample candidate must include a witness, confirm that all locked hypotheses hold, and provide a reproduction record. `REFUTED` and `COUNTEREXAMPLE_FOUND` are terminal archive statuses and cannot be overwritten. A refuted claim cannot re-enter as a positive candidate. Repair creates a new ID and preserves the counterexample.

## Deliberately widened exploration
When BO selects EXPLORE, the prompt hooks require at least one off-pool theory lens, a different proof method family, a first nontrivial inference, and a concrete map back to the locked target. Candidate sources may include an unrepresented mathematical area, a different representation, a dual formulation, a structural invariant, an energy/variational principle, an algebraic-geometric reduction, a probabilistic coupling, or a categorical/functional-analytic abstraction. These are invitations, not claims that the named method applies.

## Langevin vs discrete mutations
For continuous parameters `theta` with a differentiable energy `E`, CTSH implements an unadjusted Langevin step:
`theta' = theta - eta grad E(theta) + sqrt(2 eta T) xi`.
It is not a gradient step on natural-language statements. For discrete proof structures, use typed semantic mutations or an explicit Metropolis/annealed proposal with a declared proposal ratio. The package labels the latter as discrete tempering, not Langevin dynamics.

## Nontriviality is not obfuscation
The gate requires a substantive inference, but does not reward needless technical complexity. A short proof may be deep; a long proof may be vacuous. Nontriviality review records the actual mathematical step and its role in discharging the goal. No novelty score can override a false statement or counterexample.

## Operator contract table

| Operator | Parent count | Required witness | Extra invariant |
|---|---:|---|---|
| `DIRECT_DERIVATION` | 0 | `derivation_witness` | a derivation from the locked goal assumptions |
| `GENERALIZE` | 1 | `generalization_map` | disclose which hypotheses are weakened/retained |
| `SPECIALIZE` | 1 | `instantiation_map` | disclose substitution and side conditions |
| `COMPOSE` | 2–4 | `premise_map` | map each parent to a premise of the result |
| `CONTRAPOSE` | 1 | `negation_map` | spell out both negations and quantifier scope |
| `ANTI_UNIFY` | 2–4 | `anti_unification_result` | state the common abstraction and substitutions |
| `PROOF_REPAIR` | 1 | `repair_target_obligation` | identify the open/failed obligation being repaired |
| `PROOF_STRATEGY_DRIFT` | 1 | `strategy_change_witness` | same statement and hypotheses as parent |
| `NEUTRAL_DRIFT` | 1 | `neutrality_witness` | same claim/hypotheses; only proof representation changes |
| `COUNTEREXAMPLE_SEARCH` | 1 | `search_strategy` | relation must be `counterexample`; witness must satisfy locked hypotheses |
| `COUNTEREXAMPLE_REPAIR` | 1 REFUTED parent | `counterexample_response` | parent is negative evidence, not a true premise; repair gets a new ID |
| `TYPE_SAFE_CROSSOVER` | 2–4 | `type_compatibility_witness` | specify type/universe/domain compatibility |
| `NEW_THEORY_BRIDGE` | 0–1 | `theory_bridge_witness` | new theory principle plus explicit map to target |

The schema checks that witnesses are present and lineage is consistent; it cannot determine whether the claimed transformation is mathematically correct. The proof oracle must check resulting claims and all side conditions.
