# CTSH v2 architecture

## Execution boundary
CTSH is a local Python package controlled by the current chat model. It does not call an external LLM, does not ship model weights, and does not pretend that Python can synthesize open-domain proofs on its own. The chat model proposes structured candidates; Python maintains persistent state, schedules search, applies gates, performs supported exact/symbolic tasks, and invokes installed Lean/Wolfram tools.

## Five distinct state spaces
1. **Goal contract:** immutable theorem/discovery target, domain, quantifiers, assumptions, allowed relations and bridge obligations.
2. **Search-transition graph:** MCTS UCT/PUCT statistics live on states and parent-action edges. Transpositions share state nodes; edge visits remain parent-action specific.
3. **Proof dependency AND/OR hypergraph:** premises combine conjunctively in an AND rule; alternative proof routes are separate OR alternatives. This graph is not the MCTS graph.
4. **Similarity/novelty archive:** statement fingerprints, proof methods, dependency patterns and concept tags support retrieval/diversity only. Similarity is not semantic equivalence.
5. **Evidence ledger:** immutable tool outputs, axiom lists, assumptions, seeds, versions, source identities and statuses.

## Three proposal/evaluation engines
- **MCTS:** chooses which proof-state branch or open obligation deserves expansion. The selected frontier node is proposed as the parent so lineage follows the actual search path. It estimates search priority, not truth.
- **Semantic GA:** requests typed mutations such as GENERALIZE, SPECIALIZE, COMPOSE, CONTRAPOSE, ANTI_UNIFY, PROOF_REPAIR and NEW_THEORY_BRIDGE. The chat model supplies semantic content; Python verifies structure, lineage and scope.
- **BO:** a Matérn-5/2 GP proposes policies over `(exploration_share, mcts_share, langevin_probability, tempered_mutation_probability)`. It learns from observed progress/cost metrics. It is not a theorem-truth model.

## Exploration/exploitation schedule
`exploration_share` selects divergent vs convergent prompts; `mcts_share` chooses MCTS vs GA proposal source; `langevin_probability` triggers ULA only when an explicitly differentiable continuous parameterization, energy and gradient exist; `tempered_mutation_probability` controls a distinct discrete Metropolis/annealed mutation. Langevin is disabled by default and enabled via `ctsh init --enable-langevin`. Initial iterations use space-filling warm-up. Once enough observations exist, expected improvement chooses policy settings. The GP operates over policy coordinates, not over heterogeneous theorem genomes.

## Proof status vs empirical utility
Theorem evidence and algorithm performance are stored separately. A numerical benchmark score cannot upgrade a conjecture to a theorem. A Lean compile must be accompanied by `#print axioms`; `sorryAx` and unapproved axioms fail strict admission. Exact CAS simplification is limited to the encoded domain/assumptions. Human/model reasoning remains `DERIVED_IN_CHAT` unless a formal or exact oracle actually runs.

## Search termination
Search cycles stop when the proof is complete, a counterexample is validated, the current budget is exhausted, or a precise blocker is recorded. A rejected candidate can be mutated into a new candidate ID, never rewritten as if the rejected claim had passed.


## Proof-rule admission

A dependency edge or a chat-proposed composition is not itself a proved inference rule. The reusable-rule query therefore requires a kernel-checked certificate for the conclusion and for every premise. Symbolically checked or chat-derived nodes are never promoted to kernel reuse. If standard axioms are permitted, the caller must opt in explicitly and the axiom set remains visible in the evidence record.
