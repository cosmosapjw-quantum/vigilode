# Local proof and symbolic backends

## Lean 4
The adapter compiles a reviewed Lean source file, appends `#print axioms <theorem>`, and parses the reported dependency list. The default allowed axiom set is `{propext, Classical.choice, Quot.sound}`. `sorryAx`, unknown axiom output, source placeholders, compile errors, and timeouts do not produce `KERNEL_CHECKED`.

For a specific local installation, pin a toolchain explicitly, e.g.:
`ctsh lean-check --file examples/lean_demo.lean --theorem ctsh_add_zero_demo --toolchain leanprover/lean4:v4.34.1`

In a Mathlib project, supply `--lake-project /path/to/project`; the adapter invokes `lake env lean`. Keep `lean-toolchain` and `lake-manifest.json` with the project. Do not let the harness silently install or update toolchains.

The source scanner blocks common proof placeholders and metaprogramming/IO escape tokens unless `--trusted-source` is supplied. This is a guardrail, not a security sandbox. Do not execute untrusted generated Lean source under a privileged account. For Lean >=4.35, consider `lake check --paranoid` or `lake comparator` as an additional project-level cross-check where configured.

## Wolfram Language
`WolframBackend` calls `wolframscript -file` and compiles a restricted Python AST into Wolfram expressions. It permits declared variables, exact numeric literals, `+ - * / **`, and a small allowlist of elementary functions. This avoids evaluating arbitrary raw Wolfram code supplied by a chat model.

`SYMBOLICALLY_CHECKED` means the Wolfram engine returned exact `True` for the encoded identity under supplied assumptions. It does not mean all natural-language quantifiers/domains were faithfully represented. `UNKNOWN_OR_UNSUPPORTED` stays unresolved.

## Failure classes
- `NOT_AVAILABLE`: executable missing.
- `TIMEOUT`: bounded local process did not finish.
- `KERNEL_REJECTED_OR_BUILD_FAILED`: Lean process rejected or failed to build.
- `AXIOM_POLICY_REJECTED`: theorem depends on disallowed axioms.
- `UNKNOWN_OR_UNSUPPORTED`: symbolic system did not settle the claim.

Retain the command, full output, return code, tool version and formalization fidelity review in the run record.


Use `ctsh wolfram-counterexample --lhs 'x**2' --rhs 'x' --variables x --assumptions 'x > 1'` to ask `Reduce` for the encoded violation region. `NO_COUNTEREXAMPLE_FOUND_FOR_ENCODED_DOMAIN` means the encoded violation set reduced to empty; `COUNTEREXAMPLE_REGION_FOUND` means a symbolic set/region was returned, not necessarily a concrete sampled witness. It must still be converted to and checked as an explicit witness before marking a proposition REFUTED.


For a persisted workspace candidate, use `ctsh verify-wolfram --workspace ./research-run --candidate-id CLM-001 --lhs '(x**2-1)/(x-1)' --rhs 'x+1' --variables x --assumptions 'x != 1'`. Symbolic evidence is attached to the candidate. It is promoted to `SYMBOLICALLY_CHECKED` only when `--statement-fidelity-reviewed` is explicitly supplied. This status is not a kernel proof and does not make the lemma reusable as a formal theorem.
