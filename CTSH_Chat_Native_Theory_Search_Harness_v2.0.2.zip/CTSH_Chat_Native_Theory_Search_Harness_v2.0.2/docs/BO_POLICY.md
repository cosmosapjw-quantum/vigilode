# Bayesian policy controller

The controller tunes four policy coordinates:

- `exploration_share` in [0.10, 0.90]; exploitation is its complement.
- `mcts_share` in [0.15, 0.85]; GA receives the complementary proposal share.
- `langevin_probability` in [0.00, 0.55], enabled only when a differentiable continuous parameterization, energy, and gradient are available.
- `tempered_mutation_probability` in [0.00, 0.55] for discrete structure proposals.

The GP uses a Matérn-5/2 covariance and expected improvement over a bounded Sobol candidate pool. A deterministic space-filling warm-up is used before fitting. The controller learns only from observed progress/cost records. It never estimates theorem truth or proof-success probability.

For a goal without continuous parameters, freeze the Langevin coordinate (`active_dimensions=(0,1,3)`) rather than allowing BO to allocate probability to a nonexistent operation. The discrete tempering coordinate remains distinct. For an objective with an explicit differentiable energy and gradient, enable coordinate 2 and use `LangevinParameterPerturber` on that parameter space.

The utility values verified lemma closure and validated counterexamples more than novelty or empirical improvement, and penalizes duplicates, rejected proposals, scope violations, and evaluation cost. This utility is an allocation proxy only. Metrics remain separately available for audit and Pareto inspection.

The GP is non-stationary in practice because tool versions, libraries, human feedback, and the lemma pool change. Use separate workspaces/run IDs after material regime changes; do not pool stale observations uncritically. Reset or explicitly discount history when calibration degrades.
