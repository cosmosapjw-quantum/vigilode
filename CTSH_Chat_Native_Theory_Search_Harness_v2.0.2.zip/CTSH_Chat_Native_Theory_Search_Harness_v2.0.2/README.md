# CTSH v2.0.2: Chat-native Mathematical Theory Search Harness

An installable Python package for structured mathematical theorem proving and discovery in a chat workflow. It combines a transposition-aware MCTS search graph, semantic GA mutation contracts, a Bayesian controller for exploration/exploitation and engine mix, Langevin-like perturbation on valid continuous parameters, discrete tempered mutations for symbolic structures, strict goal-preserving gates, and local Lean/Wolfram verification adapters.

**No separate LLM is required.** The current chat model is the semantic proposal engine. The Python package does not call OpenAI or any other LLM API. It creates prompts, ingests structured candidate JSON, controls search policies, persists records, and invokes local proof tools.

## Install

```bash
python -m venv .venv
source .venv/bin/activate        # Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -e '.[dev]'
pytest -q
```

Core requirements: Python >=3.10, NumPy, SciPy, SymPy. Lean 4 and WolframScript are optional local proof/symbolic tools; no automatic package or toolchain installation is performed by CTSH.

## Quickstart: chat as proposal engine

```bash
ctsh init --workspace ./research-run \\
  --goal-id THEOREM-001 \\
  --goal "For all real x != 1, (x^2-1)/(x-1)=x+1" \\
  --mode prove --domain real
ctsh prompt --workspace ./research-run > next_chat_prompt.md
```

Paste `next_chat_prompt.md` into the same chat. Ask the model to return no more than three candidates matching the JSON schema. Save one object as `proposal.json`, then:

```bash
# Use the decision_id printed in the prompt; it binds the BO phase and parent lineage.
ctsh ingest --workspace ./research-run --file proposal.json --decision-id <DECISION_ID>
# Manual exploration is possible, but the stored decision is authoritative when supplied.
ctsh ingest --workspace ./research-run --file proposal.json --exploration
```

The exploration flag applies the additional off-pool theory/method novelty gate. It does not relax the goal contract. For a sample goal and candidate, see `examples/`.

## Search policy and BO

The controller tunes four policy coordinates: exploration fraction, MCTS fraction among MCTS/GA proposals, continuous Langevin probability, and discrete tempered-mutation probability. Langevin is disabled by default. Enable it with `--enable-langevin` only when the task has an explicit differentiable continuous parameterization, energy, and gradient. Its GP uses a Matérn-5/2 kernel and expected improvement over a Sobol candidate pool. It learns only from actual observed progress/cost records; warm-up remains deterministic before enough observations exist. It never estimates theorem truth.

## MCTS + semantic GA

The MCTS graph supports transpositions and parent-action statistics. The proof dependency DAG separately records AND/OR proof structure. Semantic GA operators are typed contracts. The chat model fills in the mathematical transformation; Python validates operator-specific parent arity and witness fields, exact parent lineage, scope, bridge, hypothesis changes, nontriviality disclosure, and novelty requirements. Proof-strategy/neutral drift must preserve the parent claim; counterexample repair may cite a refuted parent only as negative evidence.

## Perturbation

`LangevinParameterPerturber` implements a ULA step for a continuous vector with a real energy and gradient. For symbolic theorem structure, use `TemperedMutationPerturber` or semantic operators. It is intentionally not described as a Langevin gradient on discrete mathematics.

## Local proof tools

```bash
ctsh check-env
ctsh lean-check --file examples/lean_demo.lean --theorem ctsh_add_zero_demo --toolchain leanprover/lean4:v4.34.1
ctsh wolfram-check --lhs '(x**2-1)/(x-1)' --rhs 'x+1' --variables x --assumptions 'x != 1'
ctsh wolfram-counterexample --lhs 'x**2' --rhs 'x' --variables x --assumptions 'x > 1'
```

For Mathlib, pass `--lake-project /path/to/mathlib-project`. `ctsh verify-wolfram` attaches exact symbolic evidence to a workspace candidate and requires an explicit statement-fidelity acknowledgement before promoting its status. Lean sources are local code: review them before execution. The adapter scans common placeholders/metaprogramming escapes, but that scan is not a sandbox. Wolfram input is restricted to a small arithmetic expression AST and does not evaluate arbitrary WL strings.

## Ablation

```bash
ctsh ablate --budget 180 --seeds 40 --output results/ablation.json
ctsh ablate-continuous --budget 180 --seeds 40 --output results/continuous_langevin_ablation.json
```

The bundled ablation compares random, MCTS-only, GA-only, fixed hybrid, BO-controlled hybrid, and hybrid without discrete tempering on a deterministic deceptive block landscape. These validate optimizer mechanics and repeatability only. The discrete benchmark tests MCTS/GA/BO/tempering; the separate tilted-double-well benchmark tests ULA and BO allocation of a genuinely continuous Langevin probability. Neither is evidence of mathematical discovery capability. See `docs/ABLATION_PROTOCOL.md`.

## Evidence vocabulary

`OPEN`, `CONJECTURAL`, `DERIVED_IN_CHAT`, `SYMBOLICALLY_CHECKED`, `KERNEL_CHECKED`, `KERNEL_CHECKED_WITH_ALLOWED_AXIOMS`, `COUNTEREXAMPLE_FOUND`, `REFUTED`, `CONDITIONAL`, `NOT_ATTEMPTED`, `ERROR`, `BLOCKED`.

`KERNEL_CHECKED` is emitted only after Lean returns exit code 0 and the axiom audit passes. Formal statement fidelity still requires review. Wolfram `SYMBOLICALLY_CHECKED` is limited to the encoded expression, declared variables and assumptions. Empirical performance, novelty and proof validity are never collapsed into one truth score.

## Files

- `src/ctsh/`: installable package
- `tests/`: unit/integration tests; Lean/Wolfram tests skip if binaries are absent
- `examples/`: goal, proposal, Lean source
- `prompts/`: master prompt and chat workflow
- `docs/`: architecture, mutation gate, BO policy, backends, ablation and research loop
- `results/`: generated ablation evidence and validation logs in the release archive
