import os, shutil, pytest
from ctsh.backends import LeanBackend, WolframBackend, _WLRenderer

LEAN_TOOLCHAIN = os.environ.get("CTSH_TEST_LEAN_TOOLCHAIN")
@pytest.mark.skipif(not shutil.which("elan") or not LEAN_TOOLCHAIN,
                    reason="set CTSH_TEST_LEAN_TOOLCHAIN to an already-installed Lean toolchain")
def test_lean_kernel_check_simple_theorem():
    result = LeanBackend(toolchain=LEAN_TOOLCHAIN, timeout=30).check_source(
        "theorem ctsh_test_add_zero (n : Nat) : n + 0 = n := by rfl", "ctsh_test_add_zero")
    assert result.status == "KERNEL_CHECKED", result.to_dict()

@pytest.mark.skipif(not shutil.which("wolframscript"), reason="WolframScript not installed")
def test_wolfram_exact_identity():
    result = WolframBackend(timeout=30).verify_identity("(x**2 - 1)/(x - 1)", "x + 1", ["x"], "x != 1")
    assert result.status == "SYMBOLICALLY_CHECKED", result.to_dict()

def test_wolfram_ast_blocks_code_execution():
    with pytest.raises((ValueError, SyntaxError)):
        WolframBackend().verify_identity("__import__('os').system('echo unsafe')", "0", [], None)

def test_wolfram_rejects_injected_variable_names():
    with pytest.raises(ValueError):
        _WLRenderer(["x];Run['bad']"])

def test_wolfram_rejects_undeclared_symbols():
    with pytest.raises(ValueError):
        _WLRenderer(["x"]).render("x+y")


def test_wolfram_counterexample_result_false_means_empty_violation_region(monkeypatch):
    import subprocess
    monkeypatch.setattr("ctsh.backends.shutil.which", lambda _: "/usr/bin/wolframscript")
    monkeypatch.setattr("ctsh.backends.subprocess.run", lambda *a, **k: subprocess.CompletedProcess(a[0], 0,
        'CTSH_RESULT=False\n', ''))
    result = WolframBackend()._run_wl("Print[False]", "counterexample")
    assert result.status == "NO_COUNTEREXAMPLE_FOUND_FOR_ENCODED_DOMAIN"

def test_wolfram_counterexample_symbolic_region_is_not_marked_as_proof(monkeypatch):
    import subprocess
    monkeypatch.setattr("ctsh.backends.shutil.which", lambda _: "/usr/bin/wolframscript")
    monkeypatch.setattr("ctsh.backends.subprocess.run", lambda *a, **k: subprocess.CompletedProcess(a[0], 0,
        'CTSH_RESULT=x > 1\n', ''))
    result = WolframBackend()._run_wl("Print[x > 1]", "counterexample")
    assert result.status == "COUNTEREXAMPLE_REGION_FOUND"
