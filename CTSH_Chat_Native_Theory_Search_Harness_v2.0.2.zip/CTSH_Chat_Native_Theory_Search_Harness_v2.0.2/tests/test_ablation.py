from ctsh.ablation import AblationRunner

def test_ablation_is_reproducible_and_has_all_arms():
    a = AblationRunner(budget=24, seeds=2).run()
    b = AblationRunner(budget=24, seeds=2).run()
    assert set(a["summary"]) == set(AblationRunner.ARMS)
    assert a["summary"] == b["summary"]
    assert "not evidence of mathematical discovery" in a["interpretation"]

def test_ablation_uses_exact_equal_budget_and_reports_discrete_perturbation():
    result = AblationRunner(budget=30, seeds=2).run()
    assert all(r["evaluations"] == 30 for r in result["records"])
    assert "paired_vs_hybrid_fixed" in result
    no_perturb = result["summary"]["hybrid_no_perturb"]
    assert no_perturb["mean_applied_perturbation_rate"] == 0.0
    assert no_perturb["mean_continuous_langevin_probability"] == 0.0
