import pytest
from ctsh.graph import ProofDAG, MCTSSearchGraph
from ctsh.models import Candidate

def candidate(cid):
    return Candidate(cid,"G",cid,[],cid,"supporting_lemma",{"operator":"COMPOSE"},"induction","proof",[],["G"])

def test_proof_dag_rejects_cycles():
    d=ProofDAG(); d.add_candidate(candidate("A")); d.add_candidate(candidate("B"))
    d.add_rule(["A"],"B","r1")
    with pytest.raises(ValueError): d.add_rule(["B"],"A","r2")

def test_mcts_graph_shares_transposition_and_backpropagates():
    g=MCTSSearchGraph(); r=g.add_state({"s":0})
    a=g.add_transition(r,"a",{"s":1}); b=g.add_transition(r,"b",{"s":2})
    shared=g.add_transition(a,"to-shared",{"s":3})
    shared2=g.add_transition(b,"to-shared",{"s":3})
    assert shared == shared2
    path, edges=g.select_path(r); g.backpropagate(path,edges,1.0)
    assert g.nodes[shared].visits == 1

def test_symbolic_or_chat_derived_claims_are_not_kernel_reusable():
    d = ProofDAG()
    a = candidate("A")
    b = candidate("B")
    d.add_candidate(a); d.add_candidate(b)
    d.add_rule(["A"], "B", "rule-B")
    d.mark_status("A", "SYMBOLICALLY_CHECKED")
    assert d.usable_rules() == []
    d.mark_status("A", "DERIVED_IN_CHAT")
    assert d.usable_rules() == []
    d.mark_status("A", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS")
    assert d.usable_rules() == []
    assert d.usable_rules(allow_declared_standard_axioms=True) == []  # conclusion B is still OPEN
    d.mark_status("B", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS")
    assert len(d.usable_rules(allow_declared_standard_axioms=True)) == 1
    assert d.usable_rules() == []  # allowed axioms are not silently treated as axiom-free
    d.mark_status("A", "KERNEL_CHECKED")
    d.mark_status("B", "KERNEL_CHECKED")
    assert len(d.usable_rules()) == 1

def test_search_graph_serialization_and_candidate_feedback_path():
    g = MCTSSearchGraph(); root = g.add_state({"kind":"goal_root"})
    a = g.add_transition(root, "candidate-A", {"candidate_id":"A"})
    b = g.add_transition(a, "candidate-B", {"candidate_id":"B"})
    path, edges = g.path_to(root, b)
    g.backpropagate(path, edges, 2.0)
    restored = MCTSSearchGraph.from_dict(g.to_dict())
    path2, edges2 = restored.path_to(root, b)
    assert path2 == path and edges2 == edges
    assert restored.nodes[b].visits == 1
