import numpy as np
from ctsh.perturb import LangevinParameterPerturber, TemperedMutationPerturber

def test_langevin_step_respects_bounds_and_shape():
    p = LangevinParameterPerturber(step_size=.1, temperature=.01, seed=1)
    x = np.array([.2, .8])
    result = p.step(x, lambda z: float((z*z).sum()), lambda z: 2*z,
                    bounds=(np.zeros(2), np.ones(2)))
    assert result.value.shape == x.shape
    assert np.all(result.value >= 0) and np.all(result.value <= 1)

def test_discrete_tempering_returns_valid_state():
    p = TemperedMutationPerturber(temperature=.5, seed=2)
    state, info = p.step((0,0,0), lambda s: (1,0,0), lambda s: -sum(s))
    assert state in {(0,0,0), (1,0,0)}
    assert 0 <= info["acceptance_probability"] <= 1


def test_langevin_rejects_nonfinite_energy():
    p = LangevinParameterPerturber(seed=0)
    x = np.array([1.0])
    try:
        p.step(x, lambda z: float("nan"), lambda z: 2*z)
    except ValueError as exc:
        assert "energy must be finite" in str(exc)
    else:
        raise AssertionError("non-finite energy was accepted")

def test_metropolis_rejects_nonfinite_proposal_ratio():
    p = TemperedMutationPerturber(seed=0)
    try:
        p.step((0,), lambda s: (1,), lambda s: float(sum(s)),
               symmetric_proposal=False, reverse_over_forward=float("nan"))
    except ValueError as exc:
        assert "finite and positive" in str(exc)
    else:
        raise AssertionError("NaN proposal ratio was accepted")
