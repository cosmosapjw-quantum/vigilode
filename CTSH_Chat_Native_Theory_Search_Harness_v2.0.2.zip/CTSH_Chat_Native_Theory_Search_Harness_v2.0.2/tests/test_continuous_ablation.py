from ctsh.continuous_ablation import ContinuousLangevinAblationRunner


def test_continuous_ablation_has_three_equal_budget_arms_and_policy_adaptation():
    result = ContinuousLangevinAblationRunner(budget=24, seeds=3).run()
    assert set(result["summary"]) == {"gradient_only", "langevin_fixed", "langevin_bo"}
    assert all(row["budget"] == 24 for row in result["records"])
    assert result["summary"]["gradient_only"]["mean_applied_langevin_rate"] == 0.0
    assert result["summary"]["langevin_bo"]["mean_unique_policy_values"] > 1.0
    assert result["paired_vs_langevin_fixed"]
