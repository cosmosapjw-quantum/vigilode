import numpy as np
from ctsh.bo import BayesianBudgetController, BudgetPolicy
from ctsh.engines import SearchCoordinator
from ctsh.graph import MCTSSearchGraph

def make_controller():
    return BayesianBudgetController(seed=13, prior=BudgetPolicy(langevin_probability=0.0),
                                    active_dimensions=(0, 1, 3))

def test_mcts_uses_selected_graph_frontier_as_parent():
    graph = MCTSSearchGraph()
    root = graph.add_state({"kind": "goal_root"})
    a = graph.add_transition(root, "candidate-A", {"kind": "candidate", "candidate_id": "A"})
    b = graph.add_transition(a, "candidate-B", {"kind": "candidate", "candidate_id": "B"})
    coordinator = SearchCoordinator(make_controller(), graph, seed=1)
    directive = coordinator.next_directive(root, ["A", "B", "C"],
        BudgetPolicy(exploration_share=0.3, mcts_share=1.0, langevin_probability=0.0,
                     tempered_mutation_probability=0.0))
    assert directive.proposal_engine == "MCTS"
    assert directive.parent_candidate_ids == ["B"]
    assert directive.selected_state_key == b

def test_ga_selects_two_distinct_parents_from_pool():
    graph = MCTSSearchGraph(); root = graph.add_state({"kind": "goal_root"})
    coordinator = SearchCoordinator(make_controller(), graph, seed=2)
    directive = coordinator.next_directive(root, ["A", "B", "C"],
        BudgetPolicy(exploration_share=0.3, mcts_share=0.0, langevin_probability=0.0,
                     tempered_mutation_probability=0.0))
    assert directive.proposal_engine == "GA"
    assert len(directive.parent_candidate_ids) == 2
    assert len(set(directive.parent_candidate_ids)) == 2
    assert set(directive.parent_candidate_ids).issubset({"A", "B", "C"})
