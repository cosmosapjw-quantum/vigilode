import numpy as np
from ctsh.bo import BayesianBudgetController, BudgetMetrics, BudgetPolicy

def test_policy_bounds():
    try: BudgetPolicy(1.2, .5, .1)
    except ValueError: pass
    else: raise AssertionError("invalid policy accepted")

def test_bo_warmup_then_surrogate_suggests_valid_policy():
    bo = BayesianBudgetController(seed=7, min_observations=3, candidate_count=64)
    for i in range(5):
        p = bo.suggest()
        bo.observe(p, BudgetMetrics(verified_lemmas=i%2, valid_counterexamples=(i==3),
                                    obligations_closed=i, novelty_gain=.2, evaluation_cost=1))
    q = bo.suggest()
    assert 0 <= q.exploration_share <= 1
    assert 0 <= q.mcts_share <= 1
    assert 0 <= q.langevin_probability <= 1
    assert "expected_improvement" in bo.last_acquisition

def test_truth_probability_is_not_exposed():
    bo = BayesianBudgetController()
    assert not hasattr(bo, "truth_probability")

def test_bo_state_roundtrip_preserves_four_dimensional_policy_and_rng():
    bo = BayesianBudgetController(seed=19, min_observations=3, candidate_count=32)
    for i in range(6):
        policy = bo.suggest()
        bo.observe(policy, BudgetMetrics(verified_lemmas=i % 2, novelty_gain=float(i), evaluation_cost=1.0))
    state = bo.state_dict()
    restored = BayesianBudgetController.from_state_dict(state, seed=999)
    expected = bo.suggest()
    actual = restored.suggest()
    assert np.allclose(expected.vector(), actual.vector())
    assert len(actual.vector()) == 4
    assert 0 <= actual.tempered_mutation_probability <= 0.55


def test_langevin_is_disabled_by_default_without_continuous_parameter_contract():
    bo = BayesianBudgetController(seed=4)
    policy = bo.suggest()
    assert policy.langevin_probability == 0.0
    assert 2 not in bo.active_dimensions

def test_langevin_coordinate_requires_explicit_opt_in():
    bo = BayesianBudgetController(seed=4, prior=BudgetPolicy(langevin_probability=0.15),
                                  active_dimensions=(0, 1, 2, 3))
    assert 2 in bo.active_dimensions
    assert bo.suggest().langevin_probability >= 0.0
