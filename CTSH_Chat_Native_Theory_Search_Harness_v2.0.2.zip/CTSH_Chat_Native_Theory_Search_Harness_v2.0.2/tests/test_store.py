import json
from ctsh.models import Candidate
from ctsh.store import Workspace


def make_candidate(cid="C1"):
    return Candidate(
        candidate_id=cid, goal_id="G", statement="lemma P", hypotheses=["H"],
        conclusion="P", relation="supporting_lemma",
        mutation={"operator":"COMPOSE", "parent_claim_ids":[]},
        proof_method="induction", proof_sketch="derive the base and induction step",
        proof_obligations=["induction step"], mapping_to_goal=["P gives target"],
        nontriviality={"why_nontrivial":"requires a step", "distinguishing_step":"induction"})


def test_workspace_replays_candidates_status_decisions_and_feedback(tmp_path):
    ws = Workspace(tmp_path)
    ws.initialize({"goal_id":"G", "statement":"P"})
    c = make_candidate()
    ws.add_candidate(c, {"accepted": True})
    assert len(ws.accepted_candidates()) == 1
    ws.update_candidate_status("C1", "KERNEL_CHECKED", {"mocked": True})
    assert ws.accepted_candidates()[0].status == "KERNEL_CHECKED"
    ws.record_decision("D1", {"exploration_share":0.4, "mcts_share":0.5,
                              "langevin_probability":0.1, "tempered_mutation_probability":0.2},
                       {"phase":"EXPLORE"})
    assert ws.find_decision("D1")["decision_id"] == "D1"
    ws.record_feedback("D1", "C1", {"verified_lemmas":1})
    try:
        ws.find_decision("D1")
    except KeyError:
        pass
    else:
        raise AssertionError("feedback-consumed decision was offered again")


def test_refuted_and_counterexample_statuses_are_terminal(tmp_path):
    import pytest
    ws = Workspace(tmp_path); ws.initialize({"goal_id":"G", "statement":"P"})
    ws.add_candidate(make_candidate(), {"accepted":True})
    ws.update_candidate_status("C1", "REFUTED", {"witness":{"x":2}, "hypotheses_satisfied":True, "reproduction":"check P(2)"})
    assert ws.load_candidate_records()[0]["candidate"]["status"] == "REFUTED"
    with pytest.raises(ValueError, match="terminal evidence status"):
        ws.update_candidate_status("C1", "KERNEL_CHECKED", {"fake":True})
    assert ws.load_candidate_records()[0]["candidate"]["status"] == "REFUTED"
