import json
from argparse import Namespace
from pathlib import Path
import pytest
from ctsh.cli import cmd_ingest, cmd_feedback
from ctsh.models import Candidate
from ctsh.store import Workspace

def make_goal():
    return {"goal_id":"G-INGEST", "statement":"For all real x, P(x)", "mode":"prove",
            "domain":"real", "hypotheses":["x is real"], "target_terms":["P", "x"],
            "required_obligations":["derive P(x)"], "pool_theories":[], "pool_methods":[],
            "allowed_auxiliary_assumptions":[], "max_new_assumptions":0,
            "forbidden_scope_tags":[], "require_goal_bridge":True}

def make_candidate(cid="C-new", **overrides):
    data = dict(candidate_id=cid, goal_id="G-INGEST", statement="A lemma controlling P(x)",
        hypotheses=["x is real"], conclusion="Intermediate bound for P(x)", relation="supporting_lemma",
        mutation={"operator":"DIRECT_DERIVATION", "parent_claim_ids":[],
                  "changed_fields":["statement", "proof_obligations"], "expected_gain":"derive the intermediate estimate",
                  "derivation_witness":"derive the coercive estimate under x real"}, proof_method="energy estimate",
        proof_sketch="Derive a coercive estimate and substitute it into the target obligation.",
        proof_obligations=["derive coercive estimate"], mapping_to_goal=["P(x) follows from the intermediate bound"],
        scope_tags=[], new_concepts=["coercive estimate"], new_perspective=None,
        assumption_discharge_obligations=[], nontriviality={"why_nontrivial":"requires coercivity",
        "distinguishing_step":"absorb the boundary contribution", "self_assessed_trivial":False},
        formalization={}, status="OPEN", parent_ids=[], metadata={})
    data.update(overrides)
    return Candidate(**data)

def write_candidate(tmp_path, candidate):
    p=tmp_path/(candidate.candidate_id+".json")
    p.write_text(json.dumps(candidate.to_dict()), encoding="utf-8")
    return str(p)

def setup_workspace(tmp_path):
    ws=Workspace(tmp_path); ws.initialize(make_goal(), {"schema_version":2})
    return ws

def run_ingest(ws, candidate, decision_id, tmp_path):
    args=Namespace(workspace=str(ws.root), file=write_candidate(tmp_path,candidate),
                   decision_id=decision_id, exploration=False)
    return cmd_ingest(args)

def test_exploration_phase_from_decision_cannot_be_bypassed(tmp_path):
    ws=setup_workspace(tmp_path)
    ws.record_decision("D-EXPLORE", {"exploration_share":1.0},
                       {"phase":"EXPLORE", "proposal_engine":"GA", "parent_candidate_ids":[]})
    c=make_candidate()  # no new_perspective; would pass a non-exploration gate
    with pytest.raises(SystemExit) as exc:
        run_ingest(ws,c,"D-EXPLORE",tmp_path)
    assert exc.value.code == 2
    row=ws.load_candidate_records()[-1]
    assert not row["gate"]["accepted"]
    assert any("exploration_requires_a_theory" in x for x in row["gate"]["reasons"])

def test_parent_lineage_from_decision_is_enforced(tmp_path):
    ws=setup_workspace(tmp_path)
    parent=make_candidate("C-parent")
    ws.add_candidate(parent, {"accepted":True})
    ws.record_decision("D-MCTS", {"exploration_share":0.0},
                       {"phase":"EXPLOIT", "proposal_engine":"MCTS", "parent_candidate_ids":["C-parent"]})
    child=make_candidate("C-child")  # deliberately omits required selected parent
    with pytest.raises(SystemExit) as exc:
        run_ingest(ws,child,"D-MCTS",tmp_path)
    assert exc.value.code == 2
    row=ws.load_candidate_records()[-1]
    assert any("parent_lineage_mismatch" in x for x in row["gate"]["reasons"])


def test_exploit_decision_roundtrip_ingest_and_bo_feedback(tmp_path, capsys):
    ws = setup_workspace(tmp_path)
    policy = {"exploration_share":0.30, "mcts_share":0.60,
              "langevin_probability":0.0, "tempered_mutation_probability":0.10}
    ws.record_decision("D-ROUNDTRIP", policy,
                       {"phase":"EXPLOIT", "proposal_engine":"MCTS", "parent_candidate_ids":[]})
    c = make_candidate()
    run_ingest(ws, c, "D-ROUNDTRIP", tmp_path)
    row = ws.load_candidate_records()[-1]
    assert row["gate"]["accepted"] is True
    cmd_feedback(Namespace(workspace=str(ws.root), decision_id="D-ROUNDTRIP",
                           candidate_id=c.candidate_id, obligations_closed=1,
                           evaluation_cost=0.5, empirical_improvement=0.0, seed=10))
    output = capsys.readouterr().out
    assert '"bo_observations": 1' in output
    events = ws.load_events()
    assert any(e.get("event") == "SEARCH_FEEDBACK" for e in events)


def test_counterexample_repair_ingest_uses_terminal_refutation_as_negative_parent_only(tmp_path):
    ws = setup_workspace(tmp_path)
    parent = make_candidate("C-refuted", relation="direct_target",
                            statement="For all real x, P(x)", mapping_to_goal=[])
    ws.add_candidate(parent, {"accepted":True})
    ws.update_candidate_status("C-refuted", "REFUTED", evidence={
        "witness":{"x":2}, "hypotheses_satisfied":True,
        "reproduction":"substitute x=2 under x real and evaluate P(2)"
    })
    repair = make_candidate("C-repair", mutation={
        "operator":"COUNTEREXAMPLE_REPAIR", "parent_claim_ids":["C-refuted"],
        "changed_fields":["statement", "hypotheses"],
        "expected_gain":"replace the failed global statement by a valid restricted statement",
        "counterexample_response":{"refuted_claim_ids":["C-refuted"],
                                   "repair_strategy":"state and prove a domain-restricted claim"}
    }, parent_ids=["C-refuted"])
    args = Namespace(workspace=str(ws.root), file=write_candidate(tmp_path, repair),
                     decision_id=None, exploration=False)
    cmd_ingest(args)
    row = ws.load_candidate_records()[-1]
    assert row["gate"]["accepted"] is True, row["gate"]["reasons"]
    assert row["candidate"]["candidate_id"] == "C-repair"
