from ctsh.models import GoalContract, Candidate
from ctsh.gates import GoalMutationGate, NoveltyArchive

def make_goal():
    return GoalContract(goal_id="G1", statement="For all x in R, target property P(x)",
                        target_terms=("x", "property", "P"), hypotheses=("x is real",),
                        allowed_auxiliary_assumptions=("x is positive",), max_new_assumptions=1)

def make_candidate(**kw):
    d = dict(candidate_id="C1", goal_id="G1", statement="A supporting lemma about P(x)",
             hypotheses=["x is real"], conclusion="intermediate bound for P(x)",
             relation="supporting_lemma", mutation={"operator":"DIRECT_DERIVATION", "parent_claim_ids":[],
                 "changed_fields":["statement", "proof_obligations"], "expected_gain":"derive a scoped intermediate result",
                 "derivation_witness":"derive from the locked assumptions"},
             proof_method="energy estimate", proof_sketch="Derive an energy inequality, control the boundary term, then substitute into the target estimate.",
             proof_obligations=["derive energy bound"], mapping_to_goal=["P(x): energy estimate implies target inequality"],
             scope_tags=[], new_concepts=["energy method"], nontriviality={"why_nontrivial":"The estimate needs a coercive bound.", "distinguishing_step":"Boundary absorption using epsilon inequality.", "self_assessed_trivial":False})
    d.update(kw); return Candidate(**d)

def test_accepts_scoped_supporting_lemma():
    gate = GoalMutationGate(make_goal())
    v = gate.validate(make_candidate())
    assert v.accepted, v.reasons

def test_rejects_goal_drift():
    gate = GoalMutationGate(make_goal())
    c = make_candidate(goal_id="OTHER")
    assert not gate.validate(c).accepted

def test_rejects_hidden_assumption():
    gate = GoalMutationGate(make_goal())
    c = make_candidate(hypotheses=["x is real", "x > 0"])
    assert not gate.validate(c).accepted

def test_rejects_missing_bridge():
    gate = GoalMutationGate(make_goal())
    c = make_candidate(mapping_to_goal=[])
    assert not gate.validate(c).accepted

def test_exploration_requires_off_pool_theory_and_method_novelty():
    goal = GoalContract(goal_id="G1", statement="Prove P(x)", target_terms=("P","x"),
                        pool_theories=("energy methods",), pool_methods=("energy estimate",), hypotheses=("x is real",))
    gate = GoalMutationGate(goal)
    c = make_candidate(mutation={"operator":"NEW_THEORY_BRIDGE", "parent_claim_ids":[],
                       "changed_fields":["proof_method", "concepts"], "expected_gain":"transfer a new theory lens",
                       "theory_bridge_witness":"map the categorical invariant into P(x)"},
                       new_perspective={"theory":"category theory", "principle":"functoriality", "bridge_to_goal":["P(x) via invariant map"]},
                       proof_method="categorical lifting", new_concepts=["functorial invariant"],
                       mapping_to_goal=["P(x) via categorical invariant"])
    assert gate.validate(c, exploration=True).accepted

def test_exploration_rejects_pool_rediscovery():
    goal = GoalContract(goal_id="G1", statement="P(x)", target_terms=("P","x"),
                        pool_theories=("energy methods",), pool_methods=("energy estimate",), hypotheses=("x is real",))
    gate = GoalMutationGate(goal)
    c = make_candidate(new_perspective={"theory":"energy methods", "principle":"coercivity", "bridge_to_goal":["P(x)"]})
    assert not gate.validate(c, exploration=True).accepted

def test_same_statement_new_proof_method_is_proof_space_novelty():
    goal = GoalContract(goal_id="G1", statement="P(x)", target_terms=("P", "x"),
                        hypotheses=("x is real",), pool_theories=("energy methods",),
                        pool_methods=("energy estimate",))
    archive = NoveltyArchive()
    original = make_candidate(candidate_id="C-old", relation="direct_target", statement="P(x)",
                              mapping_to_goal=[], proof_method="energy estimate")
    archive.add(original)
    gate = GoalMutationGate(goal, archive, known_theories={"energy methods"}, known_methods={"energy estimate"},
                            known_candidate_ids={"C-old"}, known_candidates={"C-old": original})
    c = make_candidate(candidate_id="C-new", relation="direct_target", statement="P(x)", mapping_to_goal=[],
                       mutation={"operator":"PROOF_STRATEGY_DRIFT", "parent_claim_ids":["C-old"],
                                 "changed_fields":["proof_method", "proof_sketch"], "expected_gain":"use an independent proof route",
                                 "strategy_change_witness":"replace direct energy estimate by contradiction via invariant"},
                       parent_ids=["C-old"], proof_method="contradiction via invariant",
                       proof_sketch="Assume the negation and derive a contradiction using an invariant.",
                       new_perspective={"theory":"spectral graph theory", "principle":"interlacing", "bridge_to_goal":["P(x) via eigenvalue bound"]},
                       new_concepts=["interlacing bound"])
    # For a direct-target route, exploration still requires the new perspective
    # and a new method. This is a proof-route novelty on the same proposition.
    assert gate.validate(c, exploration=True).accepted

def test_rejects_known_off_pool_theory_reuse():
    goal = GoalContract(goal_id="G1", statement="P(x)", target_terms=("P", "x"),
                        hypotheses=("x is real",), pool_theories=("energy methods",))
    gate = GoalMutationGate(goal, known_theories={"energy methods", "category theory"},
                            known_methods={"energy estimate"})
    c = make_candidate(mutation={"operator":"NEW_THEORY_BRIDGE", "parent_claim_ids":[],
                       "changed_fields":["proof_method", "concepts"], "expected_gain":"transfer a new theory lens",
                       "theory_bridge_witness":"map the categorical invariant into P(x)"},
                       new_perspective={"theory":"category theory", "principle":"functoriality", "bridge_to_goal":["P(x)"]},
                       proof_method="categorical lifting", new_concepts=["functorial invariant"],
                       mapping_to_goal=["P(x) via invariant"])
    assert not gate.validate(c, exploration=True).accepted

def test_refuted_statement_is_permanently_blocked_as_positive_claim():
    goal = GoalContract(goal_id="G1", statement="P(x)", target_terms=("P", "x"))
    candidate = make_candidate(relation="direct_target", mapping_to_goal=[])
    fp = candidate.statement_fingerprint
    gate = GoalMutationGate(goal, refuted_fingerprints={fp: "C-refuted"})
    verdict = gate.validate(candidate)
    assert not verdict.accepted
    assert any("previously_refuted" in reason for reason in verdict.reasons)


def test_rejects_model_authored_kernel_status():
    gate = GoalMutationGate(make_goal())
    c = make_candidate(status="KERNEL_CHECKED")
    verdict = gate.validate(c)
    assert not verdict.accepted
    assert any("initial_status_must_be_OPEN" in reason for reason in verdict.reasons)


def test_direct_target_must_preserve_statement_and_exact_hypotheses():
    goal = GoalContract(goal_id="G1", statement="For all real x, P(x)",
                        hypotheses=("x is real", "x != 0"), target_terms=("P", "x"))
    gate = GoalMutationGate(goal)
    changed_statement = make_candidate(relation="direct_target", statement="For all real x, Q(x)",
                                       hypotheses=["x is real", "x != 0"], mapping_to_goal=[])
    verdict = gate.validate(changed_statement)
    assert not verdict.accepted
    assert any("statement_differs" in r for r in verdict.reasons)
    dropped_hypothesis = make_candidate(relation="direct_target", statement=goal.statement,
                                        hypotheses=["x is real"], mapping_to_goal=[])
    verdict = gate.validate(dropped_hypothesis)
    assert not verdict.accepted
    assert any("hypotheses_must_match" in r for r in verdict.reasons)

def test_counterexample_must_satisfy_hypotheses_and_be_reproducible():
    goal = GoalContract(goal_id="G1", statement="For all real x, P(x)", target_terms=("P", "x"))
    gate = GoalMutationGate(goal)
    c = make_candidate(relation="counterexample",
                       mutation={"operator":"COUNTEREXAMPLE_SEARCH", "parent_claim_ids":["C-parent"],
                                 "changed_fields":["witness"], "expected_gain":"attempt to falsify the target",
                                 "search_strategy":"solve the negated conclusion under target hypotheses"},
                       parent_ids=["C-parent"],
                       metadata={"counterexample_witness": {"x": 2},
                                 "hypotheses_satisfied": False, "reproduction": "evaluate P(2)"})
    verdict = gate.validate(c)
    assert not verdict.accepted
    assert any("hypotheses_are_satisfied" in r for r in verdict.reasons)


def test_accepts_direct_target_with_exact_locked_statement_and_hypotheses():
    goal = GoalContract(goal_id="G1", statement="For all real x, P(x)",
                        hypotheses=("x is real", "x != 0"), target_terms=("P", "x"))
    c = make_candidate(relation="direct_target", statement=goal.statement,
                       hypotheses=list(goal.hypotheses), mapping_to_goal=[])
    verdict = GoalMutationGate(goal).validate(c)
    assert verdict.accepted, verdict.reasons

def test_accepts_counterexample_with_witness_hypothesis_check_and_reproduction():
    goal = GoalContract(goal_id="G1", statement="For all real x, P(x)",
                        hypotheses=("x is real",), target_terms=("P", "x"))
    c = make_candidate(relation="counterexample", mapping_to_goal=["P(x) is false at x=2"],
                       metadata={"counterexample_witness": {"x": 2},
                                 "hypotheses_satisfied": True,
                                 "reproduction": "evaluate P(2) and verify x is real"})
    verdict = GoalMutationGate(goal).validate(c)
    assert verdict.accepted, verdict.reasons


def test_compose_requires_two_known_parents_and_premise_map():
    goal = make_goal()
    p1 = make_candidate(candidate_id="P1")
    p2 = make_candidate(candidate_id="P2")
    gate = GoalMutationGate(goal, known_candidate_ids={"P1", "P2"},
                            known_candidates={"P1": p1, "P2": p2})
    c = make_candidate(mutation={"operator":"COMPOSE", "parent_claim_ids":["P1", "P2"],
                                 "changed_fields":["conclusion"], "expected_gain":"compose two estimates",
                                 "premise_map":{"P1":"coercivity", "P2":"boundary control"}},
                       parent_ids=["P1", "P2"])
    verdict = gate.validate(c)
    assert verdict.accepted, verdict.reasons


def test_compose_without_parents_is_rejected():
    c = make_candidate(mutation={"operator":"COMPOSE", "parent_claim_ids":[],
                                 "changed_fields":["statement"], "expected_gain":"compose",
                                 "premise_map":{}})
    verdict = GoalMutationGate(make_goal()).validate(c)
    assert not verdict.accepted
    assert any("mutation_parent_arity" in x for x in verdict.reasons)


def test_neutral_drift_preserves_claim_and_hypotheses():
    goal = make_goal()
    parent = make_candidate(candidate_id="P-neutral", statement="A supporting lemma about P(x)")
    gate = GoalMutationGate(goal, known_candidate_ids={"P-neutral"}, known_candidates={"P-neutral": parent})
    c = make_candidate(mutation={"operator":"NEUTRAL_DRIFT", "parent_claim_ids":["P-neutral"],
                                 "changed_fields":["proof_sketch"], "expected_gain":"improve future tactic evolvability",
                                 "neutrality_witness":"same proposition and assumptions; alternate tactic route"},
                       parent_ids=["P-neutral"], proof_sketch="Alternative proof term construction.")
    assert gate.validate(c).accepted
    altered = make_candidate(mutation=c.mutation, parent_ids=["P-neutral"],
                             statement="A stronger but different lemma about P(x)")
    verdict = gate.validate(altered)
    assert not verdict.accepted
    assert any("preserve_parent_statement" in x for x in verdict.reasons)


def test_counterexample_repair_can_reference_refuted_parent_as_negative_evidence_only():
    goal = make_goal()
    refuted = make_candidate(candidate_id="C-refuted", relation="direct_target", statement=goal.statement,
                             hypotheses=list(goal.hypotheses), mapping_to_goal=[])
    refuted.status = "REFUTED"
    repaired = make_candidate(
        candidate_id="C-repair",
        mutation={"operator":"COUNTEREXAMPLE_REPAIR", "parent_claim_ids":["C-refuted"],
                  "changed_fields":["statement", "hypotheses"],
                  "expected_gain":"repair the failed global claim by restricting its domain",
                  "counterexample_response":{"refuted_claim_ids":["C-refuted"],
                                             "repair_strategy":"exclude the singular boundary and prove the restricted result"}},
        parent_ids=["C-refuted"],
    )
    gate = GoalMutationGate(goal, known_candidate_ids=set(), known_refuted_candidate_ids={"C-refuted"},
                            known_candidates={"C-refuted": refuted})
    verdict = gate.validate(repaired)
    assert verdict.accepted, verdict.reasons


def test_refuted_parent_cannot_be_used_by_compose_or_proof_repair():
    goal = make_goal()
    refuted = make_candidate(candidate_id="C-refuted", relation="direct_target", statement=goal.statement,
                             hypotheses=list(goal.hypotheses), mapping_to_goal=[])
    refuted.status = "REFUTED"
    c = make_candidate(mutation={"operator":"PROOF_REPAIR", "parent_claim_ids":["C-refuted"],
                                 "changed_fields":["proof_sketch"], "expected_gain":"repair proof",
                                 "repair_target_obligation":"close the main goal"},
                       parent_ids=["C-refuted"])
    gate = GoalMutationGate(goal, known_candidate_ids=set(), known_refuted_candidate_ids={"C-refuted"},
                            known_candidates={"C-refuted": refuted})
    verdict = gate.validate(c)
    assert not verdict.accepted
    assert any("refuted_claims_cannot_be_used" in reason for reason in verdict.reasons)


def test_malformed_changed_fields_are_rejected_without_crashing():
    c = make_candidate(mutation={"operator":"NEUTRAL_DRIFT", "parent_claim_ids":["P"],
                                 "changed_fields":None, "expected_gain":"neutral route",
                                 "neutrality_witness":"same claim, alternate proof"},
                       parent_ids=["P"])
    verdict = GoalMutationGate(make_goal(), known_candidate_ids={"P"},
                               known_candidates={"P": make_candidate(candidate_id="P")}).validate(c)
    assert not verdict.accepted
    assert any("changed_fields" in reason for reason in verdict.reasons)


def test_parent_id_without_snapshot_is_rejected():
    c = make_candidate(mutation={"operator":"PROOF_REPAIR", "parent_claim_ids":["missing"],
                                 "changed_fields":["proof_sketch"], "expected_gain":"repair",
                                 "repair_target_obligation":"close the estimate"},
                       parent_ids=["missing"])
    verdict = GoalMutationGate(make_goal(), known_candidate_ids={"missing"}).validate(c)
    assert not verdict.accepted
    assert any("parent_snapshot_missing" in reason for reason in verdict.reasons)


def test_candidate_parser_rejects_malformed_mutation_and_list_types():
    from copy import deepcopy
    base = make_candidate().to_dict()
    malformed_mutation = deepcopy(base)
    malformed_mutation["mutation"] = None
    try:
        Candidate.from_dict(malformed_mutation)
    except ValueError as exc:
        assert "mutation" in str(exc)
    else:
        raise AssertionError("malformed mutation object was accepted")
    malformed_hypotheses = deepcopy(base)
    malformed_hypotheses["hypotheses"] = "x is real"
    try:
        Candidate.from_dict(malformed_hypotheses)
    except ValueError as exc:
        assert "hypotheses" in str(exc)
    else:
        raise AssertionError("malformed hypotheses were accepted")


def test_goal_contract_parser_preserves_default_allowed_relations_when_omitted():
    goal = GoalContract.from_dict({"goal_id":"G-default", "statement":"P(x)"})
    assert "supporting_lemma" in goal.allowed_relations
    assert "counterexample" in goal.allowed_relations
