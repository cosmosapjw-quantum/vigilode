# Result artifacts

- `results/ablation.json` / `.md`: six-arm discrete benchmark, 40 seeds per arm, 180 evaluations per run.
- `results/continuous_langevin_ablation.json` / `.md`: gradient-only vs fixed ULA vs BO-controlled ULA, 40 seeds per arm, 180 evaluations per run.
- `results/local_environment_probe.md`: connected-device Lean/Wolfram executable checks and environment versions.
- `results/validation_summary.md`: package tests, CLI, wheel, and ablation validation summary.
- `results/*_run.log`: captured CLI output for both ablation runs.

All benchmark outputs are reproducible optimizer diagnostics. They are not proof certificates or theorem-search success claims.
