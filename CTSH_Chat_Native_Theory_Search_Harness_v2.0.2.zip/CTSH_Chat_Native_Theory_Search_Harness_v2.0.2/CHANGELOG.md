# Changelog

## 2.0.0
- Added installable Python package and CLI.
- Added MCTS transposition graph and separate proof dependency AND/OR DAG.
- Added typed semantic mutation contract, strict goal-scope gate and novelty/off-pool theory hooks.
- Added continuous ULA Langevin perturbation and a separately named discrete Metropolis tempering operator.
- Added Matérn-5/2 GP expected-improvement controller for exploration/MCTS/perturbation policy allocation.
- Added local Lean kernel/axiom audit and restricted-AST WolframScript adapters.
- Added equal-budget optimizer-mechanics ablation runner and tests.


## 2.0.1
- Reject model-authored initial verification statuses; candidates must enter as OPEN.
- Require both premise and conclusion kernel certificates before exposing a proof-DAG rule as reusable.
- Clarify BO's four separate control dimensions and disable Langevin allocation when no differentiable continuous objective is configured.
- Refresh the release ablation artifacts and package manifest.


## 2.0.2
- Enforce operator-specific mutation parent arity and mandatory semantic witness fields.
- Add explicit direct-derivation and counterexample-search operators.
- Require strategy drift/neutral drift to preserve the parent theorem and hypotheses; neutral drift only changes proof representation.
- Allow counterexample repair to cite one REFUTED parent as negative evidence only, never as a proved premise.
- Bind top-level and mutation parent lists exactly and restore all accepted/refuted candidates for mutation-gate validation.
- Add a continuous tilted-double-well ablation separating true ULA from discrete Metropolis mutations and testing BO allocation of Langevin probability.
- Fix GoalContract JSON parsing so omitted optional relation lists retain their declared defaults; add successful BO-decision roundtrip and counterexample-repair ingest coverage.
