# CTSH v2.0.2 validation record

**Scope:** package code, CLI integration, strict candidate gates, local backend interfaces, and two optimizer-mechanics ablations. This validation does not establish general theorem-discovery performance or mathematical novelty.

## Automated checks

| Check | Result |
|---|---|
| `PYTHONPATH=src pytest -q` | **53 passed, 2 skipped** |
| `python -m compileall -q src/ctsh tests` | PASS |
| `python -m ctsh --version` | `2.0.2` |
| CLI help contains all declared subcommands including `ablate-continuous` | PASS |
| Sample workspace init + proposal ingest | PASS; valid `DIRECT_DERIVATION` accepted |
| BO decision-bound ingest + feedback roundtrip | PASS; tested in pytest |
| Refuted-parent counterexample repair ingest | PASS; tested in pytest |
| Forged model-authored verification status | REJECTED by tests |
| Terminal REFUTED / COUNTEREXAMPLE_FOUND overwrite | REJECTED by tests |
| Wheel build | PASS: `ctsh_theory_harness-2.0.2-py3-none-any.whl` |
| Wheel installed into isolated target with `--no-deps`; package import, version and CLI help | PASS |

The two skipped test cases are the package test-suite's Lean and Wolfram runtime tests: this portable build container has neither executable. A separate connected Ubuntu 24.04 environment probe is recorded in `local_environment_probe.md`; it confirmed Python 3.12.3, Lean 4.34.1 kernel acceptance with no axioms on a small theorem, and WolframScript arithmetic/symbolic checks. Those remote smoke tests demonstrate executable availability and representative functionality, not a full package installation on that host.

## Ablation results

- Discrete deceptive-block benchmark: 6 arms, 40 paired seeds, 180 evaluation budget per run. Hybrid fixed mean score 10.500/12 (8/40 exact hits); BO hybrid 10.525/12 (10/40 hits). Paired BO-minus-fixed difference +0.025 with bootstrap 95% interval [-0.325, +0.400], so no demonstrated benefit over the fixed ratio.
- Continuous tilted-double-well benchmark: 3 arms, 40 paired seeds, 180 evaluations per run. Fixed ULA p=0.35 reached mean best energy -0.3469 and 37/40 success; BO-controlled ULA varied p (mean 0.274, 177.3 unique rounded probabilities) but reached -0.1698 and 28/40 success. Its paired energy difference versus fixed was +0.1770 (95% CI [+0.0782, +0.2796], lower is better), so BO adaptation was active but inferior to this fixed p on this toy problem.

The discrete benchmark has no continuous parameters and therefore fixes the ULA probability to zero. The continuous benchmark tests ULA only on a real-valued differentiable energy with a supplied gradient. Neither benchmark tests theorem truth, proof quality, discovery novelty, or proof-assistant correctness.
