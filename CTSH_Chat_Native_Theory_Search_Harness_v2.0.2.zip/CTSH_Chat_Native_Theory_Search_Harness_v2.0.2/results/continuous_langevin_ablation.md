# CTSH continuous Langevin ablation

Benchmark: `tilted_double_well_continuous`
Package: 2.0.2; Python: 3.13.5; NumPy: 2.3.5
Budget/run: 180; seeds/arm: 40
Objective: `E(x)=(x^2-1)^2 + 0.4 x; start x=+1 in the deceptive local basin`
Global minimum (numerically located): -0.409544
Success threshold: -0.189544
ULA step size/temperature: 0.12 / 0.45

| Arm | Mean best energy (lower is better) | SD | Successes | Mean BO Langevin p | Applied ULA rate | Unique policy values |
|---|---:|---:|---:|---:|---:|---:|
| gradient_only | 0.3894 | 0.0000 | 0/40 | 0.000 | 0.000 | 1.0 |
| langevin_fixed | -0.3469 | 0.2127 | 37/40 | 0.350 | 0.352 | 1.0 |
| langevin_bo | -0.1698 | 0.3708 | 28/40 | 0.274 | 0.280 | 177.3 |

## Paired comparisons against fixed-probability ULA

| Arm | Mean paired energy Δ | Bootstrap 95% CI | Lower / higher / ties |
|---|---:|---:|---:|
| gradient_only | 0.7363 | [0.6581, 0.7956] | 0 / 37 / 3 |
| langevin_bo | 0.1770 | [0.0782, 0.2796] | 11 / 16 / 13 |

This only tests a one-dimensional differentiable optimization toy problem. It does not demonstrate Langevin usefulness on theorem/proof graphs, and BO's policy result is problem- and budget-dependent.
