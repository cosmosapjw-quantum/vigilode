# Connected local environment probe

**Probe date:** 2026-11-04 (Asia/Seoul). This is an environment-capability record, not a claim that the packaged adapter was installed on the remote host as part of this archive build.

| Component | Observed environment/result |
|---|---|
| OS | Ubuntu 24.04 family, Linux x86_64 |
| Python | 3.12.3 |
| NumPy / SciPy / SymPy | 2.4.2 / 1.17.0 / 1.14.0 |
| pytest / Hypothesis | 9.1.1 / 6.98.15 |
| Lean launcher | `~/.elan/bin/lean`; Elan toolchains v4.31.0 and v4.34.1 installed; default `stable` pointed to v4.35.0, not installed |
| Selected Lean test | `elan run leanprover/lean4:v4.34.1 lean <temporary-file>` returned exit code 0; theorem `n + 0 = n` reported no axioms |
| Wolfram launchers | `/usr/bin/wolframscript`, `/usr/local/bin/WolframKernel` |
| Wolfram command probe | printed `4` and `True` for integer arithmetic and a rational identity under `x != 1`; exit code 0 |
| Adapter-shape smoke | a standalone Python adapter probe returned `KERNEL_CHECKED` for the Lean theorem, rejected a `sorry` source by policy, returned `SYMBOLICALLY_CHECKED` for the rational identity, and returned `x > 1` as a symbolic violation region for `x^2 != x` under `x > 1` |

The package's portable pytest environment does not include Lean/Wolfram executables, so `tests/test_backends.py` skips those two runtime tests there. The direct connected-device probes above establish that the required local executables exist and can perform the demonstrated exact tasks. Run `ctsh check-env` and the package-specific `ctsh lean-check` / `ctsh wolfram-check` on the target machine after installing the ZIP.
