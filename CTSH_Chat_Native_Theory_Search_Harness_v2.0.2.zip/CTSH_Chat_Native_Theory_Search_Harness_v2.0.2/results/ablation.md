# CTSH v2 ablation report

Benchmark: `deceptive_block_landscape`
Package: 2.0.2; Python: 3.13.5; NumPy: 2.3.5
Budget/run: 180; seeds/arm: 40

This benchmark tests optimizer mechanics on an artificial deceptive landscape. It does not test theorem discovery, proof soundness, or novelty.

| Arm | Mean best | SD | Successes | Success rate | Unique candidates | Explore | MCTS | Langevin p | Tempering p | Applied tempering | Accept rate |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| random | 9.625 | 0.838 | 1/40 | 2.5% | 176.4 | n/a | n/a | n/a | n/a | 0.00 | n/a |
| mcts_only | 10.000 | 0.000 | 0/40 | 0.0% | 112.0 | n/a | n/a | n/a | n/a | 0.00 | n/a |
| ga_only | 10.000 | 0.847 | 1/40 | 2.5% | 80.4 | n/a | n/a | n/a | n/a | 0.00 | n/a |
| hybrid_fixed | 10.500 | 0.816 | 8/40 | 20.0% | 103.0 | 0.45 | 0.50 | 0.00 | 0.20 | 0.20 | 0.39 |
| hybrid_bo | 10.525 | 0.877 | 10/40 | 25.0% | 109.2 | 0.54 | 0.51 | 0.00 | 0.27 | 0.27 | 0.41 |
| hybrid_no_perturb | 10.350 | 0.580 | 1/40 | 2.5% | 105.8 | 0.45 | 0.50 | 0.00 | 0.20 | 0.00 | n/a |

## Paired comparisons against `hybrid_fixed`

| Arm | Mean paired Δ score | Bootstrap 95% CI | Wins / losses / ties |
|---|---:|---:|---:|
| random | -0.875 | [-1.275, -0.500] | 3 / 21 / 16 |
| mcts_only | -0.500 | [-0.750, -0.250] | 0 / 12 / 28 |
| ga_only | -0.500 | [-0.825, -0.175] | 7 / 22 / 11 |
| hybrid_bo | 0.025 | [-0.325, 0.400] | 9 / 9 / 22 |
| hybrid_no_perturb | -0.150 | [-0.475, 0.150] | 8 / 10 / 22 |

The intervals are paired-seed bootstrap intervals on this synthetic objective, not theorem-search confidence bounds.
