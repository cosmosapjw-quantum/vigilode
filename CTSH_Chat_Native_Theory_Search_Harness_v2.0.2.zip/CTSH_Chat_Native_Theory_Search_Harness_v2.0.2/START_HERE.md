# CTSH v2.0.2 — start here

CTSH is a **chat-driven local research harness**, not a second language model. The current ChatGPT model proposes mathematical candidates; the Python package schedules MCTS/GA/BO, applies goal and mutation gates, persists state, runs local Lean/Wolfram commands, and records evidence. Uploading this ZIP to an online chat does **not** by itself give that chat access to your computer. Run the CLI on the machine where Lean/Wolfram are installed, or use an explicitly connected remote-execution bridge.

## 1. Install

```bash
python -m venv .venv
source .venv/bin/activate                 # Windows PowerShell: .venv\\Scripts\\Activate.ps1
python -m pip install -e '.[dev]'
pytest -q
ctsh --version
ctsh check-env
```

A prebuilt wheel is in `dist/`. If the same Python environment already has NumPy, SciPy and SymPy, install it offline with:

```bash
python -m pip install --no-deps dist/ctsh_theory_harness-2.0.2-py3-none-any.whl
```

Lean and Wolfram are optional and are never downloaded/updated by CTSH. Pin the exact installed Lean toolchain in each run.

## 2. Create a locked goal

```bash
ctsh init --workspace ./research-run \
  --goal-id THEOREM-001 \
  --goal 'For every real x with x != 1, (x^2 - 1)/(x - 1) = x + 1' \
  --mode prove --domain real \
  --hypothesis 'x is real' --hypothesis 'x != 1' \
  --target-term x --target-term factorization --target-term identity \
  --required-obligation 'prove x^2 - 1 = (x - 1)(x + 1)' \
  --required-obligation 'cancel x - 1 using x != 1'
```

The goal statement, domain, quantifiers and hypotheses are immutable for that workspace. For a materially different goal, create a new workspace.

## 3. Run one chat search cycle

```bash
ctsh prompt --workspace ./research-run > next_chat_prompt.md
```

Paste the content of `next_chat_prompt.md` into the chat model. It contains the current BO decision ID, selected exploration/exploitation phase, MCTS/GA source, parent lineage, required hooks and candidate JSON contract. Ask for no more than three genuinely distinct candidates. Save one candidate as `proposal.json`.

```bash
ctsh ingest --workspace ./research-run --file proposal.json --decision-id DECISION_ID
```

Use the exact decision ID printed in the prompt. It makes the stored BO phase and selected parent IDs authoritative. Do not strip `parent_ids`, `mutation.parent_claim_ids`, changed fields, or the operator-specific witness.

## 4. Understand the mutation gate

A direct derivation starts with `DIRECT_DERIVATION` and zero parents. `COMPOSE`, `ANTI_UNIFY` and `TYPE_SAFE_CROSSOVER` require 2–4 existing parents. Unary transformations require one parent. Every mutation needs a nonempty `changed_fields`, an `expected_gain`, and its operator-specific witness. `NEUTRAL_DRIFT` preserves the exact claim and changes only proof representation. `COUNTEREXAMPLE_REPAIR` references a REFUTED claim only as negative evidence and creates a new ID.

A BO-selected `EXPLORE` requires a theory principle absent from the current pool, a different proof-method family, a nontrivial inference and an explicit bridge back to the locked goal. These hooks widen the route, not the target.

## 5. Verify and feed evidence back

For a reviewed Lean file:

```bash
ctsh verify-lean --workspace ./research-run --candidate-id CLM-001 \
  --file candidate.lean --theorem candidate_theorem \
  --toolchain leanprover/lean4:v4.34.1 --statement-fidelity-reviewed
```

For a supported exact identity:

```bash
ctsh verify-wolfram --workspace ./research-run --candidate-id CLM-001 \
  --lhs '(x**2-1)/(x-1)' --rhs 'x+1' --variables x \
  --assumptions 'x != 1' --statement-fidelity-reviewed
```

A formal proof certifies the formal Lean proposition under its reported axioms, not automatically its equivalence to the natural-language goal. Review statement fidelity before promotion. Wolfram symbolic checking applies only to the encoded expression and assumptions; it is not interchangeable with a Lean kernel proof.

After reviewing candidate outcome, feed the exact decision back:

```bash
ctsh feedback --workspace ./research-run --decision-id DECISION_ID \
  --candidate-id CLM-001 --obligations-closed 1 --evaluation-cost 4.2
```

Then issue the next `ctsh prompt`. Repeat until a proof, counterexample, budget limit or precise blocker is reached. `ctsh` stores the candidate pool, counterexample archive, proof/search graphs, BO observations and decision log in the workspace.

## 6. Reproducibility and boundaries

- `ctsh ablate --budget 180 --seeds 40 --output results/ablation.json` reruns the included optimizer-mechanics benchmark.
- The included benchmark is not a theorem-proving benchmark and cannot establish proof soundness or mathematical novelty.
- Langevin is disabled by default. Enable it only for a real continuous parameterization with an explicit differentiable energy and gradient: `ctsh init ... --enable-langevin`.
- Discrete theorem/proof mutations use typed operators or a separately labelled Metropolis/tempering proposal, never a fabricated gradient on text or graph structure.
- `REFUTED` and `COUNTEREXAMPLE_FOUND` archive records are terminal. Repair by creating a new candidate ID and retaining the refutation evidence.
- Lean source execution is local code execution. Review it; CTSH's source scan is not a sandbox. Wolfram receives only a restricted expression grammar.

Read `README.md`, `docs/`, and `prompts/MASTER_PROMPT.md` for complete interfaces and evidence semantics.
