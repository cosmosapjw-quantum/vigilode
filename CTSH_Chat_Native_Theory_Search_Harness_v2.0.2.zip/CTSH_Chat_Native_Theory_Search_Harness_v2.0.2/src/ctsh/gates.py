from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from .models import Candidate, GoalContract, GateVerdict, tokens

# Mutation contracts are deliberately typed. Each operator has an admissible
# lineage arity and a witness field that states what semantic transformation was
# attempted. The gate checks the declaration and lineage, not mathematical truth.
MUTATION_CONTRACTS = {
    "DIRECT_DERIVATION": (0, 0, "derivation_witness"),
    "GENERALIZE": (1, 1, "generalization_map"),
    "SPECIALIZE": (1, 1, "instantiation_map"),
    "COMPOSE": (2, 4, "premise_map"),
    "CONTRAPOSE": (1, 1, "negation_map"),
    "ANTI_UNIFY": (2, 4, "anti_unification_result"),
    "PROOF_REPAIR": (1, 1, "repair_target_obligation"),
    "PROOF_STRATEGY_DRIFT": (1, 1, "strategy_change_witness"),
    "NEUTRAL_DRIFT": (1, 1, "neutrality_witness"),
    "COUNTEREXAMPLE_SEARCH": (1, 1, "search_strategy"),
    "COUNTEREXAMPLE_REPAIR": (1, 1, "counterexample_response"),
    "TYPE_SAFE_CROSSOVER": (2, 4, "type_compatibility_witness"),
    "NEW_THEORY_BRIDGE": (0, 1, "theory_bridge_witness"),
}
ALLOWED_OPERATORS = set(MUTATION_CONTRACTS)
PARENTLESS_OPERATORS = {"DIRECT_DERIVATION", "NEW_THEORY_BRIDGE"}
REFUTED_PARENT_OPERATORS = {"COUNTEREXAMPLE_REPAIR"}
SAME_CLAIM_OPERATORS = {"PROOF_STRATEGY_DRIFT", "NEUTRAL_DRIFT"}


def _jaccard_distance(a: set[str], b: set[str]) -> float:
    if not a and not b:
        return 0.0
    return 1.0 - len(a & b) / max(1, len(a | b))


@dataclass
class NoveltyRecord:
    candidate_id: str
    statement_fingerprint: str
    method: str
    concepts: set[str]
    dependencies: set[str]


class NoveltyArchive:
    """A search-diversity archive. Similarity is not semantic equivalence."""
    def __init__(self, duplicate_distance: float = 0.08):
        self.duplicate_distance = duplicate_distance
        self.records: list[NoveltyRecord] = []

    def add(self, candidate: Candidate) -> None:
        self.records.append(NoveltyRecord(
            candidate.candidate_id, candidate.statement_fingerprint,
            candidate.proof_method.lower().strip(),
            {x.lower().strip() for x in candidate.new_concepts},
            set(candidate.proof_obligations),
        ))

    def assess(self, candidate: Candidate) -> tuple[float, tuple[str, ...], bool]:
        if not self.records:
            return 1.0, ("new_statement", "new_method", "new_dependency_pattern"), True
        same_statement = [r for r in self.records if r.statement_fingerprint == candidate.statement_fingerprint]
        method = candidate.proof_method.lower().strip()
        # The same theorem with a genuinely different proof-method family is a
        # useful proof-space novelty, not a duplicate proposition. Same statement
        # plus same method remains a duplicate; proof-sketch text alone is not used
        # as a novelty loophole.
        if same_statement:
            if all(method == r.method for r in same_statement):
                return 0.0, (), False
            return 1.0, ("proof_method",), True
        concepts = {x.lower().strip() for x in candidate.new_concepts}
        deps = set(candidate.proof_obligations)
        distances = []
        axes = set()
        for r in self.records:
            d_concept = _jaccard_distance(concepts, r.concepts)
            d_deps = _jaccard_distance(deps, r.dependencies)
            d_method = 0.0 if method == r.method else 1.0
            distances.append(0.45 * d_concept + 0.35 * d_deps + 0.20 * d_method)
        nearest = min(distances)
        if nearest > self.duplicate_distance:
            axes.add("proof_structure_or_concept")
        if method and all(method != r.method for r in self.records):
            axes.add("proof_method")
        if concepts - set().union(*(r.concepts for r in self.records)):
            axes.add("new_concept_tag")
        return nearest, tuple(sorted(axes)), nearest > self.duplicate_distance


class GoalMutationGate:
    """Hard scope/type/lineage gates, plus conservative exploration-only novelty gates.

    The gate checks declared contracts; it is not a theorem prover and cannot infer
    semantic equivalence from natural-language text.
    """
    def __init__(self, goal: GoalContract, novelty: NoveltyArchive | None = None,
                 min_exploration_novelty: float = 0.18, require_nontriviality_fields: bool = True,
                 refuted_fingerprints: dict[str, str] | None = None,
                 known_theories: Iterable[str] | None = None,
                 known_methods: Iterable[str] | None = None,
                 known_candidate_ids: Iterable[str] | None = None,
                 known_refuted_candidate_ids: Iterable[str] | None = None,
                 known_candidates: dict[str, Candidate] | None = None):
        self.goal = goal
        self.novelty = novelty or NoveltyArchive()
        self.min_exploration_novelty = min_exploration_novelty
        self.require_nontriviality_fields = require_nontriviality_fields
        self.refuted_fingerprints = dict(refuted_fingerprints or {})
        self.known_theories = {x.strip().lower() for x in (known_theories or goal.pool_theories) if x.strip()}
        self.known_methods = {x.strip().lower() for x in (known_methods or goal.pool_methods) if x.strip()}
        self.known_candidate_ids = set(known_candidate_ids) if known_candidate_ids is not None else None
        self.known_refuted_candidate_ids = set(known_refuted_candidate_ids or ())
        self.known_candidates = dict(known_candidates or {})

    def validate(self, candidate: Candidate, *, exploration: bool = False,
                 parent_ids: Iterable[str] | None = None) -> GateVerdict:
        errors: list[str] = []
        novelty_axes: tuple[str, ...] = ()
        novelty_distance: float | None = None
        if candidate.goal_id != self.goal.goal_id:
            errors.append("goal_id_mismatch: candidate cannot change the locked target")
        if not candidate.statement.strip() or not candidate.conclusion.strip():
            errors.append("empty_statement_or_conclusion")
        if candidate.relation not in self.goal.allowed_relations:
            errors.append(f"relation_not_allowed:{candidate.relation}")
        if candidate.relation == "direct_target":
            normalize = lambda value: " ".join(str(value).split())
            if normalize(candidate.statement) != normalize(self.goal.statement):
                if not self.goal.allow_target_reformulation:
                    errors.append("direct_target_statement_differs_from_locked_goal")
                elif not candidate.metadata.get("target_equivalence_obligation"):
                    errors.append("authorized_target_reformulation_requires_explicit_equivalence_obligation")
            if set(candidate.hypotheses) != set(self.goal.hypotheses):
                errors.append("direct_target_hypotheses_must_match_locked_goal_exactly")
        operator = str(candidate.mutation.get("operator", "")).upper()
        if operator not in ALLOWED_OPERATORS:
            errors.append(f"unknown_or_unregistered_mutation_operator:{operator or 'MISSING'}")
        expected_parents = set(parent_ids or candidate.parent_ids or candidate.mutation.get("parent_claim_ids", []))
        declared_parents = list(candidate.mutation.get("parent_claim_ids", []))
        object_parents = list(candidate.parent_ids)
        if len(declared_parents) != len(set(declared_parents)) or len(object_parents) != len(set(object_parents)):
            errors.append("duplicate_parent_ids_are_not_allowed")
        if set(declared_parents) != set(object_parents):
            errors.append("parent_ids_must_match_between_candidate_and_mutation_record")
        recorded_parents = set(object_parents)
        if expected_parents and not expected_parents.issubset(recorded_parents):
            errors.append("parent_lineage_mismatch")
        min_parents, max_parents, witness_field = MUTATION_CONTRACTS.get(operator, (0, 0, ""))
        if len(recorded_parents) < min_parents or len(recorded_parents) > max_parents:
            errors.append(f"mutation_parent_arity:{operator}:{len(recorded_parents)}_not_in_{min_parents}..{max_parents}")
        changed_fields = candidate.mutation.get("changed_fields", [])
        if not isinstance(changed_fields, list) or not changed_fields or not all(isinstance(x, str) and x.strip() for x in changed_fields):
            errors.append("mutation_requires_nonempty_changed_fields")
        if not str(candidate.mutation.get("expected_gain", "")).strip():
            errors.append("mutation_requires_expected_gain")
        witness = candidate.mutation.get(witness_field) if witness_field else None
        if witness is None or witness == "" or witness == [] or witness == {}:
            errors.append(f"mutation_requires_semantic_witness:{witness_field}")

        refuted_parents = recorded_parents & self.known_refuted_candidate_ids
        active_parents = recorded_parents - refuted_parents
        if operator in REFUTED_PARENT_OPERATORS:
            if not refuted_parents:
                errors.append("counterexample_repair_requires_refuted_parent")
            if active_parents:
                errors.append("counterexample_repair_parent_must_be_from_refutation_archive_only")
            response = candidate.mutation.get("counterexample_response", {})
            if not isinstance(response, dict) or not refuted_parents.issubset(set(response.get("refuted_claim_ids", []))):
                errors.append("counterexample_repair_must_explicitly_reference_refuted_parent_ids")
        elif refuted_parents:
            errors.append("refuted_claims_cannot_be_used_as_positive_lemma_parents")
        if self.known_candidate_ids is not None and active_parents - self.known_candidate_ids:
            errors.append(f"unknown_or_unaccepted_parent_ids:{sorted(active_parents - self.known_candidate_ids)}")
        missing_parent_snapshots = recorded_parents - set(self.known_candidates)
        if missing_parent_snapshots:
            errors.append(f"parent_snapshot_missing:{sorted(missing_parent_snapshots)}")
        if operator == "COUNTEREXAMPLE_SEARCH" and candidate.relation != "counterexample":
            errors.append("counterexample_search_operator_requires_counterexample_relation")
        if operator == "COUNTEREXAMPLE_REPAIR" and candidate.relation == "counterexample":
            errors.append("counterexample_repair_must_propose_a_repair_not_a_second_counterexample")
        declared_change_set = set(changed_fields) if isinstance(changed_fields, list) else set()
        if operator == "NEUTRAL_DRIFT" and not declared_change_set.issubset({"proof_sketch", "proof_method", "formalization", "tactic_strategy"}):
            errors.append("neutral_drift_may_only_change_proof_representation_not_claim_content")
        if operator in SAME_CLAIM_OPERATORS and len(recorded_parents) == 1:
            parent = self.known_candidates.get(next(iter(recorded_parents)))
            if parent is None:
                errors.append("same_claim_mutation_requires_parent_snapshot")
            else:
                if " ".join(candidate.statement.split()) != " ".join(parent.statement.split()):
                    errors.append("proof_strategy_drift_must_preserve_parent_statement")
                if set(candidate.hypotheses) != set(parent.hypotheses):
                    errors.append("proof_strategy_drift_must_preserve_parent_hypotheses")
                if candidate.conclusion != parent.conclusion or candidate.relation != parent.relation:
                    errors.append("proof_strategy_drift_must_preserve_conclusion_and_relation")
                proof_fields = {"proof_method", "proof_sketch", "proof_obligations", "formalization"}
                actual_changes = set()
                for field_name in proof_fields:
                    if getattr(candidate, field_name) != getattr(parent, field_name):
                        actual_changes.add(field_name)
                declared_changes = declared_change_set
                if not actual_changes:
                    errors.append("proof_strategy_drift_must_change_a_proof_representation_field")
                if not actual_changes.issubset(declared_changes):
                    errors.append(f"mutation_changed_fields_omit_actual_proof_changes:{sorted(actual_changes-declared_changes)}")
                if operator == "NEUTRAL_DRIFT":
                    invariant_fields = (
                        "proof_obligations", "mapping_to_goal", "scope_tags", "new_concepts",
                        "new_perspective", "assumption_discharge_obligations", "nontriviality"
                    )
                    if any(getattr(candidate, f) != getattr(parent, f) for f in invariant_fields):
                        errors.append("neutral_drift_must_preserve_all_non_proof_claim_metadata")
                    if not actual_changes.issubset({"proof_method", "proof_sketch", "formalization"}):
                        errors.append("neutral_drift_changed_fields_exceed_proof_representation")
        if operator == "COMPOSE" and isinstance(witness, dict):
            if set(witness) != recorded_parents or any(not str(v).strip() for v in witness.values()):
                errors.append("compose_premise_map_must_map_each_parent_exactly_once")
        if operator == "COUNTEREXAMPLE_REPAIR":
            response = candidate.mutation.get("counterexample_response", {})
            if not isinstance(response, dict) or not str(response.get("repair_strategy", "")).strip():
                errors.append("counterexample_repair_requires_explicit_repair_strategy")
            for refuted_id in refuted_parents:
                refuted_candidate = self.known_candidates.get(refuted_id)
                if refuted_candidate is None or refuted_candidate.status != "REFUTED":
                    errors.append("counterexample_repair_parent_must_have_terminal_REFUTED_status")

        forbidden = set(candidate.scope_tags) & set(self.goal.forbidden_scope_tags)
        if forbidden:
            errors.append(f"forbidden_scope_tags:{sorted(forbidden)}")
        if self.goal.require_goal_bridge and candidate.relation != "direct_target":
            if not candidate.mapping_to_goal or not any(str(x).strip() for x in candidate.mapping_to_goal):
                errors.append("missing_explicit_bridge_to_locked_goal")
        target_tokens = set(self.goal.target_terms) or tokens(self.goal.statement)
        bridge_tokens = tokens(" ".join(candidate.mapping_to_goal + candidate.proof_obligations + candidate.scope_tags))
        if self.goal.require_goal_bridge and candidate.relation != "direct_target" and target_tokens:
            if not (target_tokens & bridge_tokens):
                errors.append("bridge_has_no_target_anchor")

        goal_hyps = set(self.goal.hypotheses)
        cand_hyps = set(candidate.hypotheses)
        extras = cand_hyps - goal_hyps
        if len(extras) > self.goal.max_new_assumptions:
            errors.append(f"too_many_new_assumptions:{len(extras)}>{self.goal.max_new_assumptions}")
        allowed_aux = set(self.goal.allowed_auxiliary_assumptions)
        if extras - allowed_aux:
            errors.append(f"unapproved_auxiliary_assumptions:{sorted(extras - allowed_aux)}")
        if extras and not extras.issubset(set(candidate.assumption_discharge_obligations)):
            errors.append("new_assumptions_not_explicitly_discharged")
        if candidate.relation == "direct_target" and extras:
            errors.append("direct_target_cannot_strengthen_the_locked_hypotheses")

        if not candidate.proof_method.strip():
            errors.append("missing_proof_method")
        if not candidate.proof_sketch.strip():
            errors.append("missing_proof_sketch")
        if self.require_nontriviality_fields:
            nt = candidate.nontriviality
            if not nt.get("why_nontrivial", "").strip():
                errors.append("missing_nontriviality_argument")
            if not nt.get("distinguishing_step", "").strip():
                errors.append("missing_nontrivial_proof_step")
            if nt.get("self_assessed_trivial", False):
                errors.append("candidate_declares_itself_trivial")

        # A proposal generator cannot self-assign an evidential status. New
        # candidates enter as OPEN; every later status transition is recorded by
        # an explicit verifier or human-reviewed evidence command.
        if candidate.status != "OPEN":
            errors.append(f"initial_status_must_be_OPEN:{candidate.status}")
        if candidate.status in {"REFUTED", "COUNTEREXAMPLE_FOUND"} and candidate.relation != "counterexample":
            errors.append("refuted_claim_cannot_reenter_as_positive_candidate")
        if (candidate.relation != "counterexample" and
                candidate.statement_fingerprint in self.refuted_fingerprints):
            errors.append("previously_refuted_statement_cannot_reenter_as_positive_candidate")
        if candidate.relation == "counterexample":
            if not candidate.metadata.get("counterexample_witness"):
                errors.append("counterexample_relation_requires_witness")
            if candidate.metadata.get("hypotheses_satisfied") is not True:
                errors.append("counterexample_must_record_that_locked_hypotheses_are_satisfied")
            if not str(candidate.metadata.get("reproduction", "")).strip():
                errors.append("counterexample_requires_reproduction_record")

        if exploration:
            perspective = candidate.new_perspective or {}
            theory_name = str(perspective.get("theory", "")).strip()
            principle = str(perspective.get("principle", "")).strip()
            bridge = perspective.get("bridge_to_goal", [])
            if not theory_name or theory_name.lower() in self.known_theories:
                errors.append("exploration_requires_a_theory_not_already_in_pool")
            if operator not in {"NEW_THEORY_BRIDGE", "PROOF_STRATEGY_DRIFT"}:
                errors.append("exploration_requires_explicit_theory_or_strategy_mutation")
            if candidate.proof_method.lower().strip() in self.known_methods:
                errors.append("exploration_requires_a_new_proof_method_family")
            if not principle:
                errors.append("new_perspective_missing_transferable_principle")
            if not bridge or not any(str(x).strip() for x in bridge):
                errors.append("new_perspective_missing_operational_bridge")
            novelty_distance, novelty_axes, novel = self.novelty.assess(candidate)
            if not novel or novelty_distance < self.min_exploration_novelty:
                errors.append(f"insufficient_structural_novelty:{novelty_distance:.3f}")

        if errors:
            return GateVerdict(False, "REJECTED_BY_HARD_GATE", tuple(errors), novelty_distance, novelty_axes)
        return GateVerdict(True, "ACCEPTED_FOR_ORACLE_EVALUATION", (), novelty_distance, novelty_axes)
