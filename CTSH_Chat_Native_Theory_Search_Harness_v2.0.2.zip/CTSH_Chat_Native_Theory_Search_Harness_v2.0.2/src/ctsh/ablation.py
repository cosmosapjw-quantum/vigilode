from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Callable
import json, time, platform
import numpy as np
from .bo import BayesianBudgetController, BudgetMetrics, BudgetPolicy
from .perturb import TemperedMutationPerturber

@dataclass
class AblationRecord:
    arm: str
    seed: int
    budget: int
    best_score: float
    success: bool
    evaluations: int
    unique_candidates: int
    mean_exploration_share: float | None
    mean_mcts_share: float | None
    mean_continuous_langevin_probability: float | None
    mean_discrete_tempering_probability: float | None
    applied_perturbation_rate: float | None
    perturbation_acceptance_rate: float | None
    unique_policy_vectors: int | None
    best_genome: str

class DeceptiveBlockLandscape:
    """Known finite optimizer benchmark, NOT a theorem benchmark.

    Each k-bit block rewards the all-correct block with k, but any incomplete
    block scores k-1-matches. This creates a deceptive local optimum.
    """
    def __init__(self, target: tuple[int, ...] = (1,0,1,1,0,1,0,0,1,1,0,1), block_size: int = 4):
        if len(target) % block_size: raise ValueError("target length must be multiple of block_size")
        self.target, self.block_size = target, block_size
        self.optimum = float(len(target))

    def score(self, genome: tuple[int, ...]) -> float:
        if len(genome) != len(self.target): raise ValueError("genome length mismatch")
        total = 0.0
        for start in range(0, len(genome), self.block_size):
            matches = sum(genome[i] == self.target[i] for i in range(start, start + self.block_size))
            total += self.block_size if matches == self.block_size else self.block_size - 1 - matches
        return total

class _BitMCTS:
    def __init__(self, n: int, rng: np.random.Generator, c: float = 1.2):
        self.n, self.rng, self.c = n, rng, c
        self.stats: dict[str, list[float]] = {"": [0.0, 0.0]}

    def propose(self, evaluate: Callable[[tuple[int, ...]], float], rollouts: int = 5):
        best = None; best_score = -1e9
        for _ in range(rollouts):
            prefix = ""; path = [prefix]
            while len(prefix) < self.n:
                choices = [prefix + "0", prefix + "1"]
                for c in choices: self.stats.setdefault(c, [0.0, 0.0])
                parent_n = max(1.0, self.stats[prefix][0])
                def ucb(c):
                    v, s = self.stats[c]
                    return (s / v if v else 0.0) + self.c * np.sqrt(np.log(parent_n + 1.0) / (v + 1.0))
                nxt = max(choices, key=ucb)
                prefix = nxt; path.append(prefix)
            genome = tuple(int(x) for x in prefix)
            score = evaluate(genome)
            for node in path:
                self.stats[node][0] += 1.0; self.stats[node][1] += score / self.n
            if score > best_score: best, best_score = genome, score
        return best, best_score

class _GA:
    def __init__(self, n: int, rng: np.random.Generator, pop_size: int = 24):
        self.n, self.rng, self.pop_size = n, rng, pop_size
        self.population = [tuple(int(x) for x in rng.integers(0,2,size=n)) for _ in range(pop_size)]
        self.scored: list[tuple[float, tuple[int,...]]] = []

    def propose(self, evaluate: Callable[[tuple[int,...]], float], mutation_rate: float = 0.08):
        if not self.scored:
            genome = self.population[int(self.rng.integers(len(self.population)))]
        else:
            ranked = sorted(self.scored, reverse=True)
            p1 = ranked[int(self.rng.integers(min(8, len(ranked))))][1]
            p2 = ranked[int(self.rng.integers(min(8, len(ranked))))][1]
            cut = int(self.rng.integers(1, self.n))
            child = list(p1[:cut] + p2[cut:])
            for i in range(self.n):
                if self.rng.random() < mutation_rate: child[i] ^= 1
            genome = tuple(child)
        return genome, evaluate(genome)

    def tell(self, genome, score):
        self.scored.append((float(score), genome)); self.scored = sorted(self.scored, reverse=True)[:self.pop_size]
        self.population = [g for _,g in self.scored]

class AblationRunner:
    """Equal evaluation-budget comparison on an artificial deceptive landscape."""
    ARMS = ("random", "mcts_only", "ga_only", "hybrid_fixed", "hybrid_bo", "hybrid_no_perturb")
    def __init__(self, budget: int = 180, seeds: int = 12, block_size: int = 4):
        self.budget, self.seeds, self.block_size = budget, seeds, block_size

    def _run_one(self, arm: str, seed: int) -> AblationRecord:
        rng = np.random.default_rng(seed)
        task = DeceptiveBlockLandscape(block_size=self.block_size)
        n = len(task.target); mcts = _BitMCTS(n, rng); ga = _GA(n, rng)
        bo = BayesianBudgetController(seed=seed, min_observations=4,
                                      prior=BudgetPolicy(0.30, 0.60, 0.0, 0.10),
                                      active_dimensions=(0, 1, 3))
        tempering = TemperedMutationPerturber(temperature=0.9, seed=seed + 7919)
        best_score, best = -1e9, tuple(int(x) for x in rng.integers(0,2,size=n))
        seen: set[tuple[int, ...]] = set()
        evaluations = 0
        # This discrete benchmark has no continuous theta, so continuous Langevin
        # probability is held at zero; only the discrete Metropolis kernel is ablated.
        fixed = BudgetPolicy(0.45, 0.50, 0.0, 0.20)
        policy_trace: list[BudgetPolicy] = []
        proposal_decisions = 0
        perturbation_attempts = 0
        perturbation_accepts = 0
        current_state = None
        current_score = None
        while evaluations < self.budget:
            policy = bo.suggest() if arm == "hybrid_bo" else fixed
            if arm in {"hybrid_bo", "hybrid_fixed", "hybrid_no_perturb"}: policy_trace.append(policy)
            previous_best = best_score
            phase = {"phase": "EXPLOIT", "proposal_engine": "MCTS", "apply_langevin": False}
            if arm == "random":
                g = tuple(int(x) for x in rng.integers(0,2,size=n))
                s = task.score(g); evaluations += 1; seen.add(g)
            elif arm == "mcts_only":
                mcts.c = 1.2
                g, s = mcts.propose(lambda genome: task.score(genome), rollouts=1)
                evaluations += 1; seen.add(g)
            elif arm == "ga_only":
                g, s = ga.propose(task.score); ga.tell(g, s)
                evaluations += 1; seen.add(g)
            else:
                if arm == "hybrid_bo":
                    phase = bo.choose(rng, policy)
                else:
                    phase = {"phase": "EXPLORE" if rng.random()<policy.exploration_share else "EXPLOIT",
                             "proposal_engine": "MCTS" if rng.random()<policy.mcts_share else "GA",
                             "apply_langevin": False,
                             "apply_discrete_tempering": rng.random()<policy.tempered_mutation_probability}
                proposal_decisions += 1
                if phase["proposal_engine"] == "MCTS":
                    mcts.c = 1.8 if phase["phase"] == "EXPLORE" else 0.75
                    g, s = mcts.propose(task.score, rollouts=1)
                else:
                    mutation_rate = 0.18 if phase["phase"] == "EXPLORE" else 0.04
                    g, s = ga.propose(task.score, mutation_rate=mutation_rate); ga.tell(g, s)
                was_new = g not in seen
                evaluations += 1; seen.add(g)
                if current_state is None or s >= current_score:
                    current_state, current_score = g, float(s)
                use_tempering = phase.get("apply_discrete_tempering", False) and arm != "hybrid_no_perturb"
                perturbation_eval_used = False
                if use_tempering and evaluations < self.budget:
                    perturbation_eval_used = True
                    # Symmetric block-flip Metropolis proposal on the current chain
                    # state. This is a discrete mutation kernel, not Langevin dynamics.
                    perturbation_attempts += 1
                    if current_state is None:
                        current_state, current_score = g, float(s)
                    score_cache = {current_state: float(current_score)}
                    def energy(state):
                        if state not in score_cache:
                            score_cache[state] = float(task.score(state))
                        return -score_cache[state]
                    def flip_block(state):
                        values = list(state)
                        block = int(rng.integers(n // self.block_size))
                        for j in range(block*self.block_size, (block+1)*self.block_size):
                            values[j] ^= 1
                        return tuple(values)
                    accepted_state, perturb_info = tempering.step(current_state, flip_block, energy)
                    g2 = perturb_info["proposal"]
                    s2 = score_cache[g2]
                    evaluations += 1; seen.add(g2)
                    if perturb_info["accepted"]:
                        perturbation_accepts += 1
                        current_state, current_score = accepted_state, float(s2)
                    if s2 > best_score:
                        best, best_score = g2, float(s2)
                if arm == "hybrid_bo":
                    bo.observe(policy, BudgetMetrics(
                        verified_lemmas=0,
                        valid_counterexamples=0,
                        obligations_closed=0,
                        novelty_gain=float(was_new),
                        empirical_improvement=max(0.0, s - previous_best) if previous_best > -1e8 else 0.0,
                        duplicate_rate=0.0,
                        evaluation_cost=1.0 + float(perturbation_eval_used),
                    ))
            if s > best_score: best, best_score = g, float(s)
        mean_policy = np.mean([p.vector() for p in policy_trace], axis=0) if policy_trace else None
        return AblationRecord(arm, seed, self.budget, best_score, best_score >= task.optimum, evaluations, len(seen),
                              float(mean_policy[0]) if mean_policy is not None else None,
                              float(mean_policy[1]) if mean_policy is not None else None,
                              float(mean_policy[2]) if mean_policy is not None else None,
                              float(mean_policy[3]) if mean_policy is not None else None,
                              perturbation_attempts / proposal_decisions if proposal_decisions else 0.0,
                              perturbation_accepts / perturbation_attempts if perturbation_attempts else None,
                              len({tuple(np.round(p.vector(), 4)) for p in policy_trace}) if policy_trace else None,
                              ''.join(map(str,best)))

    def run(self) -> dict:
        records = [self._run_one(arm, seed) for arm in self.ARMS for seed in range(self.seeds)]
        summary = {}
        for arm in self.ARMS:
            rows = [r for r in records if r.arm == arm]
            scores = np.asarray([r.best_score for r in rows], dtype=float)
            successes = sum(r.success for r in rows)
            summary[arm] = {
                "n": len(rows), "mean_best_score": float(scores.mean()),
                "std_best_score": float(scores.std(ddof=1)) if len(scores)>1 else 0.0,
                "successes": successes, "success_rate": successes/len(rows),
                "mean_oracle_evaluations": float(np.mean([r.evaluations for r in rows])),
                "mean_unique_candidates": float(np.mean([r.unique_candidates for r in rows])),
                "mean_exploration_share": float(np.mean([r.mean_exploration_share for r in rows if r.mean_exploration_share is not None])) if any(r.mean_exploration_share is not None for r in rows) else None,
                "mean_mcts_share": float(np.mean([r.mean_mcts_share for r in rows if r.mean_mcts_share is not None])) if any(r.mean_mcts_share is not None for r in rows) else None,
                "mean_continuous_langevin_probability": float(np.mean([r.mean_continuous_langevin_probability for r in rows if r.mean_continuous_langevin_probability is not None])) if any(r.mean_continuous_langevin_probability is not None for r in rows) else None,
                "mean_discrete_tempering_probability": float(np.mean([r.mean_discrete_tempering_probability for r in rows if r.mean_discrete_tempering_probability is not None])) if any(r.mean_discrete_tempering_probability is not None for r in rows) else None,
                "mean_applied_perturbation_rate": float(np.mean([r.applied_perturbation_rate for r in rows if r.applied_perturbation_rate is not None])) if any(r.applied_perturbation_rate is not None for r in rows) else None,
                "mean_perturbation_acceptance_rate": float(np.mean([r.perturbation_acceptance_rate for r in rows if r.perturbation_acceptance_rate is not None])) if any(r.perturbation_acceptance_rate is not None for r in rows) else None,
                "mean_unique_policy_vectors": float(np.mean([r.unique_policy_vectors for r in rows if r.unique_policy_vectors is not None])) if any(r.unique_policy_vectors is not None for r in rows) else None,
            }
        paired = {}
        fixed_rows = {r.seed: r for r in records if r.arm == "hybrid_fixed"}
        bootstrap_rng = np.random.default_rng(20261104)
        for arm in self.ARMS:
            if arm == "hybrid_fixed":
                continue
            differences = np.asarray([r.best_score - fixed_rows[r.seed].best_score
                                      for r in records if r.arm == arm], dtype=float)
            if len(differences):
                draws = bootstrap_rng.choice(differences, size=(5000, len(differences)), replace=True).mean(axis=1)
                paired[arm] = {
                    "mean_paired_difference_vs_hybrid_fixed": float(differences.mean()),
                    "bootstrap_95pct_ci": [float(np.quantile(draws, 0.025)), float(np.quantile(draws, 0.975))],
                    "wins": int(np.sum(differences > 0)), "losses": int(np.sum(differences < 0)),
                    "ties": int(np.sum(differences == 0)),
                }
        from . import __version__
        return {"benchmark": "deceptive_block_landscape", "package_version": __version__,
                "python_version": platform.python_version(), "numpy_version": np.__version__,
                "interpretation": "optimizer-mechanics test only; not evidence of mathematical discovery capability",
                "budget_per_run": self.budget, "seeds": self.seeds,
                "target": ''.join(map(str, DeceptiveBlockLandscape(block_size=self.block_size).target)),
                "summary": summary, "paired_vs_hybrid_fixed": paired,
                "records": [asdict(r) for r in records]}


def write_report(result: dict, output: str | Path):
    path = Path(output); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    md = path.with_suffix('.md')
    lines = ["# CTSH v2 ablation report", "", f"Benchmark: `{result['benchmark']}`",
             f"Package: {result.get('package_version', 'unknown')}; Python: {result.get('python_version', 'unknown')}; NumPy: {result.get('numpy_version', 'unknown')}",
             f"Budget/run: {result['budget_per_run']}; seeds/arm: {result['seeds']}", "",
             "This benchmark tests optimizer mechanics on an artificial deceptive landscape. It does not test theorem discovery, proof soundness, or novelty.", "",
             "| Arm | Mean best | SD | Successes | Success rate | Unique candidates | Explore | MCTS | Langevin p | Tempering p | Applied tempering | Accept rate |", "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for arm, v in result['summary'].items():
        fmt = lambda x: 'n/a' if x is None else f'{x:.2f}'
        lines.append(f"| {arm} | {v['mean_best_score']:.3f} | {v['std_best_score']:.3f} | {v['successes']}/{v['n']} | {v['success_rate']:.1%} | {v['mean_unique_candidates']:.1f} | {fmt(v['mean_exploration_share'])} | {fmt(v['mean_mcts_share'])} | {fmt(v['mean_continuous_langevin_probability'])} | {fmt(v['mean_discrete_tempering_probability'])} | {fmt(v['mean_applied_perturbation_rate'])} | {fmt(v['mean_perturbation_acceptance_rate'])} |")
    lines.extend(["", "## Paired comparisons against `hybrid_fixed`", "", "| Arm | Mean paired Δ score | Bootstrap 95% CI | Wins / losses / ties |", "|---|---:|---:|---:|"])
    for arm, v in result.get("paired_vs_hybrid_fixed", {}).items():
        ci = v["bootstrap_95pct_ci"]
        lines.append(f"| {arm} | {v['mean_paired_difference_vs_hybrid_fixed']:.3f} | [{ci[0]:.3f}, {ci[1]:.3f}] | {v['wins']} / {v['losses']} / {v['ties']} |")
    lines.extend(["", "The intervals are paired-seed bootstrap intervals on this synthetic objective, not theorem-search confidence bounds."])
    md.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    return path, md
