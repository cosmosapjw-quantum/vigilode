from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Mapping
import hashlib, json, re


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)


def stable_hash(value: Any, length: int = 16) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()[:length]


def tokens(text: str) -> set[str]:
    return {x.lower() for x in re.findall(r"[A-Za-z][A-Za-z0-9_]*|[가-힣]{2,}|[0-9]+", text or "")}


class VerificationStatus(str, Enum):
    OPEN = "OPEN"
    CONJECTURAL = "CONJECTURAL"
    DERIVED_IN_CHAT = "DERIVED_IN_CHAT"
    SYMBOLICALLY_CHECKED = "SYMBOLICALLY_CHECKED"
    KERNEL_CHECKED = "KERNEL_CHECKED"
    KERNEL_CHECKED_WITH_ALLOWED_AXIOMS = "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS"
    COUNTEREXAMPLE_FOUND = "COUNTEREXAMPLE_FOUND"
    REFUTED = "REFUTED"
    CONDITIONAL = "CONDITIONAL"
    NOT_ATTEMPTED = "NOT_ATTEMPTED"
    ERROR = "ERROR"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class GoalContract:
    goal_id: str
    statement: str
    mode: str = "prove"  # prove | discover | algorithm
    domain: str = "unspecified"
    hypotheses: tuple[str, ...] = ()
    target_terms: tuple[str, ...] = ()
    required_obligations: tuple[str, ...] = ()
    allowed_relations: tuple[str, ...] = (
        "direct_target", "supporting_lemma", "bridge_result", "counterexample", "method_idea"
    )
    forbidden_scope_tags: tuple[str, ...] = ()
    pool_theories: tuple[str, ...] = ()
    pool_methods: tuple[str, ...] = ()
    allowed_auxiliary_assumptions: tuple[str, ...] = ()
    max_new_assumptions: int = 0
    require_goal_bridge: bool = True
    allow_target_reformulation: bool = False

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "GoalContract":
        seq_fields = {
            "hypotheses", "target_terms", "required_obligations", "allowed_relations",
            "forbidden_scope_tags", "pool_theories", "pool_methods", "allowed_auxiliary_assumptions"
        }
        clean = dict(data)
        for key in seq_fields:
            if key in clean:
                clean[key] = tuple(clean[key])
        return cls(**clean)

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def fingerprint(self) -> str:
        return stable_hash({
            "statement": self.statement,
            "domain": self.domain,
            "hypotheses": sorted(self.hypotheses),
            "target_terms": sorted(self.target_terms),
            "required_obligations": sorted(self.required_obligations),
        }, 24)


@dataclass
class Candidate:
    candidate_id: str
    goal_id: str
    statement: str
    hypotheses: list[str]
    conclusion: str
    relation: str
    mutation: dict[str, Any]
    proof_method: str
    proof_sketch: str
    proof_obligations: list[str]
    mapping_to_goal: list[str]
    scope_tags: list[str] = field(default_factory=list)
    new_concepts: list[str] = field(default_factory=list)
    new_perspective: dict[str, Any] | None = None
    assumption_discharge_obligations: list[str] = field(default_factory=list)
    nontriviality: dict[str, Any] = field(default_factory=dict)
    formalization: dict[str, Any] = field(default_factory=dict)
    status: str = VerificationStatus.OPEN.value
    parent_ids: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "Candidate":
        if not isinstance(data, Mapping):
            raise ValueError("candidate must be a JSON object")
        known = set(cls.__dataclass_fields__)
        extra = set(data) - known
        if extra:
            raise ValueError(f"Unknown candidate fields: {sorted(extra)}")
        candidate = cls(**dict(data))
        list_fields = (
            "hypotheses", "proof_obligations", "mapping_to_goal", "scope_tags",
            "new_concepts", "assumption_discharge_obligations", "parent_ids",
        )
        for field_name in list_fields:
            value = getattr(candidate, field_name)
            if not isinstance(value, list) or not all(isinstance(x, str) for x in value):
                raise ValueError(f"candidate.{field_name} must be a list of strings")
        dict_fields = ("mutation", "nontriviality", "formalization", "metadata")
        for field_name in dict_fields:
            if not isinstance(getattr(candidate, field_name), dict):
                raise ValueError(f"candidate.{field_name} must be an object")
        if candidate.new_perspective is not None and not isinstance(candidate.new_perspective, dict):
            raise ValueError("candidate.new_perspective must be an object or null")
        for field_name in ("candidate_id", "goal_id", "statement", "conclusion", "relation",
                           "proof_method", "proof_sketch", "status"):
            if not isinstance(getattr(candidate, field_name), str):
                raise ValueError(f"candidate.{field_name} must be a string")
        return candidate

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @property
    def statement_fingerprint(self) -> str:
        normalized = " ".join(self.statement.split())
        return stable_hash({"goal": self.goal_id, "statement": normalized, "hypotheses": sorted(self.hypotheses)}, 24)

    @property
    def structural_signature(self) -> str:
        return stable_hash({
            "relation": self.relation,
            "method": self.proof_method.lower().strip(),
            "obligations": sorted(self.proof_obligations),
            "concepts": sorted(x.lower() for x in self.new_concepts),
            "parents": sorted(self.parent_ids),
        }, 24)


@dataclass(frozen=True)
class GateVerdict:
    accepted: bool
    code: str
    reasons: tuple[str, ...] = ()
    novelty_distance: float | None = None
    novelty_axes: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        return {
            "accepted": self.accepted,
            "code": self.code,
            "reasons": list(self.reasons),
            "novelty_distance": self.novelty_distance,
            "novelty_axes": list(self.novelty_axes),
        }
