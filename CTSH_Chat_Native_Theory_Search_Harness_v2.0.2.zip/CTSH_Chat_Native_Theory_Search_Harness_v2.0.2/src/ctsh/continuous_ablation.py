from __future__ import annotations
from dataclasses import asdict, dataclass
from pathlib import Path
import json, platform
import numpy as np
from scipy.optimize import minimize_scalar
from .bo import BayesianBudgetController, BudgetMetrics, BudgetPolicy
from .perturb import LangevinParameterPerturber


def _double_well_energy(x: float) -> float:
    """A one-dimensional tilted double-well with a deceptive local minimum."""
    return float((x * x - 1.0) ** 2 + 0.4 * x)


def _double_well_gradient(x: float) -> float:
    return float(4.0 * x * (x * x - 1.0) + 0.4)


@dataclass
class ContinuousAblationRecord:
    arm: str
    seed: int
    budget: int
    best_energy: float
    best_parameter: float
    success: bool
    mean_langevin_probability: float
    applied_langevin_rate: float
    unique_policy_values: int


class ContinuousLangevinAblationRunner:
    """Equal-budget ablation for ULA and BO allocation on a differentiable objective.

    This is an optimizer-mechanics experiment only. It is not a theorem-search
    benchmark and does not imply that Langevin applies to discrete proof objects.
    """
    ARMS = ("gradient_only", "langevin_fixed", "langevin_bo")

    def __init__(self, budget: int = 180, seeds: int = 40,
                 step_size: float = 0.12, temperature: float = 0.45,
                 fixed_probability: float = 0.35):
        if budget < 1 or seeds < 2:
            raise ValueError("budget must be >=1 and seeds must be >=2")
        if not 0.0 <= fixed_probability <= 1.0:
            raise ValueError("fixed_probability must lie in [0,1]")
        self.budget, self.seeds = int(budget), int(seeds)
        self.step_size, self.temperature = float(step_size), float(temperature)
        self.fixed_probability = float(fixed_probability)
        minima = [minimize_scalar(_double_well_energy, bounds=b, method="bounded")
                  for b in ((-2.0, 0.0), (0.0, 2.0))]
        self.global_minimum = float(min(x.fun for x in minima))
        # Success means leaving the deceptive right-hand basin and reaching the
        # global basin to within a broad, predeclared energy tolerance.
        self.success_threshold = self.global_minimum + 0.22

    def _run_one(self, arm: str, seed: int) -> ContinuousAblationRecord:
        rng = np.random.default_rng(seed)
        perturb = LangevinParameterPerturber(
            step_size=self.step_size, temperature=self.temperature, seed=seed + 101
        )
        controller = BayesianBudgetController(
            seed=seed, min_observations=5,
            prior=BudgetPolicy(0.30, 0.60, 0.15, 0.10),
            active_dimensions=(2,),
        )
        x = 1.0  # Start in the deceptive right-hand local basin.
        best_x, best_e = x, _double_well_energy(x)
        probabilities: list[float] = []
        applied = 0

        for _ in range(self.budget):
            if arm == "gradient_only":
                probability = 0.0
            elif arm == "langevin_fixed":
                probability = self.fixed_probability
            elif arm == "langevin_bo":
                probability = controller.suggest().langevin_probability
            else:
                raise ValueError(f"unknown continuous ablation arm: {arm}")
            probabilities.append(probability)
            best_before = best_e

            if rng.random() < probability:
                result = perturb.step(
                    np.asarray([x], dtype=float),
                    lambda z: _double_well_energy(float(z[0])),
                    lambda z: np.asarray([_double_well_gradient(float(z[0]))]),
                    bounds=(np.asarray([-2.0]), np.asarray([2.0])),
                )
                x_next = float(result.value[0])
                applied += 1
            else:
                x_next = float(np.clip(x - self.step_size * _double_well_gradient(x), -2.0, 2.0))

            current_e = _double_well_energy(x_next)
            x = x_next  # ULA is a chain transition; the elite archive separately retains best.
            if current_e < best_e:
                best_e, best_x = current_e, x_next

            if arm == "langevin_bo":
                controller.observe(
                    BudgetPolicy(0.30, 0.60, probability, 0.10),
                    BudgetMetrics(
                        empirical_improvement=max(0.0, best_before - best_e) * 10.0,
                        evaluation_cost=0.0,
                    ),
                )

        return ContinuousAblationRecord(
            arm=arm, seed=seed, budget=self.budget, best_energy=best_e,
            best_parameter=best_x, success=best_e <= self.success_threshold,
            mean_langevin_probability=float(np.mean(probabilities)),
            applied_langevin_rate=applied / self.budget,
            unique_policy_values=len({round(x, 4) for x in probabilities}),
        )

    def run(self) -> dict:
        records = [self._run_one(arm, seed) for arm in self.ARMS for seed in range(self.seeds)]
        summary = {}
        for arm in self.ARMS:
            rows = [r for r in records if r.arm == arm]
            values = np.asarray([r.best_energy for r in rows], dtype=float)
            summary[arm] = {
                "n": len(rows), "mean_best_energy": float(values.mean()),
                "std_best_energy": float(values.std(ddof=1)),
                "successes": sum(r.success for r in rows),
                "success_rate": float(np.mean([r.success for r in rows])),
                "mean_langevin_probability": float(np.mean([r.mean_langevin_probability for r in rows])),
                "mean_applied_langevin_rate": float(np.mean([r.applied_langevin_rate for r in rows])),
                "mean_unique_policy_values": float(np.mean([r.unique_policy_values for r in rows])),
            }
        fixed = {r.seed: r for r in records if r.arm == "langevin_fixed"}
        bootstrap_rng = np.random.default_rng(20261104)
        paired = {}
        for arm in ("gradient_only", "langevin_bo"):
            diffs = np.asarray([r.best_energy - fixed[r.seed].best_energy
                                for r in records if r.arm == arm], dtype=float)
            draws = bootstrap_rng.choice(diffs, size=(5000, len(diffs)), replace=True).mean(axis=1)
            paired[arm] = {
                "mean_paired_energy_difference_vs_fixed": float(diffs.mean()),
                "bootstrap_95pct_ci": [float(np.quantile(draws, 0.025)),
                                        float(np.quantile(draws, 0.975))],
                "wins_lower_energy": int(np.sum(diffs < 0)),
                "losses_higher_energy": int(np.sum(diffs > 0)),
                "ties": int(np.sum(diffs == 0)),
            }
        from . import __version__
        return {
            "benchmark": "tilted_double_well_continuous", "package_version": __version__,
            "python_version": platform.python_version(), "numpy_version": np.__version__,
            "interpretation": "continuous ULA/BO mechanics only; not a theorem or proof-search benchmark",
            "budget_per_run": self.budget, "seeds": self.seeds,
            "objective": "E(x)=(x^2-1)^2 + 0.4 x; start x=+1 in the deceptive local basin",
            "gradient": "dE/dx=4x(x^2-1)+0.4",
            "global_minimum_numeric": self.global_minimum,
            "success_threshold": self.success_threshold,
            "step_size": self.step_size, "temperature": self.temperature,
            "fixed_langevin_probability": self.fixed_probability,
            "summary": summary, "paired_vs_langevin_fixed": paired,
            "records": [asdict(r) for r in records],
        }


def write_continuous_report(result: dict, output: str | Path):
    path = Path(output)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    md = path.with_suffix(".md")
    lines = [
        "# CTSH continuous Langevin ablation", "",
        f"Benchmark: `{result['benchmark']}`",
        f"Package: {result.get('package_version', 'unknown')}; Python: {result.get('python_version', 'unknown')}; NumPy: {result.get('numpy_version', 'unknown')}",
        f"Budget/run: {result['budget_per_run']}; seeds/arm: {result['seeds']}",
        f"Objective: `{result['objective']}`",
        f"Global minimum (numerically located): {result['global_minimum_numeric']:.6f}",
        f"Success threshold: {result['success_threshold']:.6f}",
        f"ULA step size/temperature: {result['step_size']} / {result['temperature']}", "",
        "| Arm | Mean best energy (lower is better) | SD | Successes | Mean BO Langevin p | Applied ULA rate | Unique policy values |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for arm, row in result["summary"].items():
        lines.append(
            f"| {arm} | {row['mean_best_energy']:.4f} | {row['std_best_energy']:.4f} | "
            f"{row['successes']}/{row['n']} | {row['mean_langevin_probability']:.3f} | "
            f"{row['mean_applied_langevin_rate']:.3f} | {row['mean_unique_policy_values']:.1f} |"
        )
    lines += ["", "## Paired comparisons against fixed-probability ULA", "",
              "| Arm | Mean paired energy Δ | Bootstrap 95% CI | Lower / higher / ties |",
              "|---|---:|---:|---:|"]
    for arm, row in result["paired_vs_langevin_fixed"].items():
        ci = row["bootstrap_95pct_ci"]
        lines.append(
            f"| {arm} | {row['mean_paired_energy_difference_vs_fixed']:.4f} | "
            f"[{ci[0]:.4f}, {ci[1]:.4f}] | {row['wins_lower_energy']} / "
            f"{row['losses_higher_energy']} / {row['ties']} |"
        )
    lines += ["", "This only tests a one-dimensional differentiable optimization toy problem. "
              "It does not demonstrate Langevin usefulness on theorem/proof graphs, and BO's policy result is problem- and budget-dependent."]
    md.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path, md
