from __future__ import annotations
from dataclasses import dataclass
from typing import Callable
from math import isfinite
import numpy as np

@dataclass
class LangevinResult:
    value: np.ndarray
    energy_before: float
    energy_after: float
    step_size: float
    temperature: float

class LangevinParameterPerturber:
    """Unadjusted Langevin (ULA) step on an explicitly continuous parameter space.

    x' = x - eta * grad(E(x)) + sqrt(2 eta T) * Normal(0,I).
    This is a stochastic optimizer/sampler step, not a theorem-space gradient.
    """
    def __init__(self, step_size: float = 0.01, temperature: float = 0.05, seed: int | None = None):
        if not isfinite(step_size) or not isfinite(temperature) or step_size <= 0 or temperature < 0:
            raise ValueError("step_size must be finite and >0; temperature must be finite and >=0")
        self.step_size, self.temperature = float(step_size), float(temperature)
        self.rng = np.random.default_rng(seed)

    def step(self, x: np.ndarray, energy: Callable[[np.ndarray], float],
             gradient: Callable[[np.ndarray], np.ndarray],
             bounds: tuple[np.ndarray, np.ndarray] | None = None) -> LangevinResult:
        x = np.asarray(x, dtype=float)
        g = np.asarray(gradient(x), dtype=float)
        if g.shape != x.shape or not np.all(np.isfinite(g)):
            raise ValueError("gradient must be finite and match parameter shape")
        before = float(energy(x))
        if not isfinite(before):
            raise ValueError("energy must be finite at the current state")
        noise = self.rng.normal(size=x.shape)
        proposal = x - self.step_size * g + np.sqrt(2.0 * self.step_size * self.temperature) * noise
        if bounds is not None:
            lo, hi = (np.asarray(bounds[0], dtype=float), np.asarray(bounds[1], dtype=float))
            if lo.shape != x.shape or hi.shape != x.shape or np.any(lo > hi) or np.any(np.isnan(lo)) or np.any(np.isnan(hi)):
                raise ValueError("invalid bounds")
            proposal = np.clip(proposal, lo, hi)
        after = float(energy(proposal))
        if not np.all(np.isfinite(proposal)) or not isfinite(after):
            raise ValueError("proposed parameters and energy must remain finite")
        return LangevinResult(proposal, before, after, self.step_size, self.temperature)

class TemperedMutationPerturber:
    """Metropolis mutation on a discrete state space; deliberately not called Langevin."""
    def __init__(self, temperature: float = 0.25, seed: int | None = None):
        if not isfinite(temperature) or temperature <= 0:
            raise ValueError("temperature must be finite and positive")
        self.temperature = float(temperature); self.rng = np.random.default_rng(seed)

    def step(self, state, propose: Callable[[object], object], energy: Callable[[object], float],
             symmetric_proposal: bool = True, reverse_over_forward: float = 1.0):
        if not symmetric_proposal and (not isfinite(reverse_over_forward) or reverse_over_forward <= 0):
            raise ValueError("proposal ratio must be finite and positive")
        proposal = propose(state)
        e0, e1 = float(energy(state)), float(energy(proposal))
        if not isfinite(e0) or not isfinite(e1):
            raise ValueError("energy must be finite for both current and proposed states")
        ratio = np.exp(np.clip(-(e1 - e0) / self.temperature, -700, 700))
        if not symmetric_proposal: ratio *= reverse_over_forward
        accept_prob = min(1.0, float(ratio))
        accepted = bool(self.rng.random() < accept_prob)
        return (proposal if accepted else state), {"accepted": accepted, "acceptance_probability": accept_prob,
                                                    "energy_before": e0, "energy_after": e1,
                                                    "proposal": proposal}
