from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from typing import Any
import json, os, tempfile
from .models import Candidate


class Workspace:
    """Append-only research workspace with replayable candidates and decisions."""
    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)
        self.goal_path = self.root / "goal.json"
        self.candidates_path = self.root / "candidates.jsonl"
        self.events_path = self.root / "events.jsonl"
        self.controller_path = self.root / "controller.json"
        self.search_graph_path = self.root / "search_graph.json"

    def initialize(self, goal: dict, config: dict | None = None):
        if self.goal_path.exists():
            raise FileExistsError(f"workspace already initialized: {self.root}")
        self._atomic_json(self.goal_path, goal)
        self._atomic_json(self.root / "config.json", config or {})
        self._append_event("WORKSPACE_INITIALIZED", {"goal_id": goal.get("goal_id")})

    def load_goal(self) -> dict:
        return json.loads(self.goal_path.read_text(encoding="utf-8"))

    def load_events(self) -> list[dict[str, Any]]:
        if not self.events_path.exists():
            return []
        rows = []
        for line_no, line in enumerate(self.events_path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"corrupt events.jsonl at line {line_no}: {exc}") from exc
        return rows

    def load_candidate_records(self) -> list[dict[str, Any]]:
        if not self.candidates_path.exists():
            return []
        rows = []
        for line_no, line in enumerate(self.candidates_path.read_text(encoding="utf-8").splitlines(), 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise RuntimeError(f"corrupt candidates.jsonl at line {line_no}: {exc}") from exc
        # Status changes are append-only events; overlay the latest status without
        # rewriting the original candidate or losing its original gate decision.
        latest_status: dict[str, str] = {}
        latest_evidence: dict[str, dict] = {}
        for event in self.load_events():
            if event.get("event") == "CANDIDATE_STATUS_UPDATED":
                payload = event.get("payload", {})
                cid = payload.get("candidate_id")
                latest_status[cid] = payload.get("status")
                latest_evidence[cid] = payload.get("evidence", {})
        for row in rows:
            candidate = row.get("candidate", {})
            cid = candidate.get("candidate_id")
            if cid in latest_status:
                candidate["status"] = latest_status[cid]
                candidate.setdefault("metadata", {})["status_evidence"] = latest_evidence.get(cid, {})
                if latest_status[cid] == "REFUTED":
                    candidate["metadata"]["refutation_evidence"] = latest_evidence.get(cid, {})
        return rows

    def accepted_candidates(self) -> list[Candidate]:
        accepted = []
        for row in self.load_candidate_records():
            if row.get("gate", {}).get("accepted") and row.get("candidate", {}).get("status") != "REFUTED":
                accepted.append(Candidate.from_dict(row["candidate"]))
        return accepted

    def refuted_fingerprints(self) -> dict[str, str]:
        refuted: dict[str, str] = {}
        for row in self.load_candidate_records():
            candidate = Candidate.from_dict(row["candidate"])
            if candidate.status == "REFUTED":
                refuted[candidate.statement_fingerprint] = candidate.candidate_id
        return refuted

    def add_candidate(self, candidate: Candidate, gate_verdict: dict):
        existing = {r.get("candidate", {}).get("candidate_id") for r in self.load_candidate_records()}
        if candidate.candidate_id in existing:
            raise ValueError(f"candidate_id already exists; mutations require a new ID: {candidate.candidate_id}")
        record = {"timestamp": datetime.now(timezone.utc).isoformat(),
                  "candidate": candidate.to_dict(), "gate": gate_verdict}
        self._append_jsonl(self.candidates_path, record)
        self._append_event("CANDIDATE_INGESTED", {"candidate_id": candidate.candidate_id,
                                                   "accepted": gate_verdict.get("accepted", False)})

    def record_candidate_evidence(self, candidate_id: str, evidence: dict):
        known = {r.get("candidate", {}).get("candidate_id") for r in self.load_candidate_records()}
        if candidate_id not in known:
            raise KeyError(f"unknown candidate_id: {candidate_id}")
        self._append_event("CANDIDATE_EVIDENCE_RECORDED", {"candidate_id": candidate_id, "evidence": evidence})

    def update_candidate_status(self, candidate_id: str, status: str, evidence: dict | None = None):
        records = self.load_candidate_records()
        rows = [r for r in records if r.get("candidate", {}).get("candidate_id") == candidate_id]
        if not rows:
            raise KeyError(f"unknown candidate_id: {candidate_id}")
        current = rows[-1].get("candidate", {}).get("status", "OPEN")
        terminal = {"REFUTED", "COUNTEREXAMPLE_FOUND"}
        if current in terminal and status != current:
            raise ValueError(f"terminal evidence status {current} cannot be overwritten; create a new candidate ID for a repair")
        self._append_event("CANDIDATE_STATUS_UPDATED", {
            "candidate_id": candidate_id, "status": status, "evidence": evidence or {}
        })

    def record_decision(self, decision_id: str, policy: dict, directive: dict):
        self._append_event("SEARCH_DECISION", {"decision_id": decision_id,
                                                "policy": policy, "directive": directive,
                                                "feedback_recorded": False})

    def find_decision(self, decision_id: str | None = None) -> dict:
        decisions = [e["payload"] for e in self.load_events() if e.get("event") == "SEARCH_DECISION"]
        feedback = {e.get("payload", {}).get("decision_id") for e in self.load_events()
                    if e.get("event") == "SEARCH_FEEDBACK"}
        decisions = [d for d in decisions if d.get("decision_id") not in feedback]
        if decision_id is not None:
            for item in reversed(decisions):
                if item.get("decision_id") == decision_id:
                    return item
            raise KeyError(f"unmatched or already-used decision_id: {decision_id}")
        if not decisions:
            raise KeyError("no unconsumed search decision is available")
        return decisions[-1]

    def record_feedback(self, decision_id: str, candidate_id: str, metrics: dict):
        self._append_event("SEARCH_FEEDBACK", {"decision_id": decision_id,
                                                "candidate_id": candidate_id, "metrics": metrics})

    def load_controller_state(self) -> dict | None:
        if not self.controller_path.exists():
            return None
        return json.loads(self.controller_path.read_text(encoding="utf-8"))

    def save_controller_state(self, state: dict):
        self._atomic_json(self.controller_path, state)

    def load_search_graph_state(self) -> dict | None:
        if not self.search_graph_path.exists():
            return None
        return json.loads(self.search_graph_path.read_text(encoding="utf-8"))

    def save_search_graph_state(self, state: dict):
        self._atomic_json(self.search_graph_path, state)

    def _append_event(self, event: str, payload: dict):
        self._append_jsonl(self.events_path, {"timestamp": datetime.now(timezone.utc).isoformat(),
                                               "event": event, "payload": payload})

    @staticmethod
    def _append_jsonl(path: Path, value: dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")
            f.flush(); os.fsync(f.fileno())

    @staticmethod
    def _atomic_json(path: Path, value: dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        data = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
        fd, tmp = tempfile.mkstemp(prefix=path.name, dir=path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(data); f.flush(); os.fsync(f.fileno())
            os.replace(tmp, path)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
