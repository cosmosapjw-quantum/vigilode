from __future__ import annotations
from dataclasses import dataclass, field, asdict
from math import log, sqrt, isfinite
from typing import Any
from collections import deque
from .models import Candidate, stable_hash


@dataclass
class ProofNode:
    candidate_id: str
    statement_fingerprint: str
    status: str = "OPEN"
    consumers: set[str] = field(default_factory=set)


@dataclass
class ProofRule:
    rule_id: str
    premises: tuple[str, ...]
    conclusion: str
    alternative_group: str
    kind: str = "AND"


class ProofDAG:
    """Proof dependency hypergraph, independent of MCTS transition statistics."""
    KERNEL_PROVED = {"KERNEL_CHECKED"}
    KERNEL_PROVED_WITH_DECLARED_AXIOMS = {"KERNEL_CHECKED", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS"}

    def __init__(self):
        self.nodes: dict[str, ProofNode] = {}
        self.rules: dict[str, ProofRule] = {}
        self._outgoing: dict[str, set[str]] = {}

    def add_candidate(self, candidate: Candidate) -> None:
        old = self.nodes.get(candidate.candidate_id)
        if old and old.statement_fingerprint != candidate.statement_fingerprint:
            raise ValueError("candidate ID collision with a different statement fingerprint")
        self.nodes.setdefault(candidate.candidate_id, ProofNode(
            candidate.candidate_id, candidate.statement_fingerprint, candidate.status
        ))

    def add_rule(self, premises: list[str], conclusion: str, rule_id: str,
                 alternative_group: str | None = None) -> ProofRule:
        if rule_id in self.rules:
            raise ValueError(f"duplicate proof rule id: {rule_id}")
        if conclusion not in self.nodes or any(p not in self.nodes for p in premises):
            raise KeyError("all premise and conclusion nodes must exist before adding a rule")
        if len(set(premises)) != len(premises):
            raise ValueError("duplicate premise in proof rule")
        if conclusion in premises:
            raise ValueError("self-dependent proof rule")
        rule = ProofRule(rule_id, tuple(premises), conclusion, alternative_group or rule_id)
        adjacency = {k: set(v) for k, v in self._outgoing.items()}
        for premise in premises:
            adjacency.setdefault(premise, set()).add(conclusion)

        def reaches(start: str, target: str) -> bool:
            stack, seen = [start], set()
            while stack:
                node = stack.pop()
                if node == target:
                    return True
                if node in seen:
                    continue
                seen.add(node)
                stack.extend(adjacency.get(node, ()))
            return False

        if any(reaches(conclusion, premise) for premise in premises):
            raise ValueError("proof dependency cycle")
        self.rules[rule_id] = rule
        self._outgoing = adjacency
        for premise in premises:
            self.nodes[premise].consumers.add(conclusion)
        return rule

    def mark_status(self, candidate_id: str, status: str) -> None:
        self.nodes[candidate_id].status = status

    def usable_rules(self, *, allow_declared_standard_axioms: bool = False) -> list[ProofRule]:
        """Return rules whose premises have actual kernel proof certificates.

        Symbolic simplification and informal/chat derivation are deliberately not
        accepted as proof of arbitrary premise propositions.
        """
        accepted = (self.KERNEL_PROVED_WITH_DECLARED_AXIOMS if allow_declared_standard_axioms
                    else self.KERNEL_PROVED)
        return [rule for rule in self.rules.values()
                if self.nodes[rule.conclusion].status in accepted
                and all(self.nodes[p].status in accepted for p in rule.premises)]

    def downstream_value(self, candidate_id: str, cap: float = 3.0) -> float:
        return min(cap, 1.0 + log(1 + len(self.nodes[candidate_id].consumers)))


@dataclass
class SearchEdge:
    action: str
    child_key: str
    prior: float = 1.0
    visits: int = 0
    value_sum: float = 0.0

    @property
    def q(self) -> float:
        return self.value_sum / self.visits if self.visits else 0.0


@dataclass
class SearchStateNode:
    key: str
    payload: dict[str, Any]
    visits: int = 0
    value_sum: float = 0.0
    edges: dict[str, SearchEdge] = field(default_factory=dict)
    parents: set[str] = field(default_factory=set)
    expanded: bool = False

    @property
    def value(self) -> float:
        return self.value_sum / self.visits if self.visits else 0.0


class MCTSSearchGraph:
    """Transposition-aware UCT/PUCT graph with edge-local action statistics."""
    def __init__(self, exploration_constant: float = 1.25):
        if exploration_constant < 0:
            raise ValueError("exploration_constant must be non-negative")
        self.c = float(exploration_constant)
        self.nodes: dict[str, SearchStateNode] = {}

    def add_state(self, payload: dict[str, Any]) -> str:
        key = stable_hash(payload, 24)
        self.nodes.setdefault(key, SearchStateNode(key, dict(payload)))
        return key

    def add_transition(self, parent_key: str, action: str, child_payload: dict[str, Any], prior: float = 1.0) -> str:
        if parent_key not in self.nodes:
            raise KeyError(parent_key)
        if not isfinite(float(prior)) or prior <= 0:
            raise ValueError("prior must be finite and positive")
        child_key = self.add_state(child_payload)
        parent = self.nodes[parent_key]
        existing = parent.edges.get(action)
        if existing and existing.child_key != child_key:
            raise ValueError("an action label cannot point to two different child states")
        parent.edges.setdefault(action, SearchEdge(action, child_key, float(prior)))
        self.nodes[child_key].parents.add(parent_key)
        parent.expanded = True
        return child_key

    def select_path(self, root_key: str) -> tuple[list[str], list[tuple[str, str]]]:
        if root_key not in self.nodes:
            raise KeyError(root_key)
        node_key = root_key
        node_path, edge_path = [root_key], []
        visited = set()
        while True:
            if node_key in visited:
                break
            visited.add(node_key)
            node = self.nodes[node_key]
            if not node.edges:
                break
            total = max(1, node.visits)

            def score(edge: SearchEdge) -> float:
                return edge.q + self.c * edge.prior * sqrt(log(total + 1) / (edge.visits + 1))

            action, edge = max(node.edges.items(), key=lambda item: score(item[1]))
            edge_path.append((node_key, action))
            node_key = edge.child_key
            node_path.append(node_key)
            if not self.nodes[node_key].edges:
                break
        return node_path, edge_path

    def path_to(self, root_key: str, target_key: str) -> tuple[list[str], list[tuple[str, str]]]:
        """Find a deterministic lowest-visit parent path to a shared transposition."""
        if root_key not in self.nodes or target_key not in self.nodes:
            raise KeyError("root or target state is not in search graph")
        queue = deque([(target_key, [target_key], [])])
        seen = {target_key}
        while queue:
            current, reverse_nodes, reverse_edges = queue.popleft()
            if current == root_key:
                return list(reversed(reverse_nodes)), list(reversed(reverse_edges))
            options = []
            for parent_key in self.nodes[current].parents:
                parent = self.nodes[parent_key]
                for action, edge in parent.edges.items():
                    if edge.child_key == current:
                        options.append((edge.visits, parent_key, action))
            for _, parent_key, action in sorted(options):
                if parent_key not in seen:
                    seen.add(parent_key)
                    queue.append((parent_key, reverse_nodes + [parent_key], reverse_edges + [(parent_key, action)]))
        raise ValueError("target state is not reachable from root")

    def backpropagate(self, node_path: list[str], edge_path: list[tuple[str, str]], reward: float) -> None:
        if not isfinite(float(reward)):
            raise ValueError("reward must be finite")
        for key in set(node_path):
            node = self.nodes[key]
            node.visits += 1
            node.value_sum += float(reward)
        for parent_key, action in edge_path:
            edge = self.nodes[parent_key].edges[action]
            edge.visits += 1
            edge.value_sum += float(reward)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 1,
            "exploration_constant": self.c,
            "nodes": {
                key: {
                    "key": node.key, "payload": node.payload, "visits": node.visits,
                    "value_sum": node.value_sum, "expanded": node.expanded,
                    "parents": sorted(node.parents),
                    "edges": {action: asdict(edge) for action, edge in node.edges.items()},
                } for key, node in self.nodes.items()
            },
        }

    @classmethod
    def from_dict(cls, state: dict[str, Any]) -> "MCTSSearchGraph":
        if state.get("schema_version") != 1:
            raise ValueError("unsupported MCTS graph state schema")
        graph = cls(float(state.get("exploration_constant", 1.25)))
        for key, raw in state.get("nodes", {}).items():
            node = SearchStateNode(key=key, payload=dict(raw["payload"]),
                                   visits=int(raw.get("visits", 0)),
                                   value_sum=float(raw.get("value_sum", 0.0)),
                                   parents=set(raw.get("parents", [])),
                                   expanded=bool(raw.get("expanded", False)))
            node.edges = {action: SearchEdge(**edge) for action, edge in raw.get("edges", {}).items()}
            graph.nodes[key] = node
        for key, node in graph.nodes.items():
            for edge in node.edges.values():
                if edge.child_key not in graph.nodes:
                    raise ValueError(f"MCTS graph edge from {key} points to missing child {edge.child_key}")
        return graph
