from __future__ import annotations
from dataclasses import dataclass, asdict
from math import erf, exp, pi, sqrt
from typing import Any
import numpy as np
from scipy.linalg import cho_factor, cho_solve, solve_triangular
from scipy.stats import qmc

@dataclass(frozen=True)
class BudgetPolicy:
    exploration_share: float = 0.30
    mcts_share: float = 0.60
    langevin_probability: float = 0.15
    tempered_mutation_probability: float = 0.10

    def __post_init__(self):
        for name, value in asdict(self).items():
            if not 0.0 <= value <= 1.0: raise ValueError(f"{name} must be in [0,1]")

    def vector(self) -> np.ndarray:
        return np.asarray([self.exploration_share, self.mcts_share, self.langevin_probability,
                           self.tempered_mutation_probability], dtype=float)

    @classmethod
    def from_vector(cls, v):
        v = np.asarray(v, dtype=float)
        return cls(*map(float, np.clip(v, 0.0, 1.0)))

@dataclass
class BudgetMetrics:
    verified_lemmas: int = 0
    valid_counterexamples: int = 0
    obligations_closed: int = 0
    novelty_gain: float = 0.0
    duplicate_rate: float = 0.0
    rejected_mutations: int = 0
    scope_violations: int = 0
    evaluation_cost: float = 0.0
    empirical_improvement: float = 0.0

    def progress_utility(self) -> float:
        # Proxy for allocating search effort, never a probability of truth.
        return (2.0 * self.verified_lemmas + 1.5 * self.valid_counterexamples
                + 0.20 * self.obligations_closed + 0.25 * self.novelty_gain
                + 0.10 * self.empirical_improvement - 0.50 * self.duplicate_rate
                - 0.15 * self.rejected_mutations - 2.0 * self.scope_violations
                - 0.01 * max(0.0, self.evaluation_cost))

class _Matern52GP:
    def __init__(self, lengthscale: float = 0.28, noise: float = 1e-5):
        self.lengthscale, self.noise = float(lengthscale), float(noise)
        self.x = self.y = self.alpha = self.chol = None
        self.y_mean, self.y_scale = 0.0, 1.0

    def _kernel(self, a, b):
        a, b = np.atleast_2d(a), np.atleast_2d(b)
        d = np.sqrt(np.maximum(0.0, ((a[:, None, :] - b[None, :, :]) ** 2).sum(axis=2)))
        r = np.sqrt(5.0) * d / self.lengthscale
        return (1.0 + r + r * r / 3.0) * np.exp(-r)

    def fit(self, x, y):
        self.x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
        self.y_mean = float(y.mean()); self.y_scale = float(y.std()) or 1.0
        self.y = (y - self.y_mean) / self.y_scale
        k = self._kernel(self.x, self.x)
        jitter = self.noise
        for _ in range(7):
            try:
                self.chol = cho_factor(k + jitter * np.eye(len(k)), lower=True, check_finite=True)
                break
            except np.linalg.LinAlgError:
                jitter *= 10
        else: raise np.linalg.LinAlgError("GP covariance remained singular after jitter escalation")
        self.alpha = cho_solve(self.chol, self.y)
        return self

    def predict(self, x):
        x = np.atleast_2d(np.asarray(x, dtype=float))
        kx = self._kernel(self.x, x)
        mu = kx.T @ self.alpha
        v = solve_triangular(self.chol[0], kx, lower=True, check_finite=False)
        var = np.maximum(1e-12, 1.0 - np.sum(v * v, axis=0))
        return self.y_mean + self.y_scale * mu, self.y_scale * np.sqrt(var)


def _norm_pdf(z): return np.exp(-0.5 * z * z) / sqrt(2.0 * pi)
def _norm_cdf(z): return 0.5 * (1.0 + np.vectorize(erf)(z / sqrt(2.0)))

class BayesianBudgetController:
    """BO over policy controls, trained only on observed search-progress records.

    It controls exploration/exploitation mix, MCTS/GA mix, and perturbation rate.
    It never assigns a truth probability to a theorem or proof obligation.
    """
    def __init__(self, seed: int = 0, min_observations: int = 5, candidate_count: int = 256,
                 xi: float = 0.02, prior: BudgetPolicy | None = None,
                 active_dimensions: tuple[int, ...] | None = None):
        self.rng = np.random.default_rng(seed)
        self.min_observations, self.candidate_count, self.xi = min_observations, candidate_count, xi
        # No continuous parameterization is assumed by default. The caller must
        # explicitly opt in to BO control of Langevin probability (dimension 2).
        self.prior = prior or BudgetPolicy(langevin_probability=0.0)
        self.active_dimensions = tuple(active_dimensions if active_dimensions is not None else (0, 1, 3))
        if not self.active_dimensions or len(set(self.active_dimensions)) != len(self.active_dimensions) or any(i not in range(4) for i in self.active_dimensions):
            raise ValueError("active_dimensions must be a non-empty unique subset of {0,1,2,3}")
        self.policies: list[BudgetPolicy] = []
        self.metrics: list[BudgetMetrics] = []
        self.utilities: list[float] = []
        self.last_acquisition: dict[str, float] = {}

    def observe(self, policy: BudgetPolicy, metrics: BudgetMetrics) -> float:
        self.policies.append(policy); self.metrics.append(metrics)
        y = metrics.progress_utility(); self.utilities.append(y)
        return y

    def suggest(self) -> BudgetPolicy:
        if len(self.policies) < self.min_observations:
            # A deterministic space-filling warm-up, not a claimed posterior estimate.
            k = len(self.policies)
            warm = [
                BudgetPolicy(0.20, 0.75, 0.05, 0.05),
                BudgetPolicy(0.70, 0.30, 0.35, 0.30),
                BudgetPolicy(0.45, 0.50, 0.20, 0.20),
                BudgetPolicy(0.80, 0.70, 0.10, 0.45),
                BudgetPolicy(0.25, 0.25, 0.45, 0.10),
            ]
            base = self.prior.vector()
            warm_vector = warm[k % len(warm)].vector()
            base[list(self.active_dimensions)] = warm_vector[list(self.active_dimensions)]
            return BudgetPolicy.from_vector(base)
        x_all = np.vstack([p.vector() for p in self.policies])
        x = x_all[:, self.active_dimensions]
        y = np.asarray(self.utilities, dtype=float)
        gp = _Matern52GP().fit(x, y)
        sampler = qmc.Sobol(d=len(self.active_dimensions), scramble=True,
                            seed=int(self.rng.integers(0, 2**31 - 1)))
        raw = sampler.random(self.candidate_count)
        # Coordinate-specific bounds; inactive coordinates remain at the prior.
        lo_all = np.array([0.10, 0.15, 0.00, 0.00])
        hi_all = np.array([0.90, 0.85, 0.55, 0.55])
        dims = list(self.active_dimensions)
        candidates = lo_all[dims] + raw * (hi_all[dims] - lo_all[dims])
        mu, sigma = gp.predict(candidates)
        best = float(np.max(y)); z = (mu - best - self.xi) / sigma
        ei = (mu - best - self.xi) * _norm_cdf(z) + sigma * _norm_pdf(z)
        idx = int(np.argmax(ei))
        self.last_acquisition = {"expected_improvement": float(ei[idx]), "posterior_mean": float(mu[idx]),
                                 "posterior_std": float(sigma[idx]), "observations": len(y)}
        full = self.prior.vector()
        full[dims] = candidates[idx]
        return BudgetPolicy.from_vector(full)

    def state_dict(self) -> dict[str, Any]:
        return {
            "schema_version": 2,
            "min_observations": self.min_observations,
            "candidate_count": self.candidate_count,
            "xi": self.xi,
            "prior": asdict(self.prior),
            "active_dimensions": list(self.active_dimensions),
            "policies": [asdict(p) for p in self.policies],
            "metrics": [asdict(m) for m in self.metrics],
            "utilities": list(self.utilities),
            "rng_state": self.rng.bit_generator.state,
            "last_acquisition": self.last_acquisition,
        }

    @classmethod
    def from_state_dict(cls, state: dict[str, Any], seed: int = 0) -> "BayesianBudgetController":
        if state.get("schema_version") not in {1, 2}:
            raise ValueError("unsupported BO controller state schema")
        prior_data = dict(state["prior"])
        prior_data.setdefault("tempered_mutation_probability", 0.10)
        obj = cls(seed=seed, min_observations=int(state["min_observations"]),
                  candidate_count=int(state["candidate_count"]), xi=float(state["xi"]),
                  prior=BudgetPolicy(**prior_data),
                  active_dimensions=tuple(state.get("active_dimensions", (0, 1, 2, 3))))
        obj.policies = []
        for raw_policy in state.get("policies", []):
            migrated = dict(raw_policy)
            migrated.setdefault("tempered_mutation_probability", 0.10)
            obj.policies.append(BudgetPolicy(**migrated))
        obj.metrics = [BudgetMetrics(**x) for x in state.get("metrics", [])]
        obj.utilities = [float(x) for x in state.get("utilities", [])]
        if not (len(obj.policies) == len(obj.metrics) == len(obj.utilities)):
            raise ValueError("inconsistent BO history lengths")
        if "rng_state" in state:
            obj.rng.bit_generator.state = state["rng_state"]
        obj.last_acquisition = dict(state.get("last_acquisition", {}))
        return obj

    def choose(self, rng: np.random.Generator, policy: BudgetPolicy | None = None) -> dict[str, Any]:
        p = policy or self.suggest()
        explore = bool(rng.random() < p.exploration_share)
        engine = "MCTS" if rng.random() < p.mcts_share else "GA"
        apply_langevin = bool(rng.random() < p.langevin_probability)
        apply_tempered = bool(rng.random() < p.tempered_mutation_probability)
        return {"phase": "EXPLORE" if explore else "EXPLOIT", "proposal_engine": engine,
                "apply_langevin": apply_langevin,
                "apply_discrete_tempering": apply_tempered,
                "policy": asdict(p)}
