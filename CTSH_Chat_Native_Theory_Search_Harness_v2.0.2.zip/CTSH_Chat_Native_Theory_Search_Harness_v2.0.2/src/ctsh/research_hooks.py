"""Prompt hooks that increase search breadth without relaxing the goal lock."""

CORE_HOOKS = {
    "OFF_POOL_THEORY_LENS": "Propose at least one mathematically substantive theory or technique not present in the current candidate pool. Name its exact principle, preconditions, and a concrete bridge lemma to the locked goal. A metaphor or name-drop is not enough.",
    "PROOF_METHOD_DIVERSITY": "Attempt a proof route whose method family differs from those already in the pool (e.g. invariant/energy estimate, compactness, spectral argument, algebraic factorization, duality, geometric reformulation, induction, contradiction, construction). State the new obligations created.",
    "NONTRIVIALITY_AUDIT": "Explain the first genuinely nontrivial inference. Identify why the statement is not merely a restatement, tautology, notation change, or consequence of an unexamined hidden assumption.",
    "BRIDGE_BACK_TO_GOAL": "Map every imported concept to a specific locked target term or open proof obligation. If no explicit derivation chain exists, mark the proposal OUT_OF_SCOPE rather than forcing a superficial connection.",
    "LEMMA_REUSE": "Inspect the proof dependency DAG and reuse compatible proved lemmas. Check all hypotheses, types, domains, conventions, and versions at the consumer site.",
    "PROOF_REPAIR": "Repair the failed proof locally while keeping the theorem statement and axiom context fixed. If a hypothesis or statement must change, create a new claim ID and preserve the original result.",
    "LOCAL_OBLIGATION_CLOSURE": "Choose one frontier obligation with the best combination of downstream relevance, tractability evidence, and cost. Do not infer truth probability from search scores.",
    "GOAL_LOCK": "Keep the exact target, quantifiers, domain, definitions, fixed hypotheses, and requested conclusion unchanged. Supporting lemmas must state an explicit bridge to the goal.",
    "HYPOTHESIS_PRESERVATION": "Do not silently add assumptions or strengthen the theorem. Every auxiliary assumption must be explicitly declared and discharged as a separate obligation.",
    "MUTATION_SCHEMA": "Return mutations as typed JSON with operator, parent IDs, changed fields, new obligations, proof method, bridge mapping, and expected gain. No free-form mutation bypasses the gate.",
    "NOVELTY_ARCHIVE": "Compare statement structure, proof method, dependency pattern, and concept tags with the archive. Similarity is a retrieval heuristic, not an equivalence proof.",
    "CONTINUOUS_PARAMETER_LANGEVIN": "Perturb only explicitly continuous parameters with a defined differentiable energy and gradient. Do not invent gradients on theorem text or discrete proof graphs.",
    "DISCRETE_TEMPERED_MUTATION": "For discrete theorem/proof structures, use a declared typed mutation proposal with an explicit forward/reverse proposal ratio and Metropolis temperature. Record proposal and acceptance separately; never label this a Langevin gradient.",
}


def render_hooks(names: list[str]) -> str:
    missing = [n for n in names if n not in CORE_HOOKS]
    if missing: raise KeyError(f"unknown hooks: {missing}")
    return "\n\n".join(f"### {n}\n{CORE_HOOKS[n]}" for n in names)
