"""CTSH: Chat-native Mathematical Theory Search Harness."""
__version__ = "2.0.2"

from .models import Candidate, GoalContract, GateVerdict, VerificationStatus
from .gates import GoalMutationGate, NoveltyArchive
from .bo import BayesianBudgetController, BudgetMetrics, BudgetPolicy

__all__ = [
    "Candidate", "GoalContract", "GateVerdict", "VerificationStatus",
    "GoalMutationGate", "NoveltyArchive", "BayesianBudgetController",
    "BudgetMetrics", "BudgetPolicy", "__version__",
]
