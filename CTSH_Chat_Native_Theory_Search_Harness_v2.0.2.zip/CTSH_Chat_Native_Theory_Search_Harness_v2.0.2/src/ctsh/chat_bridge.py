from __future__ import annotations
import json
from dataclasses import asdict
from pathlib import Path
from .models import Candidate, GoalContract
from .engines import SearchDirective
from .research_hooks import render_hooks

CANDIDATE_REQUIRED = {
    "candidate_id", "goal_id", "statement", "hypotheses", "conclusion", "relation",
    "mutation", "proof_method", "proof_sketch", "proof_obligations", "mapping_to_goal",
}

def build_chat_prompt(goal: GoalContract, directive: SearchDirective, pool_summary: dict | None = None) -> str:
    pool_summary = pool_summary or {}
    phase_text = ("DIVERGENT EXPLORATION: deliberately search outside the current pool, require a new theory lens or proof-method family, and keep the bridge to the original goal explicit."
                  if directive.phase == "EXPLORE" else
                  "CONVERGENT EXPLOITATION: repair the strongest open obligations, compose compatible proved lemmas, and reduce proof debt without changing the locked target.")
    return f"""# CTSH candidate-generation request

You are the proposal engine inside CTSH. Do not claim that a proposition is proved merely because you generated it. The local Python gate and optional Lean/Wolfram backends will evaluate the structured proposal.

## Immutable goal contract
- goal_id: `{goal.goal_id}`
- target: {goal.statement}
- mode/domain: {goal.mode} / {goal.domain}
- fixed hypotheses: {json.dumps(list(goal.hypotheses), ensure_ascii=False)}
- target terms: {json.dumps(list(goal.target_terms), ensure_ascii=False)}
- required obligations: {json.dumps(list(goal.required_obligations), ensure_ascii=False)}
- forbidden scope tags: {json.dumps(list(goal.forbidden_scope_tags), ensure_ascii=False)}
- direct_target rule: reproduce the exact locked statement and exact fixed-hypothesis set. A different statement must be a supporting lemma/bridge result with an explicit mapping; if target reformulation was explicitly authorized, add a dedicated equivalence obligation.
- initial status: always `OPEN`. Never self-assign SYMBOLICALLY_CHECKED, KERNEL_CHECKED, REFUTED, or any other evidential status.

## Current search directive
- decision_id: `{pool_summary.get('decision_id', 'NOT_ASSIGNED')}` (use this exact ID when recording feedback)
- phase: {directive.phase}
- proposal engine: {directive.proposal_engine}
- perturb continuous parameters with Langevin dynamics: {directive.apply_langevin}
- perturb discrete structures with Metropolis tempering: {directive.apply_discrete_tempering}
- parent candidates: {json.dumps(directive.parent_candidate_ids)}
- search state: `{directive.selected_state_key}`

{phase_text}

## Existing pool summary
{json.dumps(pool_summary, ensure_ascii=False, indent=2)}

Do not re-propose an archived refuted statement as a positive claim. Reuse accepted
kernel-checked lemmas only when their full hypotheses and axiom dependencies fit.
A symbolic simplification or an informal chat derivation is not a formal proof.

## Required hooks
{render_hooks(directive.required_hooks)}

## Output contract
Return JSON object(s), not prose, using exactly these fields where applicable:
```json
{{
  "candidate_id": "CLM-...",
  "goal_id": "{goal.goal_id}",
  "statement": "precise mathematical statement",
  "hypotheses": [],
  "conclusion": "exact conclusion",
  "relation": "direct_target | supporting_lemma | bridge_result | counterexample | method_idea",
  "mutation": {{"operator": "DIRECT_DERIVATION", "parent_claim_ids": [], "changed_fields": ["statement", "proof_obligations"], "expected_gain": "...", "derivation_witness": "..."}},
  "proof_method": "named proof-method family",
  "proof_sketch": "nontrivial derivation outline with explicit steps",
  "proof_obligations": [],
  "mapping_to_goal": ["specific goal term or obligation -> bridge step"],
  "scope_tags": [],
  "new_concepts": [],
  "new_perspective": {{"theory": "only for exploration", "principle": "...", "bridge_to_goal": ["..."]}},
  "assumption_discharge_obligations": [],
  "nontriviality": {{"why_nontrivial": "...", "distinguishing_step": "...", "self_assessed_trivial": false}},
  "formalization": {{}},
  "status": "OPEN",
  "parent_ids": [],
  "metadata": {{"counterexample_witness": null, "hypotheses_satisfied": false, "reproduction": ""}}
}}
```
For `relation: counterexample`, use `COUNTEREXAMPLE_SEARCH`, declare exactly one target parent, and replace the metadata fields with a concrete witness, `hypotheses_satisfied: true` only after checking every locked hypothesis, and a reproducible evaluation/derivation. A mere proposed point without the hypothesis check is not a counterexample. For `COUNTEREXAMPLE_REPAIR`, cite the archived REFUTED claim in `counterexample_response.refuted_claim_ids`; do not use its conclusion as a true premise. No hidden assumptions. `parent_ids` and `mutation.parent_claim_ids` must be identical. No operator may omit its required witness. If a proposal cannot meet the scope bridge, return `OUT_OF_SCOPE` with the reason instead of weakening the goal. Separate new conjectures from established lemmas. Return at most 3 candidates per turn, each genuinely distinct.
"""

def load_candidate(path: str | Path) -> Candidate:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if not CANDIDATE_REQUIRED.issubset(data):
        raise ValueError(f"candidate JSON missing fields: {sorted(CANDIDATE_REQUIRED - set(data))}")
    return Candidate.from_dict(data)
