from __future__ import annotations
import argparse, json, os, shutil, subprocess, sys, uuid
from dataclasses import asdict
from pathlib import Path
from . import __version__
from .models import Candidate, GoalContract
from .gates import GoalMutationGate, NoveltyArchive
from .store import Workspace
from .chat_bridge import build_chat_prompt, load_candidate
from .engines import SearchCoordinator
from .graph import MCTSSearchGraph, ProofDAG
from .bo import BayesianBudgetController, BudgetMetrics, BudgetPolicy
from .ablation import AblationRunner, write_report
from .continuous_ablation import ContinuousLangevinAblationRunner, write_continuous_report
from .backends import LeanBackend, WolframBackend


def _candidate_state_payload(candidate: Candidate) -> dict:
    return {"kind": "candidate", "goal_id": candidate.goal_id,
            "candidate_id": candidate.candidate_id,
            "open_obligations": list(candidate.proof_obligations),
            "relation": candidate.relation}


def _insert_candidate_graph_node(ws: Workspace, goal: GoalContract, candidate: Candidate):
    state = ws.load_search_graph_state()
    graph = MCTSSearchGraph.from_dict(state) if state else MCTSSearchGraph()
    root_payload = {"kind": "goal_root", "goal_id": goal.goal_id,
                    "open_obligations": list(goal.required_obligations)}
    root_key = graph.add_state(root_payload)
    child_payload = _candidate_state_payload(candidate)
    child_key = graph.add_state(child_payload)
    parent_ids = list(dict.fromkeys(candidate.parent_ids or candidate.mutation.get("parent_claim_ids", [])))
    parent_keys = [k for k, node in graph.nodes.items() if node.payload.get("candidate_id") in parent_ids]
    if not parent_keys:
        parent_keys = [root_key]
    action = f"{candidate.relation}:{candidate.mutation.get('operator','UNKNOWN')}:{candidate.candidate_id}"
    for parent_key in parent_keys:
        graph.add_transition(parent_key, action, child_payload, prior=1.0)
    ws.save_search_graph_state(graph.to_dict())
    return graph, root_key, child_key


def _load_pool_and_graph(ws: Workspace, goal: GoalContract):
    records = ws.load_candidate_records()
    accepted = [Candidate.from_dict(r["candidate"]) for r in records
                if r.get("gate", {}).get("accepted") and r.get("candidate", {}).get("status") != "REFUTED"]
    root_payload = {"kind": "goal_root", "goal_id": goal.goal_id,
                    "open_obligations": list(goal.required_obligations)}
    stored = ws.load_search_graph_state()
    graph = MCTSSearchGraph.from_dict(stored) if stored else MCTSSearchGraph()
    root_key = graph.add_state(root_payload)
    keys = {}
    for candidate in accepted:
        payload = _candidate_state_payload(candidate)
        keys[candidate.candidate_id] = graph.add_state(payload)
    known = set(keys)
    proof_dag = ProofDAG()
    for candidate in accepted:
        proof_dag.add_candidate(candidate)
    for candidate in accepted:
        parent_ids = list(dict.fromkeys(candidate.parent_ids or candidate.mutation.get("parent_claim_ids", [])))
        if parent_ids and all(parent_id in proof_dag.nodes for parent_id in parent_ids):
            try:
                proof_dag.add_rule(parent_ids, candidate.candidate_id,
                                   f"rule:{candidate.candidate_id}")
            except ValueError:
                # Preserve the candidates but do not manufacture a dependency edge
                # when the declared proof DAG would be cyclic.
                pass
    for candidate in accepted:
        child = keys[candidate.candidate_id]
        parents = list(dict.fromkeys(candidate.parent_ids or candidate.mutation.get("parent_claim_ids", [])))
        parent_keys = [keys[x] for x in parents if x in known]
        if not parent_keys:
            parent_keys = [root_key]
        action = f"{candidate.relation}:{candidate.mutation.get('operator','UNKNOWN')}:{candidate.candidate_id}"
        for parent_key in parent_keys:
            graph.add_transition(parent_key, action, graph.nodes[child].payload, prior=1.0)
    ws.save_search_graph_state(graph.to_dict())
    return records, accepted, graph, root_key, proof_dag


def cmd_init(args):
    ws = Workspace(args.workspace)
    goal = GoalContract(
        goal_id=args.goal_id, statement=args.goal, mode=args.mode, domain=args.domain,
        hypotheses=tuple(args.hypothesis or []), target_terms=tuple(args.target_term or []),
        required_obligations=tuple(args.required_obligation or []),
        forbidden_scope_tags=tuple(args.forbidden_scope_tag or []),
        pool_theories=tuple(args.pool_theory or []), pool_methods=tuple(args.pool_method or []),
        allowed_auxiliary_assumptions=tuple(args.allowed_auxiliary_assumption or []),
        max_new_assumptions=args.max_new_assumptions,
        allow_target_reformulation=args.allow_target_reformulation,
    ).to_dict()
    ws.initialize(goal, {"schema_version": 2, "seed": args.seed, "strict_mutation_gate": True,
                         "continuous_parameter_space_enabled": bool(args.enable_langevin)})
    if args.enable_langevin:
        prior = BudgetPolicy(langevin_probability=0.15)
        controller = BayesianBudgetController(seed=args.seed, prior=prior, active_dimensions=(0, 1, 2, 3))
    else:
        prior = BudgetPolicy(langevin_probability=0.0)
        controller = BayesianBudgetController(seed=args.seed, prior=prior, active_dimensions=(0, 1, 3))
    ws.save_controller_state(controller.state_dict())
    print(f"Initialized CTSH workspace: {ws.root}")


def cmd_prompt(args):
    ws = Workspace(args.workspace)
    goal = GoalContract.from_dict(ws.load_goal())
    records, accepted, graph, root, proof_dag = _load_pool_and_graph(ws, goal)
    controller_state = ws.load_controller_state()
    controller = (BayesianBudgetController.from_state_dict(controller_state, seed=args.seed)
                  if controller_state else BayesianBudgetController(seed=args.seed))
    coordinator = SearchCoordinator(controller, graph, seed=args.seed + len(records) + len(ws.load_events()))
    directive = coordinator.next_directive(root, [c.candidate_id for c in accepted])
    decision_id = uuid.uuid4().hex[:12]
    pool_entries = []
    for candidate in accepted[-args.pool_limit:]:
        pool_entries.append({
            "candidate_id": candidate.candidate_id,
            "statement": candidate.statement,
            "conclusion": candidate.conclusion,
            "relation": candidate.relation,
            "proof_method": candidate.proof_method,
            "proof_obligations": candidate.proof_obligations,
            "new_concepts": candidate.new_concepts,
            "status": candidate.status,
        })
    refuted_entries = []
    for row in records:
        c = row.get("candidate", {})
        if c.get("status") == "REFUTED":
            refuted_entries.append({"candidate_id": c.get("candidate_id"),
                                    "statement": c.get("statement"),
                                    "evidence": c.get("metadata", {}).get("refutation_evidence", {})})
    pool_summary = {
        "decision_id": decision_id,
        "pool_size": len(accepted),
        "accepted_candidates": pool_entries,
        "refuted_claims": refuted_entries[-10:],
        "known_theories": sorted(set(goal.pool_theories) | {
            str(c.new_perspective.get("theory")) for c in accepted if c.new_perspective and c.new_perspective.get("theory")
        }),
        "known_proof_methods": sorted(set(goal.pool_methods) | {c.proof_method for c in accepted}),
        "bo_observations": len(controller.policies),
        "kernel_checked_lemma_ids": [c.candidate_id for c in accepted if c.status == "KERNEL_CHECKED"],
        "reusable_proof_rule_count": len(proof_dag.usable_rules()),
        "note": "Pool/archive, proof dependency DAG and BO state are reconstructed from this persistent workspace.",
    }
    ws.record_decision(decision_id, directive.policy, asdict(directive))
    ws.save_controller_state(controller.state_dict())
    print(build_chat_prompt(goal, directive, pool_summary))


def cmd_ingest(args):
    ws = Workspace(args.workspace)
    goal = GoalContract.from_dict(ws.load_goal())
    candidate = load_candidate(args.file)
    decision = None
    expected_parents: list[str] = []
    decision_exploration = False
    if args.decision_id:
        decision = ws.find_decision(args.decision_id)
        candidate.metadata.setdefault("search_decision_id", args.decision_id)
        directive = decision.get("directive", {})
        expected_parents = list(directive.get("parent_candidate_ids", []))
        decision_exploration = directive.get("phase") == "EXPLORE"
    novelty = NoveltyArchive()
    for prior in ws.accepted_candidates():
        novelty.add(prior)
    prior = ws.accepted_candidates()
    known_theories = set(goal.pool_theories) | {
        str(c.new_perspective.get("theory")).strip() for c in prior
        if c.new_perspective and c.new_perspective.get("theory")
    }
    known_methods = set(goal.pool_methods) | {c.proof_method for c in prior}
    all_candidates = [Candidate.from_dict(r["candidate"]) for r in ws.load_candidate_records()]
    refuted_candidates = {c.candidate_id for c in all_candidates if c.status == "REFUTED"}
    gate = GoalMutationGate(goal, novelty, refuted_fingerprints=ws.refuted_fingerprints(),
                            known_theories=known_theories, known_methods=known_methods,
                            known_candidate_ids={c.candidate_id for c in prior},
                            known_refuted_candidate_ids=refuted_candidates,
                            known_candidates={c.candidate_id: c for c in all_candidates})
    # The stored BO decision is authoritative: users cannot accidentally bypass
    # the divergence gate by omitting --exploration on ingest.
    verdict = gate.validate(candidate, exploration=(args.exploration or decision_exploration),
                            parent_ids=expected_parents)
    ws.add_candidate(candidate, verdict.to_dict())
    if verdict.accepted:
        _insert_candidate_graph_node(ws, goal, candidate)
    print(json.dumps(verdict.to_dict(), ensure_ascii=False, indent=2))
    if not verdict.accepted:
        raise SystemExit(2)


def cmd_feedback(args):
    ws = Workspace(args.workspace)
    decision = ws.find_decision(args.decision_id)
    rows = ws.load_candidate_records()
    matching = [r for r in rows if r.get("candidate", {}).get("candidate_id") == args.candidate_id]
    if not matching:
        raise KeyError(f"unknown candidate_id: {args.candidate_id}")
    row = matching[-1]
    candidate = Candidate.from_dict(row["candidate"])
    gate = row.get("gate", {})
    attached_decision = candidate.metadata.get("search_decision_id")
    if attached_decision and attached_decision != decision["decision_id"]:
        raise ValueError("candidate is attached to a different search decision")
    status = candidate.status
    metrics = BudgetMetrics(
        verified_lemmas=1 if gate.get("accepted") and status == "KERNEL_CHECKED" else 0,
        valid_counterexamples=1 if gate.get("accepted") and status == "COUNTEREXAMPLE_FOUND" and candidate.relation == "counterexample" else 0,
        obligations_closed=args.obligations_closed,
        novelty_gain=1.0 if gate.get("accepted") else 0.0,
        duplicate_rate=1.0 if any("novelty" in x for x in gate.get("reasons", [])) else 0.0,
        rejected_mutations=0 if gate.get("accepted") else 1,
        scope_violations=1 if any("scope" in x or "goal_id" in x or "bridge" in x for x in gate.get("reasons", [])) else 0,
        evaluation_cost=args.evaluation_cost,
        empirical_improvement=args.empirical_improvement,
    )
    controller_state = ws.load_controller_state()
    controller = (BayesianBudgetController.from_state_dict(controller_state, seed=args.seed)
                  if controller_state else BayesianBudgetController(seed=args.seed))
    policy_data = dict(decision["policy"])
    policy_data.setdefault("tempered_mutation_probability", 0.10)
    policy = BudgetPolicy(**policy_data)
    utility = controller.observe(policy, metrics)
    ws.save_controller_state(controller.state_dict())
    graph_state = ws.load_search_graph_state()
    if graph_state:
        graph = MCTSSearchGraph.from_dict(graph_state)
        target_key = next((k for k, node in graph.nodes.items()
                           if node.payload.get("candidate_id") == args.candidate_id), None)
        root_key = next((k for k, node in graph.nodes.items()
                         if node.payload.get("kind") == "goal_root" and node.payload.get("goal_id") == candidate.goal_id), None)
        if target_key and root_key:
            path, edges = graph.path_to(root_key, target_key)
            graph.backpropagate(path, edges, utility)
            ws.save_search_graph_state(graph.to_dict())
    ws.record_feedback(decision["decision_id"], args.candidate_id, asdict(metrics))
    print(json.dumps({"decision_id": decision["decision_id"], "candidate_id": args.candidate_id,
                      "bo_observations": len(controller.policies), "observed_utility": utility,
                      "metrics": asdict(metrics), "policy": asdict(policy)}, indent=2))


def cmd_ablate(args):
    result = AblationRunner(args.budget, args.seeds).run()
    json_path, md_path = write_report(result, args.output)
    print(f"Wrote {json_path}\nWrote {md_path}")
    print(json.dumps(result["summary"], indent=2))


def cmd_ablate_continuous(args):
    result = ContinuousLangevinAblationRunner(
        budget=args.budget, seeds=args.seeds, step_size=args.step_size,
        temperature=args.temperature, fixed_probability=args.fixed_probability,
    ).run()
    json_path, md_path = write_continuous_report(result, args.output)
    print(f"Wrote {json_path}\nWrote {md_path}")
    print(json.dumps(result["summary"], indent=2))


def cmd_env(args):
    info = {"ctsh_version": __version__, "python": sys.version, "executables": {}}
    for name in ["lean", "lake", "elan", "wolframscript", "WolframKernel"]:
        info["executables"][name] = shutil.which(name)
    lean_backend = LeanBackend()
    try:
        installed_toolchain = lean_backend._resolve_toolchain()
    except RuntimeError as exc:
        installed_toolchain = None
        info.setdefault("probes", []).append({"backend": "lean", "status": "TOOLCHAIN_NOT_INSTALLED", "detail": str(exc)})
    if installed_toolchain and shutil.which("elan"):
        command = ["elan", "run", installed_toolchain, "lean", "--version"]
    elif shutil.which("lean") and not shutil.which("elan"):
        command = ["lean", "--version"]
    else:
        command = None
    if command:
        try:
            p = subprocess.run(command, capture_output=True, text=True, timeout=20)
            info.setdefault("probes", []).append({"backend": "lean", "toolchain": installed_toolchain,
                                                   "command": command, "returncode": p.returncode,
                                                   "stdout": p.stdout.strip(), "stderr": p.stderr.strip()})
        except Exception as exc:
            info.setdefault("probes", []).append({"backend": "lean", "command": command, "error": str(exc)})
    elif not installed_toolchain:
        info.setdefault("probes", []).append({"backend": "lean", "status": "NOT_RUN_NO_INSTALLED_TOOLCHAIN"})
    if shutil.which("wolframscript"):
        command = ["wolframscript", "-code", "Print[2+2]"]
        try:
            p = subprocess.run(command, capture_output=True, text=True, timeout=25)
            info.setdefault("probes", []).append({"backend": "wolfram", "command": command,
                                                   "returncode": p.returncode, "stdout": p.stdout.strip(),
                                                   "stderr": p.stderr.strip()})
        except Exception as exc:
            info.setdefault("probes", []).append({"backend": "wolfram", "command": command, "error": str(exc)})
    print(json.dumps(info, indent=2))


def _lean_backend(args):
    return LeanBackend(toolchain=args.toolchain, lake_project=args.lake_project, timeout=args.timeout)


def cmd_lean(args):
    source = Path(args.file).read_text(encoding="utf-8")
    result = _lean_backend(args).check_source(source, args.theorem, trusted_source=args.trusted_source)
    print(json.dumps(result.to_dict(), indent=2))
    if result.status not in {"KERNEL_CHECKED", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS"}:
        raise SystemExit(2)


def cmd_verify_lean(args):
    ws = Workspace(args.workspace)
    source = Path(args.file).read_text(encoding="utf-8")
    result = _lean_backend(args).check_source(source, args.theorem, trusted_source=args.trusted_source)
    records = ws.load_candidate_records()
    row = next((r for r in reversed(records) if r.get("candidate", {}).get("candidate_id") == args.candidate_id), None)
    if row is None:
        raise KeyError(f"unknown candidate_id: {args.candidate_id}")
    if not row.get("gate", {}).get("accepted"):
        raise ValueError("only a gate-accepted candidate can be promoted by verify-lean")
    if row.get("candidate", {}).get("status") in {"REFUTED", "COUNTEREXAMPLE_FOUND"}:
        raise ValueError("terminal refutation/counterexample records are immutable; create a new candidate ID for a repair")
    ws.record_candidate_evidence(args.candidate_id, result.to_dict())
    promoted = False
    if result.status in {"KERNEL_CHECKED", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS"} and args.statement_fidelity_reviewed:
        ws.update_candidate_status(args.candidate_id, result.status,
                                   evidence={**result.to_dict(), "statement_fidelity_reviewed": True})
        promoted = True
    output = result.to_dict()
    output["candidate_promotion"] = ("PROMOTED" if promoted else
                                     "NOT_PROMOTED: review natural-language/formal statement equivalence and rerun with --statement-fidelity-reviewed")
    print(json.dumps(output, indent=2))
    if result.status not in {"KERNEL_CHECKED", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS"}:
        raise SystemExit(2)


def cmd_mark_status(args):
    ws = Workspace(args.workspace)
    records = ws.load_candidate_records()
    row = next((r for r in reversed(records) if r.get("candidate", {}).get("candidate_id") == args.candidate_id), None)
    if row is None:
        raise KeyError(f"unknown candidate_id: {args.candidate_id}")
    if not row.get("gate", {}).get("accepted"):
        raise ValueError("only gate-accepted candidates can receive a research status update")
    candidate = Candidate.from_dict(row["candidate"])
    evidence = json.loads(Path(args.evidence_file).read_text(encoding="utf-8"))
    if args.status == "REFUTED":
        required = {"witness", "hypotheses_satisfied", "reproduction"}
        missing = required - set(evidence)
        if missing or evidence.get("hypotheses_satisfied") is not True or not str(evidence.get("reproduction", "")).strip():
            raise ValueError(f"REFUTED requires a concrete witness, hypotheses_satisfied=true and a reproduction record; missing/invalid {sorted(missing)}")
        if candidate.relation == "counterexample":
            raise ValueError("a counterexample artifact should be COUNTEREXAMPLE_FOUND, not REFUTED")
    if args.status == "COUNTEREXAMPLE_FOUND":
        required = {"witness", "hypotheses_satisfied", "reproduction"}
        missing = required - set(evidence)
        if (candidate.relation != "counterexample" or missing
                or evidence.get("hypotheses_satisfied") is not True
                or not str(evidence.get("reproduction", "")).strip()):
            raise ValueError("COUNTEREXAMPLE_FOUND requires a counterexample candidate, a concrete witness, satisfied locked hypotheses, and a reproduction record")
    if args.status in {"KERNEL_CHECKED", "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS"}:
        raise ValueError("kernel statuses can only be promoted by verify-lean")
    if args.status == "SYMBOLICALLY_CHECKED":
        raise ValueError("symbolic statuses can only be promoted by verify-wolfram")
    ws.update_candidate_status(args.candidate_id, args.status, evidence=evidence)
    print(json.dumps({"candidate_id": args.candidate_id, "status": args.status,
                      "evidence_recorded": True}, indent=2))


def cmd_wolfram(args):
    result = WolframBackend(timeout=args.timeout).verify_identity(
        args.lhs, args.rhs, args.variables.split(",") if args.variables else [], args.assumptions)
    print(json.dumps(result.to_dict(), indent=2))
    if result.status != "SYMBOLICALLY_CHECKED":
        raise SystemExit(2)




def cmd_verify_wolfram(args):
    ws = Workspace(args.workspace)
    result = WolframBackend(timeout=args.timeout).verify_identity(
        args.lhs, args.rhs, args.variables.split(",") if args.variables else [], args.assumptions)
    records = ws.load_candidate_records()
    row = next((r for r in reversed(records) if r.get("candidate", {}).get("candidate_id") == args.candidate_id), None)
    if row is None:
        raise KeyError(f"unknown candidate_id: {args.candidate_id}")
    if not row.get("gate", {}).get("accepted"):
        raise ValueError("only a gate-accepted candidate can receive symbolic backend evidence")
    if row.get("candidate", {}).get("status") in {"REFUTED", "COUNTEREXAMPLE_FOUND"}:
        raise ValueError("terminal refutation/counterexample records are immutable; create a new candidate ID for a repair")
    ws.record_candidate_evidence(args.candidate_id, result.to_dict())
    promoted = False
    if result.status == "SYMBOLICALLY_CHECKED" and args.statement_fidelity_reviewed:
        ws.update_candidate_status(args.candidate_id, "SYMBOLICALLY_CHECKED",
                                   evidence={**result.to_dict(), "statement_fidelity_reviewed": True})
        promoted = True
    output = result.to_dict()
    output["candidate_promotion"] = ("PROMOTED" if promoted else
        "NOT_PROMOTED: verify that the encoded expression, assumptions and domain faithfully represent the archived statement")
    print(json.dumps(output, indent=2))
    if result.status not in {"SYMBOLICALLY_CHECKED", "SYMBOLICALLY_REFUTED"}:
        raise SystemExit(2)


def cmd_wolfram_counterexample(args):
    result = WolframBackend(timeout=args.timeout).find_counterexample(
        args.lhs, args.rhs, args.variables.split(",") if args.variables else [], args.assumptions)
    print(json.dumps(result.to_dict(), indent=2))
    if result.status not in {"COUNTEREXAMPLE_REGION_FOUND", "NO_COUNTEREXAMPLE_FOUND_FOR_ENCODED_DOMAIN"}:
        raise SystemExit(2)


def build_parser():
    p = argparse.ArgumentParser(prog="ctsh", description="Chat-native Mathematical Theory Search Harness")
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="command", required=True)

    q = sub.add_parser("init", help="initialize a scoped research workspace")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--goal-id", default="GOAL-001")
    q.add_argument("--goal", required=True); q.add_argument("--mode", choices=["prove", "discover", "algorithm"], default="prove")
    q.add_argument("--domain", default="unspecified"); q.add_argument("--hypothesis", action="append")
    q.add_argument("--target-term", action="append"); q.add_argument("--required-obligation", action="append")
    q.add_argument("--forbidden-scope-tag", action="append"); q.add_argument("--pool-theory", action="append")
    q.add_argument("--pool-method", action="append"); q.add_argument("--allowed-auxiliary-assumption", action="append")
    q.add_argument("--max-new-assumptions", type=int, default=0)
    q.add_argument("--allow-target-reformulation", action="store_true")
    q.add_argument("--enable-langevin", action="store_true",
                   help="enable BO allocation to Langevin only when a differentiable continuous objective is supplied")
    q.add_argument("--seed", type=int, default=0)
    q.set_defaults(func=cmd_init)

    q = sub.add_parser("prompt", help="print a pool-aware chat proposal prompt and persist its decision")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--seed", type=int, default=0)
    q.add_argument("--pool-limit", type=int, default=12); q.set_defaults(func=cmd_prompt)

    q = sub.add_parser("ingest", help="validate and archive a structured chat proposal")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--file", required=True)
    q.add_argument("--exploration", action="store_true"); q.add_argument("--decision-id")
    q.set_defaults(func=cmd_ingest)

    q = sub.add_parser("feedback", help="feed observed outcomes back to the persistent BO and MCTS controllers")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--decision-id")
    q.add_argument("--candidate-id", required=True); q.add_argument("--obligations-closed", type=int, default=0)
    q.add_argument("--evaluation-cost", type=float, default=0.0)
    q.add_argument("--empirical-improvement", type=float, default=0.0); q.add_argument("--seed", type=int, default=0)
    q.set_defaults(func=cmd_feedback)

    q = sub.add_parser("ablate", help="run equal-budget optimizer-mechanics ablation")
    q.add_argument("--budget", type=int, default=180); q.add_argument("--seeds", type=int, default=12)
    q.add_argument("--output", default="./results/ablation.json"); q.set_defaults(func=cmd_ablate)

    q = sub.add_parser("ablate-continuous", help="ablate continuous ULA and BO-controlled Langevin probability")
    q.add_argument("--budget", type=int, default=180); q.add_argument("--seeds", type=int, default=40)
    q.add_argument("--step-size", type=float, default=0.12); q.add_argument("--temperature", type=float, default=0.45)
    q.add_argument("--fixed-probability", type=float, default=0.35)
    q.add_argument("--output", default="./results/continuous_langevin_ablation.json")
    q.set_defaults(func=cmd_ablate_continuous)

    q = sub.add_parser("check-env", help="probe Lean/Wolfram CLI availability"); q.set_defaults(func=cmd_env)

    q = sub.add_parser("lean-check", help="compile reviewed Lean source and audit theorem axioms")
    q.add_argument("--file", required=True); q.add_argument("--theorem", required=True); q.add_argument("--toolchain")
    q.add_argument("--lake-project"); q.add_argument("--timeout", type=float, default=45)
    q.add_argument("--trusted-source", action="store_true"); q.set_defaults(func=cmd_lean)

    q = sub.add_parser("verify-lean", help="run Lean verification and attach its evidence/status to a workspace candidate")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--candidate-id", required=True)
    q.add_argument("--file", required=True); q.add_argument("--theorem", required=True); q.add_argument("--toolchain")
    q.add_argument("--lake-project"); q.add_argument("--timeout", type=float, default=45)
    q.add_argument("--trusted-source", action="store_true")
    q.add_argument("--statement-fidelity-reviewed", action="store_true",
                   help="assert that the formal Lean statement matches the archived candidate statement and hypotheses")
    q.set_defaults(func=cmd_verify_lean)

    q = sub.add_parser("mark-status", help="record a human-reviewed counterexample/refutation status with evidence")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--candidate-id", required=True)
    q.add_argument("--status", required=True, choices=["CONJECTURAL", "DERIVED_IN_CHAT",
                                                        "COUNTEREXAMPLE_FOUND", "REFUTED", "CONDITIONAL", "ERROR", "BLOCKED"])
    q.add_argument("--evidence-file", required=True); q.set_defaults(func=cmd_mark_status)

    q = sub.add_parser("verify-wolfram", help="run Wolfram on an archived candidate and attach evidence/status")
    q.add_argument("--workspace", default="./ctsh-work"); q.add_argument("--candidate-id", required=True)
    q.add_argument("--lhs", required=True); q.add_argument("--rhs", required=True)
    q.add_argument("--variables", default=""); q.add_argument("--assumptions")
    q.add_argument("--timeout", type=float, default=60)
    q.add_argument("--statement-fidelity-reviewed", action="store_true",
                   help="assert that the encoded symbolic identity and assumptions faithfully represent the archived claim")
    q.set_defaults(func=cmd_verify_wolfram)

    q = sub.add_parser("wolfram-check", help="check a symbolic identity in a safe arithmetic expression grammar")
    q.add_argument("--lhs", required=True); q.add_argument("--rhs", required=True); q.add_argument("--variables", default="")
    q.add_argument("--assumptions"); q.add_argument("--timeout", type=float, default=60); q.set_defaults(func=cmd_wolfram)

    q = sub.add_parser("wolfram-counterexample", help="find the symbolic region where an identity fails")
    q.add_argument("--lhs", required=True); q.add_argument("--rhs", required=True); q.add_argument("--variables", default="")
    q.add_argument("--assumptions"); q.add_argument("--timeout", type=float, default=60); q.set_defaults(func=cmd_wolfram_counterexample)
    return p


def main():
    args = build_parser().parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        raise SystemExit(130)
    except Exception as exc:
        print(f"CTSH ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
