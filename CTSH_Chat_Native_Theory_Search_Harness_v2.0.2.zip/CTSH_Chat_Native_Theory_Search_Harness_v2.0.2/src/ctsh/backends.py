from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Sequence
import ast, os, re, shutil, subprocess, tempfile, time

@dataclass
class VerificationResult:
    backend: str
    status: str
    command: list[str]
    returncode: int | None
    stdout: str
    stderr: str
    elapsed_seconds: float
    theorem_name: str | None = None
    axioms: list[str] | None = None
    details: dict | None = None

    def to_dict(self): return asdict(self)

class LeanBackend:
    """Lean CLI adapter. Successful compile plus #print axioms is required.

    This executes local Lean source. Do not run source from an untrusted origin.
    In theorem workflows, prefer tightly reviewed theorem-only files and project
    sandboxes. A shell timeout is not a security sandbox.
    """
    SAFE_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
    DISALLOWED_SOURCE = re.compile(r"\b(sorry|admit)\b|#eval|run_tac|run_elab|initialize|implemented_by|\bunsafe\b", re.I)

    def __init__(self, lean: str = "lean", elan: str = "elan", toolchain: str | None = None,
                 lake_project: str | Path | None = None, timeout: float = 45.0,
                 allowed_axioms: set[str] | None = None, strict_source_scan: bool = True):
        self.lean, self.elan, self.toolchain = lean, elan, toolchain
        self.lake_project = Path(lake_project).resolve() if lake_project else None
        self.timeout = timeout
        self.allowed_axioms = set(self.SAFE_AXIOMS if allowed_axioms is None else allowed_axioms)
        self.strict_source_scan = strict_source_scan

    def _installed_toolchains(self) -> list[str]:
        if not shutil.which(self.elan):
            return []
        try:
            proc = subprocess.run([self.elan, "toolchain", "list"], capture_output=True,
                                  text=True, timeout=5, check=False)
        except (OSError, subprocess.TimeoutExpired):
            return []
        names = []
        for line in proc.stdout.splitlines():
            item = line.strip().split()
            if item and item[0].startswith(("leanprover/", "lean4:", "lean:")):
                names.append(item[0])
        return names

    @staticmethod
    def _version_key(name: str):
        import re
        match = re.search(r"v?(\d+(?:\.\d+){1,2})", name)
        return tuple(int(x) for x in match.group(1).split(".")) if match else (0,)

    def _resolve_toolchain(self) -> str | None:
        installed = self._installed_toolchains()
        if self.lake_project:
            pin = self.lake_project / "lean-toolchain"
            if pin.exists():
                required = pin.read_text(encoding="utf-8").strip()
                if self.toolchain and self.toolchain != required:
                    raise RuntimeError(f"requested toolchain {self.toolchain!r} conflicts with project pin {required!r}")
                if shutil.which(self.elan) and required not in installed:
                    raise RuntimeError(f"pinned Lean toolchain {required!r} is not installed; CTSH will not trigger an automatic elan download")
                return required
        if self.toolchain:
            if shutil.which(self.elan) and self.toolchain not in installed:
                raise RuntimeError(f"requested Lean toolchain {self.toolchain!r} is not installed; CTSH will not install toolchains automatically")
            return self.toolchain
        if installed:
            # Avoid invoking the Elan proxy's default shim when its selected
            # toolchain is absent, because that could trigger a network install.
            return max(installed, key=self._version_key)
        lean_path = shutil.which(self.lean)
        if shutil.which(self.elan) and lean_path and ".elan" in Path(lean_path).parts:
            raise RuntimeError("elan is present but no Lean toolchain is installed; CTSH will not trigger an automatic download")
        return None

    def _command(self, path: Path) -> list[str]:
        selected = self._resolve_toolchain()
        if self.lake_project:
            if selected and shutil.which(self.elan):
                return [self.elan, "run", selected, "lake", "env", "lean", str(path)]
            return ["lake", "env", "lean", str(path)]
        if selected and shutil.which(self.elan):
            return [self.elan, "run", selected, self.lean, str(path)]
        return [self.lean, str(path)]

    def check_source(self, source: str, theorem_name: str, *, trusted_source: bool = False) -> VerificationResult:
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_'.]*", theorem_name):
            raise ValueError("invalid Lean theorem identifier")
        if self.strict_source_scan and not trusted_source and self.DISALLOWED_SOURCE.search(source):
            return VerificationResult("lean", "REJECTED_SOURCE_POLICY", [], None, "",
                                      "source contains a forbidden placeholder or metaprogramming escape; review manually", 0.0,
                                      theorem_name, None, {"trusted_source_required": True})
        workdir = self.lake_project or Path(tempfile.gettempdir())
        workdir.mkdir(parents=True, exist_ok=True)
        fd, name = tempfile.mkstemp(prefix="ctsh_", suffix=".lean", dir=workdir)
        path = Path(name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(source.rstrip() + f"\n\n#print axioms {theorem_name}\n")
            try:
                cmd = self._command(path)
            except RuntimeError as exc:
                return VerificationResult("lean", "TOOLCHAIN_NOT_INSTALLED", [], None, "", str(exc),
                                          0.0, theorem_name)
            start = time.monotonic()
            try:
                proc = subprocess.run(cmd, cwd=workdir, capture_output=True, text=True,
                                      timeout=self.timeout, check=False)
                elapsed = time.monotonic() - start
            except FileNotFoundError as e:
                return VerificationResult("lean", "NOT_AVAILABLE", cmd, None, "", str(e),
                                          time.monotonic() - start, theorem_name)
            except subprocess.TimeoutExpired as e:
                return VerificationResult("lean", "TIMEOUT", cmd, None,
                                          e.stdout or "", e.stderr or "", time.monotonic() - start,
                                          theorem_name)
            output = proc.stdout + "\n" + proc.stderr
            if proc.returncode != 0:
                status = "KERNEL_REJECTED_OR_BUILD_FAILED"
                axioms = None
            elif "does not depend on any axioms" in output:
                status, axioms = "KERNEL_CHECKED", []
            else:
                match = re.search(r"depends on axioms:\s*\[([^\]]*)\]", output, re.I | re.S)
                if not match:
                    status, axioms = "AXIOM_AUDIT_UNPARSED", None
                else:
                    axioms = [x.strip() for x in match.group(1).split(",") if x.strip()]
                    bad = sorted(set(axioms) - self.allowed_axioms)
                    status = "KERNEL_CHECKED_WITH_ALLOWED_AXIOMS" if not bad else "AXIOM_POLICY_REJECTED"
            return VerificationResult("lean", status, cmd, proc.returncode, proc.stdout, proc.stderr,
                                      elapsed, theorem_name, axioms,
                                      {"allowed_axioms": sorted(self.allowed_axioms),
                                       "source_trusted_by_user": trusted_source,
                                       "note": "Kernel acceptance is relative to the exact formalized statement and its reported axiom dependencies."})
        finally:
            try: path.unlink(missing_ok=True)
            except OSError: pass

_ALLOWED_FUNCS = {"Abs": "Abs", "Sqrt": "Sqrt", "Exp": "Exp", "Log": "Log",
                  "Sin": "Sin", "Cos": "Cos", "Tan": "Tan", "Sinh": "Sinh", "Cosh": "Cosh"}

class _WLRenderer:
    VARIABLE_PATTERN = re.compile(r"[a-z][A-Za-z0-9]*\Z")

    def __init__(self, variables: Sequence[str]):
        if len(set(variables)) != len(list(variables)):
            raise ValueError("Wolfram variables must be unique")
        invalid = [name for name in variables if not self.VARIABLE_PATTERN.fullmatch(name)]
        if invalid:
            raise ValueError(f"invalid Wolfram variable names: {invalid}; use simple identifiers beginning with a lowercase letter")
        self.variables = set(variables)

    def render(self, expr: str) -> str:
        tree = ast.parse(expr, mode="eval")
        return self.visit(tree.body)
    def visit(self, node):
        if isinstance(node, ast.Constant) and isinstance(node.value, int) and not isinstance(node.value, bool):
            return str(node.value)
        if isinstance(node, ast.Constant) and isinstance(node.value, float):
            import math
            if not math.isfinite(node.value):
                raise ValueError("non-finite numeric literals are not allowed")
            return re.sub(r"[eE]([+-]?\d+)$", r"*^\1", repr(node.value))
        if isinstance(node, ast.Name):
            if node.id not in self.variables: raise ValueError(f"undeclared variable: {node.id}")
            return node.id
        if isinstance(node, ast.BinOp):
            a, b = self.visit(node.left), self.visit(node.right)
            ops = {ast.Add: " + ", ast.Sub: " - ", ast.Mult: " * ", ast.Div: " / ", ast.Pow: " ^ "}
            op = ops.get(type(node.op))
            if not op: raise ValueError("operator not in safe Wolfram expression grammar")
            return f"({a}{op}{b})"
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.USub, ast.UAdd)):
            return ("-" if isinstance(node.op, ast.USub) else "+") + f"({self.visit(node.operand)})"
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in _ALLOWED_FUNCS:
            if node.keywords: raise ValueError("keyword arguments are not allowed")
            return _ALLOWED_FUNCS[node.func.id] + "[" + ", ".join(self.visit(a) for a in node.args) + "]"
        raise ValueError(f"expression node not allowed: {type(node).__name__}")

class WolframBackend:
    """Safe arithmetic-expression adapter to local wolframscript.

    It compiles a deliberately small Python-expression AST into WL. No arbitrary
    user-supplied Wolfram source is evaluated by this API.
    """
    def __init__(self, executable: str = "wolframscript", timeout: float = 60.0):
        self.executable, self.timeout = executable, timeout

    def verify_identity(self, lhs: str, rhs: str, variables: Sequence[str],
                        assumptions: str | None = None) -> VerificationResult:
        renderer = _WLRenderer(variables)
        left, right = renderer.render(lhs), renderer.render(rhs)
        assumption = "True"
        if assumptions:
            assumption = renderer.render_boolean(assumptions) if hasattr(renderer, "render_boolean") else assumptions
        domain = "Element[{" + ",".join(variables) + "}, Reals]" if variables else "True"
        wl = f"""result = Quiet[Check[FullSimplify[({left}) == ({right}), Assumptions -> (({domain}) && ({assumption}))], $Failed]];
Print["CTSH_RESULT=" <> ToString[InputForm[result]]];
"""
        return self._run_wl(wl, "identity")

    def find_counterexample(self, lhs: str, rhs: str, variables: Sequence[str],
                            assumptions: str | None = None) -> VerificationResult:
        renderer = _WLRenderer(variables)
        left, right = renderer.render(lhs), renderer.render(rhs)
        domain = "Element[{" + ",".join(variables) + "}, Reals]" if variables else "True"
        assumption = assumptions or "True"
        # Assumptions are restricted to the same arithmetic grammar plus comparisons.
        assumption_wl = _render_wl_boolean(assumption, set(variables))
        wl = f"""result = Quiet[Check[Reduce[({domain}) && ({assumption_wl}) && (({left}) != ({right})), {{{','.join(variables)}}}, Reals], $Failed]];
Print["CTSH_RESULT=" <> ToString[InputForm[result]]];
"""
        return self._run_wl(wl, "counterexample")

    def _run_wl(self, source: str, purpose: str) -> VerificationResult:
        exe = shutil.which(self.executable)
        if not exe:
            return VerificationResult("wolfram", "NOT_AVAILABLE", [self.executable], None, "", "wolframscript not found", 0.0)
        with tempfile.TemporaryDirectory(prefix="ctsh_wl_") as td:
            path = Path(td) / "check.wls"
            path.write_text(source, encoding="utf-8")
            cmd = [exe, "-file", str(path)]
            start = time.monotonic()
            try:
                proc = subprocess.run(cmd, capture_output=True, text=True, timeout=self.timeout, check=False)
                elapsed = time.monotonic() - start
            except subprocess.TimeoutExpired as e:
                return VerificationResult("wolfram", "TIMEOUT", cmd, None, e.stdout or "", e.stderr or "",
                                          time.monotonic() - start, details={"purpose": purpose})
            except OSError as e:
                return VerificationResult("wolfram", "ERROR", cmd, None, "", str(e),
                                          time.monotonic() - start, details={"purpose": purpose})
            output = proc.stdout + "\n" + proc.stderr
            m = re.search(r"CTSH_RESULT=(.*)", output)
            value = m.group(1).strip() if m else None
            if proc.returncode != 0:
                status = "ERROR"
            elif value in {"$Failed", "Null", None}:
                status = "UNKNOWN_OR_UNSUPPORTED"
            elif purpose == "identity" and value == "True":
                status = "SYMBOLICALLY_CHECKED"
            elif purpose == "identity" and value == "False":
                status = "SYMBOLICALLY_REFUTED"
            elif purpose == "counterexample" and value == "False":
                # Reduce returned the empty set for the encoded violation region.
                status = "NO_COUNTEREXAMPLE_FOUND_FOR_ENCODED_DOMAIN"
            elif purpose == "counterexample":
                # A symbolic region is not yet a concrete witness, even if Reduce
                # has solved the quantified violation condition.
                status = "COUNTEREXAMPLE_REGION_FOUND"
            else:
                status = "UNKNOWN_OR_UNSUPPORTED"
            interpretation = {
                "NO_COUNTEREXAMPLE_FOUND_FOR_ENCODED_DOMAIN": "Reduce returned an empty set for the encoded violation condition",
                "COUNTEREXAMPLE_REGION_FOUND": "Reduce returned a nonempty symbolic region in which the identity fails",
                "SYMBOLICALLY_CHECKED": "FullSimplify reduced the encoded identity to True",
                "SYMBOLICALLY_REFUTED": "FullSimplify reduced the encoded identity to False",
            }.get(status, "symbolic backend did not produce a classified exact result")
            return VerificationResult("wolfram", status, cmd, proc.returncode, proc.stdout, proc.stderr,
                                      elapsed, details={"purpose": purpose, "wolfram_result": value,
                                                        "scope": "exact symbolic result for the encoded expression/domain/assumptions; natural-language statement fidelity must be reviewed",
                                                        "interpretation": interpretation})


def _render_wl_boolean(expr: str, variables: set[str]) -> str:
    tree = ast.parse(expr, mode="eval")
    def v(n):
        if isinstance(n, ast.Compare) and len(n.ops) == 1 and len(n.comparators) == 1:
            a, b = _WLRenderer(variables).visit(n.left), _WLRenderer(variables).visit(n.comparators[0])
            ops = {ast.Eq: " == ", ast.NotEq: " != ", ast.Lt: " < ", ast.LtE: " <= ", ast.Gt: " > ", ast.GtE: " >= "}
            op = ops.get(type(n.ops[0]));
            if op is None: raise ValueError("unsupported comparison")
            return f"({a}{op}{b})"
        if isinstance(n, ast.BoolOp):
            op = " && " if isinstance(n.op, ast.And) else " || " if isinstance(n.op, ast.Or) else None
            if op is None: raise ValueError("unsupported boolean operator")
            return "(" + op.join(v(x) for x in n.values) + ")"
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.Not): return "!" + v(n.operand)
        return _WLRenderer(variables).visit(n)
    return v(tree.body)

# Attach the restricted boolean renderer without exposing arbitrary WL evaluation.
_WLRenderer.render_boolean = lambda self, expr: _render_wl_boolean(expr, self.variables)
