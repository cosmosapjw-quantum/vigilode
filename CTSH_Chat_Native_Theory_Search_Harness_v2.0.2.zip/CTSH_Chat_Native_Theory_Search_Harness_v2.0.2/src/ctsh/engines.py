from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
from .bo import BayesianBudgetController, BudgetPolicy
from .graph import MCTSSearchGraph

@dataclass
class SearchDirective:
    phase: str
    proposal_engine: str
    apply_langevin: bool
    apply_discrete_tempering: bool
    parent_candidate_ids: list[str]
    selected_state_key: str | None
    policy: dict[str, float]
    required_hooks: list[str]

class SearchCoordinator:
    """Coordinates engines; the chat model supplies semantic candidate proposals."""
    def __init__(self, controller: BayesianBudgetController, search_graph: MCTSSearchGraph,
                 seed: int = 0):
        self.controller, self.search_graph = controller, search_graph
        self.rng = np.random.default_rng(seed)

    def next_directive(self, root_state_key: str, known_candidate_ids: list[str],
                       policy: BudgetPolicy | None = None) -> SearchDirective:
        choice = self.controller.choose(self.rng, policy)
        path, _ = self.search_graph.select_path(root_state_key)
        state = self.search_graph.nodes[path[-1]]
        # MCTS expands from the selected leaf on the transposition graph.
        # GA recombines two distinct pool members where possible. Parent IDs are
        # explicit lineage, never inferred from whichever candidates were ingested last.
        path_candidate_ids = [self.search_graph.nodes[k].payload.get("candidate_id")
                              for k in path if self.search_graph.nodes[k].payload.get("candidate_id")]
        path_candidate_ids = [cid for cid in path_candidate_ids if cid in set(known_candidate_ids)]
        if choice["proposal_engine"] == "MCTS":
            parents = path_candidate_ids[-1:] or known_candidate_ids[-1:]
        else:
            count = min(2, len(known_candidate_ids))
            parents = (self.rng.choice(known_candidate_ids, size=count, replace=False).tolist()
                       if count else [])
        hooks = ["GOAL_LOCK", "HYPOTHESIS_PRESERVATION", "MUTATION_SCHEMA", "NONTRIVIALITY_AUDIT"]
        if choice["phase"] == "EXPLORE":
            hooks += ["OFF_POOL_THEORY_LENS", "PROOF_METHOD_DIVERSITY", "NOVELTY_ARCHIVE", "BRIDGE_BACK_TO_GOAL"]
        else:
            hooks += ["PROOF_REPAIR", "LEMMA_REUSE", "LOCAL_OBLIGATION_CLOSURE"]
        if choice["apply_langevin"]: hooks.append("CONTINUOUS_PARAMETER_LANGEVIN")
        if choice["apply_discrete_tempering"]: hooks.append("DISCRETE_TEMPERED_MUTATION")
        return SearchDirective(choice["phase"], choice["proposal_engine"], choice["apply_langevin"],
                               choice["apply_discrete_tempering"],
                               parents, path[-1], choice["policy"], hooks)

    def record_search_outcome(self, path: list[str], edge_path: list[tuple[str, str]], reward: float) -> None:
        self.search_graph.backpropagate(path, edge_path, reward)
